# 📖 Quran Shazam — Production Web Service

Identify Quranic recitation from any audio or video. Upload a file or record
live — a Quran-specialized AI transcribes the Arabic recitation and a
text-evidence engine verifies it against the complete Quran, ayah by ayah,
with honest confidence labels.

This is the production evolution of the `Quran_Shazam_Python_v1` demo:
hardened backend, professional web UI, security model, deployment materials,
tests, and documentation.

---

## ✨ Features

| Area | What you get |
|---|---|
| 🎙️ Verification | Mic recording + file upload (MP3/WAV/M4A/MP4/WebM/…), Quran-specialized Arabic ASR, ayah-level matching |
| 🏷️ Honest labels | `VERIFIED TEXT MATCH` · `GOOD / POSSIBLE MATCH` · `LOW CONFIDENCE` · `SEQUENCE RECOVERY` (incomplete evidence, always disclosed) |
| 📜 Canonical corpus | Pinned, checksummed Quran text; startup validation of 6,236 ayat / 114 surahs — verification is **blocked**, never faked, when unhealthy |
| 🌍 Translations | English + Urdu attached to every identified ayah |
| 🔒 Security | Rate limiting, optional API key, upload allow-lists + magic-byte sniffing, security headers, no stack-trace leaks, request ids |
| 🚀 Deploy-ready | Dockerfile, docker-compose + nginx TLS stack, systemd unit, `.env.example`, preflight checks, start scripts |
| ⚡ Fast engine | **faster-whisper** (CTranslate2 int8 on CPU): ~25× realtime transcription, VAD silence-skip, live SSE progress, queue position + ETA + cancel, transcript download (TXT/SRT/VTT/JSON) |

---

## 🚀 Quickstart

**Requirements:** Python 3.11+, FFmpeg on PATH, ~4 GB free disk (model + corpus download on first run).

```bash
# 1. Clone / copy this project, then:
cp .env.example .env          # adjust if needed

# 2. Start (Linux/macOS) — creates venv, installs deps, runs preflight checks:
./scripts/start.sh

#    Windows:
#    scripts\start.bat

# 3. Open http://127.0.0.1:8000
```

First verification downloads the ASR model (~150 MB) and the Quran corpus
(~a few MB, cached in `backend/data/`). Subsequent runs are instant.

### Docker (recommended for production)

```bash
docker build -f deploy/Dockerfile -t quran-shazam:latest .
docker run --rm -p 8000:8000 --env-file .env quran-shazam:latest
```

### Full production stack (app + nginx TLS)

```bash
# 1. Set ENV=production, TRUSTED_HOSTS, API_KEY in .env
# 2. Place TLS certs at deploy/certs/fullchain.pem + privkey.pem
# 3. Update server_name in deploy/nginx.conf
docker compose -f deploy/docker-compose.yml up -d --build
```

---

## ⚙️ Configuration

All settings come from the environment (see `.env.example`) and are
**validated at startup** — an invalid value aborts boot loudly.

| Variable | Default | Purpose |
|---|---|---|
| `ENV` | `development` | `production` disables `/docs` and enables HSTS |
| `MAX_UPLOAD_MB` | `200` | Upload size cap |
| `MAX_AUDIO_SECONDS` | `1800` | Max media duration (30 min) |
| `RATE_LIMIT_VERIFY` | `20/minute` | Per-IP limit on `/api/verify` |
| `API_KEY` | _(empty)_ | When set, API routes require `X-API-Key` header |
| `TRUSTED_HOSTS` | `*` | Set to your domain(s) in production |
| `PROXY_HEADERS` | `0` | Set `1` behind nginx / TLS terminator |
| `CORS_ORIGINS` | _(empty)_ | Browsers origins allowed; empty = same-origin only |

**Transcription engine (faster-whisper):**

| Variable | Default | Purpose |
|---|---|---|
| `ASR_MODEL` | `tarteel-ai/whisper-tiny-ar-quran` | HF model id (auto-converted to CTranslate2 once, then cached) **or** a stock size: `tiny`/`base`/`small`/`medium`/`large-v3` |
| `ASR_CT2_DIR` | _(empty)_ | Pre-converted model directory (overrides `ASR_MODEL`) |
| `ASR_COMPUTE_TYPE` | `auto` | `auto` → int8 on CPU, float16 on GPU |
| `ASR_BEAM_SIZE` | `1` | 1 = greedy/fastest … 5 = slower, slightly more accurate |
| `ASR_VAD` | `1` | Skip silence with Silero VAD |
| `ASR_LANGUAGE` | `ar` | `ar` for Quran recitation; `auto`/`ur`/`hi`/`en` also supported |
| `ASR_CHUNK_SECONDS` | `60` | Chunk size for progress reporting + bounded RAM |
| `JOB_WORKERS` | `1` | Parallel transcription workers (raise on bigger machines) |

Corpus/model pins (`QURAN_CORPUS_URL`, `ASR_MODEL`, `ASR_REVISION`) and
verification thresholds (`VERIFIED_SCORE`, …) are also configurable.

---

## 🔌 API reference

```
GET  /api/health        → { ready, warming_up?, corpus{checks…}, asr_model, asr_loaded, error }
GET  /api/diagnostics   → detailed corpus validation report (API key if set)
POST /api/verify        → multipart/form-data { file } → 202 { job_id, status }
GET  /api/jobs/{job_id} → { status, stage, progress, result?, error? }
```

Verification is **asynchronous** (v2.1+): a full check takes minutes, so
`POST /api/verify` validates the upload and immediately returns
`202 {"job_id": "…", "status": "queued"}`. A background worker processes jobs
one at a time; poll `GET /api/jobs/{job_id}` every ~2–3 s for live
`stage`/`progress` until `status` becomes `"done"` (with `result` below) or
`"error"` (with a human-readable `error`). Polls are cheap — if one fails on
a flaky network, just retry; the job keeps running server-side.

`result` (inside a done job):

```json
{
  "request_id": "a1b2c3d4e5f6",
  "duration": 42.5,
  "transcript": "…arabic text…",
  "recognized_words": 38,
  "results": [
    {
      "surah": 112, "ayah": 1, "key": "112:1",
      "text": "…", "translation_en": "…", "translation_ur": "…",
      "confidence": 96.4, "coverage": 100.0, "missing": 0.0, "sequence": 100.0,
      "label": "VERIFIED TEXT MATCH", "reason": ""
    }
  ],
  "verified_count": 1, "coverage": 92.0,
  "device": "cpu", "realtime": 3.2, "processing_seconds": 13.4
}
```

Error codes: `400` bad request · `401` bad API key · `413` too large ·
`415` unsupported media · `422` undecodable/empty audio · `429` rate limited ·
`503` corpus not ready.

---

## 🗂️ Project structure

```
quran-shazam/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI app: routes, middleware, error handling
│   │   ├── security.py        # headers, rate limiting, API key, upload checks
│   │   ├── engine/            # AI verification engine (from the v1 demo)
│   │   │   ├── config.py      # validated settings
│   │   │   ├── service.py     # media → ASR → matching orchestration
│   │   │   ├── corpus.py      # canonical Quran corpus + validation
│   │   │   ├── asr.py         # Quran-specialized Whisper transcription
│   │   │   ├── matcher.py     # text-evidence alignment + sequence recovery
│   │   │   ├── media.py       # FFmpeg decoding to 16kHz mono
│   │   │   └── normalization.py
│   │   ├── static/css|js/     # theme + verification page logic
│   │   └── templates/         # landing, verify, about, security pages
│   └── data/                  # runtime cache (corpus, never committed)
├── deploy/
│   ├── Dockerfile
│   ├── docker-compose.yml     # app + nginx
│   ├── nginx.conf             # TLS, rate limits, upload caps
│   └── systemd/               # bare-metal service unit
├── scripts/                   # preflight.py, start.sh, start.bat
├── tests/                     # engine unit tests + API security tests
├── .env.example  README.md  SECURITY.md  requirements.txt
```

---

## 🧪 Development & testing

```bash
pip install -r requirements.txt -r requirements-dev.txt
pytest -q                        # engine unit tests (no model/FFmpeg needed)
pytest -q tests/test_api_security.py   # upload validation + header tests
python scripts/preflight.py      # environment readiness
```

## 🔒 Security

Read **[SECURITY.md](SECURITY.md)** before exposing this publicly — it covers
the threat model, the responsible-disclosure policy, and the production
checklist (TLS, `ENV=production`, `API_KEY`, `TRUSTED_HOSTS`, …).
A human-readable summary is also served at `/security`.

## ⚠️ Important note

This engine is **text-evidence based**. A `VERIFIED TEXT MATCH` means the
transcribed words match the canonical Quran text with high confidence. It
does **not** claim acoustic proof of tajweed, makharij, or voice correctness,
and it is not a religious ruling on anyone's recitation.

## 📄 License

Add your license here (e.g. MIT). The Quran text is served from the
[quran-json](https://github.com/risan/quran-json) dataset; translations via
the same pinned release.
