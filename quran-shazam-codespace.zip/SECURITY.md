# Security Policy — Quran Shazam

## Supported versions

| Version | Supported          |
| ------- | ------------------ |
| 2.x     | ✅ actively maintained |
| 1.x (demo) | ❌ demo only, do not expose publicly |

## Reporting a vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Instead, email the maintainer privately with:
1. A description of the vulnerability and its potential impact.
2. Steps to reproduce (proof-of-concept welcome).
3. Your contact details for follow-up.

We aim to acknowledge reports within **72 hours** and to ship a fix or
mitigation within **30 days** for high-severity issues. Please allow us that
window before any public disclosure.

## Security architecture (summary)

- **Fail-closed verification**: the engine refuses to run unless the canonical
  Quran corpus (6,236 ayat / 114 surahs, checksummed) validates on startup.
- **Upload pipeline**: extension allow-list → magic-byte sniffing → streaming
  byte cap → UUID temp names → FFmpeg as authoritative decoder → guaranteed
  cleanup. Uploads are never persisted.
- **Abuse controls**: per-IP rate limiting on `/api/verify`, optional
  `X-API-Key` gate (`API_KEY` env), request timeouts, duration caps.
- **Transport**: TLS termination at nginx (see `deploy/nginx.conf`); HSTS
  enabled in production; `PROXY_HEADERS=1` only behind a trusted proxy.
- **Headers**: CSP, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy`, `Permissions-Policy` on every response.
- **Error handling**: clients never receive stack traces, file paths, or model
  internals. Each request carries an `X-Request-Id` for support correlation.
- **Configuration**: every env var is validated at startup; invalid values
  abort boot instead of silently misbehaving.
- **Dependencies**: pin major versions in `requirements.txt`; run
  `pip audit` (or Dependabot) on a schedule.

## Operational checklist for public deployment

- [ ] Set `ENV=production` (disables `/docs`, enables HSTS).
- [ ] Set a strong `API_KEY` if the API is reachable beyond your users' browsers.
- [ ] Set `TRUSTED_HOSTS` to your domain(s).
- [ ] Terminate TLS at nginx with valid certificates; redirect HTTP → HTTPS.
- [ ] Run behind the provided `nginx.conf` rate limits.
- [ ] Keep FFmpeg, Python and pip packages patched.
- [ ] Back up nothing user-related (nothing is stored) — but do persist the
      `data/` volume so the corpus/model aren't re-downloaded on restart.
- [ ] Review logs for `unhandled_error` and repeated `429`/`422` patterns.

## Known non-goals

- The engine verifies **textual evidence** only; it makes no claim about
  tajweed, makharij, or the religious validity of a recitation.
- Client-side (browser) code is inherently observable; all security-critical
  checks are enforced server-side and re-validated there.
