/* ========================================================================
   Word Translator — EN<->UR with Quranic context (Issue 5 + 6).
   ========================================================================
   Extracted verbatim from voice_qa.js on 2026-11-04 when the Voice Q&A
   ("Ask about the Quran") feature was removed: the Q&A code is gone, but
   the translator must keep working exactly as before. It depends on the
   $ and esc helpers and on copyText, all carried over below (copyText is
   generic clipboard code, not Q&A logic). It calls /api/quran/translate
   and, for ayah examples, window.qsOpenSurah from quran.js.
   ======================================================================== */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function copyText(t, btn) {
    const done = () => {
      const old = btn.textContent;
      btn.textContent = '✓ Copied';
      setTimeout(() => { btn.textContent = old; }, 1500);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(done).catch(done);
    } else {
      const ta = document.createElement('textarea');
      ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove(); done();
    }
  }

  /* ---------------- word translator (Issue 5 + 6) ---------------- */
  let trDir = 'en2ur';
  const trInput = $('tr-input'), trGo = $('tr-go'),
        trStatus = $('tr-status'), trResult = $('tr-result'),
        trVoiceBtn = $('tr-voice-btn');

  if (!trInput) return; // not on the Quran page — nothing to wire up
  document.querySelectorAll('.tr-dir-btn').forEach(b =>
    b.addEventListener('click', () => {
      document.querySelectorAll('.tr-dir-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      trDir = b.dataset.dir;
      trInput.placeholder = trDir === 'en2ur' ? 'e.g. mercy …' : '… مثلاً صبر';
      trInput.dir = trDir === 'en2ur' ? 'ltr' : 'rtl';
    }));
  async function doTranslate(q) {
    q = (q || '').trim();
    if (q.length < 2) { trStatus.textContent = 'Please type a word first.'; return; }
    trStatus.textContent = 'Translating…';
    trResult.hidden = true;
    try {
      const r = await fetch('/api/quran/translate?q=' + encodeURIComponent(q)
        + '&direction=' + trDir);
      if (!r.ok) throw new Error('bad response');
      const d = await r.json();
      trStatus.textContent = '';
      const isUr = trDir === 'ur2en';
      let h = '<div class="tr-cands">';
      if (d.candidates && d.candidates.length) {
        h += '<p class="tr-note muted small">' + esc(d.note || '') + ':</p>';
        h += d.candidates.map(c =>
          '<span class="tr-cand" dir="' + (isUr ? 'ltr' : 'rtl') + '">' + esc(c.text)
          + ' <button class="tr-copy" data-copy="' + esc(c.text) + '" title="Copy" aria-label="Copy / نقل کریں">📋</button></span>'
        ).join('');
      } else {
        h += '<p class="muted">No translation found for "' + esc(q) + '".</p>';
      }
      h += '</div>';
      if (d.examples && d.examples.length) {
        h += '<p class="tr-ayat-head">📖 <strong>' + d.examples.length
          + '</strong> ayat use this word:</p><div class="tr-ayats">';
        h += d.examples.map(x =>
          /* TEAM 4 (2026-10-22, RTL audit): target_text is the TARGET-language
             snippet — Urdu for en2ur, English for ur2en — so it needs the SAME
             dir polarity as the candidate chips above (isUr ? 'ltr' : 'rtl').
             The old code had it BACKWARDS ('rtl' : 'ltr'), which put Urdu
             snippets in an LTR paragraph and English snippets in an RTL one:
             on phones the wrapped lines scattered and the 3:120-style ref
             detached from its text. <bdi> isolates the ref; .tr-ayah-text lets
             CSS give the snippet its own block + alignment on small screens. */
          '<button class="search-hit" data-s="' + x.surah + '" data-a="' + x.ayah + '">'
          + '<bdi><strong>' + x.surah + ':' + x.ayah + '</strong></bdi> '
          + '<span class="tr-ayah-text" dir="' + (isUr ? 'ltr' : 'rtl') + '">' + esc(x.target_text.slice(0, 110)) + '…</span>'
          + '</button>').join('');
        h += '</div>';
      }
      trResult.innerHTML = h;
      trResult.hidden = false;
      trResult.querySelectorAll('[data-copy]').forEach(b =>
        b.addEventListener('click', ev => { ev.stopPropagation(); copyText(b.dataset.copy, b); }));
      trResult.querySelectorAll('.search-hit').forEach(b =>
        b.addEventListener('click', async () => {
          const s = +b.dataset.s;
          if (typeof window.qsOpenSurah === 'function') await window.qsOpenSurah(s);
          setTimeout(() => {
            const el = document.getElementById('ayah-' + b.dataset.a);
            if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('highlight'); }
          }, 300);
        }));
    } catch (e) {
      trStatus.textContent = 'Translation failed — check connection.';
    }
  }
  if (trGo) trGo.addEventListener('click', () => doTranslate(trInput.value));
  if (trInput) trInput.addEventListener('keydown', e => { if (e.key === 'Enter') doTranslate(trInput.value); });
  // Voice input for translator (reuses Web Speech API pattern)
  if (trVoiceBtn) trVoiceBtn.addEventListener('click', () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { trStatus.textContent = 'Voice not supported in this browser.'; return; }
    const rec = new SR();
    rec.lang = trDir === 'en2ur' ? 'en-US' : 'ur-PK';
    trStatus.textContent = 'Listening… speak the word.';
    rec.onresult = ev => {
      const t = ev.results[0][0].transcript.trim();
      trInput.value = t;
      trStatus.textContent = '';
      doTranslate(t);
    };
    rec.onerror = () => { trStatus.textContent = 'Could not hear — try typing.'; };
    rec.onend = () => { if (!trInput.value) trStatus.textContent = ''; };
    try { rec.start(); } catch (e) { trStatus.textContent = 'Mic unavailable.'; }
  });
})();
