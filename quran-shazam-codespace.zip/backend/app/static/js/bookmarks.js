/* Bookmarks + Reading Progress — localStorage based. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /* ---------- bookmarks ---------- */
  function getBookmarks() {
    try { return JSON.parse(localStorage.getItem('qs-bookmarks') || '[]'); }
    catch (e) { return []; }
  }
  function renderBookmarks() {
    const grid = $('bookmark-grid');
    if (!grid) return;
    const list = getBookmarks();
    if (!list.length) {
      grid.innerHTML = '<p class="muted">No bookmarks yet. Tap 🔖 on any ayah.</p>';
      return;
    }
    grid.innerHTML = list.map(k => {
      const [s, a] = k.split(':');
      return '<div class="bookmark-card" data-goto="' + esc(k) + '">'
        + '<strong>' + esc(s) + ':' + esc(a) + '</strong><br>'
        + '<span class="hint">Tap to open</span></div>';
    }).join('');
    grid.querySelectorAll('[data-goto]').forEach(c =>
      c.addEventListener('click', () => {
        const [s] = c.dataset.goto.split(':');
        if (typeof window.qsOpenSurah === 'function') window.qsOpenSurah(+s);
        const reader = $('reader');
        if (reader) { reader.hidden = false; reader.scrollIntoView({ behavior: 'smooth' }); }
      }));
  }

  /* ---------- reading progress ---------- */
  function getRead() {
    try { return JSON.parse(localStorage.getItem('qs-read-surahs') || '[]'); }
    catch (e) { return []; }
  }
  function markRead(n) {
    let list = getRead();
    if (!list.includes(n)) {
      list.push(n);
      try { localStorage.setItem('qs-read-surahs', JSON.stringify(list)); } catch (e) {}
    }
    renderProgress();
  }
  function renderProgress() {
    const list = getRead();
    const pct = Math.round(list.length / 114 * 100);
    const t = $('progress-text'), f = $('progress-fill');
    if (t) t.textContent = list.length + ' of 114 surahs read (' + pct + '%)';
    if (f) f.style.width = pct + '%';
  }

  // Hook into surah opening: listen for qs-open-surah
  window.addEventListener('qs-open-surah', e => markRead(e.detail));
  /* TEAM 3 (2026-10-22): signature-guarded refresh. The signature is the
     bookmark list itself — if it didn't change, hands off: the rich cards
     (if any) stay exactly as quran.js painted them. */
  let lastBookmarkSig = '';
  function refreshBookmarksIfChanged() {
    const sig = getBookmarks().join('|');
    if (sig === lastBookmarkSig) return; // nothing changed — don't touch the grid
    lastBookmarkSig = sig;
    if (typeof window.qsRenderBookmarksRich === 'function') window.qsRenderBookmarksRich();
    else renderBookmarks();
  }
  // Also wrap the global opener if present
  document.addEventListener('DOMContentLoaded', () => {
    renderBookmarks();
    lastBookmarkSig = getBookmarks().join('|');
    renderProgress();
    // TEAM 3 (2026-10-22): the old code re-ran renderBookmarks() BLINDLY
    // every 3 s. On the reader page #bookmark-grid is owned by quran.js's
    // paintBookmarks() (rich cards: Arabic preview + Remove button) — the
    // blind re-render kept overwriting those rich cards with the plain list
    // seconds after they appeared, and churned the DOM on every tick.
    // FYP STUDY GUIDE: re-render ONLY when the bookmark LIST actually
    // changed (cross-tab edits, detected via signature + storage event),
    // and delegate to the rich renderer when it exists.
    setInterval(refreshBookmarksIfChanged, 3000);
  });
  window.addEventListener('storage', refreshBookmarksIfChanged);
  // Expose for manual refresh
  window.qsRenderBookmarks = renderBookmarks;
})();
