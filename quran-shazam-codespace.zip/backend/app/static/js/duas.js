/* ========================================================================
   Duas — per-dua listen (ar-SA TTS) + copy-Arabic.
   ========================================================================
   C-12 (2026-10-22): the Duas page was a static list. Each dua card now
   gets two actions, reusing the Voice Q&A speech patterns (same browser
   APIs, same voice-picking and copy fallbacks):
     🔊 Suno / Listen — speaks the Arabic via speechSynthesis (ar-SA)
     📋 Copy Arabic   — copies the Arabic to the clipboard

   FYP STUDY GUIDE: Web Speech API (output)
     - window.speechSynthesis.speak(new SpeechSynthesisUtterance(text))
     - cancel() first so tapping a second dua never overlaps the first
     - u.lang='ar-SA' + prefer a voice whose lang starts with 'ar'
       (getVoices() loads async in Chrome → cached + refreshed)
     - onend/onerror always reset the button back to 🔊
   FYP STUDY GUIDE: clipboard
     - navigator.clipboard.writeText when available; textarea+execCommand
       fallback for older mobile browsers; "✓ Copied" feedback on the button.
   The Arabic is read from the card's own .arabic div textContent — never
   from a data attribute, so no attribute-escaping of Arabic is needed.
   ======================================================================== */
(function () {
  'use strict';
  const cards = document.querySelectorAll('.dua-card');
  if (!cards.length) return; // not on the duas page

  /* ---------------- voice cache (async voices load) ---------------- */
  const canSpeak = 'speechSynthesis' in window;
  let arVoices = [];
  function refreshVoices() {
    try { arVoices = canSpeak ? window.speechSynthesis.getVoices() : []; }
    catch (e) { arVoices = []; }
  }
  refreshVoices();
  try {
    if (canSpeak && typeof window.speechSynthesis.addEventListener === 'function')
      window.speechSynthesis.addEventListener('voiceschanged', refreshVoices);
    else if (canSpeak)
      window.speechSynthesis.onvoiceschanged = refreshVoices;
  } catch (e) {}
  function pickArVoice() {
    const norm = v => (v && v.lang ? String(v.lang).toLowerCase() : '');
    return arVoices.find(v => norm(v).startsWith('ar-sa'))
        || arVoices.find(v => norm(v).startsWith('ar')) || null;
  }

  /* ---------------- speak / stop (one dua at a time) ---------------- */
  let activeBtn = null; // the 🔊 button whose dua is currently playing
  /* TEAM 2 (2026-10-22): generation token for dua speech state.
     FYP STUDY GUIDE: tapping dua B while dua A plays calls cancel(), which
     fires an async 'error' event on A's utterance. A's chunk counter (done())
     then ran AFTER B had claimed the button — resetting B's button to
     "🔊 Suno / Listen" mid-play, so the toggle state lied (a mid-play tap
     restarted the dua instead of stopping it). Every new speak bumps the
     token; stale callbacks ignore themselves. */
  let duaGen = 0;
  function stopDuaSpeech() {
    duaGen++; // invalidate any chunk callbacks still queued from killed speech
    try { if (canSpeak) window.speechSynthesis.cancel(); } catch (e) {}
    // TEAM 2 (2026-10-22): also kill the qari <audio> — Stop must silence
    // tilawat too, and stale audio callbacks from the killed dua ignore
    // themselves via the duaGen check in playQariForDua().
    if (duaAudio) { try { duaAudio.pause(); } catch (e) {} duaAudio = null; }
    if (activeBtn) {
      activeBtn.classList.remove('speaking');
      activeBtn.innerHTML = '🔊 Suno / Listen';
      activeBtn = null;
    }
  }
  function speakDua(text, btn) {
    // NOTE (TEAM 2): the tap-again-to-stop toggle moved to the card click
    // handler below, so it covers qari audio too. This function is now only
    // the Arabic AI-TTS path — used for duas WITHOUT a Quran reference.
    if (!canSpeak) return;
    stopDuaSpeech();
    const ss = window.speechSynthesis;
    const chunks = [];
    const CHUNK = 400;
    let rest = String(text || '').trim();
    while (rest.length > CHUNK) {
      let cut = rest.lastIndexOf('۔', CHUNK);
      if (cut < CHUNK * 0.4) cut = rest.lastIndexOf(' ', CHUNK);
      if (cut < 1) cut = CHUNK;
      chunks.push(rest.slice(0, cut + 1).trim());
      rest = rest.slice(cut + 1).trim();
    }
    if (rest) chunks.push(rest);
    if (!chunks.length) return;
    const voice = pickArVoice();
    let ended = 0;
    // TEAM 2: stopDuaSpeech() above already claimed a fresh generation —
    // chunk callbacks from the cancelled dua must not touch this one.
    const myGen = duaGen;
    const done = () => {
      if (myGen !== duaGen) return;
      if (++ended >= chunks.length) stopDuaSpeech();
    };
    activeBtn = btn;
    btn.classList.add('speaking');
    btn.innerHTML = '⏹️ Rok do / Stop';
    chunks.forEach(c => {
      const u = new SpeechSynthesisUtterance(c);
      u.lang = 'ar-SA';
      if (voice) u.voice = voice;
      u.rate = 0.95;
      u.onend = done; u.onerror = done;
      ss.speak(u);
    });
  }

  /* ---------------- TEAM 2 (2026-10-22): qari-audio routing ----------------
     NEW RULE (user's order): an AYAH is never read by the AI voice. The 🔊
     button plays the QARI's everyayah recitation whenever the dua's
     reference is a Quran citation — "Quran 2:201", "Quran 14:41 (dua of
     Ibrahim AS)", "Quran 20:25-26" (a range plays each ayah in order).

     DECISION (documented per the task): duas WITHOUT a Quran reference
     (e.g. "Sahih al-Bukhari 6405", "Sunan Ibn Majah 925") KEEP Arabic
     AI-TTS. No qari recording exists for non-Quranic dua text, so the AI
     voice is the only way to hear them at all. The rule "AI voice only for
     EN/UR" means: never let the robot REPLACE the Qari on Quranic Arabic —
     it does not mean silencing duas that have no recitation.

     FYP STUDY GUIDE — URL scheme: identical to quran.js audioUrl() —
     https://everyayah.com/data/{QARI}/{SSAAA}.mp3, where SSAAA = 3-digit
     surah + 3-digit ayah (2:201 → "002201" via padStart(3,'0')). The Qari
     folder comes from the SAME localStorage 'qs-qari' key the reader uses
     (default 'Alafasy_128kbps') — no second URL scheme was invented.
     Playback tries our /api/audio proxy FIRST, then direct everyayah.com —
     the same primary→fallback rule quran.js's playWithFallback uses.
     ------------------------------------------------------------------------ */
  let duaAudio = null; // <audio> element of the dua's qari tilawat (if any)
  const DUA_STALL_MS = 20000; // per-URL give-up on hung mobile connections
  function duaCurrentQariId() {
    try { return localStorage.getItem('qs-qari') || 'Alafasy_128kbps'; }
    catch (e) { return 'Alafasy_128kbps'; }
  }
  function duaQariUrls(surah, ayah) {
    const s = String(surah).padStart(3, '0'), a = String(ayah).padStart(3, '0');
    const q = duaCurrentQariId();
    return {
      primary: '/api/audio/' + (+surah) + '/' + (+ayah) + '?qari=' + encodeURIComponent(q),
      fallback: 'https://everyayah.com/data/' + q + '/' + s + a + '.mp3',
    };
  }
  function parseQuranRef(text) {
    // FYP STUDY GUIDE: matches "Quran 2:201", "Quran 14:41 (dua of Ibrahim
    // AS)", "Quran 20:25-26". A range expands to one entry per ayah, because
    // the dua's Arabic text spans both. Non-Quran refs ("Sahih al-Bukhari
    // 6405") don't match → null → Arabic AI-TTS (see DECISION above).
    const m = /\bQuran\s+(\d{1,3}):(\d{1,3})(?:-(\d{1,3}))?/i.exec(String(text || ''));
    if (!m) return null;
    const s = +m[1], a1 = +m[2], a2 = m[3] ? +m[3] : a1;
    if (s < 1 || s > 114) return null;                 // sanity: 114 surahs
    const lo = Math.max(1, Math.min(a1, a2));
    const hi = Math.min(286, Math.max(a1, a2));       // 286 = longest surah
    const out = [];
    for (let a = lo; a <= hi; a++) out.push({ surah: s, ayah: a });
    return out;
  }
  function duaIsPlaying() {
    return !!duaAudio || (canSpeak && window.speechSynthesis.speaking);
  }
  function playQariForDua(refs, btn) {
    // FYP STUDY GUIDE: sequential tilawat — one <audio> per ayah, the next
    // starts on 'ended'. Failure rule: proxy → direct everyayah → SKIP the
    // ayah (a 20 s stall watchdog covers hung mobile connections that fire
    // neither 'error' nor 'ended'). The duaGen check is the same stale-guard
    // TEAM 2 uses for TTS: tapping another dua (or Stop via a second tap)
    // bumps duaGen, so callbacks from the killed dua ignore themselves.
    stopDuaSpeech();
    const myGen = duaGen;
    activeBtn = btn;
    btn.classList.add('speaking');
    btn.innerHTML = '⏹️ Rok do / Stop';
    let i = 0;
    const playRef = () => {
      if (myGen !== duaGen) return;
      if (i >= refs.length) { stopDuaSpeech(); return; }
      const r = refs[i++];
      const urls = duaQariUrls(r.surah, r.ayah);
      const el = new Audio();
      el.preload = 'auto';
      duaAudio = el;
      let finished = false, attempt = 0, timer = null;
      const clearTimer = () => { if (timer) { clearTimeout(timer); timer = null; } };
      const finish = () => {
        if (finished) return; finished = true;
        clearTimer();
        if (duaAudio === el) duaAudio = null;
        try { el.pause(); el.removeAttribute('src'); el.load(); } catch (e) {}
        if (myGen !== duaGen) return;
        playRef(); // on to the next ayah (a failed one is simply skipped —
                   // no crash, no hang; the button resets at the end)
      };
      const tryNextUrl = () => {
        clearTimer();
        if (myGen !== duaGen) return;
        const list = [urls.primary, urls.fallback];
        if (attempt >= list.length) { finish(); return; }
        try { el.src = list[attempt++]; } catch (e) { tryNextUrl(); return; }
        timer = setTimeout(tryNextUrl, DUA_STALL_MS);
        try {
          const p = el.play();
          if (p && typeof p.catch === 'function') p.catch(() => { /* 'error' event or the timer handles it */ });
        } catch (e) { tryNextUrl(); }
      };
      el.onended = () => finish();
      el.onerror = () => tryNextUrl();
      tryNextUrl();
    };
    playRef();
  }

  /* ---------------- copy ---------------- */
  function copyDuaArabic(text, btn) {
    const done = () => {
      const old = btn.innerHTML;
      btn.innerHTML = '✓ Copied';
      setTimeout(() => { btn.innerHTML = old; }, 1500);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(done);
    } else {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove(); done();
    }
  }

  /* ---------------- wire every card ---------------- */
  cards.forEach(card => {
    const arabicEl = card.querySelector('.arabic');
    const sayBtn = card.querySelector('[data-dua-say]');
    const copyBtn = card.querySelector('[data-dua-copy]');
    if (sayBtn) {
      if (!canSpeak) { sayBtn.disabled = true; sayBtn.title = 'Speech not supported in this browser'; }
      // TEAM 2 (2026-10-22): route the 🔊 button by reference. A Quran
      // citation ("Quran 2:201", "Quran 20:25-26") → the QARI's recitation;
      // anything else (hadith collections etc.) → Arabic AI-TTS, because no
      // qari recording exists for non-Quranic text. Tap-again = stop, for
      // both paths. The reference is read from the card's own .tafseer-src
      // element (rendered from the backend's `reference` field) — never
      // from a data attribute.
      sayBtn.addEventListener('click', () => {
        if (activeBtn === sayBtn && duaIsPlaying()) { stopDuaSpeech(); return; }
        const refEl = card.querySelector('.tafseer-src');
        const refs = parseQuranRef(refEl ? refEl.textContent : '');
        if (refs && refs.length) playQariForDua(refs, sayBtn);
        else speakDua(arabicEl ? arabicEl.textContent : '', sayBtn);
      });
    }
    if (copyBtn)
      copyBtn.addEventListener('click', () =>
        copyDuaArabic(arabicEl ? arabicEl.textContent : '', copyBtn));
  });
})();
