/* Quran Shazam — verification page logic (no frameworks, no tracking).
 *
 * Flow (async jobs):
 *   POST /api/verify  -> 202 {job_id}           (upload accepted, job queued)
 *   GET  /api/jobs/{id} every 2.5s              (short polls: stage/progress/result)
 *
 * Polls are cheap and independent: if one fails because the network blipped,
 * we simply retry — the job keeps running on the server meanwhile.
 */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const statusEl = $('status'), progressEl = $('progress'), barEl = $('progress-bar');
  const btnVerify = $('btn-verify'), fileInput = $('file');
  let recordedBlob = null, recordedExt = '.webm';
  let mediaRecorder = null, recStream = null, recTimer = null, recSeconds = 0;
  let polling = false;

  /* ------------------------------------------------------------------ ui */
  function showStatus(msg, kind) {
    statusEl.style.display = 'block';
    statusEl.innerHTML = msg;
    statusEl.style.borderColor = kind === 'error' ? '#c0565d' : kind === 'ok' ? '#2d9b68' : '';
  }
  function setProgress(pct) {
    progressEl.style.display = 'block';
    barEl.style.width = Math.min(100, Math.max(0, pct)) + '%';
  }
  function fmtTime(s) {
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }
  function refreshVerifyButton() {
    btnVerify.disabled = polling || !(fileInput.files.length || recordedBlob);
    if (fileInput.files.length || recordedBlob) setStep(2);
  }

  /* drag-and-drop highlight on the file input */
  ['dragenter', 'dragover'].forEach(ev => fileInput.addEventListener(ev, e => {
    e.preventDefault(); fileInput.classList.add('dragover');
  }));
  ['dragleave', 'drop'].forEach(ev => fileInput.addEventListener(ev, () => {
    fileInput.classList.remove('dragover');
  }));
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* step tracker in the verify hero: 1 engine · 2 audio · 3 transcription · 4 results */
  let curStep = 0;
  function setStep(n) {
    if (n <= curStep) return;
    curStep = n;
    for (let i = 1; i <= 4; i++) {
      const el = $('vstep-' + i);
      if (!el) continue;
      el.classList.toggle('done', i < n);
      el.classList.toggle('current', i === n);
    }
  }

  /* ------------------------------------------------- human error messages */
  function submitErrorMessage(status, data) {
    if (data && data.detail) {
      // The server already speaks plainly for 400/413/415/429/503.
      return '❌ ' + esc(data.detail);
    }
    if (status === 429) return '❌ Too many requests — please wait a minute and try again.';
    if (status === 503) return '❌ The engine is warming up. Please try again in a minute.';
    if (status === 413) return '❌ Your file is larger than the 200 MB limit. Please use a shorter recording.';
    if (status === 415) return '❌ This file doesn’t look like a supported audio or video file.';
    if (status >= 500) return '❌ The server had trouble accepting your file. Please try again.';
    return '❌ Something went wrong while uploading. Please try again.';
  }
  function networkErrorMessage() {
    return '❌ Could not reach the server. Please check your internet connection and try again.';
  }

  /* -------------------------------------------------------- engine health */
  fetch('/api/health').then(r => r.json()).then(d => {
    const box = $('engine-status');
    if (d.ready) {
      box.innerHTML = '<span class="pill ok">● READY</span>';
      $('engine-detail').textContent = 'Corpus verified: 6,236 ayat · 114 surahs · model ' + d.asr_model;
      setStep(1);
    } else if (d.warming_up) {
      box.innerHTML = '<span class="pill warn">● WARMING UP</span>';
      $('engine-detail').textContent = 'The engine is loading — this takes a minute on first start. You can upload already; verification starts automatically.';
    } else {
      box.innerHTML = '<span class="pill bad">● NOT READY</span>';
      $('engine-detail').textContent = d.error || 'Verification is blocked until the corpus is healthy.';
    }
  }).catch(() => { $('engine-status').innerHTML = '<span class="pill bad">● UNREACHABLE</span>'; });

  /* ------------------------------------------------------------ recording */
  function extFromMime(mt) {
    mt = String(mt || '').toLowerCase();
    if (mt.indexOf('mp4') !== -1) return '.mp4';
    if (mt.indexOf('ogg') !== -1 || mt.indexOf('opus') !== -1) return '.ogg';
    if (mt.indexOf('wav') !== -1) return '.wav';
    return '.webm';
  }
  $('btn-start').addEventListener('click', async () => {
    try {
      recStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      showStatus('Microphone access was denied. You can still upload a file.', 'error');
      return;
    }
    const chunks = [];
    mediaRecorder = new MediaRecorder(recStream);
    mediaRecorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
    mediaRecorder.onstop = () => {
      recordedExt = extFromMime(mediaRecorder.mimeType);
      recordedBlob = new Blob(chunks, { type: mediaRecorder.mimeType || 'audio/webm' });
      recStream.getTracks().forEach(t => t.stop());
      $('rec-dot').classList.remove('live');
      $('recorder-box').classList.remove('recording');
      $('btn-start').disabled = false; $('btn-stop').disabled = true;
      fileInput.value = '';
      showStatus('Recording ready (' + fmtTime(recSeconds) + '). Press “Verify recitation”.', 'ok');
      refreshVerifyButton();
    };
    mediaRecorder.start();
    $('recorder-box').classList.add('recording');
    recSeconds = 0; $('rec-timer').textContent = '00:00';
    recTimer = setInterval(() => { recSeconds++; $('rec-timer').textContent = fmtTime(recSeconds); }, 1000);
    $('rec-dot').classList.add('live');
    $('btn-start').disabled = true; $('btn-stop').disabled = false;
  });
  $('btn-stop').addEventListener('click', () => {
    clearInterval(recTimer);
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
  });
  fileInput.addEventListener('change', () => { recordedBlob = null; refreshVerifyButton(); });

  /* --------------------------------------------------------- verification */
  btnVerify.addEventListener('click', async () => {
    let file = fileInput.files[0];
    let filename = 'recording' + recordedExt;
    if (!file && recordedBlob) { file = recordedBlob; }
    else if (file) { filename = file.name; }
    if (!file || polling) return;

    polling = true;
    refreshVerifyButton();
    setProgress(4);
    setStep(3);
    showStatus('Uploading your audio…');
    $('transcript-card').style.display = 'none';
    $('results-card').style.display = 'none';

    const fd = new FormData();
    fd.append('file', file, filename);

    let jobId;
    try {
      const res = await fetch('/api/verify', { method: 'POST', body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.job_id) {
        showStatus(submitErrorMessage(res.status, data)
          + (data.request_id ? '<br><span class="hint">Reference: ' + esc(data.request_id) + '</span>' : ''), 'error');
        polling = false; refreshVerifyButton();
        return;
      }
      jobId = data.job_id;
    } catch (e) {
      showStatus(networkErrorMessage(), 'error');
      polling = false; refreshVerifyButton();
      return;
    }

    pollJob(jobId, 0);
  });

  async function pollJob(jobId, netFails) {
    // Give the server a moment before the first poll.
    await new Promise(r => setTimeout(r, 2200));
    for (;;) {
      let res, data;
      try {
        res = await fetch('/api/jobs/' + encodeURIComponent(jobId));
        data = await res.json();
      } catch (e) {
        netFails++;
        if (netFails > 12) {
          showStatus('❌ Lost connection to the server. Your audio may still be processing — '
            + 'please check your connection and try again.', 'error');
          polling = false; refreshVerifyButton();
          return;
        }
        showStatus('Connection hiccup — retrying… (' + netFails + ')');
        await new Promise(r => setTimeout(r, 2500));
        continue;
      }
      if (!res.ok) {
        if (res.status === 404) {
          showStatus('❌ This verification expired on the server. Please upload your audio again.', 'error');
        } else {
          showStatus(submitErrorMessage(res.status, data), 'error');
        }
        polling = false; refreshVerifyButton();
        return;
      }
      netFails = 0;
      setProgress(data.progress || 5);
      if (data.status === 'done' && data.result) {
        renderResults(data.result);
        const r = data.result;
        showStatus('✅ Done in ' + r.processing_seconds + 's on ' + r.device
          + ' · ' + r.realtime + '× realtime'
          + '<br><span class="hint">Reference: ' + esc(r.request_id) + '</span>', 'ok');
        polling = false; refreshVerifyButton();
        return;
      }
      if (data.status === 'error') {
        showStatus('❌ ' + esc(data.error || 'Verification failed. Please try a clearer recording.')
          + '<br><span class="hint">Reference: ' + esc(data.request_id) + '</span>', 'error');
        polling = false; refreshVerifyButton();
        return;
      }
      showStatus(esc(data.stage || 'Processing…') + '<br><span class="hint">You can keep this page open — it updates automatically.</span>');
      await new Promise(r => setTimeout(r, 2500));
    }
  }

  /* -------------------------------------------------------------- results */
  function labelPill(label) {
    if (label.indexOf('VERIFIED') === 0) return 'ok';
    if (label.indexOf('SEQUENCE') === 0) return 'warn';
    if (label.indexOf('LOW') === 0) return 'bad';
    return 'info';
  }

  function renderResults(d) {
    setProgress(100);
    setStep(4);
    $('transcript-card').style.display = 'block';
    $('transcript').textContent = d.transcript || '(empty)';
    $('transcript-meta').textContent = d.recognized_words + ' words recognized · ' + d.duration + 's audio · coverage ' + d.coverage + '%';

    $('results-card').style.display = 'block';
    const box = $('results');
    if (!d.results || !d.results.length) {
      box.innerHTML = '<p class="muted">No reliable ayah sequence could be established from this audio. Try a clearer or longer recording.</p>';
      return;
    }
    box.innerHTML = '<p><span class="pill ok">' + d.verified_count + ' verified</span> '
      + '<span class="muted small">of ' + d.results.length + ' candidate ayat</span></p>'
      + d.results.map(r =>
        '<div class="card result-card" style="margin:12px 0">'
        + '<div><strong>Surah ' + r.surah + ' · Ayah ' + r.ayah + '</strong></div>'
        + '<div class="result-meta">'
        + '<span class="pill ' + labelPill(r.label) + '">' + esc(r.label) + '</span>'
        + '<span class="pill">confidence ' + r.confidence + '%</span>'
        + '<span class="pill">coverage ' + r.coverage + '%</span>'
        + '<span class="pill">sequence ' + r.sequence + '%</span>'
        + '</div>'
        + '<div class="arabic">' + esc(r.text) + '</div>'
        + (r.translation_en ? '<div class="translation"><strong>EN:</strong> ' + esc(r.translation_en) + '</div>' : '')
        + (r.translation_ur ? '<div class="translation" dir="rtl" style="text-align:right;border-right:none;border-left:3px solid var(--gold);padding-right:0;padding-left:14px"><strong>UR:</strong> ' + esc(r.translation_ur) + '</div>' : '')
        + (r.reason ? '<p class="hint">' + esc(r.reason) + '</p>' : '')
        + '</div>'
      ).join('');
    setTimeout(() => { progressEl.style.display = 'none'; barEl.style.width = '0'; }, 1200);
  }
})();
