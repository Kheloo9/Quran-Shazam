/* Quran Shazam — verification page logic (no frameworks, no tracking).
 *
 * Flow (async jobs):
 *   POST /api/verify            -> 202 {job_id}      (upload accepted, queued)
 *   GET  /api/jobs/{id}/events  -> SSE stream        (preferred: live updates)
 *   GET  /api/jobs/{id}         -> polling fallback  (cheap, retry-safe)
 *
 * A page refresh never loses a job: the job id is kept in localStorage
 * ("Recent verifications") and status can be re-attached any time.
 */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const statusEl = $('status'), progressEl = $('progress'), barEl = $('progress-bar');
  const btnVerify = $('btn-verify'), btnCancel = $('btn-cancel'), fileInput = $('file');
  // MOBILE-FIRST (2026-10-19): sticky bottom bar mirrors the main verify button
  // on phones so the thumb never has to scroll up to find it.
  const stickyBar = $('sticky-verify-bar'), btnVerifySticky = $('btn-verify-sticky');
  if (btnVerifySticky) btnVerifySticky.addEventListener('click', () => { if (!btnVerify.disabled) btnVerify.click(); });
  /* ------------------------------------------- audio source of truth (P1)
   * FYP STUDY GUIDE — WHY this variable exists (stale-audio bug, 2026-10-21):
   * This page has TWO places audio can come from: the file picker
   * (`fileInput.files`) and the microphone (`recordedBlob`). They used to be
   * kept "mutually exclusive" by convention — choosing a file nulled the blob
   * (change handler), stopping a recording cleared the file input (onstop) —
   * and the Verify button picked "whichever is non-null, file first". That
   * broke in the real user flow upload → verify → record → stop → verify:
   * the record-stop clear (`fileInput.value = ''`) runs ASYNC inside
   * mediaRecorder.onstop, AFTER fallible UI teardown, and the sticky Verify
   * bar stays enabled during recording (fileInput still holds the upload).
   * So if the clear never ran — an exception before it, or Verify tapped in
   * the stop→onstop window — BOTH sources were set and the old "file wins"
   * rule resubmitted the STALE upload instead of the fresh recording.
   *
   * `audioSource` fixes it: ONE explicit flag records the user's LAST choice.
   * Every transition below sets it; the Verify handler trusts ONLY it.
   * Allowed transitions:
   *   null → 'upload'            (a file is chosen and passes validation)
   *   null → 'recording'         (a mic take stops with a non-empty blob)
   *   'upload' → 'recording'     (a fresh take replaces the upload)
   *   'recording' → 'upload'     (a file is chosen; the old take is discarded)
   *   any → null                 (source removed: dz-remove, empty take,
   *                               re-record confirm, failed stop)
   * Switching source always clears the OTHER source's data too, so the two
   * can never disagree — but even if they did, Verify follows audioSource.
   */
  let audioSource = null; // 'upload' | 'recording' | null — the user's last audio choice
  let recordedBlob = null, recordedExt = '.webm';
  let mediaRecorder = null, recStream = null, recTimer = null, recSeconds = 0;
  let audioCtx = null, analyser = null, levelRAF = null, meterSrc = null;
  let recPeakPct = 0; // TEAM 14: max mic level seen during this recording (silent-mic guard)
  /* RECORD-LIVE RESTORE (2026-11-04): recPreviewUrl/revoke helpers restored
     from v116 (L-11). revokeDzAudio is ADAPTED: this copy's showFileCard
     never stored the upload blob URL, so clearing the dz-audio src (not a
     revoke) is the matching teardown here. */
  let recPreviewUrl = null;
  function revokeRecPreview() {
    if (recPreviewUrl) { try { URL.revokeObjectURL(recPreviewUrl); } catch (e) {} recPreviewUrl = null; }
  }
  function revokeDzAudio() {
    const a = $('dz-audio');
    if (a) { try { a.removeAttribute('src'); a.load(); } catch (e) {} }
  }
  let activeJobId = null, eventSource = null, polling = false, pollTimer = null;
  /* V-3: /api/health gate — the Verify buttons stay disabled until the
     engine reports READY, so nobody uploads MBs into a guaranteed rejection. */
  let engineReady = false;
  let engineHintShown = false; // V-3: one-time "engine not ready" hint
  /* V-7: the in-flight upload XHR — Cancel aborts it mid-upload. */
  let uploadXhr = null;

  /* ------------------------------------------------------------------ ui */
  function showStatus(msg, kind) {
    statusEl.style.display = 'block';
    statusEl.innerHTML = msg;
    statusEl.style.borderColor = kind === 'error' ? '#c0565d' : kind === 'ok' ? '#2d9b68' : '';
  }
  function setProgress(pct) {
    /* A-8 (2026-10-22): keep the progressbar semantics in sync — screen
       readers announce the numeric value while the bar animates. */
    const v = Math.min(100, Math.max(0, pct));
    progressEl.style.display = 'block';
    barEl.style.width = v + '%';
    progressEl.setAttribute('aria-valuenow', String(Math.round(v)));
  }
  function fmtTime(s) {
    s = Math.max(0, Math.round(s));
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }
  function refreshVerifyButton() {
    // FYP STUDY GUIDE: readiness follows `audioSource`, not "either variable
    // is non-null". The two data holders can briefly disagree across the
    // async record-stop boundary; the flag is what the user actually chose.
    // V-3: the engine must ALSO be READY (from /api/health) — enabling Verify
    // into a warming engine wastes Pakistani mobile data on a dead request.
    const ready = !polling && audioSource !== null && engineReady;
    btnVerify.disabled = !ready;
    // V-3: explain the disabled state. `title` covers desktop hover; the
    // one-time status line below covers phones (title never shows there).
    const gated = audioSource !== null && !polling && !engineReady;
    const hint = gated
      ? 'Engine not ready yet — please wait a moment / Engine abhi ready nahi hai — thori der wait karein'
      : '';
    btnVerify.title = hint;
    if (gated && !engineHintShown) {
      engineHintShown = true;
      showStatus('⏳ Engine not ready yet — please wait a moment.<br><span class="hint">(Engine abhi ready nahi hai — thori der wait karein, phir Verify dabayein.)</span>');
    } else if (!gated) {
      engineHintShown = false;
    }
    // MOBILE-FIRST: slide the sticky bar in only when audio is ready.
    if (stickyBar && btnVerifySticky) {
      btnVerifySticky.disabled = !ready;
      btnVerifySticky.title = hint;
      stickyBar.classList.toggle('show', ready);
      stickyBar.setAttribute('aria-hidden', ready ? 'false' : 'true');
      // V-9: a hidden bar must not stay keyboard-focusable — `inert` mirrors
      // aria-hidden; visibility:hidden is the fallback for older browsers.
      if ('inert' in stickyBar) stickyBar.inert = !ready;
      else stickyBar.style.visibility = ready ? '' : 'hidden';
      // V-6: while the fixed bar is shown, give the page bottom ~84px of
      // breathing room so it can't cover transcript actions / coach cards.
      document.body.classList.toggle('sticky-verify-visible', ready);
    }
    if (audioSource !== null) setStep(2);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* step tracker: 1 engine · 2 audio · 3 transcription · 4 results */
  let curStep = 0;
  function setStep(n) {
    if (n <= curStep) return;
    curStep = n;
    for (let i = 1; i <= 4; i++) {
      const el = $('vstep-' + i);
      if (!el) continue;
      el.classList.toggle('done', i < n);
      el.classList.toggle('current', i === n);
    }
  }
  /* V-2: FYP STUDY GUIDE — setStep()'s `n <= curStep` guard means a tracker
     that finished at step ④ NEVER advances again. Every new verification
     must reset curStep AND strip the .done/.current classes first, otherwise
     repeat runs show a lying "step ④ current" during the anxious wait. */
  function resetSteps() {
    curStep = 0;
    for (let i = 1; i <= 4; i++) {
      const el = $('vstep-' + i);
      if (!el) continue;
      el.classList.remove('done', 'current');
    }
  }

  /* ------------------------------------------------- human error messages */
  function submitErrorMessage(status, data) {
    if (data && data.detail) return '❌ ' + esc(data.detail);
    if (status === 429) return '❌ Too many requests — please wait a minute and try again.';
    if (status === 503) return '❌ The engine is warming up. Please try again in a minute.';
    if (status === 413) return '❌ Your file is larger than the 200 MB limit. Please use a shorter recording.';
    if (status === 415) return '❌ This file doesn’t look like a supported audio or video file.';
    if (status >= 500) return '❌ The server had trouble accepting your file. Please try again.';
    return '❌ Something went wrong while uploading. Please try again.';
  }
  function networkErrorMessage() {
    return '❌ Could not reach the server. Please check your internet connection and try again.';
  }
  /* RECORD-LIVE RESTORE (2026-11-04): micErrorMessage, mic-check block and
     recording section restored verbatim from v116 verify.js (micError
     L166-177, mic-check L215-344, recording L346-603), adapted only by
     the revoke helpers above. Speak-verify block below is untouched. */
  function micErrorMessage(e) {
    const n = (e && e.name) || '';
    if (n === 'NotAllowedError' || n === 'SecurityError')
      return '❌ Microphone blocked. Allow mic access in your browser’s site settings, then try again. You can still upload a file.';
    if (n === 'NotFoundError' || n === 'OverconstrainedError')
      return '❌ No microphone found on this device. You can still upload a file.';
    if (n === 'NotReadableError')
      return '❌ The microphone is busy in another app. Close it and try again.';
    if (location.protocol !== 'https:' && location.hostname !== 'localhost' && !/\.app\.github\.dev$/.test(location.hostname))
      return '❌ Microphone needs a secure (HTTPS) page. You can still upload a file.';
    return '❌ Could not start the microphone (' + esc(n || 'unknown error') + '). You can still upload a file.';
  }

  /* TEAM 2 — RECORDING UX (2026-10-27) (a): pre-record mic check.
   * Runs BEFORE any recording: samples room noise for ~3 seconds while
   * the user stays silent, shows a live noise meter, then warns when
   * background noise is high. Deliberately separate from the recording
   * meter (startLevelMeter) and from any recording state: checking never
   * starts a MediaRecorder, never sets audioSource, and its stream is
   * stopped as soon as the check ends (or when recording starts).
   * Thresholds are a best-effort heuristic on the same peak scale the
   * recording meter uses (peak/128*160, 0–100): mean peak < 15 = quiet,
   * 15–25 = moderate, >= 25 = high (warn). They are NOT calibrated dB —
   * the warning text says so implicitly by advising a re-check, and the
   * user can always record anyway; the check never blocks recording. */
  let micCheckStream = null, micCheckCtx = null, micCheckSrc = null,
      micCheckAnalyser = null, micCheckRAF = null, micCheckTimer = null,
      micCheckSamples = [], micCheckActive = false;
  function stopMicCheckStream() {
    if (micCheckRAF) cancelAnimationFrame(micCheckRAF);
    micCheckRAF = null;
    if (micCheckTimer) clearTimeout(micCheckTimer);
    micCheckTimer = null;
    if (micCheckSrc) { try { micCheckSrc.disconnect(); } catch (e) {} micCheckSrc = null; }
    if (micCheckCtx) { try { micCheckCtx.close(); } catch (e) {} micCheckCtx = null; }
    micCheckAnalyser = null;
    if (micCheckStream) { micCheckStream.getTracks().forEach(t => t.stop()); micCheckStream = null; }
    micCheckActive = false;
  }
  function stopMicCheck() {
    stopMicCheckStream();
    const b = $('btn-mic-check'), w = $('mic-check-meter-wrap'),
          m = $('mic-check-meter'), s = $('mic-check-status'), warn = $('mic-check-warning');
    if (b) b.textContent = '🔍 Mic check — shor ki jaanch karein';
    if (w) w.style.display = 'none';
    if (m) m.style.width = '0%';
    if (s) s.textContent = 'Recording shuru karne se pehle kamre ka shor jaanch lein (3 second tak khamosh rahein).';
    if (warn) { warn.style.display = 'none'; warn.innerHTML = ''; }
  }
  function evaluateMicCheck() {
    const s = $('mic-check-status'), warn = $('mic-check-warning'),
          b = $('btn-mic-check');
    const samples = micCheckSamples;
    stopMicCheckStream();
    if (b) b.textContent = '🔍 Mic check — shor ki jaanch karein';
    if (!samples.length) {
      if (s) s.textContent = '❌ Shor ki paimaish nahi ho saki — barah-e-karam dobara jaanch karein.';
      return;
    }
    const mean = samples.reduce((a, v) => a + v, 0) / samples.length;
    if (mean >= 25) {
      if (s) s.textContent = '⚠️ Background noise zyada hai (avg ' + Math.round(mean) + '/100) — recording se pehle barah-e-karam shor kam karein.';
      if (warn) {
        warn.style.display = 'block';
        warn.innerHTML = '⚠️ <b>Shor zyada hai!</b> Pankha/TV band karein, khamosh kamre me muntaqil ho jayein, ya mic munh ke qareeb (15–20 cm) rakhein — warna AI ghalat sun sakta hai. Durust kar ke dobara <b>Mic check</b> par click karein. (Ye sirf aik warning hai — aap phir bhi record kar sakte hain.)';
      }
    } else if (mean >= 15) {
      if (s) s.textContent = '⚠️ Halka shor hai (avg ' + Math.round(mean) + '/100) — behtareen natijay ke liye khamosh jagah munasib rahegi.';
      if (warn) {
        warn.style.display = 'block';
        warn.innerHTML = '⚠️ <b>Halka shor hai.</b> Agar mumkin ho to khamosh jagah par recording farmayen; warna aap phir bhi record kar sakte hain.';
      }
    } else {
      if (s) s.textContent = '✅ Kamra khamosh hai (avg ' + Math.round(mean) + '/100) — ab recording ki ja sakti hai.';
      if (warn) { warn.style.display = 'none'; warn.innerHTML = ''; }
    }
  }
  (function setupMicCheck() {
    const btn = $('btn-mic-check');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      if (micCheckActive) { stopMicCheck(); return; }
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        $('mic-check-status').textContent = 'Barah-e-karam pehle recording band karein, phir mic check karein.';
        return;
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        $('mic-check-status').textContent = '❌ Is browser me mic check mumkin nahi — phir bhi record/upload kar sakte hain.';
        return;
      }
      let stream;
      // TEAM 3 (2026-10-29, F6 double-tap guard): same await-gap orphan as
      // F1 — micCheckActive is set only AFTER getUserMedia resolves, so a
      // second tap during the prompt orphaned the first check stream
      // (never stopped, mic indicator stuck on). Disable during the await;
      // success below re-enables the button as the stop-toggle.
      btn.disabled = true;
      try {
        // Same RAW constraints as recording (no noise suppression): the
        // check must hear the room as it is, not a cleaned-up feed.
        stream = await navigator.mediaDevices.getUserMedia({ audio: {
          echoCancellation: false, noiseSuppression: false,
          autoGainControl: false, channelCount: 1, sampleRate: { ideal: 48000 }
        } });
      } catch (e) {
        btn.disabled = false;
        $('mic-check-status').textContent = micErrorMessage(e);
        return;
      }
      btn.disabled = false;
      micCheckStream = stream;
      micCheckActive = true;
      micCheckSamples = [];
      btn.textContent = '⏹️ Mic check band karein';
      $('mic-check-meter-wrap').style.display = 'block';
      $('mic-check-warning').style.display = 'none';
      $('mic-check-warning').innerHTML = '';
      $('mic-check-status').textContent = '🔊 Khamoshi ikhtiyar karein — kamre ke shor ki paimaish ho rahi hai (3 second)…';
      try {
        micCheckCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (micCheckCtx.state === 'suspended') micCheckCtx.resume();
        micCheckSrc = micCheckCtx.createMediaStreamSource(stream);
        micCheckAnalyser = micCheckCtx.createAnalyser();
        micCheckAnalyser.fftSize = 512;
        micCheckSrc.connect(micCheckAnalyser);
        const buf = new Uint8Array(micCheckAnalyser.frequencyBinCount);
        const meter = $('mic-check-meter'), label = $('mic-check-label');
        const tick = () => {
          if (!micCheckActive) return;
          micCheckAnalyser.getByteTimeDomainData(buf);
          let peak = 0;
          for (let i = 0; i < buf.length; i++) peak = Math.max(peak, Math.abs(buf[i] - 128));
          const pct = Math.min(100, Math.round(peak / 128 * 160));
          micCheckSamples.push(pct);
          if (meter) meter.style.width = pct + '%';
          if (label) label.textContent = pct < 15 ? 'Quiet 🤫' : pct < 25 ? 'Halka shor' : 'Shor zyada 🔊';
          micCheckRAF = requestAnimationFrame(tick);
        };
        tick();
      } catch (e) { /* meter best-effort; samples still empty -> honest message */ }
      micCheckTimer = setTimeout(evaluateMicCheck, 3000);
    });
  })();

  /* ------------------------------------------------------------ recording */
  function pickMimeType() {
    const candidates = [
      'audio/webm;codecs=opus', 'audio/webm',
      'audio/mp4',                    // Safari fallback
      'audio/ogg;codecs=opus', 'audio/ogg',
    ];
    for (const mt of candidates) {
      try { if (window.MediaRecorder && MediaRecorder.isTypeSupported(mt)) return mt; }
      catch (e) { /* ignore */ }
    }
    return '';
  }
  function extFromMime(mt) {
    mt = String(mt || '').toLowerCase();
    if (mt.indexOf('mp4') !== -1) return '.mp4';
    // TEAM 8: test 'webm' BEFORE 'opus' — 'audio/webm;codecs=opus' is WebM
    // content; the old order mislabeled Chrome mic uploads as .ogg.
    if (mt.indexOf('webm') !== -1) return '.webm';
    if (mt.indexOf('ogg') !== -1 || mt.indexOf('opus') !== -1) return '.ogg';
    if (mt.indexOf('wav') !== -1) return '.wav';
    return '.webm';
  }
  function startLevelMeter(stream) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      meterSrc = audioCtx.createMediaStreamSource(stream);
      const src = meterSrc;
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      const buf = new Uint8Array(analyser.frequencyBinCount);
      // V-4: only the larger LABELED meter (#mic-meter + #mic-label with
      // Good/Too quiet/Too loud text) is driven now — the small inline
      // #level-meter/#level-fill was removed (two meters, two scales).
      const meter = $('mic-meter'), label = $('mic-label');
      const tick = () => {
        analyser.getByteTimeDomainData(buf);
        let peak = 0;
        for (let i = 0; i < buf.length; i++) peak = Math.max(peak, Math.abs(buf[i] - 128));
        const pct = Math.min(100, Math.round(peak / 128 * 160));
        if (pct > recPeakPct) recPeakPct = pct; // TEAM 14: track loudest moment
        if (meter) meter.style.width = pct + '%';
        if (label) label.textContent = pct < 10 ? 'Too quiet 🤫' : pct < 70 ? 'Good ✅' : 'Too loud 🔊';
        levelRAF = requestAnimationFrame(tick);
      };
      tick();
    } catch (e) { /* meter is best-effort */ }
  }
  function stopLevelMeter() {
    if (levelRAF) cancelAnimationFrame(levelRAF);
    levelRAF = null;
    // L-12 (2026-10-23): disconnect the source node too — every take used
    // to leak one MediaStreamSource on the shared AudioContext.
    if (meterSrc) { try { meterSrc.disconnect(); } catch (e) {} meterSrc = null; }
    // V-4: reset the surviving labeled meter too (it used to be #level-fill).
    const meter = $('mic-meter');
    if (meter) meter.style.width = '0';
    const mmw = $('mic-meter-wrap');
    if (mmw) mmw.style.display = 'none';
  }
  function setRecUI(state) {
    // state: idle | recording | paused
    $('btn-start').disabled = state !== 'idle';
    $('btn-pause').disabled = state === 'idle';
    $('btn-pause').textContent = state === 'paused' ? 'Resume' : 'Pause';
    $('btn-stop').disabled = state === 'idle';
    $('recorder-box').classList.toggle('recording', state === 'recording');
    $('rec-dot').classList.toggle('live', state === 'recording');
    $('rec-dot').classList.toggle('paused', state === 'paused');
  }
  function resetRecording(clearBlob) {
    if (recTimer) clearInterval(recTimer);
    recTimer = null;
    stopLevelMeter();
    if (recStream) { recStream.getTracks().forEach(t => t.stop()); recStream = null; }
    mediaRecorder = null;
    recSeconds = 0;
    $('rec-timer').textContent = '00:00';
    // FYP STUDY GUIDE: if the RECORDING is discarded, its source flag goes
    // too — but only when the flag actually pointed at the recording. (A
    // failed stop mid-take after an upload must keep 'upload': the file is
    // still there and still the user's choice.)
    if (clearBlob) { recordedBlob = null; if (audioSource === 'recording') audioSource = null; }
    setRecUI('idle');
    refreshVerifyButton();
  }
  $('btn-start').addEventListener('click', async () => {
    // TEAM 3 (2026-10-29, F1 double-tap guard): this handler awaits
    // getUserMedia BEFORE setRecUI('recording') disables Start, so a
    // second phone tap during the permission prompt ran a second
    // getUserMedia + MediaRecorder that overwrote recStream/mediaRecorder
    // and orphaned the first stream/recorder (mic never stopped, chunks
    // lost). Disable Start synchronously at entry; every failure return
    // below re-enables it, the success path ends in setRecUI('recording')
    // which keeps it disabled.
    if ($('btn-start').disabled) return;
    $('btn-start').disabled = true;
    // TEAM 2 (2026-10-27): a running mic check must not hold the mic while
    // recording starts — stop it (stream + meter) first.
    stopMicCheck();
    if (!window.MediaRecorder || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showStatus('❌ This browser cannot record audio. Please upload a file instead.', 'error');
      $('btn-start').disabled = false;
      return;
    }
    // TEAM 8 (2026-10-19): RAW mic feed, not a phone-call chain. The old
    // constraints (echoCancellation+noiseSuppression, AGC default-on) engaged
    // Android's telephony voice-processing pipeline, which smears the soft
    // Quranic phonemes Whisper needs (madd tails, ghunnah nasals, hams
    // letters) — the #1 cause of "bolta kuch, ata kuch". Whisper is trained
    // on noisy audio and the server has its own VAD; browser-side spectral
    // noise suppression deletes information the model could have used.
    try {
      recStream = await navigator.mediaDevices.getUserMedia({ audio: {
        echoCancellation: false,  // no call partner; nothing to cancel
        noiseSuppression: false,  // keep soft phonemes intact
        autoGainControl: false,   // no gain pumping on quiet recitation
        channelCount: 1,
        sampleRate: { ideal: 48000 }
      } });
    } catch (e) {
      showStatus(micErrorMessage(e), 'error');
      $('btn-start').disabled = false; // F1: permission denial must re-enable Start
      return;
    }
    // TEAM 7 (2026-10-27): the old take is discarded ONLY AFTER the mic was
    // actually granted. Previously the confirm+clear ran BEFORE getUserMedia,
    // so a permission denial destroyed a good previous recording (preview
    // hidden, audioSource nulled) and left the user with no audio at all.
    // Declining now also stops the just-granted stream, or the mic indicator
    // would stay on with no recording running.
    if (recordedBlob && recordedBlob.size > 0) {
      if (!confirm('You already have a recording. Start a new one? (The old recording will be replaced.)')) {
        recStream.getTracks().forEach(t => t.stop());
        recStream = null;
        $('btn-start').disabled = false; // F1: declining re-enables Start
        return;
      }
      recordedBlob = null;
      audioSource = null; // old take discarded; no source until the new take stops
      revokeRecPreview(); // L-11
      $('rec-preview').style.display = 'none';
      btnVerify.textContent = '✨ Verify recitation';
      btnVerify.classList.remove('pulse');
      refreshVerifyButton();
    }
    // Mic level meter (visual)
    const mmw = $('mic-meter-wrap');
    if (mmw) mmw.style.display = 'block';
    const mimeType = pickMimeType();
    const chunks = [];
    try {
      // TEAM 8: fixed 64 kbps Opus — deterministic encode, no VBR surprises;
      // 32–64 kbps mono is Whisper's sweet spot for speech.
      mediaRecorder = mimeType
        ? new MediaRecorder(recStream, { mimeType, audioBitsPerSecond: 64000 })
        : new MediaRecorder(recStream, { audioBitsPerSecond: 64000 });
    } catch (e) {
      showStatus('❌ Could not start recording in this browser. Please upload a file instead.', 'error');
      recStream.getTracks().forEach(t => t.stop());
      recStream = null; // TEAM 7: do not leave a stopped stream dangling for the next Start
      $('btn-start').disabled = false; // F1
      return;
    }
    mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    /* L-21 (2026-10-23): the old handler only showed a toast and left the
       recorder UI stuck in "recording" state. resetRecording(true) restores
       the idle UI so the user can retry without a page refresh. */
    mediaRecorder.onerror = () => {
      showStatus('❌ Recording error. Please try again or upload a file.', 'error');
      resetRecording(true);
    };
    mediaRecorder.onstop = () => {
      recordedExt = extFromMime(mediaRecorder.mimeType);
      recordedBlob = new Blob(chunks, { type: mediaRecorder.mimeType || 'audio/webm' });
      const wasEmpty = !recordedBlob.size;
      const dur = recSeconds;
      // FYP STUDY GUIDE (P1 fix): when switching source, clear the OTHER
      // source FIRST — before resetRecording()'s UI teardown, which can throw
      // and would otherwise leave the stale upload in fileInput. Even if the
      // clear below somehow failed, `audioSource` (set in the branches) is
      // what the Verify handler trusts, so a leftover file can never win.
      fileInput.value = '';
      resetRecording(false);
      // V-1: the old upload is GONE (fileInput cleared above) — its card must
      // not stay on screen pretending otherwise. Mirror the dz-remove
      // handler's 3 lines: hide the file card, restore the empty state,
      // clear any error. Covers the empty-take branch too, where the same
      // stale-card lie would appear.
      revokeDzAudio(); // L-11: upload card hidden — drop its preview URL
      dzCard.style.display = 'none';
      dzEmpty.style.display = 'block';
      dzError.style.display = 'none';
      if (wasEmpty) {
        recordedBlob = null;
        audioSource = null; // empty take: no usable audio from any source
        showStatus('❌ The recording came out empty. Please try again.', 'error');
        $('rec-preview').style.display = 'none';
      } else {
        audioSource = 'recording'; // this fresh take is now the source of truth
        // Show preview player + make the next step unmissable.
        revokeRecPreview(); // L-11: never leak the previous take's blob URL
        recPreviewUrl = URL.createObjectURL(recordedBlob);
        $('rec-audio').src = recPreviewUrl;
        $('rec-preview').style.display = 'block';
        // Change Start button so re-recording is a deliberate choice.
        $('btn-start').textContent = '🔄 Record again';
        // Make the verify button shout the next step.
        btnVerify.textContent = '✨ Verify this recording (' + fmtTime(dur) + ')';
        btnVerify.classList.add('pulse');
        // TEAM 14: silent-mic guard — if the meter barely moved, the mic heard
        // almost nothing and the AI will "mismatch". Warn instead of failing silently.
        const weakMic = recPeakPct < 10;
        showStatus(weakMic
          ? '⚠️ Recording me awaz bohat halki thi (mic meter me koi khaas harkat nahi hui) — mic 15–20 cm par rakhein aur dobara record farmayen, warna natija ghalat aa sakta hai. (' + fmtTime(dur) + ' mehfooz hai)'
          : '✅ Recording ready (' + fmtTime(dur) + '). Listen above, then press “Verify”.',
          weakMic ? 'error' : 'ok');
        // Gentle scroll so the verify button is in view on mobile.
        setTimeout(() => { btnVerify.scrollIntoView({behavior:'smooth', block:'center'}); }, 300);
      }
      refreshVerifyButton();
    };
    try {
      mediaRecorder.start(1000); // 1s timeslices: memory-safe for long recordings
    } catch (e) {
      showStatus('❌ Could not start recording. Please upload a file instead.', 'error');
      recStream.getTracks().forEach(t => t.stop());
      recStream = null; // TEAM 7: failed start leaves no dangling stream/recorder
      mediaRecorder = null;
      $('btn-start').disabled = false; // F1
      return;
    }
    startLevelMeter(recStream);
    recSeconds = 0; $('rec-timer').textContent = '00:00';
    recPeakPct = 0; // TEAM 14: reset peak tracker for the new take
    recTimer = setInterval(() => { recSeconds++; $('rec-timer').textContent = fmtTime(recSeconds); }, 1000);
    setRecUI('recording');
  });
  $('btn-pause').addEventListener('click', () => {
    if (!mediaRecorder) return;
    try {
      if (mediaRecorder.state === 'recording') {
        mediaRecorder.pause();
        clearInterval(recTimer);
        setRecUI('paused');
      } else if (mediaRecorder.state === 'paused') {
        mediaRecorder.resume();
        recTimer = setInterval(() => { recSeconds++; $('rec-timer').textContent = fmtTime(recSeconds); }, 1000);
        setRecUI('recording');
      }
    } catch (e) { /* ignore */ }
  });
  $('btn-stop').addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') { try { mediaRecorder.stop(); } catch (e) { resetRecording(true); } }
    else resetRecording(true);
  });

  /* -------------------------------------------------------- engine health */
  /* V-3 + V-11: FYP STUDY GUIDE — one fetch does three jobs: (1) it sets the
     `engineReady` gate that refreshVerifyButton() enforces before Verify can
     be pressed; (2) step ① advances only on a REAL ready signal; (3) the old
     "Engine status" card is gone — its detail now lives in step ①'s tooltip,
     so the hero and the engine can never show two different stories. */
  fetch('/api/health').then(r => r.json()).then(d => {
    engineReady = !!d.ready;
    const step1 = $('vstep-1');
    const detail = d.ready
      ? 'Corpus verified: 6,236 ayat · 114 surahs · model ' + d.asr_model
      : d.warming_up
        ? 'The engine is loading — this takes a minute on first start. Aap audio upload kar sakte hain; verification khud start ho jayegi.'
        : (d.error || 'Verification is blocked until the corpus is healthy.');
    if (step1) step1.title = '① Engine — ' + detail;
    if (d.ready) setStep(1);
    refreshVerifyButton(); // re-evaluate the V-3 gate now that health is known
  }).catch(() => {
    engineReady = false;
    const step1 = $('vstep-1');
    if (step1) step1.title = '① Engine — server se rabta nahi ho raha / server unreachable. Please check your connection.';
    refreshVerifyButton();
  });

  /* ---------------- professional dropzone ---------------- */
  const dropzone = $('dropzone'), dzEmpty = $('dz-empty'), dzCard = $('dz-filecard'),
        dzError = $('dz-error');

  // Click to browse
  dropzone.addEventListener('click', e => {
    if (e.target.closest('.dz-remove') || e.target.closest('audio')) return;
    fileInput.click();
  });

  /* TEAM 1 (2026-10-22, A-4): the dropzone is a <div> acting as a button —
     keyboard users could never reach the file picker. The template exposes
     it as role="button" + tabindex="0"; Enter/Space opens the picker here.
     (A real <button> can't wrap the inner ✕ button / audio controls — nested
     interactive content — so this is the accessible equivalent.) */
  dropzone.addEventListener('keydown', e => {
    if (e.target !== dropzone) return; // inner controls (✕ button, audio) own their keys
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
  });

  // Drag & drop
  ['dragenter', 'dragover'].forEach(ev => dropzone.addEventListener(ev, e => {
    e.preventDefault(); e.stopPropagation();
    dropzone.classList.add('dragover');
  }));
  ['dragleave', 'drop'].forEach(ev => dropzone.addEventListener(ev, e => {
    e.preventDefault(); e.stopPropagation();
    dropzone.classList.remove('dragover');
    if (ev === 'drop' && e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      fileInput.dispatchEvent(new Event('change'));
    }
  }));

  // Remove file
  $('dz-remove').addEventListener('click', e => {
    e.stopPropagation();
    fileInput.value = '';
    if (audioSource === 'upload') audioSource = null; // uploaded file removed → no source
    dzCard.style.display = 'none';
    dzEmpty.style.display = 'block';
    dzError.style.display = 'none';
    refreshVerifyButton();
  });

  fileInput.addEventListener('change', () => {
    // RECORD-LIVE RESTORE (2026-11-04): v116 F5 order — validate FIRST, discard
    // the recording ONLY on a valid file. The old order nulled the recording
    // before validation, so picking an invalid file destroyed a good take.
    showFileCard(fileInput.files[0]);
    // showFileCard() clears fileInput on invalid files, so only claim
    // 'upload' — and only discard the recording — when a valid file remains.
    if (!fileInput.files.length) { refreshVerifyButton(); return; }
    recordedBlob = null;
    audioSource = 'upload';
    revokeRecPreview(); // L-11
    $('rec-preview').style.display = 'none';
    $('btn-start').textContent = 'Start recording';
    btnVerify.textContent = '✨ Verify recitation';
    btnVerify.classList.remove('pulse');
    refreshVerifyButton();
  });

  /* File card: validation + preview + waveform */
  function showFileCard(f) {
    dzError.style.display = 'none';
    if (!f) { dzCard.style.display = 'none'; dzEmpty.style.display = 'block'; return; }

    // Validation
    const maxMB = 200;
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    const validExts = ['mp3','wav','m4a','aac','ogg','opus','flac','mp4','mov','mkv','webm'];
    if (f.size > maxMB * 1048576) {
      dzError.textContent = '❌ File too large (' + (f.size/1048576).toFixed(1) + ' MB). Max is ' + maxMB + ' MB.';
      dzError.style.display = 'block';
      fileInput.value = '';
      return;
    }
    if (!validExts.includes(ext) && !f.type.startsWith('audio/') && !f.type.startsWith('video/')) {
      dzError.textContent = '❌ Unsupported format. Please use MP3, WAV, M4A, AAC, OGG, FLAC, or MP4.';
      dzError.style.display = 'block';
      fileInput.value = '';
      return;
    }

    // Show card
    dzEmpty.style.display = 'none';
    dzCard.style.display = 'flex';
    $('dz-file-name').textContent = f.name;
    $('dz-file-size').textContent = (f.size / 1048576).toFixed(1) + ' MB';
    $('dz-file-fmt').textContent = ext.toUpperCase();
    $('dz-file-icon').textContent = f.type.startsWith('video/') ? '🎬' : '🎵';

    // Audio preview + duration + waveform
    try {
      const url = URL.createObjectURL(f);
      const audio = $('dz-audio');
      audio.src = url;
      audio.onloadedmetadata = () => {
        if (isFinite(audio.duration)) {
          const m = Math.floor(audio.duration / 60), s = Math.floor(audio.duration % 60);
          let txt = m + ':' + String(s).padStart(2, '0') + ' min';
          if (audio.duration > 3600) txt += ' (long — be patient 🤲)';
          $('dz-file-dur').textContent = txt;
        }
        drawWaveform(f);
      };
    } catch (e) { /* ignore */ }
  }

  /* Waveform visualization */
  function drawWaveform(f) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const reader = new FileReader();
      reader.onload = e => {
        ctx.decodeAudioData(e.target.result, buf => {
          const data = buf.getChannelData(0);
          const canvas = $('wave-canvas');
          const x = canvas.getContext('2d');
          const W = canvas.width, H = canvas.height;
          x.clearRect(0, 0, W, H);
          x.fillStyle = '#d4af6a';
          const step = Math.floor(data.length / W);
          for (let i = 0; i < W; i++) {
            let sum = 0;
            for (let j = 0; j < step; j += 10) sum += Math.abs(data[i * step + j] || 0);
            const h = Math.min(H, (sum / (step / 10)) * H * 3);
            x.fillRect(i, (H - h) / 2, 1, h);
          }
          ctx.close();
        }, () => ctx.close());
      };
      reader.readAsArrayBuffer(f.slice(0, 10 * 1048576)); // first 10MB for speed
    } catch (e) { /* waveform is best-effort */ }
  }

  /* ------------------------------------------------------- job history */
  const HISTORY_KEY = 'qs_jobs_v1';
  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function saveHistory(h) {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(h.slice(0, 20))); }
    catch (e) { /* storage full/blocked: history is best-effort */ }
  }
  function addToHistory(jobId, label) {
    const h = loadHistory().filter(j => j.job_id !== jobId);
    h.unshift({ job_id: jobId, label: label || 'Recitation', ts: Date.now() });
    saveHistory(h);
    renderHistory();
  }
  function renderHistory() {
    const h = loadHistory();
    const card = $('history-card'), list = $('history-list');
    if (!h.length) { card.style.display = 'none'; return; }
    card.style.display = 'block';
    list.innerHTML = h.map(j =>
      '<button class="history-item" data-job="' + esc(j.job_id) + '">'
      + '<span class="history-label">' + esc(j.label) + '</span>'
      + '<span class="hint">' + esc(new Date(j.ts).toLocaleString()) + '</span>'
      + '<span class="pill">' + esc(j.job_id.slice(0, 8)) + '</span>'
      + '</button>'
    ).join('');
    list.querySelectorAll('.history-item').forEach(b =>
      b.addEventListener('click', () => attachToJob(b.getAttribute('data-job'))));
  }

  /* --------------------------------------------------------- verification */
  function statusLine(data) {
    let line = esc(data.stage || 'Processing…');
    const bits = [];
    if (data.queue_position) bits.push('queue #' + data.queue_position);
    if (data.eta_seconds != null && data.status === 'processing')
      bits.push('~' + fmtTime(data.eta_seconds) + ' left');
    bits.push(Math.round(data.progress || 0) + '%');
    line += '<br><span class="hint">' + bits.join(' · ')
      + ' — live updates; a refresh never loses this job.</span>';
    return line;
  }
  function showLiveTranscript(text) {
    const box = $('live-transcript');
    if (!text || !text.trim()) { box.style.display = 'none'; return; }
    box.style.display = 'block';
    $('live-text').textContent = text;
  }

  btnVerify.addEventListener('click', async () => {
    // FYP STUDY GUIDE (P2→P1 integration): a new verification must silence any
    // still-speaking Coach word chip — speech from the OLD recitation must
    // never bleed into the new one. Guarded in case voice_qa/coach speech is
    // unavailable on this browser.
    if (window.qsStopCoachSpeech) window.qsStopCoachSpeech();
    resetSteps(); // V-2: fresh ①②③④ tracker for this verification
    // RECORD-LIVE RESTORE (2026-11-04): pick the audio by `audioSource` —
    // the user's last explicit choice — NEVER by "whichever variable is
    // non-null" (v116 P1 stale-audio fix).
    let file = null;
    let filename = 'recording' + recordedExt;
    let label = 'Recitation';
    if (audioSource === 'upload') {
      file = fileInput.files[0] || null;
      if (file) { filename = file.name; label = file.name; }
    } else if (audioSource === 'recording') {
      file = recordedBlob;
    }
    if (!file || polling) return;

    polling = true;
    btnVerify.classList.remove('pulse');
    btnVerify.textContent = '⏳ Verifying…';
    refreshVerifyButton();
    setProgress(4);
    setStep(3);
    showStatus('Uploading your audio…');
    btnCancel.style.display = 'none';
    $('live-transcript').style.display = 'none';
    $('transcript-card').style.display = 'none';
    $('results-card').style.display = 'none';

    const fd = new FormData();
    fd.append('file', file, filename);

    // Upload progress bar (XHR gives us progress events).
    await new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      uploadXhr = xhr; // V-7: Cancel can abort this mid-upload
      btnCancel.style.display = ''; // V-7: Cancel available during the XHR phase too
      btnCancel.disabled = false;
      xhr.open('POST', '/api/verify');
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) setProgress(2 + 8 * e.loaded / e.total);
      };
      // FYP STUDY GUIDE (V-7): one cleanup for all upload outcomes — success
      // hands off to attachToJob (which re-shows Cancel itself); every other
      // outcome hides Cancel, drops the XHR handle and restores idle UI.
      const uploadDone = () => {
        uploadXhr = null;
        btnCancel.style.display = 'none';
        progressEl.style.display = 'none';
        btnVerify.textContent = '✨ Verify recitation';
        resolve();
      };
      xhr.onload = () => {
        let data = {};
        try { data = JSON.parse(xhr.responseText); } catch (e) { /* ignore */ }
        if (xhr.status === 202 && data.job_id) {
          addToHistory(data.job_id, label);
          uploadXhr = null; // attachToJob owns the flow now; btnCancel deletes the job
          resolve();
          attachToJob(data.job_id);
        } else {
          showStatus(submitErrorMessage(xhr.status, data)
            + (data.request_id ? '<br><span class="hint">Reference: ' + esc(data.request_id) + '</span>' : ''), 'error');
          polling = false; refreshVerifyButton();
          uploadDone();
        }
      };
      xhr.onerror = () => {
        showStatus(networkErrorMessage(), 'error');
        polling = false; refreshVerifyButton();
        uploadDone();
      };
      // V-7: user-cancelled upload — no job was ever created.
      xhr.onabort = () => {
        polling = false;
        refreshVerifyButton();
        showStatus('⏹️ Cancelled. Upload again any time to retry. / Dobara upload karke retry karein.', '');
        uploadDone();
      };
      xhr.send(fd);
    });
  });

  function stopStreams() {
    if (eventSource) { try { eventSource.close(); } catch (e) { /* ignore */ } eventSource = null; }
    if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
  }

  function attachToJob(jobId) {
    stopStreams();
    resetSteps(); // V-2: re-attaching (history click / new job) restarts ①②③④
    activeJobId = jobId;
    polling = true;
    refreshVerifyButton();
    btnCancel.style.display = '';
    setStep(3);
    setProgress(4);
    $('transcript-card').style.display = 'none';
    $('results-card').style.display = 'none';
    showStatus('Connecting to live updates…');

    // Prefer Server-Sent Events; fall back to polling if it fails.
    let sseOpened = false;
    try {
      eventSource = new EventSource('/api/jobs/' + encodeURIComponent(jobId) + '/events');
      eventSource.onmessage = (ev) => {
        sseOpened = true;
        let data = {};
        try { data = JSON.parse(ev.data); } catch (e) { return; }
        handleJobUpdate(data);
      };
      eventSource.onerror = () => {
        if (!sseOpened) { stopStreams(); pollJob(jobId, 0); }  // SSE unsupported/blocked
        // else: transient drop — the server keeps the job; EventSource auto-reconnects.
      };
      // Safety: if SSE never opens within 6s, fall back to polling.
      setTimeout(() => { if (!sseOpened && activeJobId === jobId) { stopStreams(); pollJob(jobId, 0); } }, 6000);
    } catch (e) {
      pollJob(jobId, 0);
    }
  }

  btnCancel.addEventListener('click', async () => {
    // V-7: an upload still in its XHR phase has no job yet — abort it.
    // (xhr.onabort restores the UI; nothing else to do here.)
    if (uploadXhr) {
      btnCancel.disabled = true;
      try { uploadXhr.abort(); } catch (e) { /* ignore */ }
      btnCancel.disabled = false;
      return;
    }
    if (!activeJobId) return;
    btnCancel.disabled = true;
    try {
      await fetch('/api/jobs/' + encodeURIComponent(activeJobId), { method: 'DELETE' });
    } catch (e) { /* ignore: the next update will show the real state */ }
    btnCancel.disabled = false;
  });

  function handleJobUpdate(data) {
    if (!data || data.job_id !== activeJobId) return;
    setProgress(data.progress || 5);
    if (data.partial_text) showLiveTranscript(data.partial_text);

    if (data.status === 'done' && data.result) {
      finishJob();
      renderResults(data.result, data.job_id);
      const r = data.result;
      showStatus('✅ Done in ' + r.processing_seconds + 's on ' + r.device
        + ' · ' + r.realtime + '× realtime'
        + '<br><span class="hint">Reference: ' + esc(r.request_id) + '</span>', 'ok');
      return;
    }
    if (data.status === 'error') {
      finishJob();
      showStatus('❌ ' + esc(data.error || 'Verification failed. Please try a clearer recording.'), 'error');
      return;
    }
    if (data.status === 'cancelled' || data.cancelled) {
      finishJob();
      showStatus('⏹️ Cancelled. Upload again any time to retry.', '');
      return;
    }
    showStatus(statusLine(data));
  }

  function finishJob() {
    stopStreams();
    polling = false;
    activeJobId = null;
    btnCancel.style.display = 'none';
    $('live-transcript').style.display = 'none';
    // Reset verify button to its default state for the next run.
    btnVerify.textContent = '✨ Verify recitation';
    btnVerify.classList.remove('pulse');
    refreshVerifyButton();
  }

  async function pollJob(jobId, netFails) {
    if (activeJobId !== jobId) return;
    let res, data;
    try {
      res = await fetch('/api/jobs/' + encodeURIComponent(jobId));
      data = await res.json();
    } catch (e) {
      netFails++;
      if (activeJobId !== jobId) return;
      if (netFails > 12) {
        finishJob();
        showStatus('❌ Lost connection to the server. Your audio may still be processing — '
          + 'reopen this page and pick the job from “Recent verifications”.', 'error');
        return;
      }
      showStatus('Connection hiccup — retrying… (' + netFails + ')');
      pollTimer = setTimeout(() => pollJob(jobId, netFails), 2500);
      return;
    }
    if (activeJobId !== jobId) return;
    if (!res.ok) {
      finishJob();
      if (res.status === 404) showStatus('❌ This verification expired on the server (30 min). Please upload your audio again.', 'error');
      else showStatus(submitErrorMessage(res.status, data), 'error');
      return;
    }
    handleJobUpdate(data);
    if (data.status === 'queued' || data.status === 'processing') {
      pollTimer = setTimeout(() => pollJob(jobId, 0), 2500);
    }
  }

  /* -------------------------------------------------------------- results */
  function labelPill(label) {
    if (label.indexOf('VERIFIED') === 0) return 'ok';
    if (label.indexOf('SEQUENCE') === 0) return 'warn';
    if (label.indexOf('LOW') === 0) return 'bad';
    return 'info';
  }

  let lastTranscript = '';
  /* ------- graceful degradation: transcription-confidence banner (TEAM 10) */
  function transcriptionState(d) {
    // Returns 'none' | 'low' | 'ok'.
    // d.coverage is null after a manual re-match (user fixed it themselves):
    // the banner must not fire then.
    if (d.coverage == null) return 'ok';
    if (!d.results || !d.results.length) return 'none';
    if (d.coverage < 85) return 'low';
    if (d.verified_count === 0) return 'low';
    return 'ok';
  }
  function showFallbackBanner(state) {
    const fb = $('fallback-banner');
    if (state === 'ok') {
      fb.style.display = 'none';
      $('btn-edit-transcript').classList.remove('pulse');
      return;
    }
    if (state === 'none') {
      $('fallback-text').innerHTML =
        'No ayah could be confidently matched from this audio. The transcription looks uncertain — '
        + 'this is usually background noise or fast recitation, <b>not</b> a wrong recitation. '
        + 'Try one of the fixes below:<br><span class="hint">(AI ne shayad kuch ghalat suna hai — aam tor par wajah shor ya tez tilawat hoti hai.)</span>';
    } else {
      $('fallback-text').innerHTML =
        'The AI may have misheard parts of your recitation, so some results are only guesses. '
        + 'This is usually background noise or fast recitation, <b>not</b> a wrong recitation. '
        + 'Pick a fix below:<br><span class="hint">(AI ne shayad kuch alfaaz ghalat sunay hain — aam tor par wajah shor ya tez tilawat hoti hai.)</span>';
    }
    fb.style.display = 'block';
    // Make Edit prominent exactly when it matters (proposal #2).
    $('btn-edit-transcript').classList.add('pulse');
    setTimeout(() => { fb.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 400);
  }
  $('fb-edit').addEventListener('click', enterEditMode);
  // RECORD-LIVE RESTORE (2026-11-04): reverted to scroll-to-the-recorder
  // with recording wording (was retargeted to the upload dropzone on removal).
  $('fb-rerecord').addEventListener('click', () => {
    const box = $('recorder-box');
    if (box) box.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showStatus('🎙️ <b>For a clearer result:</b> record a shorter, clearer clip — quiet room · phone 15–20 cm from your mouth · '
      + 'one ayah at a time. Then press <b>Verify recitation</b>.');
  });

  function renderResults(d, jobId) {
    setProgress(100);
    setStep(4);
    lastTranscript = d.transcript || '';
    $('transcript-card').style.display = 'block';
    $('transcript').textContent = lastTranscript || '(empty)';
    $('transcript-meta').textContent = d.recognized_words + ' words recognized · ' + d.duration + 's audio'
      + (d.coverage == null ? '' : ' · coverage ' + d.coverage + '%');
    /* PROFESSIONAL quality gate (noise warning): show BEFORE the user blames
       their recitation. d.warnings comes from the backend audio assessment. */
    const wbox = $('quality-warnings');
    if (wbox) {
      const warns = (d.warnings || []).filter(w => w && w.message);
      if (warns.length) {
        wbox.innerHTML = warns.map(w =>
          '<div class="warn-chip">🔊 ' + String(w.message).replace(/</g, '&lt;') + '</div>'
        ).join('');
        wbox.style.display = 'block';
      } else {
        wbox.style.display = 'none';
        wbox.innerHTML = '';
      }
    }
    if (jobId) {
      ['txt', 'srt', 'vtt', 'json'].forEach(f => {
        $('dl-' + f).href = '/api/jobs/' + encodeURIComponent(jobId) + '/transcript.' + f;
      });
    }

    $('results-card').style.display = 'block';
    const state = transcriptionState(d);
    showFallbackBanner(state);
    const box = $('results');
    if (!d.results || !d.results.length) {
      box.innerHTML = '<p class="muted">See the suggestions above ↑</p>';
      return;
    }
    box.innerHTML = '<p><span class="pill ok">' + d.verified_count + ' verified</span> '
      + '<span class="muted small">of ' + d.results.length + ' candidate ayat</span></p>'
      + d.results.map(r =>
        '<div class="card result-card" style="margin:12px 0">'
        + '<div><strong>Surah ' + r.surah + ' · Ayah ' + r.ayah + '</strong></div>'
        + '<div class="result-meta">'
        + '<span class="pill ' + labelPill(r.label) + '">' + esc(r.label) + '</span>'
        /* V-10: these pills were unexplained jargon ("sequence 82%" reads as
           "82% correct"). Bilingual tooltips explain what each number means —
           notably that sequence is word-order match, NOT a correctness score. */
        + '<span class="pill" title="Confidence — AI kitna sure hai ke ye ayat sahi match hui / how sure the AI is this match is correct">confidence ' + r.confidence + '%</span>'
        + '<span class="pill" title="Coverage — aapki transcription ka kitna hissa is ayat se mila / how much of the transcription matched this ayah">coverage ' + r.coverage + '%</span>'
        + '<span class="pill" title="Sequence — alfaaz ki tartib kitni mili; ye sahi-parhne ka score NAHI hai / word-order match, NOT a correctness score">sequence ' + r.sequence + '%</span>'
        + '</div>'
        + '<div class="arabic" dir="rtl">' + esc(r.text) + '</div>'
        + (r.translation_en ? '<div class="translation"><strong>EN:</strong> ' + esc(r.translation_en) + '</div>' : '')
        + (r.translation_ur ? '<div class="translation" dir="rtl" style="text-align:right;border-right:none;border-left:3px solid var(--gold);padding-right:0;padding-left:14px"><strong>UR:</strong> ' + esc(r.translation_ur) + '</div>' : '')
        + (r.reason ? '<p class="hint">' + esc(r.reason) + '</p>' : '')
        + '</div>'
      ).join('');
    /* 🎯 Quran Coach: render per-ayah coaching feedback (identify + teach).
       d.coaching comes from the backend (service.verify / /api/rematch). */
    renderCoach(d.coaching);
    setTimeout(() => { progressEl.style.display = 'none'; barEl.style.width = '0'; progressEl.setAttribute('aria-valuenow', '0'); }, 1200);
  }

  /* ------------------------------------------------------- coach feedback */
  /* TEAM 2 (P2): FYP STUDY GUIDE — word chips in Coach feedback can now be
     tapped to HEAR the correct (expected) pronunciation of that word only.
     This uses the browser's built-in speechSynthesis (no network, no
     re-upload, no re-verify). Words are tracked so a second tap toggles
     (stops) the speech, and stopCoachSpeech() lets the verify flow silence
     word audio before a new verification starts. Display/UX only — verdict
     logic is untouched. */
  let coachSpeakingWord = null; // the data-say-word value currently being spoken, if any
  /* TEAM 3 (2026-10-22): cached voice list — on Android Chrome
     getVoices() can return [] until the async 'voiceschanged' event fires,
     so a fresh call per tap misses installed voices. Cache + refresh,
     exactly like voice_qa.js does. */
  let coachVoices = [];
  function refreshCoachVoices() {
    try { coachVoices = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; }
    catch (e) { coachVoices = []; }
  }
  refreshCoachVoices();
  try {
    if (window.speechSynthesis && typeof window.speechSynthesis.addEventListener === 'function')
      window.speechSynthesis.addEventListener('voiceschanged', refreshCoachVoices);
    else if (window.speechSynthesis)
      window.speechSynthesis.onvoiceschanged = refreshCoachVoices;
  } catch (e) { /* ignore */ }
  function coachArVoice() {
    try {
      const v = coachVoices || [];
      return v.find(x => (x.lang || '').toLowerCase().startsWith('ar-sa'))
          || v.find(x => (x.lang || '').toLowerCase().startsWith('ar'))
          || null;
    } catch (e) { return null; }
  }
  /* TEAM 3 (2026-10-22): generation token for Coach word speech — the same
     idea as voice_qa.js's speakGen / duas.js's duaGen, which verify.js never
     got. FYP STUDY GUIDE: speechSynthesis.cancel() fires an ASYNC 'error'
     (canceled) event on the utterance it kills. WITHOUT a token, that stale
     onerror runs AFTER the new tap's speakWord already set
     coachSpeakingWord — clearing the NEW call's state, so tapping a speaking
     chip no longer stops it (toggle desync). Also, because the new speak()
     is deferred (see speakWord), a tap already superseded by stopCoachSpeech
     (e.g. renderCoach silencing old audio) must never start speaking later.
     Every speakWord bumps the token; stopCoachSpeech bumps it too; stale
     callbacks/deferred starts that no longer own the token ignore
     themselves. The token NEVER blocks the current call — it only guards
     stale ones. */
  let coachSpeakGen = 0;
  let coachNoArVoiceWarned = false; // one-time honest warning per page load
  function speakWord(word, el) {
    // FYP STUDY GUIDE: speak JUST this word. cancel() first so a new tap
    // never overlaps the old utterance, then prefer an Arabic voice.
    // `el` (optional): the exact element that was tapped — it gets the
    // .speaking indicator directly (covers the 👂 "hear misheard" buttons).
    // Chip taps reach here via sayWordToggle without `el`; those are found
    // below by their data-say-word attribute.
    if (!('speechSynthesis' in window) || !word) return;
    try {
      const ss = window.speechSynthesis;
      const myGen = ++coachSpeakGen; // claim this tap's generation
      const u = new SpeechSynthesisUtterance(word);
      // FYP STUDY GUIDE: u.lang is ALWAYS set to 'ar-SA' so pronunciation
      // rules are right even when no Arabic voice is installed; u.voice
      // picks the best installed Arabic voice when one exists — same
      // fallback ranking as voice_qa.js (ar-SA → ar → browser default).
      u.lang = 'ar-SA';
      u.rate = 0.8; // slow enough to learn the pronunciation from
      const v = coachArVoice();
      if (v) u.voice = v;
      else if (!coachNoArVoiceWarned) {
        // Never fail silently: his phone has no Arabic TTS voice, so the
        // browser's default voice will try (it may mispronounce or stay
        // silent). Tell him ONCE how to fix it properly.
        coachNoArVoiceWarned = true;
        showStatus('⚠️ Phone me Arabic awaz install nahi — Settings → Text-to-speech → Google TTS → Arabic voice add karein taake sahi adaigi sunai de. / No Arabic voice installed — add one in your TTS settings.', 'warn');
      }
      coachSpeakingWord = word;
      markSpeakingChip(word, el);
      const clearBoth = () => {
        if (myGen !== coachSpeakGen) return; // stale: killed by a newer tap
        coachSpeakingWord = null; clearSpeakingChips();
      };
      u.onend = clearBoth;
      u.onerror = clearBoth;
      const start = () => {
        if (myGen !== coachSpeakGen) return; // superseded — stay silent
        try { ss.speak(u); }
        catch (e) { coachSpeakingWord = null; clearSpeakingChips(); }
      };
      // FYP STUDY GUIDE: Chrome (esp. Android) silently DROPS a speak()
      // that immediately follows cancel() — no sound, no onend, no onerror.
      // So we cancel ONLY when something is actually queued/playing, and we
      // start the new utterance on the next task, giving cancel()'s teardown
      // a moment to settle. A tap with nothing playing speaks immediately.
      if (ss.speaking || ss.pending) {
        try { ss.cancel(); } catch (e) { /* ignore */ }
        setTimeout(start, 80);
      } else start();
    } catch (e) { coachSpeakingWord = null; clearSpeakingChips(); }
  }
  function stopCoachSpeech() {
    // FYP STUDY GUIDE: hard stop for word audio; safe to call any time.
    // Bumping the generation first guarantees no deferred start() or stale
    // onerror from the killed speech can touch the new call's state.
    coachSpeakGen++;
    try { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    coachSpeakingWord = null;
    clearSpeakingChips();
  }
  /* C-5 (2026-10-22): visible "which word is speaking" indicator.
     FYP STUDY GUIDE — we toggle a .speaking class on the active chip/button
     so the user can SEE which word is talking (and that tapping it again
     stops it — no more blind repeated taps). Chip HTML strings are NOT
     rebuilt here (Team 1 owns them); we only add/remove a class on nodes
     already in the DOM. coachSpeakingWord stays the single source of truth,
     and the class is cleared on EVERY end/error/stop path so it can never
     get stuck "on". */
  function clearSpeakingChips() {
    document.querySelectorAll('.coach-sayable.speaking, .coach-mini.speaking')
      .forEach(node => node.classList.remove('speaking'));
  }
  function markSpeakingChip(word, el) {
    clearSpeakingChips();
    if (el && el.classList) { el.classList.add('speaking'); return; }
    // compare getAttribute values directly (no CSS-escaping needed for
    // Arabic) — every chip carrying this data-say-word lights up.
    document.querySelectorAll('[data-say-word]').forEach(chip => {
      if (chip.getAttribute('data-say-word') === word) chip.classList.add('speaking');
    });
  }
  function sayWordToggle(word) {
    // FYP STUDY GUIDE: toggle per chip — tapping the word that is already
    // being spoken stops it; any other tap stops the old and speaks the new.
    if (coachSpeakingWord === word && window.speechSynthesis.speaking) stopCoachSpeech();
    else speakWord(word);
  }
  /* WORD PRACTICE (2026-10-22): "sahi lafz record karo". A tiny self-contained
     recorder (separate from the page's main recorder so states never clash):
     records up to 4s, POSTs to /api/practice-word, shows ✅/❌ inline.
     FYP STUDY GUIDE: the server does the honest fuzzy check; the frontend
     only displays the verdict — never decides correctness itself. */
  let practiceRec = null; // active practice MediaRecorder, if any
  let coachLegendShown = false; // TEAM 1 (2026-10-22, C-2): one-line button legend, first render only
  async function practiceWord(btn) {
    const expected = btn.getAttribute('data-practice-word') || '';
    /* FYP STUDY GUIDE (Team 3, 2026-10-22): the verdict <span> sits DIRECTLY
       after its own 🎙️ button in the chip markup ([sayable][👂][🎙️]<span …>).
       The old code used btn.parentElement.querySelector('.coach-practice-res'),
       which ALWAYS returns the FIRST span in the whole card — so with two or
       more practice words, the ✅/❌ for word #2 appeared next to word #1,
       attributing the verdict to the WRONG word. nextElementSibling targets
       this chip's own span; the parent query stays only as a fallback. */
    const sib = btn.nextElementSibling;
    const resEl = (sib && sib.classList && sib.classList.contains('coach-practice-res'))
      ? sib
      : (btn.parentElement ? btn.parentElement.querySelector('.coach-practice-res') : null);
    const say = (t) => { if (resEl) resEl.textContent = t; };
    if (practiceRec) { try { practiceRec.stop(); } catch (e) { /* ignore */ } return; }
    if (!expected) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      say('Mic available nahi / Mic not available'); return;
    }
    stopCoachSpeech();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chunks = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
      rec.onstop = async () => {
        try { stream.getTracks().forEach(t => t.stop()); } catch (e) { /* ignore */ }
        practiceRec = null;
        btn.textContent = '🎙️';
        const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
        if (!blob.size) { say('Kuch record nahi hua / Nothing recorded'); return; }
        say('⏳ Check ho raha hai...');
        try {
          const fd = new FormData();
          fd.append('file', blob, 'practice.webm');
          fd.append('expected', expected);
          const r = await fetch('/api/practice-word', { method: 'POST', body: fd });
          let j = {};
          try { j = await r.json(); } catch (e) { /* ignore */ }
          if (!r.ok) { say('❌ ' + (j.detail || ('Error ' + r.status))); return; }
          const heardShort = (j.heard || '').slice(0, 60);
          say(j.match
            ? '✅ MashaAllah! Bilkul sahi parha'
            : '❌ Ye sunai diya: «' + heardShort + '» — dobara koshish karein');
        } catch (e) { say('❌ Network error — dobara try karein'); }
      };
      practiceRec = rec;
      btn.textContent = '⏹️';
      say('🎙️ Boliye... (dobara dabayein ya 4 second)');
      rec.start();
      setTimeout(() => {
        if (practiceRec === rec && rec.state === 'recording') { try { rec.stop(); } catch (e) { /* ignore */ } }
      }, 4000);
    } catch (e) { say('Mic ki ijazat nahi mili / Mic permission denied'); }
  }
  /* Exposed for Team 1's verify-click handler so a new verification silences
     any in-progress word speech (we do NOT touch that handler ourselves). */
  window.qsStopCoachSpeech = stopCoachSpeech;
  /* C-7 (2026-10-22): ⏭️ for a skipped ("missing") ayah — 🔇 universally
     reads as "muted audio" and made users think the sound had failed. */
  function coachIcon(status) {
    return status === 'perfect' ? '✅' : (status === 'missing' ? '⏭️' : '🎯');
  }
  function renderCoach(coaching) {
    const box = $('coach-feedback');
    if (!box) return;
    /* TEAM 2 (P2): re-rendering silences any in-progress word audio so a
       fresh verification never talks over itself. */
    stopCoachSpeech();
    if (!coaching || !coaching.ayat || !coaching.ayat.length) {
      /* TEAM 1 (2026-10-22, C-15): a silent empty state looks broken.
         Say it in one line instead. */
      box.style.display = 'block';
      box.innerHTML = '<h3 style="margin:4px 0 10px">🎯 Coach Feedback</h3>'
        + '<p class="muted">Coach feedback is unavailable for this result.'
        + '<br><span class="hint">Is natijay ke liye Coach feedback uplabdh nahi.</span></p>';
      return;
    }
    const s = coaching.summary || {};
    let html = '<h3 style="margin:4px 0 10px">🎯 Coach Feedback</h3>'
      + '<div class="coach-summary">🌟 ' + esc(s.message_en || '')
      + (s.message_ur ? '<br><span class="hint">' + esc(s.message_ur) + '</span>' : '')
      + '</div>';
    /* TEAM 1 (2026-10-22, C-2): the 🎙️/👂/🔊 buttons' meaning lived only in
       `title` tooltips, which never appear on phones. Explain once, on the
       first render of the session — every card after that stays compact. */
    if (!coachLegendShown) {
      coachLegendShown = true;
      html += '<p class="coach-legend">🔊 = sahi adaigi suno · 👂 = AI ne kya suna · 🎙️ = khud bolo, foran check</p>';
    }
    html += coaching.ayat.map((a, i) =>
      '<div class="coach-card coach-' + esc(a.status || 'needs_work') + '">'
      + '<div class="coach-head">' + coachIcon(a.status) + ' <span>Surah ' + a.surah + ' · Ayah ' + a.ayah + '</span></div>'
      /* P3 (2026-10-21): show the ayah's Arabic text on EVERY Coach card —
         even "perfect" ones previously had no Arabic. Guarded: if the
         backend didn't send text, no empty line is rendered. */
      + (a.text ? '<p class="coach-ayah" dir="rtl">' + esc(a.text) + '</p>' : '')
      + '<p class="coach-msg">' + esc(a.message_en || '') + '</p>'
      + (a.message_ur ? '<p class="coach-msg hint">' + esc(a.message_ur) + '</p>' : '')
      + ((a.missed_words && a.missed_words.length)
          /* TEAM 1 (2026-10-22, C-1/A-2/A-3): group heading so users see what
             these pills mean; real <button>s (not spans) so keyboard and
             screen readers can reach tap-to-speak; explicit aria-labels
             because title="" is ignored by many mobile screen readers. */
          ? '<div class="coach-group-label">🔴 Chhoote hue alfaaz / Missed words</div>'
            + '<div>' + a.missed_words.map(w => '<button type="button" class="coach-missed coach-sayable" dir="rtl" data-say-word="' + esc(w) + '" title="Suno — is lafz ki sahi adaigi / Hear the correct pronunciation" aria-label="Hear correct pronunciation of ' + esc(w) + ' — sahi adaigi sunein">' + esc(w) + '<span class="coach-say" aria-hidden="true">🔊</span></button><button type="button" class="coach-mini" data-practice-word="' + esc(w) + '" title="Is lafz ko khud bol kar record karein — foran check hoga / Record yourself saying this word" aria-label="Record yourself saying ' + esc(w) + ' — khud bol kar record karein">🎙️</button><span class="coach-practice-res" aria-live="polite"></span>').join('') + '</div>'
          : '')
      /* PROFESSIONAL REDESIGN Stage 4-lite: substituted (mispronounced)
         words shown as expected → heard, with the heard word's timing. */
      + ((a.substituted_words && a.substituted_words.length)
          /* TEAM 1 (2026-10-22, C-1/A-2/A-3/C-4/C-6):
             - heading labels this group (mispronounced);
             - real <button> with aria-label (keyboard/SR access);
             - 👂 keeps the AI's (mis)heard guess but carries an explicit
               WARNING aria-label + ⚠️ title so nobody mistakes it for the
               correct pronunciation — hearing the error spoken confidently
               can otherwise teach it;
             - RTL bidi fix: ← (not →) inside dir="rtl" so the arrow can't
               look like it points at the wrong word; each word in <bdi> so
               mixed-script words can't reorder. */
          ? '<div class="coach-group-label">🟡 Ghalat adaigi / Mispronounced</div>'
            + '<div class="coach-sub">' + a.substituted_words.map(p =>
              /* TEAM 2 (P2): speak the ref (expected) word p[0], never the
                 misheard p[1] — the learner must hear the CORRECT one. */
              '<button type="button" class="coach-subbed coach-sayable" dir="rtl" data-say-word="' + esc(p[0]) + '" title="Is lafz ki jagah ye sunai diya — tap karke SAHI adaigi sunein / The AI heard this instead — tap to hear the CORRECT pronunciation" aria-label="Hear correct pronunciation of ' + esc(p[0]) + ' — sahi adaigi sunein">'
              + '<bdi>' + esc(p[0]) + '</bdi> <span class="coach-arrow" aria-hidden="true">←</span> <bdi>' + esc(p[1]) + '</bdi><span class="coach-say" aria-hidden="true">🔊</span></button>'
              + '<button type="button" class="coach-mini" data-hear-heard="' + esc(p[1]) + '" title="⚠️ Ye woh hai jo AI ne GHALAT suna tha — sahi adaigi NAHI / Warning: what the AI misheard — NOT the correct pronunciation" aria-label="Warning: this is what the AI misheard, not the correct pronunciation — AI ne jo ghalat suna tha">👂</button>'
              + '<button type="button" class="coach-mini" data-practice-word="' + esc(p[0]) + '" title="Is lafz ko khud bol kar record karein — foran check hoga / Record yourself saying this word" aria-label="Record yourself saying ' + esc(p[0]) + ' — khud bol kar record karein">🎙️</button><span class="coach-practice-res" aria-live="polite"></span>'
            ).join('') + '</div>'
          : '')
      /* ADR-0010: "uncertain" words — the AI itself doubts what it heard.
         Shown honestly, NEVER counted as a mistake. Blue = "not sure",
         not red/amber = "wrong". */
      + ((a.uncertain_words && a.uncertain_words.length)
          /* TEAM 1 (2026-10-22, C-1/A-2/A-3/C-4/C-6): same treatment as
             mispronounced chips, EXCEPT the 👂 button is REMOVED entirely —
             on uncertain chips the AI's guess may be garbage syllables and
             speaking them can teach the learner the wrong sound. */
          ? '<div class="coach-group-label">🔵 AI sure nahi / Uncertain</div>'
            + '<div class="coach-sub">' + a.uncertain_words.map(p =>
              /* TEAM 2 (P2): uncertain chip speaks the ref (expected) word
                 p[0] — the reference, not the AI's uncertain guess p[1]. */
              '<button type="button" class="coach-uncertain coach-sayable" dir="rtl" data-say-word="' + esc(p[0]) + '" title="AI khud sure nahi ke yehi suna (aapki ghalti nahi) — tap karke SAHI adaigi sunein / The AI doubts its own hearing (not your mistake) — tap to hear the CORRECT pronunciation" aria-label="Hear correct pronunciation of ' + esc(p[0]) + ' — sahi adaigi sunein">'
              + '<bdi>' + esc(p[0]) + '</bdi> <span class="coach-arrow" aria-hidden="true">←</span> <bdi>' + esc(p[1]) + '</bdi>'
              + ' <span class="coach-q">?</span><span class="coach-say" aria-hidden="true">🔊</span></button>'
              + '<button type="button" class="coach-mini" data-practice-word="' + esc(p[0]) + '" title="Is lafz ko khud bol kar record karein — foran check hoga / Record yourself saying this word" aria-label="Record yourself saying ' + esc(p[0]) + ' — khud bol kar record karein">🎙️</button><span class="coach-practice-res" aria-live="polite"></span>'
            ).join('') + '</div>'
          : '')
      + ((a.status === 'needs_work' || a.status === 'missing')
          ? '<div class="coach-actions"><button class="btn btn-ghost btn-sm" data-coach-retry="' + i + '">🔁 Dobara parhein — Ayah ' + a.ayah + '</button></div>'
          : '')
      + '</div>'
    ).join('');
    box.innerHTML = html;
    box.style.display = 'block';
    /* TEAM 2 (P2): word chips are tappable — tap speaks just that word's
       CORRECT pronunciation (no re-upload, no re-verify); tapping the word
       that is already being spoken stops it. */
    box.querySelectorAll('[data-say-word]').forEach(chip => {
      chip.addEventListener('click', () => sayWordToggle(chip.getAttribute('data-say-word')));
    });
    /* P2-correction (2026-10-22): 👂 = jo (ghalat) sunai diya tha woh suno;
       🎙️ = sahi lafz khud record karo — /api/practice-word foran check karta hai. */
    box.querySelectorAll('[data-hear-heard]').forEach(b => {
      b.addEventListener('click', (e) => { e.stopPropagation(); speakWord(b.getAttribute('data-hear-heard'), b); });
    });
    box.querySelectorAll('[data-practice-word]').forEach(b => {
      b.addEventListener('click', (e) => { e.stopPropagation(); practiceWord(b); });
    });
    /* RECORD-LIVE RESTORE (2026-11-04): "Dobara parhein" scrolls back to the
       recorder again (was retargeted to the upload area on removal). */
    box.querySelectorAll('[data-coach-retry]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-coach-retry'), 10);
        const item = (coaching.ayat || [])[idx];
        const rec = document.querySelector('.verify-hero') || $('transcript-card');
        showStatus(item
          ? '🎙️ Ayah ' + item.ayah + ' akeli parhein — chhota clip = behtareen result. Phir Verify dabayein.'
          : '🎙️ Ek ayat akeli record karein, phir Verify dabayein.', 'ok');
        const target = $('recorder-box') || rec;
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
    });
  }

  $('btn-copy').addEventListener('click', async () => {
    if (!lastTranscript) return;
    try {
      await navigator.clipboard.writeText(lastTranscript);
      $('btn-copy').textContent = '✅ Copied';
    } catch (e) {
      // Clipboard API needs a secure context; fall back to selection.
      const ta = document.createElement('textarea');
      ta.value = lastTranscript;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); $('btn-copy').textContent = '✅ Copied'; }
      catch (err) { $('btn-copy').textContent = '❌ Copy failed'; }
      document.body.removeChild(ta);
    }
    setTimeout(() => { $('btn-copy').textContent = '📋 Copy'; }, 2000);
  });

  /* Edit transcript + re-match */
  function enterEditMode() {
    if (!lastTranscript) return;
    // Scroll the transcript card into view so the edit box is seen on mobile.
    const card = $('transcript-card');
    if (card) card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    $('transcript').style.display = 'none';
    const ta = $('transcript-edit');
    ta.value = lastTranscript;
    ta.style.display = 'block';
    $('rematch-row').style.display = 'block';
    $('btn-edit-transcript').style.display = 'none';
    $('btn-edit-transcript').classList.remove('pulse'); // its job is done now
    setTimeout(() => { try { ta.focus(); } catch (e) { /* ignore */ } }, 350);
  }
  $('btn-edit-transcript').addEventListener('click', enterEditMode);
  $('btn-cancel-edit').addEventListener('click', () => {
    $('transcript').style.display = 'block';
    $('transcript-edit').style.display = 'none';
    $('rematch-row').style.display = 'none';
    $('btn-edit-transcript').style.display = '';
    // If the fallback banner is still up, the Edit button matters again.
    if ($('fallback-banner').style.display === 'block') $('btn-edit-transcript').classList.add('pulse');
  });
  $('btn-rematch').addEventListener('click', async () => {
    const t = $('transcript-edit').value.trim();
    if (t.length < 2) { showStatus('❌ Please enter the corrected transcription.', 'error'); return; }
    $('btn-rematch').disabled = true;
    $('btn-rematch').textContent = '⏳ Matching…';
    try {
      const r = await fetch('/api/rematch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: t }),
      });
      if (!r.ok) throw new Error('rematch failed');
      const data = await r.json();
      lastTranscript = t;
      $('transcript').textContent = t;
      // renderResults expects full format
      renderResults({
        transcript: data.transcript,
        results: data.results,
        coaching: data.coaching, // 🎯 Coach works on re-matched transcripts too
        verified_count: data.verified_count,
        recognized_words: t.split(/\s+/).length,
        duration: 0,
        coverage: null, // user hand-fixed the text — "uncertain transcription" banner not applicable
      }, null);
      // Hide edit mode
      $('transcript').style.display = 'block';
      $('transcript-edit').style.display = 'none';
      $('rematch-row').style.display = 'none';
      $('btn-edit-transcript').style.display = '';
      showStatus('✅ Re-matched! ' + (data.count || 0) + ' ayat found.', 'ok');
    } catch (e) {
      showStatus('❌ Re-match failed. Please try again.', 'error');
    } finally {
      $('btn-rematch').disabled = false;
      $('btn-rematch').textContent = '🔄 Re-match';
    }
  });

  /* SPEAK-VERIFY — PORT + CONTINUOUS-MIC CHANGE (2026-11-04).
   * Ported from v116 verify.js setupSpeakVerify ("SPEAK-VERIFY REBUILD",
   * 2026-10-30): same card IDs, same guards (startBtn/textEl presence
   * check, SR availability branch, recGen/myRec stale-session guards,
   * joinTranscript single-space helper, refreshCheckBtn gating,
   * renderSpoken interim span, finals-only spokenText, Verify disabled
   * until spokenText length >= 2 plus checkBusy during fetch, button
   * shows "⏳ Matching…"), same /api/rematch + renderResults payload as
   * this copy's Re-match handler. This copy had NO speak-verify code at
   * all, so this is a port, not an edit of existing code.
   *
   * CHANGED vs v116 (user order, Roman Urdu: "mic stays ON as long as
   * the person keeps speaking; transcript contains exactly what was
   * spoken, nothing extra"):
   *  (a) rec.continuous = true — the mic keeps listening across natural
   *      pauses until the user taps "Rok dein" or "Verify karein". No
   *      per-utterance stop, no re-tap per segment.
   *  (b) Finals ONLY are ever committed. Interim renders in the faint
   *      span only. Within one session, session finals are REBUILT from
   *      the session's cumulative e.results on every onresult (as in
   *      v116), never appended across events, so a result can never
   *      count twice in-session. At session end / Rok dein / Verify,
   *      session finals move into committedFinal ONLY through
   *      appendOverlapAware (below), which strips a replayed overlap.
   *      This is the fix for the Fix 1 / Fix 2 failure on Android
   *      Chrome, where Chrome replays segments with different word
   *      tokenization and naive exact-string dedup scored 0: the
   *      comparison here is word-level with normalization ONLY
   *      (harakat/diacritics + punctuation stripped for comparison;
   *      stored words are never altered), longest suffix-of-committed
   *      == prefix-of-incoming is stripped, and an incoming chunk fully
   *      contained as a contiguous subsequence of committed words is
   *      dropped entirely.
   *  (c) Bounded auto-restart, no replay machinery: if recognition ends
   *      unexpectedly while the user has NOT stopped (listening intent
   *      still true), a new session starts WITHOUT re-committing
   *      anything; the new session's text goes through the same
   *      overlap-aware commit on its end. Hard bound: max 5 consecutive
   *      auto-restarts with no final result received; the counter
   *      resets whenever any final result arrives. Never restarts after
   *      user Stop / Clear / Verify, or on permission errors
   *      (not-allowed / service-not-allowed). On hitting the bound it
   *      stops with an honest Roman-Urdu status. A restart can never
   *      duplicate text (generation/myRec guards + overlap-aware commit).
   *      Status strings NEVER tell the user to re-tap while auto-restart
   *      is active; the listening status stays up across pauses.
   *  (d) Verify-tap mic-stop (DELIBERATE DEVIATION from v116): v116 left
   *      the mic running across Verify; here Verify FIRST commits-then-
   *      stops the mic (stopSpeak) so the posted text is exactly the
   *      committed finals, and no live session can append words to the
   *      text after it was posted. The committed text itself is kept,
   *      so Mic on again only adds the next segment.
   *  (e) Non-permission onerror (no-speech / network / audio-capture):
   *      does NOT stop the mic (v116 stopped on every error). The error
   *      is shown transiently and onend drives the bounded auto-restart,
   *      because in continuous mode a pause must not kill listening.
   *      Permission errors still stop immediately, no restart.
   * JS status/hint strings are Roman Urdu and never use "dabayein"
   * (v116 convention: "par click farmayen"). Driven in tests via the
   * button/text element IDs only, with a fake SpeechRecognition. */
  (function setupSpeakVerify() {
    const startBtn = $('btn-speak-verify-start'), stopBtn = $('btn-speak-verify-stop'),
          checkBtn = $('btn-speak-verify-check'), clearBtn = $('btn-speak-verify-clear'),
          textEl = $('speak-verify-text'), st = $('speak-verify-status'),
          checkHint = $('speak-verify-check-hint');
    if (!startBtn || !textEl) return;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      startBtn.disabled = true;
      if (stopBtn) stopBtn.disabled = true;
      if (checkBtn) checkBtn.disabled = true;
      if (st) st.textContent = 'Ye feature is browser me dastiyab nahi hai — Chrome ya Edge istemal farmayen.';
      if (checkHint) checkHint.textContent = 'Ye feature is browser me dastiyab nahi hai — Chrome ya Edge istemal farmayen.';
      return;
    }
    let rec = null, listening = false; // listening = user intent: mic is ON until Stop/Clear/Verify/bound/permission-error.
    let committedFinal = '';
    let sessionFinal = '';
    let checkBusy = false; // a fetch in flight keeps Verify disabled even if a live result refreshes the button state.
    let recGen = 0; // bumped whenever a session dies, so late results from the dead session can never write text.
    let restartsWithoutFinal = 0; // consecutive auto-restarts since the last final result; hard bound is 5.
    // Single-space joining helper, retained for display text only:
    // consecutive finals stay separate words (readable display AND
    // stable word-splitting for Verify), without double gaps. This is
    // joining, NOT dedup — no words are ever dropped by it.
    function joinTranscript(prev, next) {
      if (!prev) return next || '';
      if (!next) return prev;
      if (/\s$/.test(prev) && /^\s/.test(next)) return prev + next.replace(/^\s+/, '');
      return (/\s$/.test(prev) || /^\s/.test(next)) ? prev + next : prev + ' ' + next;
    }
    // Word splitter for the overlap-aware commit (display text is
    // untouched — this only decides what gets appended).
    function splitWords(text) {
      const t = text.trim();
      return t ? t.split(/\s+/) : [];
    }
    // Comparison-only normalization: strip Arabic harakat/diacritics
    // (tashkeel 064B-0652, superscript alef 0670, related marks) and
    // punctuation, then canonicalize hamza spelling variants (real
    // Chrome ASR output commonly varies them: أ/إ/آ vs ا, ؤ vs و,
    // ئ vs ي). The STORED words are never altered — only the
    // comparison copies are normalized. A token that normalizes to
    // empty falls back to its raw form, so empty can never falsely
    // equal empty across two different punctuation tokens.
    // NOTE: ranges are written as \u escapes, NOT literal characters —
    // a literal range starting at the wrong codepoint once swallowed
    // Arabic base letters too (U+0621-U+064A sit inside U+0610-U+0652),
    // emptying every word and silently disabling normalization.
    // NOTE (2026-11-04, harness case 3a): hamza canonicalization was
    // added because a replay delivered in plainer spelling (احد for
    // أَحَدٌ) otherwise fails both dedup rules and doubles the text.
    // Deliberately NOT mapped: ة/ه and ى/ي — those can distinguish
    // genuinely different words, so mapping them would risk dropping
    // real words; only pure hamza variants are canonicalized.
    function normalizeWord(w) {
      const n = w.replace(/[\u064B-\u0652\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED]/g, '').replace(/[^\p{L}\p{N}]/gu, '').replace(/[\u0622\u0623\u0625]/g, '\u0627').replace(/\u0624/g, '\u0648').replace(/\u0626/g, '\u064A');
      return n || w;
    }
    // OVERLAP-AWARE APPEND — the "nothing extra" guarantee. Appends
    // incomingText to committedFinal, except:
    //  1. if the incoming words appear fully as one contiguous
    //     subsequence of the committed words (Chrome replayed a whole
    //     earlier chunk, possibly re-tokenized), drop them entirely;
    //  2. otherwise strip the LONGEST suffix of committed words that
    //     equals a prefix of the incoming words (Chrome replayed the
    //     tail of the previous chunk at the new session's start), then
    //     append only the remainder.
    // Comparison is word-level on normalized words; appended words are
    // the original, unaltered incoming words.
    function appendOverlapAware(incomingText) {
      const inc = splitWords(incomingText);
      if (!inc.length) return;
      const com = splitWords(committedFinal);
      if (!com.length) { committedFinal = inc.join(' '); return; }
      const normCom = com.map(normalizeWord), normInc = inc.map(normalizeWord);
      // Rule 1: fully contained as a contiguous subsequence → drop.
      for (let s = 0; s + normInc.length <= normCom.length; s++) {
        let all = true;
        for (let k = 0; k < normInc.length; k++) {
          if (normCom[s + k] !== normInc[k]) { all = false; break; }
        }
        if (all) return;
      }
      // Rule 1b (2026-11-04, harness case 3b): re-tokenized FULL replay
      // — same words, different token boundaries (merged "بسمالله" /
      // split "و الله"). Word-level rules cannot see these, so compare
      // concatenation of normalized words: if the whole incoming text
      // concatenates to a substring of the committed concatenation, it
      // is a replay of already-committed words, drop it entirely.
      // Only FULL containment is dropped here, never partial
      // stripping: mapping a concatenated match back to incoming word
      // boundaries could split a word, so a PARTIAL merged/split
      // overlap (replay + genuinely new words in one chunk) remains a
      // known limitation and may still duplicate its replayed part.
      const concatCom = normCom.join('');
      const concatInc = normInc.join('');
      if (concatInc && concatCom.includes(concatInc)) return;
      // Rule 2: longest committed-suffix == incoming-prefix → strip it.
      let strip = 0;
      const max = Math.min(normCom.length, normInc.length);
      for (let len = max; len > 0; len--) {
        let ok = true;
        for (let k = 0; k < len; k++) {
          if (normCom[normCom.length - len + k] !== normInc[k]) { ok = false; break; }
        }
        if (ok) { strip = len; break; }
      }
      const rest = inc.slice(strip);
      if (!rest.length) return;
      committedFinal = com.concat(rest).join(' ');
    }
    // Move the current session's finals into committedFinal through the
    // overlap-aware append, then clear the session buffer. Idempotent
    // per session: sessionFinal is emptied, so a second call appends
    // nothing (and stale onend handlers are blocked by the gen guard).
    function commitSessionFinals() {
      const fin = sessionFinal.trim();
      sessionFinal = '';
      if (fin) appendOverlapAware(fin);
    }
    function setUI() {
      startBtn.disabled = listening;
      if (stopBtn) stopBtn.disabled = !listening;
      refreshCheckBtn();
    }
    // All finals so far: committed segments plus the current session's
    // finals, joined with exactly one space. Interim is never in here.
    function spokenText() {
      const acc = committedFinal.trim();
      const cur = sessionFinal.trim();
      return acc && cur ? acc + ' ' + cur : (acc || cur);
    }
    // "Verify karein" stays DISABLED until at least one final exists
    // (length >= 2) — a tap on a disabled button fires no click event,
    // so the always-visible hint next to the button IS the loud signal
    // for that tap; the early-return branch in the click handler stays
    // as belt-and-braces. Interim text never enables the button:
    // spokenText() contains finals only. Called from setUI and
    // renderSpoken, so every text mutation re-evaluates it; checkBusy
    // keeps the button disabled for the whole fetch even if a live
    // result refreshes the state mid-flight.
    function refreshCheckBtn() {
      if (!checkBtn) return;
      const hasFinals = spokenText().length >= 2;
      checkBtn.disabled = checkBusy || !hasFinals;
      if (checkHint) checkHint.textContent = checkBusy
        ? '⏳ Matching… — verification jaari hai, barah-e-karam intezar farmayen.'
        : hasFinals
        ? 'Tilawat mehfooz hai — Verify karein par click farmayen.'
        : 'Verify karein ke liye pehle Mic on kar ke kuch tilawat farmayen — alfaaz mehfooz hote hi button khud fa\'al ho jayega.';
    }
    function renderSpoken(interim) {
      refreshCheckBtn();
      const finals = spokenText();
      if (!finals && !interim) { textEl.textContent = 'Yahan live text zahir hoga…'; return; }
      // Interim text is NOT committed text — render it in its own
      // span (faint + italic, see .speak-verify-interim in style.css) so
      // a half-heard interim word can never be mistaken for a final word
      // in the box. Combined textContent is unchanged, so Verify still
      // posts exactly the finals.
      textEl.textContent = '';
      if (finals) textEl.appendChild(document.createTextNode(finals));
      if (interim) {
        const s = document.createElement('span');
        s.className = 'speak-verify-interim';
        s.textContent = (finals ? ' ' : '') + interim;
        textEl.appendChild(s);
      }
    }
    // Commit-then-stop: commit this session's finals (overlap-aware),
    // kill the session (generation bump so its late results/onend go
    // stale), stop the mic, re-enable Mic on. After this, listening is
    // false, so onend can never auto-restart. Used by Rok dein AND by
    // Verify (commit-then-stop BEFORE posting, so the posted text is
    // exactly the committed finals).
    function stopSpeak(msg) {
      recGen++; // this session is dead; its late results go stale.
      listening = false;
      restartsWithoutFinal = 0;
      commitSessionFinals();
      renderSpoken('');
      try { if (rec) rec.stop(); } catch (e) { /* already stopped */ }
      setUI();
      if (msg !== undefined && st) st.textContent = msg;
    }
    function startSession() {
      rec = new SR();
      const myRec = rec;
      const myGen = recGen; // captured generation for this session.
      rec.lang = 'ar-SA';
      rec.interimResults = true;
      rec.continuous = true; // CONTINUOUS (2026-11-04 change): keeps listening across pauses until Stop/Verify.
      sessionFinal = '';
      rec.onresult = (e) => {
        if (rec !== myRec) return; // stale session must not rewrite the new text
        if (myGen !== recGen) return; // results from a dead session (after Stop/Clear) are stale — ignore before they touch the text.
        // Rebuild this session's text from its own cumulative results
        // each time, exactly like v116: finals + interim, joined with
        // a single space at each boundary. Nothing is appended across
        // events, so a result can never be counted twice in-session.
        let fin = '', interim = '';
        for (const r of e.results) {
          if (r.isFinal) fin = joinTranscript(fin, r[0].transcript);
          else interim = joinTranscript(interim, r[0].transcript);
        }
        sessionFinal = fin;
        if (fin) restartsWithoutFinal = 0; // any final result resets the auto-restart bound counter.
        renderSpoken(interim);
        if (st && !interim && fin) st.textContent = '🔴 Suna ja raha hai — tilawat jaari rakhein…';
        else if (st && interim) st.textContent = '… ' + interim;
      };
      rec.onerror = (e) => {
        if (rec !== myRec) return; // stale error must not stop the new session
        if (myGen !== recGen) return; // dead session's error must not stop anything
        if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
          // Permission errors: stop immediately, NEVER auto-restart.
          stopSpeak('❌ Mic ki ijazat hasil nahi ho saki — browser settings me mic allow karein.');
        } else {
          // Transient errors (no-speech, network, audio-capture, ...):
          // do NOT stop — a pause must not kill continuous listening.
          // onend follows and drives the bounded auto-restart below;
          // finals so far stay safe in committedFinal/sessionFinal.
          if (st) st.textContent = '⚠️ Sunne me rukawat (' + e.error + ') — dobara sunna ja raha hai…';
        }
      };
      rec.onend = () => {
        if (rec !== myRec) return; // stale session must not commit or restart over the new one
        if (myGen !== recGen) return; // Stop/Clear/Verify already committed; never commit twice
        if (!listening) return; // user stopped — no restart, ever.
        // Session ended unexpectedly (pause, transient cut, browser
        // end-of-utterance) while the user has NOT stopped: commit this
        // session's finals once (overlap-aware), then auto-restart —
        // WITHOUT re-committing anything. The new session's text goes
        // through the same overlap-aware commit on ITS end, so a
        // replayed chunk can never duplicate text.
        commitSessionFinals();
        renderSpoken('');
        if (restartsWithoutFinal >= 5) {
          // Hard bound hit: stop honestly, never loop forever.
          listening = false;
          restartsWithoutFinal = 0;
          setUI();
          if (st) st.textContent = 'Mic band ho gaya hai — dobara Mic on par click farmayen.';
          return;
        }
        restartsWithoutFinal++;
        // Status stays on the listening message — the user is NEVER
        // told to re-tap while auto-restart is active.
        startSession();
      };
      try {
        rec.start();
        listening = true;
        if (st) st.textContent = '🔴 Suna ja raha hai — tilawat farmayen…';
        setUI();
      } catch (e) {
        stopSpeak('❌ Mic shuru nahi ho saka — dobara koshish farmayen.');
      }
    }
    startBtn.addEventListener('click', () => {
      if (listening) return;
      // Mic on keeps ALL accumulated text: this tap only adds the next
      // segment(s), it never wipes an earlier one. Fresh user intent
      // resets the auto-restart bound counter.
      restartsWithoutFinal = 0;
      startSession();
    });
    if (stopBtn) stopBtn.addEventListener('click', () => stopSpeak('Rok diya gaya.'));
    if (clearBtn) clearBtn.addEventListener('click', () => {
      // Clear wipes ALL accumulated text (committed segments AND the
      // current session). Clear-while-listening also stops the mic:
      // no new session starts without a fresh Mic tap, and the bumped
      // generation means cleared text can never resurrect.
      committedFinal = '';
      sessionFinal = '';
      restartsWithoutFinal = 0;
      renderSpoken('');
      if (st) st.textContent = 'Saaf kar diya gaya.';
      if (listening) {
        recGen++; // the stopped session's late onend/onresult go stale.
        listening = false;
        try { if (rec) rec.stop(); } catch (e) { /* already stopped */ }
        setUI();
      }
    });
    if (checkBtn) checkBtn.addEventListener('click', async () => {
      // DEVIATION from v116: commit-then-stop FIRST, so the posted text
      // is exactly the committed finals and no live session can append
      // words after posting. (v116 left the mic running across Verify.)
      if (listening) stopSpeak();
      const t = spokenText();
      if (t.length < 2) {
        if (st) {
          st.textContent = 'Verify karne ke liye pehle kuch tilawat farmayen.';
          st.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        refreshCheckBtn();
        return;
      }
      checkBusy = true;
      checkBtn.disabled = true;
      const oldText = checkBtn.textContent;
      checkBtn.textContent = '⏳ Matching…';
      try {
        const r = await fetch('/api/rematch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ transcript: t }),
        });
        if (!r.ok) throw new Error('rematch failed');
        const data = await r.json();
        // renderResults expects full format — same payload as Re-match.
        renderResults({
          transcript: data.transcript,
          results: data.results,
          coaching: data.coaching,
          verified_count: data.verified_count,
          recognized_words: t.split(/\s+/).length,
          duration: 0,
          coverage: null, // spoken text, not ASR audio — "uncertain transcription" banner not applicable
        }, null);
        // Land on transcript-card, NOT the results card (v116 mobile
        // result-view): natural reading order downward — transcript ->
        // results -> Coach. Card order is unchanged; scroll target only.
        const tc = $('transcript-card');
        if (tc) tc.scrollIntoView({ behavior: 'smooth', block: 'start' });
        showStatus('✅ Verification mukammal ho gayi! ' + (data.count || 0) + ' ayat milein.', 'ok');
      } catch (e) {
        showStatus('❌ Verification mukammal nahi ho saki. Dobara koshish farmayen.', 'error');
        // Same failure also on this card's own status line, scrolled
        // into view — #status lives in the card below, off-screen on a
        // phone, and would otherwise look like a dead tap.
        if (st) {
          st.textContent = '❌ Verification mukammal nahi ho saki — dobara koshish farmayen.';
          st.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      } finally {
        checkBusy = false;
        refreshCheckBtn();
        checkBtn.textContent = oldText;
      }
    });
    setUI();
  })();

  /* --------------------------------------------------------------- init */
  // V-8: the 9-item tips box is expanded by default — on phones it buries
  // upload + Verify below a wall of text. Collapse it on load for small
  // screens (desktop keeps it open).
  try {
    if (window.innerWidth <= 560) {
      const tips = document.querySelector('.tips-box');
      if (tips) tips.removeAttribute('open');
    }
  } catch (e) { /* ignore */ }
  renderHistory();
})();
