"""Security building blocks for the Quran Shazam web service.

What this module provides:
  1. SecurityHeadersMiddleware  - CSP, X-Frame-Options, HSTS, etc. on every response.
  2. RequestIdMiddleware        - unique request id for log correlation (no PII logged).
  3. limiter                    - slowapi rate limiter shared across routes.
  4. require_api_key            - optional API-key gate for /api/* (active only when
                                  the API_KEY env var is set).
  5. validate_upload            - extension allow-list; client MIME type is
                                  advisory only (content is verified by magic
                                  bytes + FFmpeg decode).
  6. safe_temp_path             - collision-proof temp file names (uuid, never the
                                  user-supplied filename).
"""
from __future__ import annotations

import logging
import time
import uuid
from pathlib import Path
from typing import Callable

from fastapi import HTTPException, Request, Response, UploadFile
from slowapi import Limiter
from slowapi.util import get_remote_address
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from .engine.config import settings

log = logging.getLogger("quran_shazam")


# ---------------------------------------------------------------- rate limiting
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.rate_limit_general])


# ------------------------------------------------------- security headers ----
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Attach a hardened set of response headers to every response."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        # Prevent clickjacking of the verification UI.
        response.headers["X-Frame-Options"] = "DENY"
        # Block MIME sniffing so an uploaded file can never be re-interpreted.
        response.headers["X-Content-Type-Options"] = "nosniff"
        # Keep referrers private when users follow outbound links.
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # Lock down powerful browser features the app never needs.
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(self), geolocation=(), payment=(), usb=()"
        )
        # Conservative content security policy; inline scripts are used by the
        # shipped templates, so 'unsafe-inline' is allowed for scripts/styles only.
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline' fonts.googleapis.com; "
            "font-src 'self' fonts.gstatic.com; "
            "img-src 'self' data:; "
            "media-src 'self' blob:; "
            "connect-src 'self'; "
            "object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
        )
        # Only advertise HSTS when we are actually behind TLS (production).
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response


# ------------------------------------------------------------ request ids ----
class RequestIdMiddleware(BaseHTTPMiddleware):
    """Give every request a short id, returned to the client for support tickets."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = uuid.uuid4().hex[:12]
        request.state.request_id = request_id
        start = time.perf_counter()
        response = await call_next(request)
        response.headers["X-Request-Id"] = request_id
        response.headers["X-Response-Time"] = f"{(time.perf_counter() - start) * 1000:.1f}ms"
        return response


# --------------------------------------------------------------- api key -----
async def require_api_key(request: Request) -> None:
    """Dependency that enforces X-API-Key when API_KEY is configured.

    When API_KEY is empty (default), the API stays open for self-hosted use.
    Set API_KEY in production if the endpoint is exposed publicly.
    """
    if not settings.api_key:
        return
    provided = request.headers.get("X-API-Key", "")
    # Constant-time comparison to avoid timing side-channels.
    import hmac

    if not provided or not hmac.compare_digest(provided, settings.api_key):
        raise HTTPException(status_code=401, detail="Invalid or missing API key.")


# ---------------------------------------------------------- upload checks ----
_MIME_ALLOWLIST = {
    "audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac",
    "audio/ogg", "audio/opus", "audio/flac", "audio/webm",
    "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
}

# Magic-byte signatures for the formats we claim to support. This is a
# first-pass sanity check; FFmpeg decoding is the authoritative validator.
_MAGIC_SIGNATURES: tuple[tuple[bytes, int], ...] = (
    (b"ID3", 0),                 # MP3 with ID3 tag
    (b"RIFF", 0),               # WAV (RIFF....WAVE)
    (b"fLaC", 0),               # FLAC
    (b"OggS", 0),               # OGG / Opus
    (b"\x1a\x45\xdf\xa3", 0),   # Matroska / WebM
)
_MP4_FTYP = b"ftyp"             # MP4/M4A/MOV: ....ftyp at offset 4


def _has_known_signature(head: bytes) -> bool:
    for sig, offset in _MAGIC_SIGNATURES:
        if head[offset:offset + len(sig)] == sig:
            return True
    if len(head) >= 8 and head[4:8] == _MP4_FTYP:
        return True
    # MP3 frame sync: 0xFF followed by 3 sync bits (covers MPEG-1/2/2.5,
    # e.g. FF FB, FF F3, FF FA, FF F2 ...). Real-world encoders vary.
    return len(head) >= 2 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0


def validate_upload(file: UploadFile) -> str:
    """Validate an uploaded file. Returns the safe extension.

    Raises HTTPException(400/413/415) with a client-safe message.
    Never trusts the filename beyond its extension, and never trusts the
    client-supplied MIME type (it is advisory only and logged when odd);
    the authoritative checks are the extension allow-list, magic-byte
    sniffing in check_signature_or_raise, and FFmpeg decoding in
    media.decode_to_mono16k.
    """
    original = (file.filename or "").strip()
    ext = Path(original).suffix.lower()
    if not ext or ext not in settings.allowed_extensions:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type {ext or '(none)'!r}. "
                   f"Allowed: {', '.join(sorted(settings.allowed_extensions))}.",
        )
    content_type = (file.content_type or "").split(";")[0].strip().lower()
    if content_type and content_type not in _MIME_ALLOWLIST and not content_type.startswith("application/octet-stream"):
        # Client-supplied MIME types are unreliable (mobile file pickers and
        # webviews often mislabel audio, e.g. audio/x-mpeg3 or a 3gp type).
        # Don't hard-reject here: the extension check above plus the
        # magic-byte sniffing (check_signature_or_raise) and the FFmpeg decode
        # are the authoritative content checks. Log and continue so a valid
        # audio file is never blocked by a misreported label.
        log.warning("upload content-type %r not in allowlist; relying on magic-byte check", content_type)
    return ext


async def peek_signature(file: UploadFile, num_bytes: int = 16) -> bytes:
    """Read the first bytes to sniff the real file type, then rewind."""
    head = await file.read(num_bytes)
    await file.seek(0)
    return head


def check_signature_or_raise(head: bytes) -> None:
    if not _has_known_signature(head):
        raise HTTPException(
            status_code=415,
            detail="File content does not look like a supported audio/video format.",
        )


def safe_temp_path(data_dir: Path, ext: str) -> Path:
    """Build a temp upload path that can never collide or traverse directories."""
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / f"upload_{uuid.uuid4().hex}{ext}"


def client_error_response(detail: str, status: int = 400) -> HTTPException:
    return HTTPException(status_code=status, detail=detail)
