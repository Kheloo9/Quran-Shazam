"""Security building blocks for the Quran Shazam web service.

What this module provides:
  1. SecurityHeadersMiddleware  - CSP, X-Frame-Options, HSTS, etc. on every response.
  2. RequestIdMiddleware        - unique request id for log correlation (no PII logged).
  3. limiter                    - slowapi rate limiter shared across routes.
  4. require_api_key            - optional API-key gate for /api/* (active only when
                                  the API_KEY env var is set).
  5. validate_upload            - extension allow-list; client MIME type is
                                  advisory only (content is verified by magic
                                  bytes + FFmpeg decode).
  6. safe_temp_path             - collision-proof temp file names (uuid, never the
                                  user-supplied filename).
"""
from __future__ import annotations

import logging
import time
import uuid
from pathlib import Path
from typing import Callable

from fastapi import HTTPException, Request, Response, UploadFile
from slowapi import Limiter
from slowapi.util import get_remote_address
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from .engine.config import settings

log = logging.getLogger("quran_shazam")


# ---------------------------------------------------------------- rate limiting
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.rate_limit_general])


# ------------------------------------------------------- security headers ----
# FYP STUDY GUIDE: Attaches hardened response headers (CSP, X-Frame-Options:
# DENY, nosniff, Referrer-Policy, HSTS in production) to every response.
# WHY: defense-in-depth against clickjacking and MIME-sniffing; audio/video
# responses skip CSP/nosniff because those headers make browsers REFUSE to
# play real MP3 bytes (a real 2026-10-18 bug).
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Attach a hardened set of response headers to every response."""

    # FYP STUDY GUIDE: BaseHTTPMiddleware hook - runs the route, then classifies the
    # response (media vs page) and stamps only the headers valid for that type.
    # WHY: middleware runs once per request for every route, so a new endpoint can
    # never forget security headers; the per-type classification is what keeps
    # audio playback working under a strict policy.
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        # Professional: skip security headers that break audio/video playback.
        # X-Content-Type-Options: nosniff + wrong content-type = browser refuses
        # to play audio. We ensure audio endpoints set correct content-type,
        # and skip CSP (which doesn't apply to media responses anyway).
        #
        # FYP STUDY GUIDE: security headers are not one-size-fits-all.
        # nosniff + CSP protect HTML/JS pages against content-sniffing attacks,
        # but applied to an MP3 they make the browser REJECT the file.
        # Rule: classify the response first (is_media), then apply only the
        # headers that make sense for that content type.
        content_type = response.headers.get("content-type", "")
        is_media = content_type.startswith(("audio/", "video/"))
        # Prevent clickjacking of the verification UI.
        response.headers["X-Frame-Options"] = "DENY"
        # Block MIME sniffing so an uploaded file can never be re-interpreted.
        # Skip for audio/video: browsers need to sniff media types for playback.
        if not is_media:
            response.headers["X-Content-Type-Options"] = "nosniff"
        # Keep referrers private when users follow outbound links.
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # Lock down powerful browser features the app never needs.
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(self), geolocation=(), payment=(), usb=()"
        )
        # Conservative content security policy; inline scripts are used by the
        # shipped templates, so 'unsafe-inline' is allowed for scripts/styles only.
        # Skip CSP for media responses (not applicable, can break playback).
        if not is_media:
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline' fonts.googleapis.com; "
                "font-src 'self' fonts.gstatic.com; "
                "img-src 'self' data:; "
                # TEAM 2 (2026-10-19): everyayah.com MUST be in media-src — the
                # frontend's proxy→direct fallback plays tilawat straight from
                # everyayah.com when the proxy is slow. Without this, the
                # browser CSP-blocks the fallback before any network I/O and
                # the "two-path" audio design silently becomes one-path.
                "media-src 'self' blob: https://everyayah.com; "
                "connect-src 'self'; "
                "object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
            )
        # Only advertise HSTS when we are actually behind TLS (production).
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response


# ------------------------------------------------------------ request ids ----
# FYP STUDY GUIDE: Gives every request a short random id (12-hex uuid), returned
# as X-Request-Id plus X-Response-Time.
# WHY: a user can quote the id from a bug report and the engineer correlates
# logs exactly - request tracing with zero PII logged.
class RequestIdMiddleware(BaseHTTPMiddleware):
    """Give every request a short id, returned to the client for support tickets."""

    # FYP STUDY GUIDE: Generates the id, stores it on request.state, times the request
    # with perf_counter, and stamps both headers on the response.
    # WHY: downstream code logs req=<id> across threads (verify, identify), so the
    # entire pipeline of one upload is traceable end to end.
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = uuid.uuid4().hex[:12]
        request.state.request_id = request_id
        start = time.perf_counter()
        response = await call_next(request)
        response.headers["X-Request-Id"] = request_id
        response.headers["X-Response-Time"] = f"{(time.perf_counter() - start) * 1000:.1f}ms"
        return response


# ------------------------------------------------------- perf budgets ----
# PROFESSIONAL (2026-10-19): performance-budget enforcement (log-only).
# FYP STUDY GUIDE: a middleware runs on EVERY request. This one measures how
# long each request took and compares it against the budgets in
# settings.perf_budgets. If a request is slower than its budget we log
# "perf_budget_exceeded" — we NEVER block or slow the request itself, because
# punishing the user for our slowness would be wrong. The logs let the team
# spot regressions ("surah load suddenly takes 8s — what changed?").
_PERF_PATH_BUDGETS: tuple[tuple[str, str], ...] = (
    ("/api/quran/tafseer/", "tafseer"),
    ("/api/quran/surah/", "surah_load"),
    ("/api/quran/translate", "translate"),
    ("/api/audio/", "audio_start"),
    ("/api/ask", "qa"),
)


# FYP STUDY GUIDE: Compares each request's latency against the perf budgets in
# settings and LOGS violations - it never blocks or slows a request.
# WHY: slowdowns become visible bugs ('surah load takes 8s - what changed?')
# instead of angry user reports; log-only, because punishing the user for
# server slowness would be wrong.
class PerfBudgetMiddleware(BaseHTTPMiddleware):
    """Log-only performance budgets: slow requests are logged, never blocked."""

    # FYP STUDY GUIDE: Times the request, matches the path prefix to its budget key
    # (e.g. /api/audio/ -> audio_start), logs perf_budget_exceeded when over budget.
    # WHY: measuring at the middleware layer covers every route uniformly without
    # touching a single line of endpoint code.
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        path = request.url.path
        for prefix, key in _PERF_PATH_BUDGETS:
            if path.startswith(prefix):
                budget = settings.perf_budgets.get(key)
                if budget is not None and elapsed > budget:
                    log.warning("perf_budget_exceeded path=%s elapsed=%.2fs budget=%.1fs",
                                path, elapsed, budget)
                break
        return response


# --------------------------------------------------------------- api key -----
# FYP STUDY GUIDE: FastAPI dependency enforcing the X-API-Key header with
# hmac.compare_digest - active only when the API_KEY env var is set.
# WHY: self-hosters get an open API by default; public deployments can gate
# /api/*. Constant-time comparison defeats timing side-channel key guessing.
async def require_api_key(request: Request) -> None:
    """Dependency that enforces X-API-Key when API_KEY is configured.

    When API_KEY is empty (default), the API stays open for self-hosted use.
    Set API_KEY in production if the endpoint is exposed publicly.
    """
    if not settings.api_key:
        return
    provided = request.headers.get("X-API-Key", "")
    # Constant-time comparison to avoid timing side-channels.
    import hmac

    if not provided or not hmac.compare_digest(provided, settings.api_key):
        raise HTTPException(status_code=401, detail="Invalid or missing API key.")


# ---------------------------------------------------------- upload checks ----
_MIME_ALLOWLIST = {
    "audio/mpeg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/aac",
    "audio/ogg", "audio/opus", "audio/flac", "audio/webm",
    "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
}

# Magic-byte signatures for the formats we claim to support. This is a
# first-pass sanity check; FFmpeg decoding is the authoritative validator.
_MAGIC_SIGNATURES: tuple[tuple[bytes, int], ...] = (
    (b"ID3", 0),                 # MP3 with ID3 tag
    (b"RIFF", 0),               # WAV (RIFF....WAVE)
    (b"fLaC", 0),               # FLAC
    (b"OggS", 0),               # OGG / Opus
    (b"\x1a\x45\xdf\xa3", 0),   # Matroska / WebM
)
_MP4_FTYP = b"ftyp"             # MP4/M4A/MOV: ....ftyp at offset 4


# FYP STUDY GUIDE: Checks the first bytes against known audio/video magic
# signatures (ID3, RIFF, fLaC, OggS, Matroska, MP4 ftyp, MP3 frame sync).
# WHY: the client's filename and MIME type are untrusted - but real codecs
# leave unmistakable byte patterns. This is the first content check; the
# FFmpeg decode is the final authority.
def _has_known_signature(head: bytes) -> bool:
    for sig, offset in _MAGIC_SIGNATURES:
        if head[offset:offset + len(sig)] == sig:
            return True
    if len(head) >= 8 and head[4:8] == _MP4_FTYP:
        return True
    # MP3 frame sync: 0xFF followed by 3 sync bits (covers MPEG-1/2/2.5,
    # e.g. FF FB, FF F3, FF FA, FF F2 ...). Real-world encoders vary.
    return len(head) >= 2 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0


# FYP STUDY GUIDE: Enforces the extension allow-list; logs (but never rejects
# on) odd client-supplied MIME types.
# WHY: mobile file pickers routinely mislabel audio (e.g. audio/x-mpeg3) -
# rejecting on MIME alone would block valid uploads. The real gates are the
# extension list, magic-byte sniffing, and the FFmpeg decode.
def validate_upload(file: UploadFile) -> str:
    """Validate an uploaded file. Returns the safe extension.

    Raises HTTPException(400/413/415) with a client-safe message.
    Never trusts the filename beyond its extension, and never trusts the
    client-supplied MIME type (it is advisory only and logged when odd);
    the authoritative checks are the extension allow-list, magic-byte
    sniffing in check_signature_or_raise, and FFmpeg decoding in
    media.decode_to_mono16k.
    """
    original = (file.filename or "").strip()
    ext = Path(original).suffix.lower()
    if not ext or ext not in settings.allowed_extensions:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type {ext or '(none)'!r}. "
                   f"Allowed: {', '.join(sorted(settings.allowed_extensions))}.",
        )
    content_type = (file.content_type or "").split(";")[0].strip().lower()
    if content_type and content_type not in _MIME_ALLOWLIST and not content_type.startswith("application/octet-stream"):
        # Client-supplied MIME types are unreliable (mobile file pickers and
        # webviews often mislabel audio, e.g. audio/x-mpeg3 or a 3gp type).
        # Don't hard-reject here: the extension check above plus the
        # magic-byte sniffing (check_signature_or_raise) and the FFmpeg decode
        # are the authoritative content checks. Log and continue so a valid
        # audio file is never blocked by a misreported label.
        log.warning("upload content-type %r not in allowlist; relying on magic-byte check", content_type)
    return ext


# FYP STUDY GUIDE: Reads the first 16 bytes to sniff the real file type, then
# seeks back to position 0.
# WHY: the rewind is critical - the route later streams the same file object
# to disk, and reading without seek(0) would silently truncate the upload.
async def peek_signature(file: UploadFile, num_bytes: int = 16) -> bytes:
    """Read the first bytes to sniff the real file type, then rewind."""
    head = await file.read(num_bytes)
    await file.seek(0)
    return head


# FYP STUDY GUIDE: Raises HTTP 415 when the sniffed bytes match no known
# audio/video format.
# WHY: fails fast before the file is written to disk - a 100-byte non-audio
# upload gets a clean 415 instead of a confusing 500 from FFmpeg.
def check_signature_or_raise(head: bytes) -> None:
    if not _has_known_signature(head):
        raise HTTPException(
            status_code=415,
            detail="File content does not look like a supported audio/video format.",
        )


# FYP STUDY GUIDE: Builds the temp upload path from uuid4 + validated extension -
# the user's filename is never used.
# WHY: user filenames can carry ../ path traversal; uuid names can neither
# collide nor escape the data directory.
def safe_temp_path(data_dir: Path, ext: str) -> Path:
    """Build a temp upload path that can never collide or traverse directories."""
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / f"upload_{uuid.uuid4().hex}{ext}"


# FYP STUDY GUIDE: Factory for client-safe HTTPException(4xx) responses.
# WHY: centralizes the error shape so internal details (paths, model internals)
# never leak to clients - anything unexpected still becomes a safe generic 500
# via the global handler.
def client_error_response(detail: str, status: int = 400) -> HTTPException:
    return HTTPException(status_code=status, detail=detail)
