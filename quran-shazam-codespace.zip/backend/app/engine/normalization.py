from __future__ import annotations
import re

_ARABIC_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
_NON_ARABIC = re.compile(r"[^\u0600-\u06FF\s]")


# FYP STUDY GUIDE: Strips diacritics/tatweel, unifies alef forms (alef variants ->
# plain alef, alef-maqsura -> ya, ta-marbuta -> ha), drops non-Arabic chars,
# collapses whitespace.
# WHY: ASR and the corpus spell the same word differently (diacritics, alef
# variants) - without this, the fuzzy matcher would punish spelling that isn't
# an error. Note qaf/kaf are NOT merged - that would change meaning.
def normalize_arabic(text: str) -> str:
    s = str(text or "").strip()
    s = s.replace("ـ", "")
    # Professional: U+0670 (superscript alef) becomes a regular alef, not stripped.
    # Old code stripped it ("الصراط"→"الصرط") but ASR outputs the alef
    # ("الصراط"), causing a 1-char mismatch on EVERY occurrence that the
    # fuzzy matcher couldn't absorb when combined with other ASR errors.
    # Converting to alef keeps corpus and ASR consistent.
    s = s.replace("ٰ", "ا")
    s = _ARABIC_DIACRITICS.sub("", s)
    s = s.replace("ٱ", "ا").replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    s = s.replace("ى", "ي")
    # Professional: normalize common ASR confusions so fuzzy matching works.
    # Whisper often confuses these pairs in Quranic recitation:
    s = s.replace("ة", "ه")  # ta-marbuta ↔ ha (most common: "الرحمة" vs "الرحمه")
    # Note: we do NOT normalize ق/ك or ت/ط etc. — those change meaning and
    # the fuzzy scorer handles them via edit distance.
    s = _NON_ARABIC.sub(" ", s)
    return " ".join(s.split())


# FYP STUDY GUIDE: normalize_arabic() then split into word tokens.
# WHY: every scorer in the matcher works on tokens, not raw strings - one shared
# tokenizer guarantees the matcher, coach, and candidate pool count words
# identically.
def tokens(text: str) -> list[str]:
    return [t for t in normalize_arabic(text).split() if t]
