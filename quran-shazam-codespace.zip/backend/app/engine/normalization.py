from __future__ import annotations
import re

_ARABIC_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
_NON_ARABIC = re.compile(r"[^\u0600-\u06FF\s]")


def normalize_arabic(text: str) -> str:
    s = str(text or "").strip()
    s = s.replace("ـ", "")
    # Note: U+0670 (superscript alef) is stripped like other marks. It is
    # ambiguous in Uthmani orthography ("مَٰلِكِ"→"مالك" vs "رَحْمَٰنِ"→"رحمن"),
    # and the fuzzy matcher is designed to absorb that 1-char difference.
    s = _ARABIC_DIACRITICS.sub("", s)
    s = s.replace("ٱ", "ا").replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    s = s.replace("ى", "ي")
    s = _NON_ARABIC.sub(" ", s)
    return " ".join(s.split())


def tokens(text: str) -> list[str]:
    return [t for t in normalize_arabic(text).split() if t]
