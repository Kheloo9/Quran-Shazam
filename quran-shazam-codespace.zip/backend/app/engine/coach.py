"""Per-ayah coaching feedback: from "Shazam" (identify) to "Coach" (teach).

========================================================================
FYP STUDY GUIDE: What the Coach Does
========================================================================

The verifier answers "WHAT did I recite?" (surah/ayah identification).
The coach answers "HOW WELL did I recite it?" — per ayah.

How it works (3 steps):
  1. SLICE: each verify result carries transcript_start/transcript_length
     (word positions in the transcript). We slice out the words the ASR
     heard for that ayah.
  2. COMPARE: we compare the ayah's expected words (normalized Quranic
     text) against the heard words. A word counts as "heard" if it appears
     exactly OR fuzzy-matches (>=80 similarity) — because ASR makes small
     spelling errors ("اهدن" vs "اهدنا") that shouldn't count as missed.
  3. ADVISE: based on the match label + missed words, we pick an honest,
     encouraging message (English + Roman Urdu). We NEVER invent missed
     words: everything comes from the real matcher output.

Statuses:
  - "perfect": VERIFIED/GOOD label and (almost) all words heard.
  - "needs_work": POSSIBLE/LOW label, or real words missing.
  - "missing": SEQUENCE RECOVERY — the ayah wasn't heard at all
    (inferred from neighbors, not from audio).

Word statuses (per-word evidence, ADR-0006/ADR-0010):
  - "matched": heard (exact or ASR near-miss).
  - "substituted": a different word heard, model confident.
  - "uncertain": different word heard BUT model unsure (prob < 0.70) —
    the AI probably misheard; the reciter is NOT blamed, and the word
    is NOT counted as missed.
  - "missed": expected word not heard at all. "extra": extra word heard.

Tone rule (respect): this is the Quran. Feedback is always encouraging,
never discouraging. Even "needs_work" says "ek baar dobara parhein 💪",
never "ghalat parha".
"""
from __future__ import annotations

import difflib

from .normalization import normalize_arabic, tokens
from .matcher import similarity

# Words that match at >= this similarity count as "heard" (ASR near-miss).
_FUZZY_HEARD_THRESHOLD = 80.0
# WORD CONFIDENCE (2026-10-21, ADR-0010): a "substituted" word whose model
# confidence is BELOW this is marked "uncertain" instead — the AI itself
# isn't sure what it heard, so we must not blame the reciter. Calibrated
# on the golden Al-Fatihah file: substituted probs were 0.67/0.83/0.92;
# 0.70 separates the genuinely-unsure case. Conservative by design:
# prob=None (no data) keeps the old "substituted" behavior.
_UNCERTAIN_PROB_THRESHOLD = 0.70
# Up to this many missed words still counts as "perfect" when the matcher
# already VERIFIED the ayah (the evidence is strong; tiny misses are noise).
_PERFECT_MISSED_ALLOWANCE = 1


# FYP STUDY GUIDE: Safely slices transcript words for one ayah - clamps indices,
# tolerates None/bad input by returning [].
# WHY: transcript_start/length come from the matcher; defensive clamping means one
# bad index can't crash coaching for the whole result.
def _heard_slice(transcript_words: list[str], start, length) -> list[str]:
    """Clamp word indices and slice the transcript for one ayah."""
    try:
        s = max(0, int(start or 0))
        n = max(0, int(length or 0))
    except (TypeError, ValueError):
        return []
    return transcript_words[s:s + n]


# FYP STUDY GUIDE: Exact match first (fast path), then >=80 fuzzy for ASR
# near-misses.
# WHY: the 80 threshold matches the matcher's _fuzzy_contains, so 'heard' means
# the same thing everywhere - one spelling wobble never counts as a missed word.
def _is_heard(word: str, heard_set: set[str]) -> bool:
    """Exact match first (fast), then fuzzy (ASR near-miss tolerance)."""
    if word in heard_set:
        return True
    for h in heard_set:
        if similarity(word, h) >= _FUZZY_HEARD_THRESHOLD:
            return True
    return False


# FYP STUDY GUIDE: Returns the expected ayah words the ASR did not hear -
# derived only from real matcher output, never invented.
# WHY: the raw material for 'needs_work' feedback; an empty ayah or empty heard
# set returns [] or the full list honestly instead of fabricating evidence.
def missed_words_for_ayah(expected_text: str, heard_words: list[str]) -> list[str]:
    """Words of the ayah that the ASR did not hear (honest, no invention).

    expected_text: the canonical ayah text (diacritics ok — we normalize).
    heard_words: normalized transcript words sliced for this ayah.
    Returns the expected words (normalized form) that were not heard.
    """
    expected = tokens(expected_text)
    if not expected:
        return []
    heard_set = set(heard_words)
    if not heard_set:
        return list(expected)
    return [w for w in expected if not _is_heard(w, heard_set)]


# =====================================================================
# PROFESSIONAL REDESIGN Stage 4-lite — word-level forced alignment
# (2026-10-21). Before: Coach could only say "word X was missed".
# Now: we align the ayah's expected words against what the ASR heard,
# word by word, and tell apart:
#   matched      — the word was heard (exact or ASR near-miss, >=80 like
#                  _is_heard, so behavior stays consistent)
#   substituted  — a DIFFERENT word was heard in its place
#                  (e.g. mispronunciation the ASR rendered as another word)
#   missed       — no word heard where one was expected
#   extra        — a word heard that isn't in the ayah
# Timestamps come ONLY from the ASR's own word timings (asr.py). A word
# the overlap-dedup dropped gets t_start=None — we never invent timings.
# FYP STUDY GUIDE: difflib.SequenceMatcher finds the cheapest way to turn
# one word list into the other (like "track changes" in Word). Its
# opcodes tell us exactly which words line up and which don't.
# =====================================================================
def _time_map(heard_words: list[str], seg_words: list[dict]) -> list:
    """Map each heard-word index -> (t_start, t_end, prob) evidence.

    seg_words: flat [{w, start, end, p}] from ASR segments, in order.
    Both lists are normalized; alignment is by sequence order so a word
    the dedup dropped doesn't shift every timestamp after it.
    prob is the model's own confidence for the heard word (0..1 or None).
    """
    ev: list = [(None, None, None)] * len(heard_words)
    if not heard_words or not seg_words:
        return ev
    seg_txt = [s.get("w", "") for s in seg_words]
    sm = difflib.SequenceMatcher(None, heard_words, seg_txt, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != "equal":
            continue
        for hi, sj in zip(range(i1, i2), range(j1, j2)):
            s = seg_words[sj]
            try:
                ev[hi] = (float(s.get("start")), float(s.get("end")),
                          s.get("p"))
            except (TypeError, ValueError):
                ev[hi] = (None, None, s.get("p") if isinstance(
                    s.get("p"), (int, float)) else None)
    return ev


# FYP STUDY GUIDE: difflib word alignment of expected vs heard words -> per-word
# status (matched/substituted/uncertain/missed/extra) with ASR timestamps.
# WHY: the Stage 4 redesign - 'uncertain' (model confidence < 0.70) means the AI
# probably misheard, so the reciter is NOT blamed and the word is excluded from
# missed_words (ADR-0010); timings come only from the ASR, never invented.
def align_words(ref_text: str, heard_words: list[str],
                seg_words: list[dict] | None = None) -> list[dict]:
    """Align expected ayah words to heard words -> per-word evidence.

    Returns a list of dicts:
      {"ref": expected word or None, "hyp": heard word or None,
       "status": matched|substituted|uncertain|missed|extra,
       "t_start": float|None, "t_end": float|None,
       "prob": float|None}   # model's own confidence for the heard word

    "uncertain": the heard word differs from the expected word BUT the
    model's own confidence is below _UNCERTAIN_PROB_THRESHOLD — the AI
    probably misheard, so the reciter is NOT blamed. FYP STUDY GUIDE:
    this is the core fix for "AI ne ghalat suna": we use the AI's own
    uncertainty as evidence instead of punishing the reciter.
    """
    ref_words = tokens(ref_text or "")
    heard = list(heard_words or [])
    ev = _time_map(heard, seg_words or [])

    def _rec(ref, hyp, status, hj):
        ts, te, pr = ev[hj] if hj is not None and hj < len(ev) else (None, None, None)
        # UNCERTAINTY RULE: a "substituted" word the model itself doubts
        # becomes "uncertain" — never punish the reciter for AI's doubt.
        if status == "substituted" and isinstance(pr, (int, float)) \
                and pr < _UNCERTAIN_PROB_THRESHOLD:
            status = "uncertain"
        return {"ref": ref, "hyp": hyp, "status": status,
                "t_start": ts, "t_end": te, "prob": pr}

    out: list[dict] = []
    if not ref_words:
        return out
    sm = difflib.SequenceMatcher(None, ref_words, heard, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for ri, hj in zip(range(i1, i2), range(j1, j2)):
                out.append(_rec(ref_words[ri], heard[hj], "matched", hj))
        elif tag == "replace":
            # Pair up as substitutions; ASR near-misses (>=80) stay
            # "matched" so Coach never punishes a spelling wobble.
            pairs = min(i2 - i1, j2 - j1)
            for k in range(pairs):
                ri, hj = i1 + k, j1 + k
                if similarity(ref_words[ri], heard[hj]) >= _FUZZY_HEARD_THRESHOLD:
                    st = "matched"
                else:
                    st = "substituted"
                out.append(_rec(ref_words[ri], heard[hj], st, hj))
            for ri in range(i1 + pairs, i2):
                out.append(_rec(ref_words[ri], None, "missed", None))
            for hj in range(j1 + pairs, j2):
                out.append(_rec(None, heard[hj], "extra", hj))
        elif tag == "delete":
            for ri in range(i1, i2):
                out.append(_rec(ref_words[ri], None, "missed", None))
        elif tag == "insert":
            for hj in range(j1, j2):
                out.append(_rec(None, heard[hj], "extra", hj))
    return out


# FYP STUDY GUIDE: Maps match label + missed words -> perfect / needs_work /
# missing.
# WHY: one decision function keeps statuses consistent - SEQUENCE RECOVERY is
# always 'missing' (inferred, not heard); VERIFIED/GOOD with <=1 missed word is
# 'perfect' since tiny misses on strong evidence are noise.
def _status_for(label: str, missed: list[str]) -> str:
    label = (label or "").upper()
    if "RECOVERY" in label:
        # Inferred from neighbors — the audio has no evidence for this ayah.
        return "missing"
    if label in ("VERIFIED TEXT MATCH", "GOOD TEXT MATCH"):
        if len(missed) <= _PERFECT_MISSED_ALLOWANCE:
            return "perfect"
        return "needs_work"
    # POSSIBLE MATCH / LOW CONFIDENCE: the evidence itself is weak.
    return "needs_work"


# FYP STUDY GUIDE: Builds encouraging EN + Roman-Urdu feedback naming the actual
# missed words (up to 4, then a count).
# WHY: this is the Quran - feedback is always respectful, never discouraging;
# naming real missed words makes the advice actionable instead of vague.
def _message(status: str, surah: int, ayah: int, missed: list[str]) -> tuple[str, str]:
    """(message_en, message_ur_roman). Encouraging, respectful, specific."""
    ref = f"Ayah {ayah}"
    if status == "perfect":
        return (
            f"MashaAllah! {ref} was recited beautifully ✅",
            f"MashaAllah! {ref} bilkul theek parhi ✅",
        )
    if status == "missing":
        return (
            f"{ref} wasn't heard in the recording — it may have been skipped. "
            f"Try reciting it on its own 🎯",
            f"{ref} recording mein sunai nahi di — shayad reh gayi. "
            f"Isay alag se parh kar dekhein 🎯",
        )
    # needs_work — name the actual missed words (real evidence only).
    if missed:
        shown = "، ".join(missed[:4])
        more = f" (+{len(missed) - 4} more)" if len(missed) > 4 else ""
        return (
            f"{ref}: “{shown}”{more} didn't come through clearly — "
            f"recite this ayah once more, slowly 🎯",
            f"{ref} mein “{shown}”{more} wazeh sunai nahi diya — "
            f"is ayat ko ek baar aahista dobara parhein 🎯",
        )
    return (
        f"{ref} was only partly clear — one more slow recitation will help 🎯",
        f"{ref} poori tarah wazeh nahi thi — ek baar aahista dobara parhein 🎯",
    )


# FYP STUDY GUIDE: Assembles the full coaching payload - per-ayah cards (status,
# missed/substituted/uncertain words, word alignment, messages) plus summary
# counts - from verify/rematch results and ASR segments.
# WHY: turns 'Shazam' (identify) into 'Shazam + Coach' (identify + teach); every
# field is JSON-serializable and built only from real evidence, never invented.
def build_coaching(transcript: str, results: list[dict],
                   segments: list[dict] | None = None) -> dict:
    """Build the full coaching payload from a verify/rematch result.

    Args:
        transcript: the (normalized or raw) transcript string.
        results: list of result dicts, each with surah, ayah, key, text,
            label, transcript_start, transcript_length.
        segments: ASR segments with per-word timings (asr.py). Optional —
            without them, word_alignment has no timestamps but statuses
            still work.

    Returns a JSON-serializable dict:
        {"summary": {...}, "ayat": [ {surah, ayah, key, status, label,
         missed_words, substituted_words, uncertain_words, word_alignment,
         message_en, message_ur}, ... ]}
    """
    t_words = normalize_arabic(transcript or "").split()
    seg_words: list[dict] = []
    for s in (segments or []):
        seg_words.extend(s.get("words", []) or [])
    items = []
    for r in results or []:
        label = r.get("label", "")
        if "RECOVERY" in (label or "").upper():
            missed: list[str] = []  # nothing heard — don't fake a word list
            alignment: list[dict] = []
        else:
            heard = _heard_slice(t_words, r.get("transcript_start"),
                                 r.get("transcript_length"))
            alignment = align_words(r.get("text", ""), heard, seg_words)
            # UNCERTAINTY (ADR-0010): words the AI itself doubts are NOT
            # counted as missed — the reciter is never punished for the
            # model's uncertainty. They get their own honest display.
            uncertain_refs = {a["ref"] for a in alignment
                              if a["status"] == "uncertain" and a["ref"]}
            missed = [w for w in missed_words_for_ayah(r.get("text", ""), heard)
                      if w not in uncertain_refs]
        status = _status_for(label, missed)
        msg_en, msg_ur = _message(status, r.get("surah"), r.get("ayah"), missed)
        substituted = [(a["ref"], a["hyp"]) for a in alignment
                       if a["status"] == "substituted"]
        uncertain = [(a["ref"], a["hyp"], a["prob"]) for a in alignment
                     if a["status"] == "uncertain"]
        items.append({
            "surah": r.get("surah"),
            "ayah": r.get("ayah"),
            "key": r.get("key"),
            # P3 (2026-10-21): pass the canonical ayah Arabic text through
            # to the frontend so EVERY Coach card can display it — even the
            # "perfect" ones that previously had no Arabic to show.
            # FYP STUDY GUIDE: this is the SAME string the matcher used as
            # its ground truth (r.get("text") == m.verse.text in service.py),
            # so the UI always quotes the exact ayah being coached.
            "text": r.get("text", ""),
            "status": status,
            "label": label,
            "missed_words": missed,
            "substituted_words": substituted,
            "uncertain_words": uncertain,
            "word_alignment": alignment,
            "message_en": msg_en,
            "message_ur": msg_ur,
        })

    perfect = sum(1 for i in items if i["status"] == "perfect")
    needs = sum(1 for i in items if i["status"] == "needs_work")
    missing = sum(1 for i in items if i["status"] == "missing")
    total = len(items)
    if total and perfect == total:
        sum_en = f"MashaAllah! All {total} ayat recited beautifully 🌟"
        sum_ur = f"MashaAllah! Saari {total} ayat bilkul theek 🌟"
    elif total:
        sum_en = (f"{perfect}/{total} ayat solid ✅ — {needs + missing} "
                  f"need{suffix(needs + missing)} a little more practice 💪")
        sum_ur = (f"{perfect}/{total} ayat theek ✅ — {needs + missing} mein "
                  f"thori aur mehnat ki zaroorat 💪")
    else:
        sum_en = "No ayat to coach on yet."
        sum_ur = "Abhi coach karne ke liye koi ayat nahi."
    return {
        "summary": {
            "total": total,
            "perfect": perfect,
            "needs_work": needs,
            "missing": missing,
            "message_en": sum_en,
            "message_ur": sum_ur,
        },
        "ayat": items,
    }


def suffix(n: int) -> str:
    # "1 ayat needs" (singular) vs "2 ayat need" (plural).
    return "s" if n == 1 else ""


# ---------------------------------------------------------------------------
# WORD PRACTICE (2026-10-22): "sahi lafz record karo" — the user records ONE
# word and the server checks whether they said the expected word correctly.
# FYP STUDY GUIDE: pure function (no model, no I/O) so it is unit-testable.
# The /api/practice-word endpoint transcribes, then calls this.
# A word counts as correct when the best fuzzy similarity to any heard word
# is >= _PRACTICE_MATCH_THRESHOLD (same 80.0 bar Coach uses for near-misses,
# so a small spelling wobble in the transcript never fails the learner).
# NOTE: similarity() scores 0..100 (matcher.py), NOT 0..1.
# ---------------------------------------------------------------------------
_PRACTICE_MATCH_THRESHOLD = 80.0


# FYP STUDY GUIDE: Pure function - best fuzzy similarity of the expected word vs
# heard words; match when >=80.0 (note: similarity() scores 0-100, NOT 0-1).
# WHY: pure (no model, no I/O) so it's unit-testable; the 80 bar matches Coach's
# near-miss threshold so a small spelling wobble never fails the learner; this
# powers /api/practice-word.
def word_practice_match(expected: str, heard_text: str) -> tuple[bool, float]:
    """Check a practiced word against transcribed text.

    Returns (match, best_similarity). match is True when any heard word is
    within the fuzzy threshold of the expected word.
    """
    exp = normalize_arabic(expected or "").strip()
    heard_words = normalize_arabic(heard_text or "").split()
    if not exp or not heard_words:
        return False, 0.0
    best = max(similarity(exp, w) for w in heard_words)
    return best >= _PRACTICE_MATCH_THRESHOLD, round(float(best), 3)
