"""Orchestration layer: media -> ASR -> matching -> labelled results.

========================================================================
FYP STUDY GUIDE: How Quran Shazam Verification Works (Step by Step)
========================================================================

The verification pipeline has 4 main stages:

  STAGE 1: AUDIO DECODING (media.py -> decode_to_mono16k)
    - Takes any audio/video file (MP3, WAV, MP4, etc.)
    - Uses FFmpeg to convert to: mono, 16kHz, 32-bit float
    - Why 16kHz? Whisper models are trained on 16kHz audio.
    - Why mono? Stereo doubles processing with no accuracy benefit.
    - Applies normalization: volume adjustment + light noise gate.

  STAGE 2: SPEECH-TO-TEXT (asr.py -> QuranASR.transcribe_array)
    - Uses faster-whisper (CTranslate2) with tarteel-ai/whisper-base-ar-quran
    - This is a Whisper model FINE-TUNED on Quran recitation (not general Arabic!)
    - Audio is split into 60-second chunks with 2s overlap
    - Each chunk uses BEAM SEARCH (beam_size=3) not greedy decoding:
        * Greedy picks the single best word at each step (fast, less accurate)
        * Beam search keeps top-3 candidates, picks best overall (slower, more accurate)
    - Repetition guards prevent Whisper's known "looping" failure mode
    - Output: Arabic transcript text

  STAGE 3: TEXT MATCHING (matcher.py -> align_transcript)
    - The transcript is compared against all 6,236 Quranic verses
    - Uses FUZZY matching (not exact) because ASR makes small errors
    - Key techniques:
        * IDF-weighted scoring: rare/distinctive words count more
        * Surah lock: after 3 consecutive matches from one surah, restrict search
        * Soft recovery: allows looking back 30 ayat if the match jumps wrong
    - Output: list of Match objects (surah, ayah, confidence score)

  STAGE 4: LABELLING (this file, below)
    - Each match gets an HONEST label based on evidence:
        * VERIFIED TEXT MATCH: score>=95, coverage>=90, missing<=2 (strong evidence)
        * GOOD TEXT MATCH: score>=80 (good evidence)
        * POSSIBLE MATCH: score>=70 (weak evidence)
        * LOW CONFIDENCE: score<70 (very weak - don't trust this)
        * SEQUENCE RECOVERY: inferred from neighbors, not directly heard
    - We NEVER claim 100% accuracy. Labels describe what the EVIDENCE supports.

Behavioural guarantees kept from the demo:
  * Verification is BLOCKED unless the canonical 6,236-ayah / 114-surah corpus
    is healthy (fail-closed, never silent).
  * Text-evidence only: labels describe what the audio evidence supports;
    nothing here claims acoustic proof of tajweed or makharij.
  * A sequence-inferred ayah is always labelled SEQUENCE RECOVERY.

Production additions:
  * Structured, PII-free logging (durations, counts, never transcript text).
  * Translations (EN/UR) attached to every returned ayah.
  * Thresholds come from validated settings, not hard-coded magic numbers.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable

from .config import settings
from .corpus import QuranCorpus, CorpusError
from .asr import QuranASR, ASRError, JobCancelled
from .media import decode_to_mono16k, decode_to_mono16k_with_quality, MediaError
from .matcher import align_transcript, recover_single_gap
from .normalization import normalize_arabic
from .coach import build_coaching

log = logging.getLogger("quran_shazam.service")


# FYP STUDY GUIDE: Orchestrates the 4-stage pipeline - decode -> ASR -> match ->
# honest labels - plus per-ayah coaching and the advisory embedding ID.
# WHY: one class owns the whole verification flow so main.py stays thin; the
# stage order and the honest-labelling rules live in exactly one place.
class VerificationService:
    # FYP STUDY GUIDE: Builds QuranCorpus (ensure + translations), QuranASR, and a
    # lazy embedder; records startup_error instead of raising.
    # WHY: fail-closed construction - if the corpus is broken the service records it
    # and /api/health reports it; the app starts but refuses to verify rather than
    # serving wrong results.
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.corpus = QuranCorpus(data_dir)
        self.asr = QuranASR(data_dir / "models")
        self._embedder = None  # Stage 2 (advisory): lazy EmbeddingIdentifier
        self._gemini = None  # Gemini second listen: lazy GeminiASR (None = not built yet)
        self.startup_error: str | None = None
        try:
            self.corpus.ensure()
        except Exception as exc:  # fail-closed: recorded, surfaced via /api/health
            self.startup_error = str(exc)
            log.error("corpus_startup_failed error=%r", str(exc)[:300])
        else:
            # Translations are optional and must never invalidate corpus readiness.
            self.corpus.load_translations()
            log.info(
                "corpus_ready verses=%d surahs=%d sha256=%s",
                len(self.corpus.verses), len(self.corpus.by_surah), self.corpus.sha256[:16],
            )

    # ------------------------------------------------------------- status
    # FYP STUDY GUIDE: Readiness dict - corpus diagnostics, ASR model/loaded state,
    # optional-dependency flags, perf budgets, startup error.
    # WHY: the single source of truth for /api/health - instant and non-blocking, and
    # it surfaces missing packages (soundfile, httpx) as data instead of confusing
    # runtime crashes.
    def health(self) -> dict:
        corpus_diag = (
            self.corpus.diagnostics()
            if self.corpus.verses
            else {"ready": False, "checks": [{"name": "Quran corpus size", "ok": False, "detail": "Loaded 0 verses"}]}
        )
        # Professional: report optional dependency status so missing packages
        # (e.g. soundfile, httpx) are visible in /api/health instead of
        # surfacing as confusing runtime errors.
        deps = {}
        for mod in ("soundfile", "httpx"):
            try:
                __import__(mod)
                deps[mod] = True
            except ImportError:
                deps[mod] = False
        return {
            "ready": bool(corpus_diag.get("ready")),
            "corpus": corpus_diag,
            "asr_model": settings.asr_model,
            "asr_loaded": self.asr.model is not None,
            # Gemini second listen: configured only when a key is set, and
            # enabled only when GEMINI_FALLBACK is on. No key is ever shown.
            "gemini_fallback": {
                "configured": bool(settings.gemini_api_key),
                "enabled": bool(settings.gemini_fallback),
                "model": settings.gemini_model,
            },
            "dependencies": deps,
            "perf_budgets": settings.perf_budgets,
            "error": self.startup_error,
        }

    # FYP STUDY GUIDE: Alias returning health() - the ops-facing name for the same
    # payload.
    # WHY: /api/diagnostics reads better for operators; one implementation means the
    # two route names can never drift apart.
    def diagnostics(self) -> dict:
        return self.health()

    @staticmethod
    # FYP STUDY GUIDE: Static - removes phrases repeated 3+ times consecutively
    # (lengths 15 down to 5).
    # WHY: Whisper repeats 5-15 word phrases when uncertain (its looping failure
    # mode); dedup before matching stops one hallucinated loop dominating coverage.
    def _deduplicate_transcript(text: str) -> str:
        """Remove repeated phrases from ASR output (repetition loop fix).

        Whisper sometimes repeats the same 5-15 word phrase when uncertain.
        We detect phrases repeated 3+ times consecutively and keep only
        the first occurrence.
        """
        words = text.split()
        if len(words) < 20:
            return text
        result = []
        i = 0
        while i < len(words):
            # Try phrase lengths from 15 down to 5
            found_repeat = False
            for plen in range(15, 4, -1):
                if i + plen * 3 > len(words):
                    continue
                phrase = words[i:i+plen]
                # Check if this phrase repeats 2+ more times consecutively
                repeats = 1
                j = i + plen
                while j + plen <= len(words) and words[j:j+plen] == phrase:
                    repeats += 1
                    j += plen
                if repeats >= 3:
                    # Found repetition: keep one copy, skip the rest
                    result.extend(phrase)
                    i = j
                    found_repeat = True
                    break
            if not found_repeat:
                result.append(words[i])
                i += 1
        return " ".join(result)

    # FYP STUDY GUIDE: Strips isti'adha ('a'udhu billahi minash-shaytanir-rajim')
    # spelling variants from the transcript start.
    # WHY: the preamble isn't part of any surah - left in, it derailed matching to
    # wrong surahs (27:30, 37:182, 82:15 on Al-Fatihah); this is preprocessing, not
    # cheating - like trimming silence from audio.
    @staticmethod
    def _strip_opening_supplications(text: str) -> str:
        """Remove common opening supplications (isti'adha) from transcript start.

        Professional: users often begin recitation with "A'udhu billahi minash
        shaytanir rajeem" which is NOT part of any surah. If left in, the
        matcher tries to match these words, fails, and can jump to wrong
        surahs (e.g. Al-Fatihah → 27:30/37:182/82:15). We strip known
        isti'adha phrases from the start before matching.

        FYP STUDY GUIDE: This is text preprocessing, not cheating — we're
        removing non-Quranic preamble that the user said before starting
        the actual recitation, similar to trimming silence from audio.
        """
        import re
        # Normalize for matching
        norm = text.strip()
        # Common isti'adha patterns (various ASR spellings)
        patterns = [
            r"^أعوذ\s+بالله\s+من\s+الشيطان\s+الرجيم\s*",
            r"^اعوذ\s+بالله\s+من\s+الشيطان\s+الرجيم\s*",
            r"^وعوذ\s+بالله\s+من\s+الشيطان\s+الرجيم\s*",
            r"^أَعُوذُ\s+بِاللَّهِ\s+مِنَ\s+الشَّيْطَانِ\s+الرَّجِيمِ\s*",
        ]
        for pat in patterns:
            new_text = re.sub(pat, "", norm, flags=re.IGNORECASE)
            if new_text != norm:
                norm = new_text
                break
        # Diacritic-proof fallback: Gemini returns the A'udhu WITH tashkeel,
        # but the exact code points vary (shadda/fatha order, alef forms),
        # so the literal pattern above misses it — and the unstripped
        # 5-word prefix derails the matcher (a correct Fatiha transcript
        # scored 0/7). Normalize a COPY, check for the plain A'udhu at the
        # start, and if present drop the same 5 leading words from the
        # ORIGINAL text (diacritics intact).
        plain = normalize_arabic(norm)
        if plain.startswith("اعوذ بالله من الشيطان الرجيم"):
            return " ".join(norm.split()[5:])
        return norm

    @staticmethod
    def _prepare_transcript(text: str) -> str:
        """Dedup + strip: the shared prep for every transcript, local or Gemini.

        Both ASR paths must feed the matcher identically prepared text, or
        a comparison between them would measure the prep, not the ASR.
        """
        return VerificationService._strip_opening_supplications(
            VerificationService._deduplicate_transcript(text))

    def _match_and_label(self, transcript: str) -> tuple[list[dict], int, float]:
        """Align a prepared transcript, recover single gaps, apply honest labels.

        The single scoring path for the local transcript AND the Gemini
        fallback transcript: same matcher, same thresholds, same labels.
        Returns (results, verified_count, coverage_percent).
        """
        matches = align_transcript(self.corpus, transcript)
        matches = recover_single_gap(self.corpus, matches, transcript)
        results = []
        for m in matches:
            if m.status == "SEQUENCE RECOVERY":
                label = "SEQUENCE RECOVERY / INCOMPLETE AUDIO EVIDENCE"
            elif (m.score >= settings.verified_score
                  and m.coverage >= settings.verified_coverage
                  and m.missing <= settings.verified_missing
                  and m.length >= 3):
                # Professional: VERIFIED requires at least 3 matched words.
                # Without this, a 1-word verse (e.g. 55:1 "الرحمن") gets
                # VERIFIED 100% from a single word in the basmala — a false
                # positive that destroys trust in the labels.
                label = "VERIFIED TEXT MATCH"
            elif m.score >= 80 and m.length >= 3:
                label = "GOOD TEXT MATCH"
            elif m.score >= 70:
                label = "POSSIBLE MATCH"
            else:
                label = "LOW CONFIDENCE"
            results.append({
                "surah": m.verse.surah,
                "ayah": m.verse.ayah,
                "key": m.verse.key,
                "text": m.verse.text,
                "translation_en": self.corpus.translations_en.get(m.verse.key, ""),
                "translation_ur": self.corpus.translations_ur.get(m.verse.key, ""),
                "confidence": round(m.score, 1),
                "coverage": round(m.coverage, 1),
                "missing": round(m.missing, 1),
                "sequence": round(m.sequence, 1),
                "label": label,
                "reason": m.reason,
                "transcript_start": m.start,
                "transcript_length": m.length,
            })
        transcript_words = len(transcript.split())
        covered = sum(r["transcript_length"] for r in results if "RECOVERY" not in r["label"])
        coverage = 100 * covered / max(1, transcript_words)
        verified = sum(r["label"] == "VERIFIED TEXT MATCH" for r in results)
        return results, verified, coverage

    def _gemini_transcriber(self):
        """The Gemini fallback transcriber, or None when it is unavailable.

        Unavailable means no GEMINI_API_KEY is set (the default) or the
        fallback is disabled with GEMINI_FALLBACK=0. Tests may set
        self._gemini directly to a fake with a transcribe_array method.
        """
        if getattr(self, "_gemini", None) is not None:
            return self._gemini
        if not settings.gemini_fallback or not settings.gemini_api_key:
            return None
        from .gemini_asr import GeminiASR
        self._gemini = GeminiASR(settings.gemini_api_key, settings.gemini_model)
        return self._gemini

    @staticmethod
    def _gemini_wins(g_verified: int, g_results: list[dict],
                     verified: int, results: list[dict]) -> bool:
        """Decide whether the Gemini result beats the local result.

        More VERIFIED ayat wins. On a tie, the higher best score wins.
        A tie on both keeps the local result: the fallback must clearly
        beat local to replace it.
        """
        if g_verified != verified:
            return g_verified > verified
        g_best = max((r["confidence"] for r in g_results), default=0.0)
        best = max((r["confidence"] for r in results), default=0.0)
        return g_best > best

    # ----------------------------------------------------------- verify
    # FYP STUDY GUIDE: Builds Whisper's initial_prompt from a candidate surah's ayat
    # (normalized, truncated to ~600 chars).
    # WHY: prompt-conditioned ASR - the decoder prefers real Quranic vocabulary over
    # invented non-words; truncated because Whisper only needs a vocabulary hint,
    # not the full surah.
    def _build_guided_prompt(self, surah: int, max_chars: int = 600) -> str:
        """Build Whisper initial_prompt from a candidate surah's ayat.

        FYP STUDY GUIDE — why this helps:
          Whisper's decoder predicts one word at a time, always asking "what
          word is most likely NEXT given the audio + what I already wrote?"
          The initial_prompt is text we give it BEFORE it starts — it acts
          like a cheat-sheet of vocabulary. If the prompt contains
          "الرحمن الرحيم" and the audio is unclear, the decoder prefers the
          real Quranic phrase over inventing a non-word like "كذبير".
          We truncate to ~600 chars because Whisper only uses the prompt as
          a vocabulary/style hint — the full surah text is unnecessary, and
          long prompts waste encoder time.
        """
        verses = self.corpus.by_surah.get(surah, [])
        texts = [v.text for v in verses if getattr(v, "text", "")]
        prompt = " ".join(texts)
        prompt = normalize_arabic(prompt)
        return prompt[:max_chars].strip()

    # FYP STUDY GUIDE: Guided-mode Stage A - transcribes only the first ~15s, matches
    # it, and returns the surah (or None when the score is <70).
    # WHY: a cheap surah guess (~one chunk of ASR) to guide Stage B; the >=70 gate
    # matters - a wrong surah would POISON the guided prompt, which is worse than no
    # guidance. (Guided mode itself stays OFF by default per ADR-0003.)
    def _identify_candidate_surah(self, audio, sr: int,
                                  request_id: str = "-") -> int | None:
        """STAGE A of guided verification: transcribe only the FIRST chunk
        (~15s) and match it to find the likely surah. Cheap (~one chunk of
        ASR) and lets Stage B transcribe the full audio with the surah's
        ayat as Whisper's initial_prompt.

        Returns the surah number, or None when identification is too weak
        to trust (then the caller falls back to unguided transcription).
        """
        import numpy as np

        first_s = min(settings.asr_chunk_seconds, len(audio) / sr)
        if first_s < 5:
            return None
        head = np.asarray(audio[:int(first_s * sr)], dtype=np.float32)
        try:
            res = self.asr.transcribe_array(head, sr)  # no progress: fast path
        except Exception as exc:
            log.warning("req=%s guided_stage_a_asr_failed error=%r",
                        request_id, str(exc)[:150])
            return None
        text = normalize_arabic(self._strip_opening_supplications(
            self._deduplicate_transcript(res.get("text", ""))))
        words = text.split()
        if len(words) < 3:
            return None
        try:
            matches = align_transcript(self.corpus, text)
        except Exception:
            return None
        if not matches:
            return None
        top = matches[0]
        # Only trust Stage A when the evidence is decent — a wrong surah
        # would POISON Stage B's prompt, which is worse than no prompt.
        if top.score < 70:
            log.info("req=%s guided_stage_a_weak score=%.1f — unguided",
                     request_id, top.score)
            return None
        log.info("req=%s guided_stage_a surah=%d score=%.1f words=%d",
                 request_id, top.verse.surah, top.score, len(words))
        return top.verse.surah

    # FYP STUDY GUIDE: The full pipeline - decode (+quality gate warnings), ASR with
    # progress/partial callbacks, dedup + preamble strip, no-speech gate, align +
    # gap recovery, honest labels, coaching, advisory embedding candidates.
    # WHY: the heart of the product - every honesty rule lives here: fail-closed
    # corpus check, VERIFIED needs >=90 score + >=85 coverage + <=25 missing + >=3 words
    # (0 false VERIFIED ever), progress callbacks drive the UI and cancellation.
    def verify(self, input_path: Path, request_id: str = "-",
               progress: Callable[[str, float], None] | None = None,
               on_partial: Callable[[str], None] | None = None) -> dict:
        """Run the full pipeline. `progress(stage, pct)` reports 0-100.

        Called from a job worker thread (never the ASGI event loop).
        `on_partial` receives the running transcript after each ASR chunk.
        """
        # FYP STUDY GUIDE: Closure wrapping the progress callback - swallows callback
        # errors but always re-raises JobCancelled.
        # WHY: progress reporting must never break verification, but user cancellation
        # MUST propagate - the one exception this wrapper is forbidden to swallow.
        def report(stage: str, pct: float) -> None:
            if progress:
                try:
                    progress(stage, pct)
                except JobCancelled:
                    raise  # user cancelled: must propagate, never swallow
                except Exception:
                    pass  # progress reporting must never break verification

        if not self.corpus.ready:
            raise RuntimeError(
                "Verification blocked: Quran corpus is not ready. "
                "Run /api/diagnostics first and fix the corpus."
            )
        t0 = time.perf_counter()
        report("Decoding audio…", 6)
        audio, sr, quality = decode_to_mono16k_with_quality(input_path, settings.max_audio_seconds)
        decode_s = time.perf_counter() - t0
        log.info("req=%s decode_ok seconds=%.1f decode_time=%.1fs snr_db=%.1f",
                 request_id, len(audio) / sr, decode_s, quality["snr_db"])
        # PROFESSIONAL quality gate: warn BEFORE expensive transcription when
        # background noise is high. The verify still runs (we never refuse to
        # try), but the frontend shows the warning so the user understands a
        # poor result instead of blaming the recitation.
        warnings: list[dict] = []
        if quality.get("noisy"):
            warnings.append({
                "code": "noisy_audio",
                "message": quality["message"],
                "snr_db": quality["snr_db"],
                "advice_ur": "Shor wali jagah par record na karein — khamosh kamray mein, phone munh se 15-20 cm door rakh kar dobara record karein.",
            })

        import re as _re
        # FYP STUDY GUIDE: Maps 'ASR i/n' chunk messages onto the 12%-82% progress band.
        # WHY: the ASR stage dominates runtime - a fixed band keeps the progress bar
        # truthful (decode 6%, ASR 12-82%, match 88-95%) instead of jumping arbitrarily.
        def asr_progress(msg: str) -> None:
            # msg looks like "ASR 3/12 · 40.0–60.0s" -> map chunks onto 12%..82%
            m = _re.match(r"ASR\s+(\d+)\s*/\s*(\d+)", msg)
            if m:
                idx, total = int(m.group(1)), max(1, int(m.group(2)))
                pct = 12 + 70 * (idx - 1) / total
                report(f"Transcribing audio… (part {idx} of {total})", pct)
            else:
                report("Transcribing audio…", 40)

        # PROFESSIONAL: two-stage reference-guided transcription.
        # Stage A identifies the candidate surah from the first chunk only
        # (cheap); Stage B re-transcribes everything with that surah's ayat
        # as Whisper's initial_prompt, biasing the decoder toward real
        # Quranic vocabulary. Disabled via ASR_GUIDED=0.
        guided_surah: int | None = None
        guided_prompt: str | None = None
        if settings.asr_guided:
            guided_surah = self._identify_candidate_surah(audio, sr, request_id)
            if guided_surah:
                guided_prompt = self._build_guided_prompt(guided_surah)
                log.info("req=%s guided_stage_b surah=%d prompt_chars=%d",
                         request_id, guided_surah, len(guided_prompt))
        asr = self.asr.transcribe_array(audio, sr, progress=asr_progress,
                                        on_partial=on_partial,
                                        initial_prompt=guided_prompt)
        # Shared prep (dedup + strip) for the local transcript. The Gemini
        # fallback transcript goes through the exact same prep below.
        transcript: str = self._prepare_transcript(asr["text"])
        # Professional no-speech gate: reject empty, too-short, or
        # hallucinated transcripts before matching. This prevents false
        # positives on silence, clicks, room noise, or breathing.
        _words = transcript.strip().split()
        _unique = set(_words)
        if (not _words
                or len(_words) < 3
                or len(_unique) < 3 and len(_words) >= 3):
            # Too few words, or the same 1-2 words repeated (hallucination)
            raise RuntimeError(
                "No clear Arabic speech was recognized in this audio. "
                "Please try a clearer or longer recording."
            )

        report("Matching against the Quran…", 88)
        results, verified, coverage = self._match_and_label(transcript)
        report("Finalizing results…", 95)

        # PROFESSIONAL (2026-11-07): Gemini second listen (fallback).
        # The local model always runs first. Only when it finds ZERO
        # VERIFIED ayat do we ask Gemini for a second transcription of
        # the same audio — and only keep it when it clearly beats local
        # (more VERIFIED, or a higher best score on a tie). No key (the
        # default) means no fallback: behaviour is unchanged. A failed
        # second listen never breaks verification: the local result
        # stands and the failure is reported, not hidden.
        asr_source = "local"
        fallback_used = False
        fallback_error: str | None = None
        local_transcript = transcript
        gemini_transcript: str | None = None
        gemini_seconds: float | None = None
        if verified == 0:
            gemini = self._gemini_transcriber()
            if gemini is not None:
                fallback_used = True
                report("Checking with a second listener…", 90)
                try:
                    g_asr = gemini.transcribe_array(audio, sr)
                    gemini_transcript = self._prepare_transcript(g_asr["text"])
                    gemini_seconds = g_asr.get("seconds")
                    _g_words = gemini_transcript.strip().split()
                    if len(_g_words) < 3 or len(set(_g_words)) < 3:
                        raise RuntimeError("no clear speech in second listen")
                    g_results, g_verified, g_coverage = self._match_and_label(
                        gemini_transcript)
                    if self._gemini_wins(g_verified, g_results, verified, results):
                        results, verified, coverage = g_results, g_verified, g_coverage
                        transcript = gemini_transcript
                        asr_source = "gemini"
                        log.info("req=%s gemini_fallback_won gemini_verified=%d "
                                 "gemini_seconds=%s", request_id, g_verified,
                                 gemini_seconds)
                    else:
                        log.info("req=%s gemini_fallback_kept_local "
                                 "gemini_verified=%d", request_id, g_verified)
                except Exception as exc:
                    fallback_error = str(exc)[:200]
                    log.warning("req=%s gemini_fallback_failed error=%r",
                                request_id, fallback_error)

        transcript_words = len(transcript.split())
        total_s = time.perf_counter() - t0
        log.info(
            "req=%s verify_done results=%d verified=%d coverage=%.1f total_time=%.1fs device=%s realtime=%.2f asr_source=%s fallback_used=%s",
            request_id, len(results), verified, coverage, total_s, asr["device"], asr["realtime"],
            asr_source, fallback_used,
        )
        # PROFESSIONAL "Quran Coach": per-ayah coaching feedback built from the
        # REAL matcher output (never invented). Turns "Shazam" (identify)
        # into "Shazam + Coach" (identify + teach). Word timings come from
        # the LOCAL asr segments only: when Gemini won, the local timings
        # belong to a different transcript, so coaching runs without them.
        segments = asr.get("segments", []) if asr_source == "local" else []
        coaching = build_coaching(transcript, results, segments)
        # PROFESSIONAL REDESIGN Stage 2 — embedding ID, ADVISORY ONLY.
        # A second opinion that never looks at words: wav2vec2 fingerprint
        # vs the reference index. It NEVER changes a verdict — it is logged
        # and returned for transparency while it proves itself on real data
        # (see ADR-0008). Costs nothing when the model/index is absent.
        embedding_candidates = self._embed_candidates(input_path, request_id,
                                                       results)
        out = {
            "request_id": request_id,
            "duration": round(len(audio) / sr, 1),
            "transcript": transcript,
            "segments": segments,
            "recognized_words": transcript_words,
            "results": results,
            "coaching": coaching,
            "embedding_candidates": embedding_candidates,
            "verified_count": verified,
            "coverage": round(min(100, coverage), 1),
            "device": asr["device"],
            "realtime": round(asr["realtime"], 2),
            "processing_seconds": round(total_s, 1),
            "guided_surah": guided_surah,
            "warnings": warnings,
            "audio_quality": {"snr_db": quality["snr_db"], "noisy": quality["noisy"]},
            # Gemini second listen: which engine produced the transcript.
            # "local" = the offline Whisper model (always the default);
            # "gemini" = the fallback won. The local transcript is kept
            # alongside the winner's so the choice is auditable.
            "asr_source": asr_source,
            "fallback_used": fallback_used,
        }
        if fallback_used:
            out["local_transcript"] = local_transcript
            out["gemini_transcript"] = gemini_transcript
            out["gemini_seconds"] = gemini_seconds
            out["fallback_error"] = fallback_error
        return out

    # ------------------------------------------- stage 2 (advisory only)
    # FYP STUDY GUIDE: Advisory wav2vec2 fingerprint candidates; logs whether the top
    # candidate agrees with the text matcher; never raises.
    # WHY: builds the evidence trail for/against embedding ID (ADR-0008/0009) without
    # ever touching a verdict - wrapped so its failure can't break verification.
    def _embed_candidates(self, input_path: Path, request_id: str,
                          results: list[dict]) -> list[dict]:
        """Advisory embedding-based ayat candidates (never verdicts)."""
        try:
            if self._embedder is None:
                from .embed_id import EmbeddingIdentifier
                self._embedder = EmbeddingIdentifier(self.data_dir)
            cands = self._embedder.identify(Path(input_path), top_k=5)
            if cands and results:
                top = cands[0]["key"]
                agree = any(r.get("key") == top for r in results)
                log.info("req=%s embed_id top=%s sim=%.2f "
                         "agree_with_text_matcher=%s",
                         request_id, top, cands[0]["similarity"], agree)
            return cands
        except Exception as exc:  # advisory must never break verification
            log.warning("req=%s embed_id advisory failed: %s",
                        request_id, str(exc)[:150])
            return []

    # ----------------------------------------------------------- identify (quick)
    # FYP STUDY GUIDE: Quick surah ID - 3 samples (5%/40%/75% of the audio, 20s each)
    # transcribed, votes summed by match score; no full listen.
    # WHY: answers 'which surah is this?' in seconds from ~60s of transcription
    # instead of minutes - sampling start/middle/end catches the surah even in long
    # recitations.
    def identify(self, input_path: Path, request_id: str = "-") -> dict:
        """Quick surah identification from audio samples — no full listen.

        Takes 3 short samples (start, middle, end), transcribes only those
        (~60s total instead of the whole file), and votes for the surah.
        Answers "which surah is this?" in seconds, not minutes.
        For ayah-by-ayah verification, use verify().
        """
        import numpy as np
        from .matcher import align_transcript as _align

        t0 = time.perf_counter()
        if not self.corpus.ready:
            raise RuntimeError("Corpus not ready.")
        audio, sr = decode_to_mono16k(input_path, settings.max_audio_seconds)
        total_s = len(audio) / sr
        sample_s = 20.0
        # Sample positions: 5% , 40%, 75% of the audio (skip very start/end).
        positions = [0.05 * total_s, 0.40 * total_s, 0.75 * total_s]
        votes: dict[int, float] = {}
        sample_texts = []
        for p in positions:
            s0 = int(max(0, p) * sr)
            s1 = int(min(total_s, p + sample_s) * sr)
            chunk = np.asarray(audio[s0:s1], dtype=np.float32)
            if len(chunk) < sr * 5:
                continue
            res = self.asr.transcribe_array(chunk, sr)
            txt = res["text"].strip()
            sample_texts.append({"at_seconds": round(p, 1), "text": txt[:200]})
            if not txt:
                continue
            matches = _align(self.corpus, txt)
            for m in matches[:3]:
                votes[m.verse.surah] = votes.get(m.verse.surah, 0.0) + m.score
        if not votes:
            raise RuntimeError("Could not identify any surah from the audio samples.")
        best_surah = max(votes, key=lambda k: votes[k])
        total_votes = sum(votes.values())
        verses = self.corpus.by_surah.get(best_surah, [])
        dt = time.perf_counter() - t0
        log.info("req=%s identify_done surah=%s votes=%.1f time=%.1fs",
                 request_id, best_surah, votes[best_surah], dt)
        return {
            "request_id": request_id,
            "surah": best_surah,
            "surah_name": f"Surah {best_surah}",
            "ayah_count": len(verses),
            "confidence": round(100 * votes[best_surah] / max(1, total_votes), 1),
            "audio_duration": round(total_s, 1),
            "sampled_seconds": round(sample_s * len(sample_texts), 1),
            "processing_seconds": round(dt, 1),
            "samples": sample_texts,
        }
