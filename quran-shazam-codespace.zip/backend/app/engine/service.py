"""Orchestration layer: media -> ASR -> matching -> labelled results.

This is the production evolution of the demo engine. Behavioural guarantees
kept from the demo:
  * Verification is BLOCKED unless the canonical 6,236-ayah / 114-surah corpus
    is healthy (fail-closed, never silent).
  * Text-evidence only: labels describe what the audio evidence supports;
    nothing here claims acoustic proof of tajweed or makharij.
  * A sequence-inferred ayah is always labelled SEQUENCE RECOVERY.

Production additions:
  * Structured, PII-free logging (durations, counts, never transcript text).
  * Translations (EN/UR) attached to every returned ayah.
  * Thresholds come from validated settings, not hard-coded magic numbers.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable

from .config import settings
from .corpus import QuranCorpus, CorpusError
from .asr import QuranASR, ASRError
from .media import decode_to_mono16k, MediaError
from .matcher import align_transcript, recover_single_gap

log = logging.getLogger("quran_shazam.service")


class VerificationService:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.corpus = QuranCorpus(data_dir)
        self.asr = QuranASR()
        self.startup_error: str | None = None
        try:
            self.corpus.ensure()
        except Exception as exc:  # fail-closed: recorded, surfaced via /api/health
            self.startup_error = str(exc)
            log.error("corpus_startup_failed error=%r", str(exc)[:300])
        else:
            # Translations are optional and must never invalidate corpus readiness.
            self.corpus.load_translations()
            log.info(
                "corpus_ready verses=%d surahs=%d sha256=%s",
                len(self.corpus.verses), len(self.corpus.by_surah), self.corpus.sha256[:16],
            )

    # ------------------------------------------------------------- status
    def health(self) -> dict:
        corpus_diag = (
            self.corpus.diagnostics()
            if self.corpus.verses
            else {"ready": False, "checks": [{"name": "Quran corpus size", "ok": False, "detail": "Loaded 0 verses"}]}
        )
        return {
            "ready": bool(corpus_diag.get("ready")),
            "corpus": corpus_diag,
            "asr_model": settings.asr_model,
            "asr_loaded": self.asr.pipe is not None,
            "error": self.startup_error,
        }

    def diagnostics(self) -> dict:
        return self.health()

    # ----------------------------------------------------------- verify
    def verify(self, input_path: Path, request_id: str = "-",
               progress: Callable[[str, float], None] | None = None) -> dict:
        """Run the full pipeline. `progress(stage, pct)` reports 0-100.

        Called from the job worker thread (never the ASGI event loop).
        """
        def report(stage: str, pct: float) -> None:
            if progress:
                try:
                    progress(stage, pct)
                except Exception:
                    pass  # progress reporting must never break verification

        if not self.corpus.ready:
            raise RuntimeError(
                "Verification blocked: Quran corpus is not ready. "
                "Run /api/diagnostics first and fix the corpus."
            )
        t0 = time.perf_counter()
        report("Decoding audio…", 6)
        audio, sr = decode_to_mono16k(input_path, settings.max_audio_seconds)
        decode_s = time.perf_counter() - t0
        log.info("req=%s decode_ok seconds=%.1f decode_time=%.1fs", request_id, len(audio) / sr, decode_s)

        import re as _re
        def asr_progress(msg: str) -> None:
            # msg looks like "ASR 3/12 · 40.0–60.0s" -> map chunks onto 12%..82%
            m = _re.match(r"ASR\s+(\d+)\s*/\s*(\d+)", msg)
            if m:
                idx, total = int(m.group(1)), max(1, int(m.group(2)))
                pct = 12 + 70 * (idx - 1) / total
                report(f"Transcribing audio… (part {idx} of {total})", pct)
            else:
                report("Transcribing audio…", 40)

        asr = self.asr.transcribe_array(audio, sr, progress=asr_progress)
        transcript: str = asr["text"]
        if not transcript.strip():
            raise RuntimeError(
                "No clear Arabic speech was recognized in this audio. "
                "Please try a clearer or longer recording."
            )

        report("Matching against the Quran…", 88)
        matches = align_transcript(self.corpus, transcript)
        report("Finalizing results…", 95)
        matches = recover_single_gap(self.corpus, matches, transcript)

        results = []
        for m in matches:
            if m.status == "SEQUENCE RECOVERY":
                label = "SEQUENCE RECOVERY / INCOMPLETE AUDIO EVIDENCE"
            elif (m.score >= settings.verified_score
                  and m.coverage >= settings.verified_coverage
                  and m.missing <= settings.verified_missing):
                label = "VERIFIED TEXT MATCH"
            elif m.score >= 80:
                label = "GOOD TEXT MATCH"
            elif m.score >= 70:
                label = "POSSIBLE MATCH"
            else:
                label = "LOW CONFIDENCE"
            results.append({
                "surah": m.verse.surah,
                "ayah": m.verse.ayah,
                "key": m.verse.key,
                "text": m.verse.text,
                "translation_en": self.corpus.translations_en.get(m.verse.key, ""),
                "translation_ur": self.corpus.translations_ur.get(m.verse.key, ""),
                "confidence": round(m.score, 1),
                "coverage": round(m.coverage, 1),
                "missing": round(m.missing, 1),
                "sequence": round(m.sequence, 1),
                "label": label,
                "reason": m.reason,
                "transcript_start": m.start,
                "transcript_length": m.length,
            })

        transcript_words = len(transcript.split())
        covered = sum(r["transcript_length"] for r in results if "RECOVERY" not in r["label"])
        coverage = 100 * covered / max(1, transcript_words)
        verified = sum(r["label"] == "VERIFIED TEXT MATCH" for r in results)
        total_s = time.perf_counter() - t0
        log.info(
            "req=%s verify_done results=%d verified=%d coverage=%.1f total_time=%.1fs device=%s realtime=%.2f",
            request_id, len(results), verified, coverage, total_s, asr["device"], asr["realtime"],
        )
        return {
            "request_id": request_id,
            "duration": round(len(audio) / sr, 1),
            "transcript": transcript,
            "recognized_words": transcript_words,
            "results": results,
            "verified_count": verified,
            "coverage": round(min(100, coverage), 1),
            "device": asr["device"],
            "realtime": round(asr["realtime"], 2),
            "processing_seconds": round(total_s, 1),
        }
