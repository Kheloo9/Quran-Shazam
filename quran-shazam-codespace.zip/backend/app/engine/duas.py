"""Curated masnoon duas with Arabic, transliteration, translations, and authentic references.

FYP STUDY GUIDE: Every dua carries a `reference` field citing its authentic
source (Quran ayah or Hadith collection). Islamic scholars require source
attribution for duas — a dua without a reference cannot be verified as
authentic (masnoon).
"""
DUAS = [
    {
        "title": "Rabbana Aatina",
        "arabic": "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
        "transliteration": "Rabbana atina fid-dunya hasanah, wa fil-akhirati hasanah, wa qina azaban-nar",
        "en": "Our Lord, give us good in this world and good in the Hereafter, and shield us from the punishment of the Fire.",
        "ur": "اے ہمارے رب! ہمیں دنیا میں بھلائی عطا فرما اور آخرت میں بھی بھلائی عطا فرما، اور ہمیں دوزخ کے عذاب سے بچا۔",
        "reference": "Quran 2:201",
    },
    {
        "title": "Rabbighfir Li",
        "arabic": "رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
        "transliteration": "Rabbighfir li wa liwalidayya wa lil-mu'minina yawma yaqumul-hisab",
        "en": "My Lord, forgive me, my parents, and the believers on the Day the reckoning is established.",
        "ur": "اے میرے رب! مجھے، میرے والدین کو اور تمام مومنوں کو اس دن بخش دے جس دن حساب قائم ہوگا۔",
        "reference": "Quran 14:41 (dua of Ibrahim AS)",
    },
    {
        "title": "Allahumma Inni As'aluka",
        "arabic": "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا",
        "transliteration": "Allahumma inni as'aluka ilman nafi'an, wa rizqan tayyiban, wa amalan mutaqabbal",
        "en": "O Allah, I ask You for beneficial knowledge, wholesome provision, and accepted deeds.",
        "ur": "اے اللہ! میں تجھ سے نفع بخش علم، پاکیزہ رزق اور قبول ہونے والے عمل کا سوال کرتا ہوں۔",
        "reference": "Sunan Ibn Majah 925",
    },
    {
        "title": "Hasbunallahu",
        "arabic": "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
        "transliteration": "Hasbunallahu wa ni'mal-wakil",
        "en": "Allah is sufficient for us, and He is the best Disposer of affairs.",
        "ur": "ہمیں اللہ کافی ہے اور وہ بہترین کارساز ہے۔",
        "reference": "Quran 3:173",
    },
    {
        "title": "Rabbishrah Li Sadri",
        "arabic": "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
        "transliteration": "Rabbishrah li sadri, wa yassir li amri",
        "en": "My Lord, expand for me my chest and ease for me my task.",
        "ur": "اے میرے رب! میرا سینہ کھول دے اور میرا کام آسان کر دے۔",
        "reference": "Quran 20:25-26 (dua of Musa AS)",
    },
    {
        "title": "Allahumma Ajirni",
        "arabic": "اللَّهُمَّ أَجِرْنِي مِنَ النَّارِ",
        "transliteration": "Allahumma ajirni minan-nar",
        "en": "O Allah, protect me from the Fire.",
        "ur": "اے اللہ! مجھے دوزخ کی آگ سے بچا۔",
        "reference": "Sunan Abi Dawud 5079",
    },
    {
        "title": "SubhanAllahi wa Bihamdihi",
        "arabic": "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "transliteration": "SubhanAllahi wa bihamdihi",
        "en": "Glory be to Allah and praise Him. (Whoever says it 100x daily, his sins are wiped away)",
        "ur": "اللہ پاک ہے اور اسی کی حمد ہے۔",
        "reference": "Sahih al-Bukhari 6405; Sahih Muslim 2691",
    },
    {
        "title": "La Ilaha Illa Anta",
        "arabic": "لَا إِلَٰهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ",
        "transliteration": "La ilaha illa anta, subhanaka, inni kuntu minaz-zalimin",
        "en": "There is no deity but You; glory be to You. Indeed, I have been of the wrongdoers.",
        "ur": "تیرے سوا کوئی معبود نہیں، تو پاک ہے، بے شک میں ظالموں میں سے تھا۔",
        "reference": "Quran 21:87 (dua of Yunus AS)",
    },
]
