"""Production settings for Quran Shazam.

Every value is validated at import time so a misconfigured deployment
fails loudly at startup instead of silently misbehaving at runtime.
Secrets and tunables come from the environment (see .env.example).
"""
from __future__ import annotations

import os
import sys


# FYP STUDY GUIDE: Reads a string env var (stripped), falling back to the default.
# WHY: every tunable lives in the environment (12-factor style) - the same build
# runs on a laptop and a codespace with different settings, no code change.
def _get(name: str, default: str) -> str:
    return os.getenv(name, default).strip()


# FYP STUDY GUIDE: Reads an int env var and validates it is a number inside
# [minimum, maximum]; anything else is a FATAL startup exit.
# WHY: fail loud at startup - a typo like JOB_WORKERS=abc must crash the deploy
# visibly, never silently misbehave at runtime.
def _get_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw.strip())
    except ValueError:
        sys.exit(f"FATAL: {name} must be an integer, got {raw!r}")
    if not minimum <= value <= maximum:
        sys.exit(f"FATAL: {name} must be between {minimum} and {maximum}, got {value}")
    return value


# FYP STUDY GUIDE: Same validated read as _get_int, for floats (thresholds,
# timeouts, budgets).
# WHY: verification thresholds come from here - a broken threshold would corrupt
# every label, so misconfiguration must be impossible to miss.
def _get_float(name: str, default: float, minimum: float, maximum: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = float(raw.strip())
    except ValueError:
        sys.exit(f"FATAL: {name} must be a number, got {raw!r}")
    if not minimum <= value <= maximum:
        sys.exit(f"FATAL: {name} must be between {minimum} and {maximum}, got {value}")
    return value


# FYP STUDY GUIDE: Parses truthy env strings ('1', 'true', 'yes', 'on').
# WHY: boolean flags (ASR_VAD, ASR_GUIDED) need a forgiving parser - operators
# write ASR_VAD=1, not Python literals.
def _get_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


# FYP STUDY GUIDE: All runtime settings in one place - env, model choice, chunking,
# upload caps, rate limits, verification thresholds, perf budgets - validated
# at construction.
# WHY: a single validated source of truth - thresholds come from settings, not
# hard-coded magic numbers, so tuning never requires a code change.
class Settings:
    """Validated runtime settings (frozen after construction)."""

    # FYP STUDY GUIDE: Reads ~30 settings from the environment and validates every
    # one (sys.exit with a clear message on any invalid value).
    # WHY: the fail-fast gate for the whole app - a misconfigured deploy dies in
    # seconds with 'FATAL: ...' instead of serving wrong verdicts for weeks.
    def __init__(self) -> None:
        # --- Environment ---
        # development | production. Production disables /docs, /redoc and openapi.json.
        self.env: str = _get("ENV", "development").lower()
        if self.env not in {"development", "production", "staging"}:
            sys.exit(f"FATAL: ENV must be development|staging|production, got {self.env!r}")
        self.log_level: str = _get("LOG_LEVEL", "info").upper()

        # --- Corpus / model sources (pinned by default; override only deliberately) ---
        self.corpus_url: str = _get("QURAN_CORPUS_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json")
        self.en_url: str = _get("QURAN_EN_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran_en.json")
        self.ur_url: str = _get("QURAN_UR_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran_ur.json")
        self.asr_model: str = _get("ASR_MODEL", "tarteel-ai/whisper-base-ar-quran")
        # TEAM BIGMODEL (2026-10-19): tested naazimsnh02/whisper-large-v3-turbo-ar-quran
        # (809M) and basharalrfooh/whisper-small-quran (244M) head-to-head against
        # this base model on the client's Al-Fatihah MP3 through the PRODUCTION
        # pipeline. Result: base wins on ayat recovery (7/7, 4 VERIFIED vs turbo's
        # 5/7 — turbo loses 1:2 entirely under the production noise gate; small is
        # only marginally better on words but 3.3x slower). Base stays default.
        # Override with ASR_MODEL env var to experiment.
        # Revision pin: only applies to the tiny model; base uses latest
        _default_rev = "d834ce64c6c51e3ed5d5c367b788621bd515796e" if "tiny" in self.asr_model else ""
        self.asr_revision: str = _get("ASR_REVISION", _default_rev)
        self.request_timeout: float = _get_float("REQUEST_TIMEOUT", 30.0, 5.0, 300.0)

        # --- faster-whisper (CTranslate2) engine tunables ---
        # ASR_MODEL may be a HuggingFace id (auto-converted to CTranslate2 on
        # first run and cached) or a stock faster-whisper size name
        # (tiny/base/small/medium/large-v3/...) used directly.
        self.asr_ct2_dir: str = _get("ASR_CT2_DIR", "")
        self.asr_compute_type: str = _get("ASR_COMPUTE_TYPE", "auto").lower()
        if self.asr_compute_type not in {"auto", "int8", "int8_float32", "int8_float16", "float16", "float32"}:
            sys.exit(f"FATAL: ASR_COMPUTE_TYPE must be auto|int8|int8_float32|int8_float16|float16|float32, got {self.asr_compute_type!r}")
        self.asr_beam_size: int = _get_int("ASR_BEAM_SIZE", 1, 1, 5)
        self.asr_vad: bool = _get_bool("ASR_VAD", True)
        # PROFESSIONAL (2026-10-19): reference-guided transcription.
        # When ON, verify() runs a cheap Stage A (transcribe first chunk,
        # identify candidate surah) then Stage B (re-transcribe everything
        # with that surah's ayat as Whisper's initial_prompt). DEFAULT OFF:
        # validated 2026-10-19 on the client's Al-Fatihah MP3 — guided was
        # WORSE (34 words, 2/7 ayat, 0 VERIFIED) than unguided (36 words,
        # 7/7 ayat, 4 VERIFIED). The full-surah prompt made Whisper
        # hallucinate an isti'adha opening ("واوذ بالله من الشيطان الرجيم"),
        # which the strip patterns missed (spelling variant) and derailed
        # the matcher to wrong surahs (27:30, 45:36). See
        # docs/adr/0003-reference-guided-transcription.md. Set ASR_GUIDED=1
        # to experiment.
        self.asr_guided: bool = _get_bool("ASR_GUIDED", False)
        # --- Gemini second listen (fallback, 2026-11-07) ---
        # When the local Whisper result has ZERO VERIFIED ayat, verify()
        # asks Gemini (gemini-3.8-flash) for a second transcription of the
        # same audio and keeps whichever result has more VERIFIED ayat.
        # The local model always runs first and stays the default: Gemini
        # is API-only (internet + key, free-tier 503 overloads), so it can
        # never replace the offline model — it only rescues poor results.
        # Empty key (the default) disables the fallback entirely and the
        # behaviour is exactly as before. The key is never logged.
        self.gemini_api_key: str = _get("GEMINI_API_KEY", "")
        self.gemini_model: str = _get("GEMINI_MODEL", "gemini-3.8-flash")
        self.gemini_fallback: bool = _get_bool("GEMINI_FALLBACK", True)
        # ar = Quran recitation (default, most accurate). "auto" enables
        # detection; ur/hi/en also supported by the underlying model.
        self.asr_language: str = _get("ASR_LANGUAGE", "ar").lower()
        # TEAM 7 (2026-10-19): chunk 60s->15s, overlap 2s->3s. Validated live on
        # the client's Al-Fatihah MP3: 60s chunk=27 words, tail (ayat 6-7)
        # missing; 20s chunk=27 words, tail missing; 15s chunk=35 words with
        # صراط الذين انعمت عليهم غير المغضوب...وللضالين RECOVERED. Root cause:
        # a long chunk forces two internal 30s Whisper windows in one decode;
        # the 2nd window under-generates. 15s windows keep every decode inside
        # a single Whisper window. Cost: ~1.6x ASR time (still seconds).
        self.asr_chunk_seconds: int = _get_int("ASR_CHUNK_SECONDS", 15, 10, 300)
        self.asr_overlap_seconds: int = _get_int("ASR_OVERLAP_SECONDS", 3, 0, 15)
        if self.asr_overlap_seconds >= self.asr_chunk_seconds:
            sys.exit("FATAL: ASR_OVERLAP_SECONDS must be smaller than ASR_CHUNK_SECONDS")

        # --- Background job workers ---
        # 1 = safest on small Codespaces (model is heavy). Raise to 2-4 on
        # bigger machines so several uploads transcribe concurrently.
        self.job_workers: int = _get_int("JOB_WORKERS", 1, 1, 8)

        # --- Upload / media guardrails ---
        # Hard caps keep one abusive request from exhausting RAM/disk/CPU.
        self.max_audio_seconds: int = _get_int("MAX_AUDIO_SECONDS", 10800, 10, 10800)   # default 3h (full long surahs like Al-Baqarah ~2h work out of the box)
        self.max_upload_mb: int = _get_int("MAX_UPLOAD_MB", 200, 1, 1280)             # default 200 MB
        self.chunk_seconds: int = _get_int("CHUNK_SECONDS", 20, 5, 60)
        self.overlap_seconds: int = _get_int("OVERLAP_SECONDS", 4, 0, 15)
        if self.overlap_seconds >= self.chunk_seconds:
            sys.exit("FATAL: OVERLAP_SECONDS must be smaller than CHUNK_SECONDS")
        self.allowed_extensions: frozenset[str] = frozenset(
            e.strip().lower() for e in _get(
                "ALLOWED_EXTENSIONS",
                ".mp3,.wav,.m4a,.aac,.ogg,.opus,.flac,.mp4,.mov,.mkv,.webm",
            ).split(",") if e.strip()
        )

        # --- Rate limiting (slowapi): "<n>/<period>" e.g. "20/minute" ---
        self.rate_limit_verify: str = _get("RATE_LIMIT_VERIFY", "20/minute")
        self.rate_limit_general: str = _get("RATE_LIMIT_GENERAL", "120/minute")

        # --- Network / proxy ---
        # Comma-separated origins allowed to call the API from a browser. Empty = same-origin only.
        self.cors_origins: tuple[str, ...] = tuple(
            o.strip() for o in _get("CORS_ORIGINS", "").split(",") if o.strip()
        )
        self.trusted_hosts: tuple[str, ...] = tuple(
            h.strip() for h in _get("TRUSTED_HOSTS", "*").split(",") if h.strip()
        )
        # Set to 1 when TLS is terminated at a reverse proxy (nginx) in front of the app.
        self.proxy_headers: bool = _get_bool("PROXY_HEADERS", False)

        # --- Optional API key auth ---
        # When set, /api/* (except /api/health) requires header X-API-Key: <value>.
        self.api_key: str = _get("API_KEY", "")
        # Maximum number of CPU worker processes for ASR preloading hint (informational).
        self.workers: int = _get_int("WORKERS", 1, 1, 16)

        # --- Verification policy thresholds ---
        self.verified_score: float = _get_float("VERIFIED_SCORE", 90.0, 50.0, 100.0)
        self.verified_coverage: float = _get_float("VERIFIED_COVERAGE", 85.0, 50.0, 100.0)
        self.verified_missing: float = _get_float("VERIFIED_MISSING", 25.0, 0.0, 100.0)

        # --- Performance budgets (seconds) — PROFESSIONAL (2026-10-19) ---
        # FYP STUDY GUIDE: a "performance budget" is a promise: "this endpoint
        # answers within X seconds for 95% of requests (p95)". Teams set them
        # so slowdowns are caught as BUGS, not discovered by angry users.
        # These are enforced as LOG-ONLY (never block a request): the timing
        # middleware in main.py logs "perf_budget_exceeded" when a request
        # passes its budget. See PERF_BUDGETS.md for rationale per endpoint.
        self.perf_budgets: dict[str, float] = {
            "verify_single_ayah": 30.0,   # one ayah upload -> full verify
            "surah_load": 2.0,            # GET /api/quran/surah/{n}
            "tafseer": 1.0,               # GET /api/quran/tafseer/{s}/{a}
            "audio_start": 5.0,           # GET /api/audio/{s}/{a} first byte
            "qa": 10.0,                   # POST /api/ask
            "translate": 3.0,             # GET /api/quran/translate
        }

    @property
    # FYP STUDY GUIDE: Property - True only when ENV=production.
    # WHY: gates production-only behavior (HSTS header, disabling /docs) so that
    # development conveniences can never leak onto a public deployment.
    def is_production(self) -> bool:
        return self.env == "production"


settings = Settings()
