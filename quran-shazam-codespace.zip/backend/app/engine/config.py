"""Production settings for Quran Shazam.

Every value is validated at import time so a misconfigured deployment
fails loudly at startup instead of silently misbehaving at runtime.
Secrets and tunables come from the environment (see .env.example).
"""
from __future__ import annotations

import os
import sys


def _get(name: str, default: str) -> str:
    return os.getenv(name, default).strip()


def _get_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw.strip())
    except ValueError:
        sys.exit(f"FATAL: {name} must be an integer, got {raw!r}")
    if not minimum <= value <= maximum:
        sys.exit(f"FATAL: {name} must be between {minimum} and {maximum}, got {value}")
    return value


def _get_float(name: str, default: float, minimum: float, maximum: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = float(raw.strip())
    except ValueError:
        sys.exit(f"FATAL: {name} must be a number, got {raw!r}")
    if not minimum <= value <= maximum:
        sys.exit(f"FATAL: {name} must be between {minimum} and {maximum}, got {value}")
    return value


def _get_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


class Settings:
    """Validated runtime settings (frozen after construction)."""

    def __init__(self) -> None:
        # --- Environment ---
        # development | production. Production disables /docs, /redoc and openapi.json.
        self.env: str = _get("ENV", "development").lower()
        if self.env not in {"development", "production", "staging"}:
            sys.exit(f"FATAL: ENV must be development|staging|production, got {self.env!r}")
        self.log_level: str = _get("LOG_LEVEL", "info").upper()

        # --- Corpus / model sources (pinned by default; override only deliberately) ---
        self.corpus_url: str = _get("QURAN_CORPUS_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json")
        self.en_url: str = _get("QURAN_EN_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran_en.json")
        self.ur_url: str = _get("QURAN_UR_URL", "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran_ur.json")
        self.asr_model: str = _get("ASR_MODEL", "tarteel-ai/whisper-tiny-ar-quran")
        self.asr_revision: str = _get("ASR_REVISION", "d834ce64c6c51e3ed5d5c367b788621bd515796e")
        self.request_timeout: float = _get_float("REQUEST_TIMEOUT", 30.0, 5.0, 300.0)

        # --- Upload / media guardrails ---
        # Hard caps keep one abusive request from exhausting RAM/disk/CPU.
        self.max_audio_seconds: int = _get_int("MAX_AUDIO_SECONDS", 1800, 10, 7200)   # default 30 min
        self.max_upload_mb: int = _get_int("MAX_UPLOAD_MB", 200, 1, 1280)             # default 200 MB
        self.chunk_seconds: int = _get_int("CHUNK_SECONDS", 20, 5, 60)
        self.overlap_seconds: int = _get_int("OVERLAP_SECONDS", 4, 0, 15)
        if self.overlap_seconds >= self.chunk_seconds:
            sys.exit("FATAL: OVERLAP_SECONDS must be smaller than CHUNK_SECONDS")
        self.allowed_extensions: frozenset[str] = frozenset(
            e.strip().lower() for e in _get(
                "ALLOWED_EXTENSIONS",
                ".mp3,.wav,.m4a,.aac,.ogg,.opus,.flac,.mp4,.mov,.mkv,.webm",
            ).split(",") if e.strip()
        )

        # --- Rate limiting (slowapi): "<n>/<period>" e.g. "20/minute" ---
        self.rate_limit_verify: str = _get("RATE_LIMIT_VERIFY", "20/minute")
        self.rate_limit_general: str = _get("RATE_LIMIT_GENERAL", "120/minute")

        # --- Network / proxy ---
        # Comma-separated origins allowed to call the API from a browser. Empty = same-origin only.
        self.cors_origins: tuple[str, ...] = tuple(
            o.strip() for o in _get("CORS_ORIGINS", "").split(",") if o.strip()
        )
        self.trusted_hosts: tuple[str, ...] = tuple(
            h.strip() for h in _get("TRUSTED_HOSTS", "*").split(",") if h.strip()
        )
        # Set to 1 when TLS is terminated at a reverse proxy (nginx) in front of the app.
        self.proxy_headers: bool = _get_bool("PROXY_HEADERS", False)

        # --- Optional API key auth ---
        # When set, /api/* (except /api/health) requires header X-API-Key: <value>.
        self.api_key: str = _get("API_KEY", "")
        # Maximum number of CPU worker processes for ASR preloading hint (informational).
        self.workers: int = _get_int("WORKERS", 1, 1, 16)

        # --- Verification policy thresholds ---
        self.verified_score: float = _get_float("VERIFIED_SCORE", 90.0, 50.0, 100.0)
        self.verified_coverage: float = _get_float("VERIFIED_COVERAGE", 85.0, 50.0, 100.0)
        self.verified_missing: float = _get_float("VERIFIED_MISSING", 25.0, 0.0, 100.0)

    @property
    def is_production(self) -> bool:
        return self.env == "production"


settings = Settings()
