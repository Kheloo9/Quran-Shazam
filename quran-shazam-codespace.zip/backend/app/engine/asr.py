from __future__ import annotations
import copy
import logging
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from pathlib import Path
from typing import Callable
import numpy as np

from .config import settings
from .normalization import normalize_arabic

log = logging.getLogger("quran_shazam.asr")

class ASRError(RuntimeError): pass


# Whisper's native anti-hallucination guards (OpenAI defaults).
# If a segment looks like a repetition loop (high gzip compression ratio) or
# is low-confidence, it is discarded and retried once with a higher
# temperature instead of looping forever. Without this, silence/reverb tails
# can hang a chunk for 10+ minutes ("دهدهده..." repeated hundreds of times).
# Kept to two temperatures: on slow CPUs each retry costs a full regeneration,
# so a long list would make normal audio slower instead of safer. The
# per-chunk timeout below remains the hard backstop.
_GENERATE_KWARGS: dict = {
    "language": "ar",
    "task": "transcribe",
    "temperature": (0.0, 0.5),
    "compression_ratio_threshold": 2.4,
    "logprob_threshold": -1.0,
    "no_speech_threshold": 0.6,
}

# Worst case per chunk before we give up on it. A 20s chunk normally takes
# well under 2 minutes on CPU; anything beyond this is pathological.
CHUNK_TIMEOUT_SECONDS = 300


class QuranASR:
    def __init__(self):
        self.pipe = None
        self.device = None

    def _load(self):
        if self.pipe is not None: return
        try:
            import torch
            from transformers import pipeline
        except Exception as exc:
            raise ASRError("Python ASR dependencies are missing. Install requirements.txt") from exc
        if torch.cuda.is_available():
            self.device = "cuda:0"
            dtype = torch.float16
        else:
            self.device = "cpu"
            dtype = torch.float32
        try:
            self.pipe = pipeline(
                "automatic-speech-recognition",
                model=settings.asr_model,
                revision=settings.asr_revision,
                device=self.device,
                torch_dtype=dtype,
            )
        except TypeError:
            self.pipe = pipeline(
                "automatic-speech-recognition",
                model=settings.asr_model,
                revision=settings.asr_revision,
                device=self.device,
            )
        self._patch_generation_config()

    def _patch_generation_config(self) -> None:
        """Compatibility shim for transformers >= 4.5x.

        The pinned model's generation_config predates `lang_to_id` /
        `task_to_id` / `is_multilingual`, which newer `generate()` requires
        whenever `language`/`task` are passed. We rebuild those mappings
        from the tokenizer's own vocabulary, so the standard
        `generate_kwargs={"language": "ar", "task": "transcribe"}` path
        keeps working instead of raising ValueError.
        """
        import re

        gc = self.pipe.generation_config
        if hasattr(gc, "lang_to_id") and hasattr(gc, "task_to_id"):
            return  # already modern; nothing to do
        vocab = self.pipe.tokenizer.get_vocab()
        lang_to_id = {t: i for t, i in vocab.items() if re.fullmatch(r"<\|[a-z]{2}\|>", t)}
        task_to_id = {
            name: vocab[f"<|{name}|>"]
            for name in ("transcribe", "translate")
            if f"<|{name}|>" in vocab
        }
        gc.lang_to_id = lang_to_id
        gc.task_to_id = task_to_id
        gc.is_multilingual = True
        if not hasattr(gc, "no_timestamps_token_id") and "<|notimestamps|>" in vocab:
            # Needed by the no-speech detection logits processor (used with
            # no_speech_threshold) and by long-form timestamp generation.
            gc.no_timestamps_token_id = vocab["<|notimestamps|>"]
        # CRITICAL performance fix: the pinned checkpoint's config ships with
        # use_cache=False, which makes generation O(n^2) (every step recomputes
        # the full decoder). Enabling the KV cache is ~50x faster on CPU and
        # is what makes long chunks feasible at all.
        gc.use_cache = True
        try:
            self.pipe.model.config.use_cache = True
        except Exception:
            pass
        # The pipeline hands this same object to generate(); keep the model's
        # copy in sync in case they are different objects.
        try:
            mgc = self.pipe.model.generation_config
            mgc.lang_to_id = lang_to_id
            mgc.task_to_id = task_to_id
            mgc.is_multilingual = True
            if hasattr(gc, "no_timestamps_token_id"):
                mgc.no_timestamps_token_id = gc.no_timestamps_token_id
        except Exception:
            pass

    @staticmethod
    def _merge(prev: str, nxt: str) -> tuple[str,int]:
        if not prev: return nxt,0
        if not nxt: return prev,0
        a=normalize_arabic(prev).split(); b=normalize_arabic(nxt).split(); max_k=min(24,len(a),len(b)); best=0
        for k in range(max_k,0,-1):
            if a[-k:] == b[:k]: best=k; break
        return " ".join(a+b[best:]), best

    def _transcribe_chunk(self, chunk: np.ndarray) -> str:
        """Run one chunk through the pipeline.

        Each call gets its own copy of the generation config because the
        fallback loop mutates it (do_sample/temperature) — sharing it across
        a timed-out-then-retried call would race.
        """
        gkw = dict(_GENERATE_KWARGS)
        gkw["generation_config"] = copy.deepcopy(self.pipe.generation_config)
        # Required path: plain text only. Timestamp generation is intentionally NOT required.
        out = self.pipe(chunk, generate_kwargs=gkw)
        return out.get("text", "") if isinstance(out, dict) else str(out)

    def transcribe_array(self, audio: np.ndarray, sample_rate: int = 16000, progress: Callable[[str],None]|None=None) -> dict:
        self._load()
        audio = np.asarray(audio, dtype=np.float32).flatten()
        total = len(audio) / sample_rate
        step = max(1, settings.chunk_seconds - settings.overlap_seconds)
        chunks=[]; full=""; t0=time.perf_counter()
        starts= list(np.arange(0,max(total-1e-9,0),step)) or [0.0]
        if starts and starts[-1] + settings.chunk_seconds < total:
            starts.append(max(0.0,total-settings.chunk_seconds))
        # Overall deadline: transcription should never take absurdly long.
        # (Per-chunk hangs are handled by the timeout below.)
        deadline = max(600.0, total * 40.0)
        for idx,start in enumerate(starts,1):
            if time.perf_counter() - t0 > deadline:
                raise ASRError(
                    "Transcription is taking too long for this audio. "
                    "Please try a shorter or clearer recording."
                )
            end=min(total,start+settings.chunk_seconds)
            s=int(start*sample_rate); e=int(end*sample_rate)
            chunk=audio[s:e]
            if progress: progress(f"ASR {idx}/{len(starts)} · {start:.1f}–{end:.1f}s")
            # Backstop: a single pathological chunk (e.g. heavy reverb tail
            # that defeats even the temperature fallback) must not hang the
            # whole job. We skip it with a warning; the coverage metric keeps
            # the result honest about the gap.
            with ThreadPoolExecutor(max_workers=1) as ex:
                fut = ex.submit(self._transcribe_chunk, chunk)
                try:
                    raw_text = fut.result(timeout=CHUNK_TIMEOUT_SECONDS)
                except FuturesTimeoutError:
                    log.warning("asr_chunk_timeout idx=%d start=%.1f — skipping chunk", idx, start)
                    continue
                except Exception as exc:
                    raise ASRError(f"Arabic Whisper transcription failed on chunk {idx}: {exc}") from exc
            text=normalize_arabic(raw_text)
            merged, overlap=self._merge(full,text)
            before=len(full.split())
            full=merged
            after=len(full.split())
            chunks.append({"start":start,"end":end,"text":text,"transcript_start":max(0,before-overlap),"transcript_end":max(1,after)})
        elapsed=time.perf_counter()-t0
        return {"text":full,"chunks":chunks,"seconds":elapsed,"device":self.device,"realtime":(total/elapsed if elapsed else 0.0)}
