"""Quran recitation transcription via faster-whisper (CTranslate2).

========================================================================
FYP STUDY GUIDE: How the ASR (Speech-to-Text) Engine Works
========================================================================

WHAT IS ASR?
  ASR = Automatic Speech Recognition. It converts audio (sound waves)
  into text. We use OpenAI's Whisper model, fine-tuned for Quran.

WHY FASTER-WHISPER (not regular Whisper)?
  Regular Whisper uses PyTorch in FP32 (32-bit floating point):
    - Slow on CPU, high memory usage
  Faster-whisper uses CTranslate2 with INT8 quantization:
    - INT8 = 8-bit integers instead of 32-bit floats
    - 4x less memory, 5-15x faster, nearly same accuracy
    - This is called "quantization" - a key ML optimization technique

MODEL HIERARCHY (small to large):
  tiny (39M params)  -> Fastest, least accurate. Good for demos.
  base (74M params)  -> 2x bigger. Better accuracy. OUR CHOICE.
  small (244M)       -> Even better, but slower + more memory.
  medium/large       -> Best accuracy, needs GPU. Too slow for CPU.

  We use tarteel-ai/whisper-base-ar-quran:
    - "tarteel-ai" = organization that fine-tuned it
    - "whisper-base" = base size (74M parameters)
    - "ar-quran" = fine-tuned on Arabic QURAN recitation (not general Arabic!)
  Fine-tuning matters: a Quran-tuned base beats a general small model.
  (2026-10-19: also tested whisper-small-quran 244M and
  whisper-large-v3-turbo-ar-quran 809M head-to-head — base won on ayat
  recovery through the production pipeline, so it stays the default.
  See BIGGER_MODEL_TEST.txt for the full comparison.)

BEAM SEARCH vs GREEDY (key concept for FYP!):
  Greedy (beam_size=1):
    - At each step, picks the SINGLE most likely next word
    - Fast but can get stuck in local optima
    - Example: hears "الله" -> picks it immediately, can't reconsider

  Beam search (beam_size=3):
    - Keeps TOP-3 candidates at each step
    - Explores multiple paths, picks best OVERALL sequence
    - Slower but finds better transcriptions
    - Example: considers "الله", "اللهم", "لله" -> picks best in context

CHUNKING:
  Long audio (e.g., 2 hours) can't fit in memory at once.
  We split into 60-second chunks with 2-second overlap.
  Overlap prevents cutting words at boundaries.

VAD (Voice Activity Detection):
  Silero VAD detects silence and skips it.
  Why? Transcribing silence wastes time and can cause hallucinations.

Why faster-whisper instead of the transformers pipeline
------------------------------------------------------
The old engine ran Whisper through HuggingFace transformers + PyTorch in
FP32 on CPU — the slowest viable inference path (no quantization, large
per-chunk pipeline overhead). faster-whisper runs the *same* model through
CTranslate2 with int8 quantization on CPU (float16 on GPU), which is
typically 5-15x faster at equal accuracy, with far lower memory use.

Model selection
---------------
* ``ASR_MODEL`` may be a stock faster-whisper size name
  (``tiny``/``base``/``small``/``medium``/``large-v3``/...) — used directly.
* Otherwise it is treated as a HuggingFace model id (default
  ``tarteel-ai/whisper-base-ar-quran``, fine-tuned for Quran recitation)
  which is converted to CTranslate2 format once via
  ``ct2-transformers-converter`` and cached under the models dir.
* ``ASR_CT2_DIR`` overrides everything with a pre-converted directory.

Speed knobs (all in config / env): ``ASR_COMPUTE_TYPE`` (auto -> int8 on
CPU, float16 on GPU), ``ASR_BEAM_SIZE`` (1 = greedy, fastest),
``ASR_VAD`` (Silero VAD skips silence so it is never transcribed),
``ASR_LANGUAGE`` (default ``ar``; ``auto`` enables detection),
``ASR_CHUNK_SECONDS`` / ``ASR_OVERLAP_SECONDS`` (app-level chunking for
progress reporting and bounded memory; each chunk still uses all CPU
cores inside CTranslate2).
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from pathlib import Path
from typing import Callable

import numpy as np

from .config import settings
from .normalization import normalize_arabic

log = logging.getLogger("quran_shazam.asr")


# FYP STUDY GUIDE: Raised for transcription failures the caller should report
# (bad audio, chunk timeout, missing engine) - not for programming bugs.
# WHY: separates expected ASR failures from crashes so routes can convert them
# into client-safe messages instead of 500s.
class ASRError(RuntimeError):
    """Transcription failed in a way the caller should report."""


# FYP STUDY GUIDE: Raised through the progress callback when the user cancels
# the job mid-transcription.
# WHY: the chunk loop runs inside a thread pool and can't poll a cancel flag
# itself - the exception unwinds transcription immediately instead of wasting
# minutes on an upload nobody wants anymore.
class JobCancelled(Exception):
    """Raised through the progress callback when the user cancels the job."""


# Stock faster-whisper model sizes usable without any conversion.
_STOCK_SIZES = {
    "tiny", "tiny.en", "base", "base.en", "small", "small.en",
    "medium", "medium.en", "large-v1", "large-v2", "large-v3", "large",
    "distil-small.en", "distil-medium.en", "distil-large-v2", "distil-large-v3",
    "turbo",
}

# Generous per-chunk backstop. A 60 s chunk at RTF<=1 takes ~60 s; anything
# far beyond this is pathological — skip the chunk, keep coverage honest.
_CHUNK_TIMEOUT_SECONDS = 300


# FYP STUDY GUIDE: The Whisper speech-to-text wrapper (faster-whisper /
# CTranslate2) around the Quran-tuned tarteel-ai/whisper-base-ar-quran model.
# WHY: the project's ear - every match and label downstream depends on transcript
# quality. The 74M base model beat the 244M small and 809M large-v3-turbo on the
# real Al-Fatihah test (7/7 ayat vs 5/7) - bigger is not better here (ADR-0001).
class QuranASR:
    # FYP STUDY GUIDE: Stores the models directory (default ~/.cache/quran-shazam/
    # models); the heavy model load is deferred to _load().
    # WHY: constructing the object stays cheap - the 2-4 minute load happens once,
    # in the warmup thread, never during a request.
    def __init__(self, models_dir: Path | None = None):
        self.models_dir = Path(models_dir) if models_dir else (
            Path.home() / ".cache" / "quran-shazam" / "models"
        )
        self.model = None
        self.device: str | None = None
        self.compute_type: str | None = None
        self.model_id: str | None = None

    # ------------------------------------------------------------ loading
    # FYP STUDY GUIDE: Returns 'cuda' when torch sees a GPU, else 'cpu'.
    # WHY: picks the fastest available hardware with zero config; the production
    # path is CPU (codespaces have no GPU), so the engine must be fast on CPU
    # by default.
    def _detect_device(self) -> str:
        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
        except Exception:
            pass
        return "cpu"

    # FYP STUDY GUIDE: Picks float16 on CUDA, int8 on CPU - unless ASR_COMPUTE_TYPE
    # overrides it.
    # WHY: int8 quantization makes the 74M model ~2-4x faster on CPU with negligible
    # accuracy loss - the key trick that keeps free-tier transcription usable.
    def _resolve_compute_type(self, device: str) -> str:
        if settings.asr_compute_type != "auto":
            return settings.asr_compute_type
        return "float16" if device == "cuda" else "int8"

    # FYP STUDY GUIDE: Converts the HuggingFace model to CTranslate2 format once
    # (via ct2-transformers-converter) and caches it on disk; reuses the cache.
    # WHY: faster-whisper needs the quantized CT2 format for fast inference;
    # conversion is slow and needs network - doing it once keeps every restart
    # fast and offline-friendly.
    def _ensure_ct2_model(self) -> Path:
        """Return a local CTranslate2 model dir, converting from HF once."""
        hf_id = settings.asr_model
        safe = hf_id.replace("/", "--")
        out = self.models_dir / "ct2" / f"{safe}@{settings.asr_revision[:12]}"
        if (out / "model.bin").exists():
            log.info("asr_ct2_cached dir=%s", out)
            return out
        converter = shutil.which("ct2-transformers-converter")
        if converter is None:
            # The venv's bin dir may not be on PATH (e.g. services started
            # with an absolute python path) — look next to the interpreter.
            alt = Path(sys.executable).parent / "ct2-transformers-converter"
            if alt.exists():
                converter = str(alt)
        if converter is None:
            raise ASRError(
                "The CTranslate2 model converter was not found. "
                "Install requirements.txt (ctranslate2 ships with faster-whisper)."
            )
        out.mkdir(parents=True, exist_ok=True)
        log.info("asr_ct2_convert_start model=%s revision=%s", hf_id, settings.asr_revision[:12])
        t0 = time.perf_counter()
        cmd = [converter, "--model", hf_id, "--revision", settings.asr_revision,
               "--output_dir", str(out), "--force"]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        except subprocess.TimeoutExpired as exc:
            raise ASRError("Model conversion timed out. Check network / disk and retry.") from exc
        if proc.returncode != 0 or not (out / "model.bin").exists():
            tail = (proc.stderr or "")[-800:]
            log.error("asr_ct2_convert_failed rc=%s tail=%r", proc.returncode, tail)
            raise ASRError(
                "Could not convert the speech model to the fast format. "
                f"Converter said: {tail[:200]}"
            )
        log.info("asr_ct2_convert_done seconds=%.1f", time.perf_counter() - t0)
        self._ensure_preprocessor_config(hf_id, out)
        return out

    @staticmethod
    # FYP STUDY GUIDE: Writes preprocessor_config.json with the model's true mel-bin
    # count (read from its config.json) when the converter drops it.
    # WHY: whisper-large-v3-turbo uses 128 mel bins, not 80 - with the wrong count
    # the encoder rejects the audio features entirely (the TEAM BIGMODEL fix).
    def _ensure_preprocessor_config(hf_id: str, out: Path) -> None:
        """Write preprocessor_config.json if the converter didn't.

        TEAM BIGMODEL (2026-10-19): whisper-large-v3-turbo uses 128 mel
        bins (not 80). ct2-transformers-converter does not always carry the
        preprocessor config over, so faster-whisper would extract 80-bin
        features and the encoder would reject them. We fetch the tiny
        config.json from the Hub, read num_mel_bins, and write a matching
        preprocessor_config.json next to model.bin.
        """
        try:
            if (out / "preprocessor_config.json").exists():
                return
            from huggingface_hub import hf_hub_download
            cfg_path = hf_hub_download(hf_id, "config.json",
                                       revision=settings.asr_revision or None)
            import json
            with open(cfg_path, encoding="utf-8") as f:
                n_mels = int(json.load(f).get("num_mel_bins", 80))
            pre = {
                "feature_extractor_type": "WhisperFeatureExtractor",
                "feature_size": n_mels,
                "hop_length": 160,
                "chunk_length": 30,
                "n_fft": 400,
                "padding_side": "right",
                "padding_value": 0.0,
                "return_attention_mask": False,
                "sampling_rate": 16000,
            }
            with open(out / "preprocessor_config.json", "w", encoding="utf-8") as f:
                json.dump(pre, f)
            log.info("asr_preprocessor_config_written n_mels=%d", n_mels)
        except Exception as exc:  # non-fatal: 80-bin default still works for most models
            log.warning("asr_preprocessor_config_skip: %s", exc)

    # FYP STUDY GUIDE: Builds the WhisperModel once (device, compute type, threads);
    # validates onnxruntime is present when VAD is enabled.
    # WHY: lazy single load - no request ever pays model-load latency; missing
    # dependencies fail fast here with a clear ASRError instead of a confusing
    # crash mid-transcription.
    def _load(self):
        if self.model is not None:
            return
        try:
            from faster_whisper import WhisperModel
        except Exception as exc:
            raise ASRError(
                "The fast transcription engine is not installed. "
                "Install requirements.txt (faster-whisper)."
            ) from exc
        if settings.asr_vad:
            try:
                import onnxruntime  # noqa: F401  (needed for Silero VAD)
            except Exception as exc:
                raise ASRError(
                    "VAD filtering needs the 'onnxruntime' package. "
                    "Install requirements.txt or set ASR_VAD=0."
                ) from exc

        self.device = self._detect_device()
        self.compute_type = self._resolve_compute_type(self.device)

        model_ref: str | Path
        if settings.asr_ct2_dir:
            model_ref = Path(settings.asr_ct2_dir)
            if not (model_ref / "model.bin").exists():
                raise ASRError(f"ASR_CT2_DIR has no model.bin: {model_ref}")
        elif settings.asr_model.strip().lower() in _STOCK_SIZES:
            model_ref = settings.asr_model.strip().lower()
        else:
            model_ref = self._ensure_ct2_model()
        self.model_id = str(model_ref)

        log.info("asr_load model=%s device=%s compute_type=%s beam=%d vad=%s lang=%s",
                 self.model_id, self.device, self.compute_type,
                 settings.asr_beam_size, settings.asr_vad, settings.asr_language)
        t0 = time.perf_counter()
        self.model = WhisperModel(
            str(model_ref),
            device=self.device,
            compute_type=self.compute_type,
            cpu_threads=os.cpu_count() or 4,
            num_workers=1,
        )
        log.info("asr_loaded seconds=%.1f", time.perf_counter() - t0)

    # -------------------------------------------------------- transcription
    @staticmethod
    # FYP STUDY GUIDE: Joins two chunk transcripts, deduping up to 24 overlapping
    # words at the boundary by word-sequence matching.
    # WHY: chunks overlap by 3s (ADR-0002), so boundary words appear twice - _merge
    # removes the duplication so the final transcript has no repeated phrases that
    # would confuse the matcher.
    def _merge(prev: str, nxt: str) -> tuple[str, int]:
        if not prev:
            return nxt, 0
        if not nxt:
            return prev, 0
        a = normalize_arabic(prev).split()
        b = normalize_arabic(nxt).split()
        max_k = min(24, len(a), len(b))
        best = 0
        for k in range(max_k, 0, -1):
            if a[-k:] == b[:k]:
                best = k
                break
        return " ".join(a + b[best:]), best

    @staticmethod
    # FYP STUDY GUIDE: Extracts per-word timings plus the model's own confidence (p)
    # from a faster-whisper segment; times are chunk-relative, empty words dropped.
    # WHY: Coach's forced alignment needs per-word evidence - with p the coach can
    # tell 'AI misheard' (p<0.70 -> uncertain, reciter NOT blamed) from 'reciter
    # mispronounced' (ADR-0010); no words -> [] so alignment degrades gracefully,
    # never inventing timings.
    def _words_of(seg) -> list[dict]:
        """Extract per-word timings from a faster-whisper segment.

        FYP STUDY GUIDE: with word_timestamps=True the model returns
        seg.words = [{word, start, end, probability}]. Times are relative
        to the chunk; the caller adds the chunk offset. Empty/whitespace
        words are dropped. If the model gives no words (shouldn't happen),
        we return [] and alignment degrades gracefully to text-only —
        never fake timings.
        """
        out = []
        for w in (getattr(seg, "words", None) or []):
            txt = normalize_arabic(getattr(w, "word", "") or "")
            if not txt.strip():
                continue
            try:
                prob = getattr(w, "probability", None)
                prob = round(float(prob), 3) if prob is not None else None
            except (TypeError, ValueError):
                prob = None
            try:
                out.append({"w": txt.strip(),
                            "start": float(getattr(w, "start", 0.0)),
                            "end": float(getattr(w, "end", 0.0)),
                            # WORD CONFIDENCE (2026-10-21): the model's own
                            # certainty for this word (0..1). Coach uses it
                            # to tell "AI misheard" apart from "reciter
                            # mispronounced" — see ADR-0010.
                            "p": prob})
            except (TypeError, ValueError):
                continue
        return out

    # FYP STUDY GUIDE: Transcribes one 15s chunk with beam search (not greedy),
    # repetition guards, temperature fallback on garbage, and VAD filtering.
    # WHY: beam search is more accurate than greedy; the guards fix Whisper's known
    # looping/hallucination modes; 15s chunks keep every decode inside a single
    # Whisper window - 60s chunks lost the tail ayat entirely (ADR-0002).
    def _transcribe_chunk(self, chunk: np.ndarray,
                          initial_prompt: str | None = None) -> list[dict]:
        """Transcribe one chunk -> list of {start, end, text} (relative secs).

        Professional decoding: beam search (not greedy) + repetition guards +
        temperature fallback for difficult segments.

        FYP STUDY GUIDE — initial_prompt (reference-guided transcription):
          Whisper accepts an `initial_prompt`: text that is fed to the decoder
          as "previous context" before it starts transcribing. The model then
          prefers words from that vocabulary. When we already know (from a
          first quick pass) that the audio is probably Surah Al-Fatihah, we
          pass Al-Fatihah's ayat as the prompt — Whisper stops inventing
          non-Quranic words like "كذبير" and picks real Quranic words instead.
          This is called "reference-guided" or "prompt-conditioned" ASR, and
          it is the standard professional trick for transcribing KNOWN texts
          (Quran, speeches, audiobooks) instead of unknown speech.
        """
        lang = settings.asr_language
        # Beam search for better accuracy; larger beam = better but slower
        beam = max(3, settings.asr_beam_size)
        kwargs = dict(
            language=None if lang == "auto" else lang,
            task="transcribe",
            beam_size=beam,
            best_of=beam,
            temperature=0.0,
            # Reference-guided transcription: bias the decoder toward the
            # expected Quranic vocabulary (see docstring above).
            initial_prompt=initial_prompt,
            # Prevent common Whisper failure modes
            repetition_penalty=1.1,      # discourage loops
            length_penalty=1.0,          # neutral length bias
            no_repeat_ngram_size=3,      # block 3-gram repetitions
            condition_on_previous_text=False,     # chunks are independent
            vad_filter=settings.asr_vad,
            # VAD tuning (validated 2026-10-18 on Al-Fatihah/Alafasy):
            # Silero's default speech threshold (0.5) misclassifies quiet
            # but genuine recitation as non-speech — e.g. the elongated
            # "ولا الضالين" tail (madd) was dropped entirely, losing the
            # final ayah. threshold=0.15 keeps 45.8/46.4s of real audio
            # (only true trailing silence removed) while
            # min_silence_duration_ms=500 still splits long pauses.
            # Hallucination guards (no_speech_threshold,
            # compression_ratio_threshold) stay on downstream.
            vad_parameters=dict(min_silence_duration_ms=500, threshold=0.15) if settings.asr_vad else None,
            # PROFESSIONAL REDESIGN Stage 4 (2026-10-21): word_timestamps=True
            # gives per-word start/end times from the model. Cost: slightly
            # slower inference. Benefit: forced alignment — we can now tell
            # apart a MISSED word from a MISPRONOUNCED word per ayah instead
            # of guessing from flat text. FYP STUDY GUIDE: Whisper normally
            # returns text in ~15s chunks; with word_timestamps it ALSO
            # returns each word's exact time. We never invent timings —
            # every timestamp below comes from the model itself.
            # Validated 2026-10-21: transcription text unchanged vs False
            # on the golden Al-Fatihah file (see ADR-0006).
            word_timestamps=True,
            # Compression guards: skip garbage outputs
            compression_ratio_threshold=2.4,
            log_prob_threshold=-1.0,
            no_speech_threshold=0.6,
        )
        try:
            segments_iter, _info = self.model.transcribe(chunk, **kwargs)
            out = []
            for seg in segments_iter:
                text = normalize_arabic(seg.text or "")
                if not text.strip():
                    continue
                out.append({"start": float(seg.start), "end": float(seg.end), "text": text,
                            "words": self._words_of(seg)})
            # Temperature fallback: if output looks like garbage, retry warmer
            if out and self._looks_like_garbage(" ".join(o["text"] for o in out)):
                log.info("asr_chunk_retry_warm: trying temperature fallback")
                kwargs["temperature"] = 0.3
                segments_iter, _info = self.model.transcribe(chunk, **kwargs)
                out = []
                for seg in segments_iter:
                    text = normalize_arabic(seg.text or "")
                    if not text.strip():
                        continue
                    out.append({"start": float(seg.start), "end": float(seg.end), "text": text,
                            "words": self._words_of(seg)})
            return out
        except Exception:
            # Fallback to simple greedy on any decoding error
            kwargs.update(beam_size=1, best_of=1, temperature=0.0)
            kwargs.pop("repetition_penalty", None)
            kwargs.pop("no_repeat_ngram_size", None)
            segments_iter, _info = self.model.transcribe(chunk, **kwargs)
            out = []
            for seg in segments_iter:
                text = normalize_arabic(seg.text or "")
                if not text.strip():
                    continue
                out.append({"start": float(seg.start), "end": float(seg.end), "text": text,
                            "words": self._words_of(seg)})
            return out

    @staticmethod
    # FYP STUDY GUIDE: Flags hallucinated output - a single word dominating >40%
    # of the chunk's words.
    # WHY: Whisper loops on noise/silence; detecting the loop lets the chunk retry
    # at a warmer temperature instead of poisoning the transcript with repeated junk.
    def _looks_like_garbage(text: str) -> bool:
        """Detect repetitive/garbage ASR output."""
        words = text.split()
        if len(words) < 5:
            return False
        # Same word repeated many times
        from collections import Counter
        counts = Counter(words)
        most_common = counts.most_common(1)[0][1]
        return most_common > len(words) * 0.4

    # FYP STUDY GUIDE: Full-audio transcription - 15s chunks with 3s overlap, per-chunk
    # timeout, overlapped heads dropped, text merged, word timings shifted to absolute.
    # WHY: the orchestrator of the ASR stage - chunking (ADR-0002) recovered the tail
    # ayat, timeouts stop one bad chunk hanging a job, and the progress callback
    # drives the UI while also propagating user cancellation (JobCancelled).
    def transcribe_array(self, audio: np.ndarray, sample_rate: int = 16000,
                         progress: Callable[[str], None] | None = None,
                         on_partial: Callable[[str], None] | None = None,
                         initial_prompt: str | None = None) -> dict:
        self._load()
        audio = np.asarray(audio, dtype=np.float32).flatten()
        total = len(audio) / sample_rate
        chunk_s = settings.asr_chunk_seconds
        overlap_s = settings.asr_overlap_seconds
        step = max(1, chunk_s - overlap_s)

        starts = list(np.arange(0, max(total - 1e-9, 0), step)) or [0.0]
        if starts and starts[-1] + chunk_s < total:
            starts.append(max(0.0, total - chunk_s))

        deadline = max(600.0, total * 20.0)  # overall backstop (RTF<=1 => ~total)
        t0 = time.perf_counter()
        full = ""
        segments: list[dict] = []
        chunks: list[dict] = []

        with ThreadPoolExecutor(max_workers=1) as ex:
            for idx, start in enumerate(starts, 1):
                if time.perf_counter() - t0 > deadline:
                    raise ASRError(
                        "Transcription is taking too long for this audio. "
                        "Please try a shorter or clearer recording."
                    )
                end = min(total, start + chunk_s)
                s, e = int(start * sample_rate), int(end * sample_rate)
                chunk = audio[s:e]
                if progress:
                    # May raise JobCancelled -> propagates and aborts the job.
                    progress(f"ASR {idx}/{len(starts)} · {start:.1f}–{end:.1f}s")
                fut = ex.submit(self._transcribe_chunk, chunk, initial_prompt)
                try:
                    rel = fut.result(timeout=_CHUNK_TIMEOUT_SECONDS)
                except FuturesTimeoutError:
                    log.warning("asr_chunk_timeout idx=%d start=%.1f — skipping chunk", idx, start)
                    continue
                except JobCancelled:
                    raise
                except Exception as exc:
                    raise ASRError(f"Arabic transcription failed on chunk {idx}: {exc}") from exc

                # Drop the overlapped head of every chunk after the first so
                # repeated audio at boundaries is not duplicated.
                drop_before = overlap_s if idx > 1 else 0.0
                kept = [g for g in rel if g["end"] > drop_before + 0.05]
                if not kept and rel:
                    # TEAM BIGMODEL (2026-10-19): some fine-tuned models
                    # (e.g. whisper-large-v3-turbo-ar-quran) emit degenerate
                    # timestamps (0.0-0.02) for a whole chunk. Dropping them
                    # would lose the chunk's text entirely, so keep the text
                    # and let _merge() dedup the overlap by words instead.
                    kept = rel
                for g in kept:
                    segments.append({
                        "start": round(start + g["start"], 2),
                        "end": round(start + g["end"], 2),
                        "text": g["text"],
                        # Word timings shifted by the chunk offset, like the
                        # segment times above. Alignment code maps these to
                        # transcript words in order; words the overlap-dedup
                        # dropped simply get no timestamp (never invented).
                        # "p" (model confidence) rides along for the
                        # uncertainty logic — see ADR-0010.
                        "words": [{"w": w["w"],
                                   "start": round(start + w["start"], 2),
                                   "end": round(start + w["end"], 2),
                                   "p": w.get("p")}
                                  for w in g.get("words", [])],
                    })
                chunk_text = " ".join(g["text"] for g in kept)
                merged, overlap = self._merge(full, chunk_text)
                before = len(full.split())
                full = merged
                after = len(full.split())
                chunks.append({
                    "start": start, "end": end, "text": chunk_text,
                    "transcript_start": max(0, before - overlap),
                    "transcript_end": max(1, after),
                })
                if on_partial and full.strip():
                    try:
                        on_partial(full)
                    except Exception:
                        pass  # partial updates must never break transcription

        elapsed = time.perf_counter() - t0
        return {
            "text": full,
            "chunks": chunks,          # legacy word-span info (matcher compat)
            "segments": segments,      # time-based segments (SRT/VTT export)
            "seconds": elapsed,
            "device": f"{self.device}:0" if self.device == "cuda" else "cpu",
            "realtime": (total / elapsed if elapsed else 0.0),
            "model": self.model_id,
            "compute_type": self.compute_type,
            "guided": bool(initial_prompt),
        }
