from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import requests

from .config import settings
from .normalization import normalize_arabic, tokens

EXPECTED_AYAT = 6236
EXPECTED_SURAHS = 114

@dataclass(frozen=True)
# FYP STUDY GUIDE: Frozen dataclass for one ayah - key ('112:1'), surah, ayah,
# Arabic text, normalized text, and global_index (1..6236).
# WHY: frozen = immutable ground truth; global_index gives every ayah a canonical
# position, so 'next ayah' and gap logic are simple arithmetic.
class Verse:
    key: str
    surah: int
    ayah: int
    text: str
    normalized: str
    global_index: int


# FYP STUDY GUIDE: Raised when the Quran corpus can't be loaded or fails
# validation.
# WHY: verification is BLOCKED without a healthy corpus (fail-closed) - a
# dedicated exception type lets the app distinguish 'Quran data broken' from
# ordinary errors.
class CorpusError(RuntimeError):
    pass


# FYP STUDY GUIDE: Loads and validates the 6,236-ayah / 114-surah corpus; builds
# by_key / by_surah / inverted indexes plus EN/UR translations.
# WHY: the ground truth everything is matched against - strict validation (exact
# counts, contiguous numbering, no duplicates) guarantees the matcher never
# reasons over a corrupt Quran.
class QuranCorpus:
    # FYP STUDY GUIDE: Sets paths and empty indexes (verses, by_key, by_surah,
    # inverted, translations); creates the data dir.
    # WHY: construction stays cheap and side-effect-free - the network/disk work
    # happens in ensure(), so tests can build the object without downloading.
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / "quran.json"
        self.verses: list[Verse] = []
        self.by_key: dict[str, Verse] = {}
        self.by_surah: dict[int, list[Verse]] = {}
        self.inverted: dict[str, list[Verse]] = {}
        self.translations_en: dict[str, str] = {}
        self.translations_ur: dict[str, str] = {}
        self.source = ""
        self.sha256 = ""

    @property
    # FYP STUDY GUIDE: True only with exactly 6,236 verses and 114 surahs loaded.
    # WHY: the fail-closed gate - verify() and the matcher refuse to run on a partial
    # corpus; 'almost all ayat' is not acceptable for the Quran.
    def ready(self) -> bool:
        return len(self.verses) == EXPECTED_AYAT and len(self.by_surah) == EXPECTED_SURAHS

    # FYP STUDY GUIDE: Loads the local quran.json if valid; otherwise downloads from
    # the pinned CDN; raises CorpusError if both fail.
    # WHY: first deploy needs the data; a corrupt local file is deleted and
    # re-fetched (self-healing) rather than silently used.
    def ensure(self) -> None:
        last_error = None
        if self.path.exists():
            try:
                self._load_file(self.path)
                return
            except Exception as exc:
                last_error = exc
                self.path.unlink(missing_ok=True)
        try:
            r = requests.get(settings.corpus_url, timeout=settings.request_timeout)
            r.raise_for_status()
            raw = r.content
            self.path.write_bytes(raw)
            self._load_file(self.path)
        except Exception as exc:
            if last_error:
                raise CorpusError(f"Local Quran corpus invalid ({last_error}); online reload failed: {exc}") from exc
            raise CorpusError(f"Quran corpus could not be loaded: {exc}") from exc

    # FYP STUDY GUIDE: Parses the corpus JSON (dict, real quran-json nested list, or
    # flat rows), validates counts/contiguity/duplicates, assigns global_index, and
    # builds the inverted index.
    # WHY: real corpus files come in different shapes (the 2026-10-12 bug: the loader
    # couldn't parse the real nested shape) - tolerant parsing plus strict validation
    # means the data is always exactly 6,236 clean ayat.
    def _load_file(self, path: Path) -> None:
        raw = path.read_bytes()
        if not raw:
            raise CorpusError("Quran corpus file is empty.")
        self.sha256 = hashlib.sha256(raw).hexdigest()
        obj = json.loads(raw.decode("utf-8"))
        verses: list[Verse] = []
        if isinstance(obj, dict):
            for surah_key, rows in obj.items():
                if not isinstance(rows, list):
                    continue
                surah = int(surah_key)
                for row in rows:
                    ayah = int(row.get("verse") or row.get("ayah") or row.get("id") or 0)
                    text = row.get("text") or row.get("text_ar") or row.get("arabic") or row.get("text_uthmani") or ""
                    if surah and ayah and text:
                        verses.append(Verse(f"{surah}:{ayah}", surah, ayah, text, normalize_arabic(text), 0))
        elif isinstance(obj, list):
            if obj and isinstance(obj[0], dict) and isinstance(obj[0].get("verses"), list):
                # Real quran-json shape: [{"id": <surah>, "verses": [{"id": <ayah>, "text": ...}]}]
                for surah_row in obj:
                    try:
                        surah = int(surah_row.get("id") or 0)
                    except (TypeError, ValueError):
                        continue
                    for v in surah_row.get("verses") or []:
                        try:
                            ayah = int(v.get("id") or v.get("verse") or 0)
                        except (TypeError, ValueError):
                            continue
                        text = v.get("text") or v.get("text_ar") or ""
                        if surah and ayah and text:
                            verses.append(Verse(f"{surah}:{ayah}", surah, ayah, text, normalize_arabic(text), 0))
            else:
                # Flat row shape: [{"chapter"|"surah": s, "verse"|"ayah": a, "text": ...}]
                for row in obj:
                    if not isinstance(row, dict):
                        continue
                    try:
                        surah = int(row.get("chapter") or row.get("surah") or 0)
                        ayah = int(row.get("verse") or row.get("ayah") or row.get("id") or 0)
                    except (TypeError, ValueError):
                        continue
                    text = row.get("text") or row.get("text_ar") or row.get("arabic") or ""
                    if surah and ayah and text:
                        verses.append(Verse(f"{surah}:{ayah}", surah, ayah, text, normalize_arabic(text), 0))
        verses.sort(key=lambda v: (v.surah, v.ayah))
        if len(verses) != EXPECTED_AYAT:
            raise CorpusError(f"Quran corpus validation failed: expected {EXPECTED_AYAT} ayat, loaded {len(verses)}")
        surahs = {v.surah for v in verses}
        if len(surahs) != EXPECTED_SURAHS or min(surahs) != 1 or max(surahs) != EXPECTED_SURAHS:
            raise CorpusError(
                f"Quran corpus validation failed: expected surahs 1..{EXPECTED_SURAHS}, "
                f"loaded {len(surahs)} (range {min(surahs)}..{max(surahs)})"
            )
        keys = [v.key for v in verses]
        if len(set(keys)) != len(keys):
            raise CorpusError("Quran corpus validation failed: duplicate verse keys")
        for s in range(1, 115):
            rows = [v for v in verses if v.surah == s]
            expected = list(range(1, len(rows) + 1))
            actual = [v.ayah for v in rows]
            if actual != expected:
                raise CorpusError(f"Quran corpus validation failed: Surah {s} ayah numbering is not contiguous")
        verses = [Verse(v.key, v.surah, v.ayah, v.text, v.normalized, i + 1) for i, v in enumerate(verses)]
        self.verses = verses
        self.by_key = {v.key: v for v in verses}
        self.by_surah = {}
        self.inverted = {}
        for v in verses:
            self.by_surah.setdefault(v.surah, []).append(v)
            for tok in set(tokens(v.text)):
                if len(tok) >= 2:
                    self.inverted.setdefault(tok, []).append(v)
        self.source = str(path)

    # FYP STUDY GUIDE: Downloads EN/UR translations; any failure is swallowed -
    # translations are optional.
    # WHY: translations enrich results but must never invalidate corpus readiness; a
    # translation CDN outage must not block verification of the Arabic text.
    def load_translations(self) -> None:
        # Optional; a failed translation download must never invalidate Quran text readiness.
        for lang, url, target in (("en", settings.en_url, self.translations_en), ("ur", settings.ur_url, self.translations_ur)):
            try:
                r = requests.get(url, timeout=settings.request_timeout)
                r.raise_for_status()
                obj = r.json()
                rows: list[tuple[int, list]] = []
                if isinstance(obj, list) and obj and isinstance(obj[0], dict) and isinstance(obj[0].get("verses"), list):
                    # Real quran-json shape: [{"id": <surah>, "verses": [{"id": <ayah>, "translation": ...}]}]
                    for surah_row in obj:
                        rows.append((int(surah_row.get("id") or 0), surah_row.get("verses") or []))
                elif isinstance(obj, dict):
                    for key, verses_list in obj.items():
                        if isinstance(verses_list, list):
                            rows.append((int(key), verses_list))
                for surah, verses_list in rows:
                    if not surah:
                        continue
                    for item in verses_list:
                        if not isinstance(item, dict):
                            continue
                        try:
                            ayah = int(item.get("verse") or item.get("ayah") or item.get("id") or 0)
                        except (TypeError, ValueError):
                            continue
                        text = item.get("translation") or item.get("text") or ""
                        if ayah and text:
                            target[f"{surah}:{ayah}"] = text
            except Exception:
                continue

    # FYP STUDY GUIDE: Readiness checks (verse/surah counts, key uniqueness, 1:1 and
    # 112:1-4 present, canonical ordering) plus the file's sha256.
    # WHY: /api/diagnostics exposes these so ops can prove the deployed Quran data is
    # complete and untampered - the sha256 pins exactly which file is live.
    def diagnostics(self) -> dict[str, Any]:
        checks = []
        checks.append(("Quran corpus size", len(self.verses) == EXPECTED_AYAT, f"Loaded {len(self.verses)} verses"))
        checks.append(("Surah count", len(self.by_surah) == EXPECTED_SURAHS, f"Loaded {len(self.by_surah)} surahs"))
        checks.append(("Unique verse keys", len(self.by_key) == len(self.verses), "No duplicate verse keys"))
        checks.append(("Al-Fatihah 1:1 exists", "1:1" in self.by_key, "Canonical first verse is present"))
        checks.append(("Al-Ikhlas 112:1-4 exists", all(f"112:{i}" in self.by_key for i in range(1,5)), "All four Al-Ikhlas verses are present"))
        checks.append(("Canonical ordering", all(self.verses[i].global_index < self.verses[i+1].global_index for i in range(len(self.verses)-1)), "Global verse order is increasing"))
        return {"ready": all(ok for _, ok, _ in checks), "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks], "sha256": self.sha256, "source": self.source}
