"""Transcript exporters: time-aligned segments -> TXT / SRT / VTT / JSON.

Input: list of {"start": float, "end": float, "text": str} as produced by
the ASR engine. All functions are pure and dependency-free.
"""
from __future__ import annotations

import json


# FYP STUDY GUIDE: Formats seconds -> SRT timestamp 'HH:MM:SS,mmm' (comma).
# WHY: SRT demands comma-separated milliseconds - a dedicated formatter keeps
# to_srt readable and the format exactly to spec.
def _ts_srt(seconds: float) -> str:
    ms = max(0, int(round(seconds * 1000)))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# FYP STUDY GUIDE: Formats seconds -> WebVTT timestamp 'HH:MM:SS.mmm' (dot).
# WHY: VTT uses a dot where SRT uses a comma - a separate function avoids the
# classic mix-up that breaks subtitle players.
def _ts_vtt(seconds: float) -> str:
    ms = max(0, int(round(seconds * 1000)))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


# FYP STUDY GUIDE: Joins segment texts into plain text with a trailing newline.
# WHY: the simplest export - a copy-pasteable transcript for notes and sharing.
def to_txt(segments: list[dict]) -> str:
    return "\n".join(s["text"] for s in segments if s.get("text")) + "\n"


# FYP STUDY GUIDE: Segments -> numbered SRT subtitle blocks (empty texts skipped).
# WHY: lets users open their recitation transcript in any video/subtitle player
# with correct timing.
def to_srt(segments: list[dict]) -> str:
    lines: list[str] = []
    n = 0
    for s in segments:
        text = (s.get("text") or "").strip()
        if not text:
            continue
        n += 1
        lines.append(str(n))
        lines.append(f"{_ts_srt(s['start'])} --> {_ts_srt(s['end'])}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines)


# FYP STUDY GUIDE: Segments -> 'WEBVTT' file with cue timings.
# WHY: the web-native subtitle format - browsers render VTT directly on
# <video>/<audio> elements.
def to_vtt(segments: list[dict]) -> str:
    lines = ["WEBVTT", ""]
    for s in segments:
        text = (s.get("text") or "").strip()
        if not text:
            continue
        lines.append(f"{_ts_vtt(s['start'])} --> {_ts_vtt(s['end'])}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines)


# FYP STUDY GUIDE: Segments -> pretty-printed JSON with Arabic preserved
# (ensure_ascii=False).
# WHY: machine-readable export for researchers and tests - ensure_ascii=False
# keeps Arabic readable instead of \uXXXX escapes.
def to_json(segments: list[dict]) -> str:
    return json.dumps({"segments": segments}, ensure_ascii=False, indent=2)


EXPORTERS = {"txt": to_txt, "srt": to_srt, "vtt": to_vtt, "json": to_json}
MEDIA_TYPES = {
    "txt": "text/plain; charset=utf-8",
    "srt": "text/plain; charset=utf-8",
    "vtt": "text/vtt; charset=utf-8",
    "json": "application/json; charset=utf-8",
}
