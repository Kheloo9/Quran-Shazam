"""Embedding-based ayat identification — PROFESSIONAL REDESIGN Stage 2.

========================================================================
FYP STUDY GUIDE: What This Module Does (and does NOT do)
========================================================================

The old pipeline identifies an ayah like this: audio -> Whisper writes
down the words -> we search the WORDS in the Quran text. If Whisper
mishears a word, the search can fail even though the AUDIO was fine.

This module adds a second opinion that never looks at words at all:
it turns audio into a "voice fingerprint" (a list of 768 numbers — an
*embedding*) using wav2vec2, a model trained to understand speech
sounds. Two recitations of the SAME ayah have similar fingerprints,
even from different qaris; different ayat have different fingerprints.

How we use it (advisory, honest):
  1. We pre-compute fingerprints for reference ayah recitations
     (scripts/build_embed_index.py) and save them in an index file.
  2. For a new clip, we compute its fingerprint and find the closest
     reference fingerprints (cosine similarity).
  3. service.py reports these as `embedding_candidates` and LOGS whether
     they agree with the text matcher. They NEVER change a verdict on
     their own — a new component must prove itself on real data before
     it touches verdicts (see ADR-0008).

Why wav2vec2-base (not a bigger model): 90M params, CPU-friendly
(~1-3s per clip), no GPU needed — fits the free-tier constraint.
It is a general speech model, NOT Quran-tuned: the validation script
measures whether it still works for Quranic recitation, honestly.
If it doesn't generalize, the module stays advisory-only forever.
"""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

log = logging.getLogger("quran_shazam.embed_id")

MODEL_DIR_NAME = "wav2vec2-base"
INDEX_FILE_NAME = "embed_index.npz"
# Below this similarity, a candidate is noise — don't even report it.
MIN_SIMILARITY = 0.55


# FYP STUDY GUIDE: Lazy wav2vec2 (90M) audio fingerprinting for ayat
# identification - a second opinion that never looks at words.
# WHY: fingerprints work even when Whisper mishears; but it stays ADVISORY-ONLY -
# validation showed 0/34 top-1 because embeddings cluster by speaker voice, not
# ayat content (ADR-0009, validated-negative).
class EmbeddingIdentifier:
    """Lazy wav2vec2 fingerprinting for ayat identification."""

    # FYP STUDY GUIDE: Records data/model/index paths; model and index stay unloaded
    # (available=False).
    # WHY: lazy by design - the embedding model loads only when the index exists;
    # deployments without it pay zero cost.
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.model_dir = self.data_dir / "models" / MODEL_DIR_NAME
        self.index_path = self.data_dir / INDEX_FILE_NAME
        self._model = None
        self._processor = None
        self._index: dict[str, np.ndarray] | None = None
        self.available = False

    # ---------------------------------------------------------- loading
    # FYP STUDY GUIDE: Loads the wav2vec2 model + processor from the local dir (CUDA
    # if available); returns False instead of raising on any failure.
    # WHY: fail-open by design - identification still works without it; an advisory
    # component must never break verification.
    def _load(self) -> bool:
        if self._model is not None:
            return True
        if not self.model_dir.exists():
            log.info("embed_id: model not downloaded (%s) — skipping",
                     self.model_dir)
            return False
        try:
            from transformers import Wav2Vec2Model, Wav2Vec2Processor
            import torch
            self._processor = Wav2Vec2Processor.from_pretrained(
                str(self.model_dir), local_files_only=True)
            self._model = Wav2Vec2Model.from_pretrained(
                str(self.model_dir), local_files_only=True)
            self._model.eval()
            if torch.cuda.is_available():
                self._model = self._model.cuda()
            self.available = True
            log.info("embed_id: wav2vec2-base loaded")
            return True
        except Exception as exc:  # fail-open: identification still works
            log.warning("embed_id: load failed (%s) — skipping", str(exc)[:200])
            return False

    # FYP STUDY GUIDE: Loads the prebuilt {ayah_key: fingerprint} .npz index, if it
    # exists.
    # WHY: fingerprints are computed once offline (build_index) and shipped - runtime
    # just loads vectors, so identification costs ~1-3s instead of minutes.
    def load_index(self) -> bool:
        """Load the prebuilt reference fingerprint index (if it exists)."""
        if self._index is not None:
            return True
        if not self.index_path.exists():
            return False
        try:
            z = np.load(str(self.index_path), allow_pickle=True)
            self._index = {k: z[k] for k in z.files}
            log.info("embed_id: index loaded (%d ayat)", len(self._index))
            return True
        except Exception as exc:
            log.warning("embed_id: index load failed (%s)", str(exc)[:200])
            return False

    # ---------------------------------------------------------- embed
    # FYP STUDY GUIDE: Decodes audio -> wav2vec2 -> mean-pooled, L2-normalized 768-dim
    # fingerprint; needs >=1s of audio.
    # WHY: mean-pooling over time gives one fixed-size vector per clip; L2
    # normalization turns cosine similarity into a simple dot product.
    def embed_file(self, path: Path, max_seconds: int = 120) -> np.ndarray | None:
        """Fingerprint one audio file -> L2-normalized 768-dim vector."""
        if not self._load():
            return None
        try:
            from .media import decode_to_mono16k
            import torch
            audio, sr = decode_to_mono16k(Path(path), max_seconds)
            if audio is None or len(audio) < sr:  # need >= 1s of audio
                return None
            inputs = self._processor(audio, sampling_rate=16_000,
                                     return_tensors="pt", padding=True)
            device = next(self._model.parameters()).device
            inputs = {k: v.to(device) for k, v in inputs.items()}
            with torch.no_grad():
                out = self._model(**inputs).last_hidden_state  # [1,T,768]
            # Mean-pool over time. A single clip needs no padding, so the
            # processor may omit attention_mask — fall back to all-ones.
            mask = inputs.get("attention_mask")
            if mask is None:
                mask = torch.ones(out.shape[0], out.shape[1],
                                  device=out.device)
            mask = mask.unsqueeze(-1).float()
            vec = (out * mask).sum(1) / mask.sum(1).clamp(min=1e-6)
            vec = vec.squeeze(0).cpu().numpy().astype(np.float32)
            n = np.linalg.norm(vec)
            return vec / n if n > 1e-9 else None
        except Exception as exc:
            log.warning("embed_id: embed failed (%s)", str(exc)[:200])
            return None

    # ---------------------------------------------------------- identify
    # FYP STUDY GUIDE: Ranks reference ayat by fingerprint cosine similarity (>=0.55
    # floor), top-k.
    # WHY: advisory candidates only - service.py logs whether they agree with the
    # text matcher, building the evidence trail for/against this approach (ADR-0008);
    # they never change a verdict.
    def identify(self, path: Path, top_k: int = 5) -> list[dict]:
        """Rank reference ayat by fingerprint similarity to the clip.

        Returns [{"key": "112:1", "similarity": 0.91}, ...] — advisory only.
        """
        if not self.load_index():
            return []
        vec = self.embed_file(path)
        if vec is None:
            return []
        scored = []
        for key, ref in self._index.items():
            sim = float(np.dot(vec, ref))
            if sim >= MIN_SIMILARITY:
                scored.append({"key": key, "similarity": round(sim, 3)})
        scored.sort(key=lambda d: d["similarity"], reverse=True)
        return scored[: max(1, top_k)]

    # ---------------------------------------------------------- build
    # FYP STUDY GUIDE: Builds {ayah_key: vector} from (key, audio_path) pairs and
    # saves the compressed .npz index.
    # WHY: one-time offline step - reference fingerprints are baked once per qari set,
    # then every deployment reuses them without re-encoding.
    def build_index(self, refs: list[tuple[str, Path]]) -> int:
        """Build {ayah_key: vector} from (key, audio_path) pairs; saves .npz."""
        if not self._load():
            return 0
        index: dict[str, np.ndarray] = {}
        for key, path in refs:
            vec = self.embed_file(path)
            if vec is not None:
                index[key] = vec
                log.info("embed_id: indexed %s", key)
        if index:
            np.savez_compressed(str(self.index_path),
                                **{k: v for k, v in index.items()})
        self._index = index
        return len(index)
