"""Media decoding: any supported audio/video -> 16 kHz mono float32 WAV.

Trust model:
  * The upload route already enforces extension allow-lists, magic-byte
    sniffing, and a streaming byte cap (see app/security.py).
  * FFmpeg decoding here is the AUTHORITATIVE validator: a file that FFmpeg
    cannot decode is rejected with a client-safe message. The raw FFmpeg
    stderr is truncated and never echoes attacker-controlled paths.
  * Decoding runs in a subprocess with a hard timeout so a malicious file
    cannot hang a worker forever.
"""
from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from .config import settings

log = logging.getLogger("quran_shazam.media")


class MediaError(RuntimeError):
    pass


def decode_to_mono16k(src: Path, max_seconds: int) -> tuple[np.ndarray, int]:
    # Defense in depth: the route streams with a byte cap, but a local file
    # could still be enormous (disk exhaustion) — refuse early.
    try:
        size_mb = src.stat().st_size / (1024 * 1024)
    except OSError as exc:
        raise MediaError(f"Could not read uploaded file: {exc}") from exc
    if size_mb > settings.max_upload_mb + 1:  # +1 MB tolerance for container overhead
        raise MediaError(f"Media exceeds the {settings.max_upload_mb} MB upload limit.")

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wav = Path(tmp.name)
    try:
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
               "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", str(wav)]
        try:
            subprocess.run(cmd, check=True, timeout=max(90, max_seconds * 3), capture_output=True)
        except FileNotFoundError as exc:
            raise MediaError("Audio processing is temporarily unavailable.") from exc
        except subprocess.TimeoutExpired as exc:
            raise MediaError("Media decoding timed out; the file may be corrupt.") from exc
        except subprocess.CalledProcessError as exc:
            msg = (exc.stderr or b"").decode("utf-8", "ignore").strip()
            log.warning("ffmpeg_decode_failed detail=%r", msg[:200])
            raise MediaError("This file could not be decoded as audio/video.") from exc
        try:
            import soundfile as sf
        except ImportError as exc:
            raise MediaError("Audio support is not installed on this server.") from exc
        audio, sr = sf.read(wav, dtype="float32", always_2d=False)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        seconds = len(audio) / sr
        if seconds > max_seconds:
            raise MediaError(f"Media exceeds the {max_seconds / 60:.0f}-minute limit.")
        if len(audio) == 0:
            raise MediaError("Decoded audio is empty.")
        return audio.astype("float32"), int(sr)
    finally:
        wav.unlink(missing_ok=True)
