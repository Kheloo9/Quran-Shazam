"""Media decoding: any supported audio/video -> 16 kHz mono float32 WAV.

Trust model:
  * The upload route already enforces extension allow-lists, magic-byte
    sniffing, and a streaming byte cap (see app/security.py).
  * FFmpeg decoding here is the AUTHORITATIVE validator: a file that FFmpeg
    cannot decode is rejected with a client-safe message. The raw FFmpeg
    stderr is truncated and never echoes attacker-controlled paths.
  * Decoding runs in a subprocess with a hard timeout so a malicious file
    cannot hang a worker forever.
"""
from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from .config import settings

log = logging.getLogger("quran_shazam.media")


# FYP STUDY GUIDE: Client-safe media failure - undecodable file, timeout, empty
# audio, over the size limit.
# WHY: routes convert this to HTTP 400 - a corrupt upload is the user's problem
# to fix, not a 500; the raw FFmpeg stderr stays server-side so attacker-
# controlled paths never leak.
class MediaError(RuntimeError):
    pass


# FYP STUDY GUIDE: Estimates SNR from 20ms-frame RMS - loudest 20% of frames ~=
# speech, quietest 20% ~= background; flags noisy below 12dB.
# WHY: the quality gate - transcribing a noisy phone recording wastes minutes and
# produces garbage; warning up front ('record in a quiet room') beats a bad
# result later. Must run on RAW audio, before the noise gate inflates the SNR.
def assess_audio_quality(audio: np.ndarray, sr: int = 16000,
                         noisy_threshold_db: float = 12.0) -> dict:
    """Estimate background-noise level of decoded audio.

    FYP STUDY GUIDE — how it works:
      1. Split audio into 20ms frames, compute RMS (loudness) per frame.
      2. The LOUDEST 20% of frames ≈ speech (recitation).
         The QUIETEST 20% of frames ≈ background (room noise/hiss).
      3. SNR = 20 * log10(speech_loudness / background_loudness), in decibels.
         Clean studio recitation ≈ 25-40 dB. Noisy phone recording ≈ 5-12 dB.
      4. Below `noisy_threshold_db` we flag it: transcribing noisy audio
         wastes minutes of GPU/CPU time and produces garbage — better to warn
         the user UP FRONT ("record in a quiet room") than to show a bad
         result later. This is called a "quality gate" in production ML.

    Returns {"snr_db": float, "noisy": bool, "message": str}.
    Must be called on RAW decoded audio (before normalize/gate), because
    the noise gate artificially quiets the background and would inflate SNR.
    """
    audio = np.asarray(audio, dtype=np.float32).flatten()
    if len(audio) < sr:  # < 1s: not enough signal to judge
        return {"snr_db": 99.0, "noisy": False,
                "message": "Audio too short to assess quality."}
    frame = int(sr * 0.02)  # 20ms frames
    n = (len(audio) // frame) * frame
    frames = audio[:n].reshape(-1, frame)
    rms = np.sqrt(np.mean(frames ** 2, axis=1) + 1e-12)
    order = np.argsort(rms)
    q = max(1, len(rms) // 5)
    quiet = float(np.mean(rms[order[:q]]))
    loud = float(np.mean(rms[order[-q:]]))
    snr_db = round(float(20 * np.log10(max(loud, 1e-9) / max(quiet, 1e-9))), 1)
    noisy = snr_db < noisy_threshold_db
    if noisy:
        msg = (f"Background noise is high (SNR {snr_db} dB). "
               "For better results, record in a quiet room with the phone "
               "15-20 cm from your mouth.")
    else:
        msg = f"Audio quality OK (SNR {snr_db} dB)."
    return {"snr_db": snr_db, "noisy": noisy, "message": msg}


# FYP STUDY GUIDE: FFmpeg -> 16kHz mono float32 + quality assessment, then volume
# normalize + light noise gate; guarded by size caps and a subprocess timeout.
# WHY: the AUTHORITATIVE content validator (magic bytes can lie, FFmpeg can't)
# and the exact format Whisper expects (trained on 16kHz mono); the timeout stops
# a malicious file hanging a worker forever.
def decode_to_mono16k_with_quality(src: Path, max_seconds: int
                                   ) -> tuple[np.ndarray, int, dict]:
    """Like decode_to_mono16k, but also returns an audio-quality assessment.

    Quality is measured on the RAW decoded audio BEFORE normalization and
    the noise gate (see assess_audio_quality docstring for why).
    """
    # Defense in depth: the route streams with a byte cap, but a local file
    # could still be enormous (disk exhaustion) — refuse early.
    try:
        size_mb = src.stat().st_size / (1024 * 1024)
    except OSError as exc:
        raise MediaError(f"Could not read uploaded file: {exc}") from exc
    if size_mb > settings.max_upload_mb + 1:  # +1 MB tolerance for container overhead
        raise MediaError(f"Media exceeds the {settings.max_upload_mb} MB upload limit.")

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wav = Path(tmp.name)
    try:
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
               "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", str(wav)]
        try:
            subprocess.run(cmd, check=True, timeout=max(90, max_seconds * 3), capture_output=True)
        except FileNotFoundError as exc:
            raise MediaError("Audio processing is temporarily unavailable.") from exc
        except subprocess.TimeoutExpired as exc:
            raise MediaError("Media decoding timed out; the file may be corrupt.") from exc
        except subprocess.CalledProcessError as exc:
            msg = (exc.stderr or b"").decode("utf-8", "ignore").strip()
            log.warning("ffmpeg_decode_failed detail=%r", msg[:200])
            raise MediaError("This file could not be decoded as audio/video.") from exc
        try:
            import soundfile as sf
        except ImportError as exc:
            raise MediaError("Audio support is not installed on this server.") from exc
        audio, sr = sf.read(wav, dtype="float32", always_2d=False)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        seconds = len(audio) / sr
        if seconds > max_seconds:
            raise MediaError(f"Media exceeds the {max_seconds / 60:.0f}-minute limit.")
        if len(audio) == 0:
            raise MediaError("Decoded audio is empty.")
        # Professional quality gate: assess BEFORE normalize/gate.
        quality = assess_audio_quality(np.asarray(audio, dtype=np.float32), int(sr))
        log.info("decode_quality snr_db=%.1f noisy=%s seconds=%.1f",
                 quality["snr_db"], quality["noisy"], seconds)
        # Professional preprocessing: normalize volume + light noise gate
        audio = _normalize_audio(audio)
        return audio.astype("float32"), int(sr), quality
    finally:
        wav.unlink(missing_ok=True)


# FYP STUDY GUIDE: Thin wrapper returning (audio, sr) without the quality dict.
# WHY: call sites that don't need the quality gate (e.g. quick identify) get a
# simple tuple - same decode path, less unpacking.
def decode_to_mono16k(src: Path, max_seconds: int) -> tuple[np.ndarray, int]:
    return decode_to_mono16k_with_quality(src, max_seconds)[:2]


# FYP STUDY GUIDE: Removes DC offset, peak-normalizes to -3dB, applies a light
# noise gate (<-40dB of peak, 50ms fade to avoid clicks).
# WHY: consistent loudness makes Whisper's VAD and decoder behave uniformly
# across phones and mics; the gate quiets background hiss without hard cuts.
def _normalize_audio(audio: np.ndarray) -> np.ndarray:
    """Normalize volume and apply light noise gate for cleaner ASR input."""
    # Remove DC offset
    audio = audio - np.mean(audio)
    # Peak normalize to -3dB (0.7) if too quiet, but don't amplify noise
    peak = np.max(np.abs(audio))
    if peak > 0.01 and peak < 0.7:
        audio = audio * (0.7 / peak)
    elif peak >= 0.7:
        audio = audio * (0.95 / max(peak, 1e-6))  # prevent clipping
    # Light noise gate: silence very quiet sections (< -40dB of peak)
    if peak > 0.01:
        threshold = peak * 0.01
        # Simple gate with 50ms fade to avoid clicks
        mask = np.abs(audio) < threshold
        audio = np.where(mask, audio * 0.1, audio)  # attenuate, don't hard-cut
    return audio
