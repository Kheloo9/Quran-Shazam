"""Quran Reader — full Quran text with translations and tafseer.

Serves the complete Quran (Arabic Uthmani text) with:
  * English translation (Mufti Taqi Usmani)
  * Urdu translation (Fateh Muhammad Jalandhry)
  * English tafseer (Almuntakhab Fi Tafsir Alquran Alkarim)

Data files (in backend/data/translations/):
  * translations.json — {"surah:ayah": {"en": ..., "ur": ...}}
  * tafseer.json      — {"surah:ayah": "..."}

Arabic text comes from the canonical QuranCorpus (already loaded).
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

log = logging.getLogger("quran_shazam")

# (number, arabic_name, english_name, ayahs, revelation: makki/madani)
SURAHS: list[tuple[int, str, str, int, str]] = [
    (1, "الفاتحة", "Al-Fatihah", 7, "Makki"),
    (2, "البقرة", "Al-Baqarah", 286, "Madani"),
    (3, "آل عمران", "Aal-e-Imran", 200, "Madani"),
    (4, "النساء", "An-Nisa", 176, "Madani"),
    (5, "المائدة", "Al-Ma'idah", 120, "Madani"),
    (6, "الأنعام", "Al-An'am", 165, "Makki"),
    (7, "الأعراف", "Al-A'raf", 206, "Makki"),
    (8, "الأنفال", "Al-Anfal", 75, "Madani"),
    (9, "التوبة", "At-Taubah", 129, "Madani"),
    (10, "يونس", "Yunus", 109, "Makki"),
    (11, "هود", "Hud", 123, "Makki"),
    (12, "يوسف", "Yusuf", 111, "Makki"),
    (13, "الرعد", "Ar-Ra'd", 43, "Madani"),
    (14, "إبراهيم", "Ibrahim", 52, "Makki"),
    (15, "الحجر", "Al-Hijr", 99, "Makki"),
    (16, "النحل", "An-Nahl", 128, "Makki"),
    (17, "الإسراء", "Al-Isra", 111, "Makki"),
    (18, "الكهف", "Al-Kahf", 110, "Makki"),
    (19, "مريم", "Maryam", 98, "Makki"),
    (20, "طه", "Ta-Ha", 135, "Makki"),
    (21, "الأنبياء", "Al-Anbiya", 112, "Makki"),
    (22, "الحج", "Al-Hajj", 78, "Madani"),
    (23, "المؤمنون", "Al-Mu'minun", 118, "Makki"),
    (24, "النور", "An-Nur", 64, "Madani"),
    (25, "الفرقان", "Al-Furqan", 77, "Makki"),
    (26, "الشعراء", "Ash-Shu'ara", 227, "Makki"),
    (27, "النمل", "An-Naml", 93, "Makki"),
    (28, "القصص", "Al-Qasas", 88, "Makki"),
    (29, "العنكبوت", "Al-Ankabut", 69, "Makki"),
    (30, "الروم", "Ar-Rum", 60, "Makki"),
    (31, "لقمان", "Luqman", 34, "Makki"),
    (32, "السجدة", "As-Sajdah", 30, "Makki"),
    (33, "الأحزاب", "Al-Ahzab", 73, "Madani"),
    (34, "سبأ", "Saba", 54, "Makki"),
    (35, "فاطر", "Fatir", 45, "Makki"),
    (36, "يس", "Ya-Sin", 83, "Makki"),
    (37, "الصافات", "As-Saffat", 182, "Makki"),
    (38, "ص", "Sad", 88, "Makki"),
    (39, "الزمر", "Az-Zumar", 75, "Makki"),
    (40, "غافر", "Ghafir", 85, "Makki"),
    (41, "فصلت", "Fussilat", 54, "Makki"),
    (42, "الشورى", "Ash-Shura", 53, "Makki"),
    (43, "الزخرف", "Az-Zukhruf", 89, "Makki"),
    (44, "الدخان", "Ad-Dukhan", 59, "Makki"),
    (45, "الجاثية", "Al-Jasiyah", 37, "Makki"),
    (46, "الأحقاف", "Al-Ahqaf", 35, "Makki"),
    (47, "محمد", "Muhammad", 38, "Madani"),
    (48, "الفتح", "Al-Fath", 29, "Madani"),
    (49, "الحجرات", "Al-Hujurat", 18, "Madani"),
    (50, "ق", "Qaf", 45, "Makki"),
    (51, "الذاريات", "Az-Zariyat", 60, "Makki"),
    (52, "الطور", "At-Tur", 49, "Makki"),
    (53, "النجم", "An-Najm", 62, "Makki"),
    (54, "القمر", "Al-Qamar", 55, "Makki"),
    (55, "الرحمن", "Ar-Rahman", 78, "Makki"),
    (56, "الواقعة", "Al-Waqi'ah", 96, "Makki"),
    (57, "الحديد", "Al-Hadid", 29, "Madani"),
    (58, "المجادلة", "Al-Mujadila", 22, "Madani"),
    (59, "الحشر", "Al-Hashr", 24, "Madani"),
    (60, "الممتحنة", "Al-Mumtahanah", 13, "Madani"),
    (61, "الصف", "As-Saff", 14, "Madani"),
    (62, "الجمعة", "Al-Jumu'ah", 11, "Madani"),
    (63, "المنافقون", "Al-Munafiqun", 11, "Madani"),
    (64, "التغابن", "At-Taghabun", 18, "Madani"),
    (65, "الطلاق", "At-Talaq", 12, "Madani"),
    (66, "التحريم", "At-Tahrim", 12, "Madani"),
    (67, "الملك", "Al-Mulk", 30, "Makki"),
    (68, "القلم", "Al-Qalam", 52, "Makki"),
    (69, "الحاقة", "Al-Haqqah", 52, "Makki"),
    (70, "المعارج", "Al-Ma'arij", 44, "Makki"),
    (71, "نوح", "Nuh", 28, "Makki"),
    (72, "الجن", "Al-Jinn", 28, "Makki"),
    (73, "المزمل", "Al-Muzzammil", 20, "Makki"),
    (74, "المدثر", "Al-Muddaththir", 56, "Makki"),
    (75, "القيامة", "Al-Qiyamah", 40, "Makki"),
    (76, "الإنسان", "Al-Insan", 31, "Madani"),
    (77, "المرسلات", "Al-Mursalat", 50, "Makki"),
    (78, "النبأ", "An-Naba", 40, "Makki"),
    (79, "النازعات", "An-Nazi'at", 46, "Makki"),
    (80, "عبس", "Abasa", 42, "Makki"),
    (81, "التكوير", "At-Takwir", 29, "Makki"),
    (82, "الانفطار", "Al-Infitar", 19, "Makki"),
    (83, "المطففين", "Al-Mutaffifin", 36, "Makki"),
    (84, "الانشقاق", "Al-Inshiqaq", 25, "Makki"),
    (85, "البروج", "Al-Buruj", 22, "Makki"),
    (86, "الطارق", "At-Tariq", 17, "Makki"),
    (87, "الأعلى", "Al-A'la", 19, "Makki"),
    (88, "الغاشية", "Al-Ghashiyah", 26, "Makki"),
    (89, "الفجر", "Al-Fajr", 30, "Makki"),
    (90, "البلد", "Al-Balad", 20, "Makki"),
    (91, "الشمس", "Ash-Shams", 15, "Makki"),
    (92, "الليل", "Al-Layl", 21, "Makki"),
    (93, "الضحى", "Ad-Duha", 11, "Makki"),
    (94, "الشرح", "Ash-Sharh", 8, "Makki"),
    (95, "التين", "At-Tin", 8, "Makki"),
    (96, "العلق", "Al-Alaq", 19, "Makki"),
    (97, "القدر", "Al-Qadr", 5, "Makki"),
    (98, "البينة", "Al-Bayyinah", 8, "Madani"),
    (99, "الزلزلة", "Az-Zalzalah", 8, "Madani"),
    (100, "العاديات", "Al-Adiyat", 11, "Makki"),
    (101, "القارعة", "Al-Qari'ah", 11, "Makki"),
    (102, "التكاثر", "At-Takathur", 8, "Makki"),
    (103, "العصر", "Al-Asr", 3, "Makki"),
    (104, "الهمزة", "Al-Humazah", 9, "Makki"),
    (105, "الفيل", "Al-Fil", 5, "Makki"),
    (106, "قريش", "Quraysh", 4, "Makki"),
    (107, "الماعون", "Al-Ma'un", 7, "Makki"),
    (108, "الكوثر", "Al-Kawthar", 3, "Makki"),
    (109, "الكافرون", "Al-Kafirun", 6, "Makki"),
    (110, "النصر", "An-Nasr", 3, "Madani"),
    (111, "المسد", "Al-Masad", 5, "Makki"),
    (112, "الإخلاص", "Al-Ikhlas", 4, "Makki"),
    (113, "الفلق", "Al-Falaq", 5, "Makki"),
    (114, "الناس", "An-Nas", 6, "Makki"),
]


# FYP STUDY GUIDE: Serves full Quran text + EN/UR translations + tafseer +
# transliteration from local JSON files.
# WHY: the reader is the app's study pillar - one class owns all static Quran
# content so verify, Q&A, and search always read the same data.
class QuranReader:
    """Serves full Quran text + translations + tafseer."""

    # FYP STUDY GUIDE: Stores the data dir and corpus, initializes empty dicts,
    # then loads all JSON once via _load().
    # WHY: load-once at construction - every later request is a dict lookup, so
    # surah pages answer in milliseconds.
    def __init__(self, data_dir: Path, corpus=None):
        self.data_dir = data_dir
        self.corpus = corpus
        self.translations: dict[str, dict[str, str]] = {}
        self.tafseer: dict[str, str] = {}
        self.tafseer_ur: dict[str, str] = {}
        self.transliteration: dict[str, str] = {}
        self._load()

    # FYP STUDY GUIDE: Loads translations, EN tafseer (real Ibn Kathir merged over
    # the Almuntakhab fallback), UR tafseer (real Bayan-ul-Quran), transliteration -
    # each file in its own try/except.
    # WHY: real tafseer replaced mislabeled files; per-file try/except means one
    # corrupt JSON can't kill the whole reader - missing content just shows as
    # unavailable.
    def _load(self) -> None:
        tdir = self.data_dir / "translations"
        try:
            p = tdir / "translations.json"
            if p.exists():
                self.translations = json.loads(p.read_text(encoding="utf-8"))
                log.info("reader translations loaded: %d", len(self.translations))
        except Exception as exc:
            log.warning("reader translations failed: %r", exc)
        try:
            # Professional: prefer REAL English tafseer (Ibn Kathir abridged,
            # from quran.com API). But Ibn Kathir groups verses, so ~4341 ayat
            # lack individual entries — fill gaps from the old Almuntakhab file.
            p = tdir / "tafseer_en_real.json"
            real = {}
            if p.exists():
                real = json.loads(p.read_text(encoding="utf-8"))
                log.info("reader tafseer_en_real loaded: %d", len(real))
            p2 = tdir / "tafseer.json"
            fallback = {}
            if p2.exists():
                fallback = json.loads(p2.read_text(encoding="utf-8"))
            # Merge: real first, fallback for missing/short entries
            merged = dict(fallback)
            for k, v in real.items():
                if v and len(v.strip()) >= 50:
                    merged[k] = v
            self.tafseer = merged
            log.info("reader tafseer (merged) loaded: %d", len(self.tafseer))
        except Exception as exc:
            log.warning("reader tafseer failed: %r", exc)
        try:
            # Professional: use REAL Urdu tafseer (Bayan ul Quran by Dr. Israr Ahmad)
            # from quran.com API, not the old file which was just Urdu translation.
            p = tdir / "tafseer_ur_real.json"
            if p.exists():
                self.tafseer_ur = json.loads(p.read_text(encoding="utf-8"))
                log.info("reader tafseer_ur (REAL) loaded: %d", len(self.tafseer_ur))
            else:
                # Fallback to old file (Urdu translation, mislabeled as tafseer)
                p = tdir / "tafseer_ur.json"
                if p.exists():
                    self.tafseer_ur = json.loads(p.read_text(encoding="utf-8"))
                    log.info("reader tafseer_ur (fallback) loaded: %d", len(self.tafseer_ur))
        except Exception as exc:
            log.warning("reader tafseer_ur failed: %r", exc)
        try:
            p = tdir / "transliteration.json"
            if p.exists():
                self.transliteration = json.loads(p.read_text(encoding="utf-8"))
                log.info("reader transliteration loaded: %d", len(self.transliteration))
        except Exception as exc:
            log.warning("reader transliteration failed: %r", exc)

    @property
    # FYP STUDY GUIDE: True when the backing corpus is present and valid.
    # WHY: the reader must never serve translations for ayat whose Arabic failed
    # validation - the Arabic/translation pair stays consistent.
    def ready(self) -> bool:
        return self.corpus is not None and self.corpus.ready

    # FYP STUDY GUIDE: All 114 surahs' metadata (number, Arabic/English names, ayah
    # counts, Makki/Madani) from the static SURAHS table.
    # WHY: the reader's index page data - static and safe to serve instantly, no
    # heavy corpus data involved.
    def surah_list(self) -> list[dict[str, Any]]:
        return [
            {"number": n, "arabic": ar, "english": en, "ayahs": ayahs,
             "revelation": rev}
            for n, ar, en, ayahs, rev in SURAHS
        ]

    # FYP STUDY GUIDE: Metadata for one surah number (1-114); None when out of range.
    # WHY: the single validated lookup - every route checks 'surah 99 has only 8
    # ayat' style constraints through this instead of trusting raw numbers.
    def surah_meta(self, n: int) -> dict[str, Any] | None:
        if 1 <= n <= 114:
            num, ar, en, ayahs, rev = SURAHS[n - 1]
            return {"number": num, "arabic": ar, "english": en,
                    "ayahs": ayahs, "revelation": rev}
        return None

    # FYP STUDY GUIDE: Full surah - Arabic + EN/UR per ayah, with has_tafseer flags
    # instead of the tafseer text itself.
    # WHY: the lazy-load design - 13KB+/ayah tafseer made Al-Baqarah's JSON several
    # MB; flags let the UI fetch tafseer per tap while the page opens in ~0.3s.
    def get_surah(self, n: int) -> dict[str, Any] | None:
        """Full surah with Arabic + EN/UR translations (tafseer loaded on-demand).

        Professional: tafseer (Ibn Kathir + Bayan-ul-Quran) is very large
        (13KB+ per ayah). Including it for all 286 ayat of Al-Baqarah makes
        the JSON several MB and slow on mobile. Tafseer is now fetched
        per-ayah via /api/quran/tafseer/{surah}/{ayah} when the user taps
        "Tafseer parhein".
        """
        meta = self.surah_meta(n)
        if not meta or not self.ready:
            return None
        verses = self.corpus.by_surah.get(n, [])
        ayahs = []
        for v in verses:
            key = f"{n}:{v.ayah}"
            tr = self.translations.get(key, {})
            ayahs.append({
                "ayah": v.ayah,
                "arabic": v.text,
                "translation_en": tr.get("en", ""),
                "translation_ur": tr.get("ur", ""),
                # Tafseer NOT included here (on-demand via separate endpoint)
                "has_tafseer": bool(self.tafseer.get(key, "")),
                "has_tafseer_ur": bool(self.tafseer_ur.get(key, "")),
                "transliteration": self.transliteration.get(key, ""),
            })
        return {
            "number": meta["number"],
            "arabic": meta["arabic"],
            "english": meta["english"],
            "ayah_count": meta["ayahs"],
            "revelation": meta["revelation"],
            "ayahs": ayahs,
        }

    # FYP STUDY GUIDE: EN + UR tafseer for one ayah, with +-3 neighbor fallback when
    # the ayah itself lacks an entry.
    # WHY: classical tafseers comment on verse GROUPS (e.g. 93:1-11 together) - the
    # neighbor fallback closed 1,163 gaps found in 200-user testing; on-demand
    # delivery keeps pages fast.
    def get_tafseer(self, surah: int, ayah: int) -> dict[str, str] | None:
        """Fetch tafseer (EN + UR) for a single ayah, on-demand.

        Professional: classical tafseers comment on verse GROUPS (e.g. 93:1-11
        together). Our per-ayah JSON may have the group commentary on only one
        ayah of the group. If an ayah lacks tafseer, we check neighbors (±3)
        in the same surah — the group commentary covers them all.
        Added 2026-10-18 after 200-user testing found 1,163 gaps.
        """
        key = f"{surah}:{ayah}"
        tafseer_en = self.tafseer.get(key, "")
        tafseer_ur = self.tafseer_ur.get(key, "")
        # Neighbor fallback for grouped-verse commentary
        if not tafseer_en:
            for d in (1, -1, 2, -2, 3, -3):
                t = self.tafseer.get(f"{surah}:{ayah+d}", "")
                if len(t) >= 50:
                    tafseer_en = t
                    break
        if not tafseer_ur:
            for d in (1, -1, 2, -2, 3, -3):
                t = self.tafseer_ur.get(f"{surah}:{ayah+d}", "")
                if len(t) >= 50:
                    tafseer_ur = t
                    break
        if not tafseer_en and not tafseer_ur:
            return None
        return {
            "surah": surah,
            "ayah": ayah,
            "tafseer_en": tafseer_en,
            "tafseer_ur": tafseer_ur,
            "source_en": "Tafsir Ibn Kathir (Abridged)" if tafseer_en else "",
            "source_ur": "Bayan ul Quran (Dr. Israr Ahmad)" if tafseer_ur else "",
        }

    # FYP STUDY GUIDE: Searches translations (EN/UR) for a phrase - or the Arabic
    # text directly for Arabic queries, with alef-lenient matching.
    # WHY: find-by-meaning for users who don't know the Arabic, find-by-Arabic for
    # those who do; the alef leniency absorbs the U+0670 spelling variation.
    def search(self, query: str, lang: str = "en", limit: int = 50) -> list[dict[str, Any]]:
        """Search translations for a phrase, or Arabic text for Arabic queries."""
        query = query.strip()
        if len(query) < 2 or not self.ready:
            return []
        # Detect Arabic query: search the Arabic Quran text directly
        is_arabic = any('\u0600' <= c <= '\u06ff' for c in query)
        out = []
        if is_arabic:
            from .normalization import normalize_arabic
            nq = normalize_arabic(query)
            # Lenient: also try without alef variations (U+0670 superscript
            # alef becomes regular alef in text but users type without it)
            nq_no_alef = nq.replace('ا', '').replace('أ', '').replace('إ', '').replace('آ', '')
            for key, v in self.corpus.by_key.items():
                nt = normalize_arabic(v.text)
                nt_no_alef = nt.replace('ا', '').replace('أ', '').replace('إ', '').replace('آ', '')
                if nq in nt or (len(nq_no_alef) >= 2 and nq_no_alef in nt_no_alef):
                    s, a = key.split(":")
                    tr = self.translations.get(key, {})
                    out.append({
                        "surah": int(s), "ayah": int(a),
                        "arabic": v.text,
                        "translation": tr.get("en", ""),
                    })
                    if len(out) >= limit:
                        break
            return out
        query = query.lower()
        for key, tr in self.translations.items():
            text = tr.get(lang, "") if lang in ("en", "ur") else ""
            if query in text.lower():
                s, a = key.split(":")
                v = self.corpus.by_key.get(key)
                out.append({
                    "surah": int(s), "ayah": int(a),
                    "arabic": v.text if v else "",
                    "translation": text,
                })
                if len(out) >= limit:
                    break
        return out

    # ------------------------------------------------- word translator ----
    # Everyday EN<->UR dictionary (fallback when a word is not Quranic).
    _BASIC_EN2UR = {
        "hello": "ہیلو / سلام", "hi": "سلام", "peace": "امن / سلامتی",
        "love": "محبت", "mercy": "رحم / رحمت", "forgiveness": "معافی / مغفرت",
        "patience": "صبر", "thanks": "شکریہ", "thank you": "شکریہ",
        "good": "اچھا", "bad": "برا", "morning": "صبح", "night": "رات",
        "day": "دن", "water": "پانی", "food": "کھانا", "house": "گھر",
        "book": "کتاب", "man": "آدمی / مرد", "woman": "عورت",
        "child": "بچہ", "friend": "دوست", "family": "خاندان",
        "god": "خدا / اللہ", "prophet": "نبی / پیغمبر",
        "heaven": "جنت", "hell": "جہنم", "prayer": "نماز / دعا",
        "faith": "ایمان", "truth": "سچ / حق", "lie": "جھوٹ",
        "life": "زندگی", "death": "موت", "world": "دنیا",
        "heart": "دل", "soul": "روح", "light": "روشنی / نور",
        "darkness": "اندھیرا / ظلمت", "knowledge": "علم",
        "wisdom": "حکمت / دانائی", "justice": "انصاف",
        "help": "مدد", "hope": "امید", "fear": "ڈر / خوف",
        "happy": "خوش", "sad": "اداس", "big": "بڑا", "small": "چھوٹا",
        "new": "نیا", "old": "پرانا", "time": "وقت",
        "today": "آج", "tomorrow": "کل", "yesterday": "کل (گذشتہ)",
        "yes": "ہاں", "no": "نہیں", "please": "براہ کرم / مہربانی",
        "sorry": "معاف کیجیے", "welcome": "خوش آمدید",
        "brother": "بھائی", "sister": "بہن", "father": "والد / ابا",
        "mother": "والدہ / امی", "son": "بیٹا", "daughter": "بیٹی",
        "king": "بادشاہ", "people": "لوگ", "city": "شہر",
        "village": "گاؤں", "road": "سڑک / راستہ", "door": "دروازہ",
        "window": "کھڑکی", "money": "پیسہ / رقم", "work": "کام",
        "school": "اسکول / مدرسہ", "teacher": "استاد",
        "student": "طالب علم", "question": "سوال", "answer": "جواب",
    }

    _EN_STOP = frozenset(
        "the a an and or of to in on is are was were be been being "
        "it its this that these those for with as by at from into "
        "he him his she her they them their we us our you your i my me "
        "not no but if then than so such will would shall should can could "
        "may might must do does did done have has had having all any each "
        "who whom whose what which when where why how there here their "
        "o indeed verily surely".split()
    )
    _UR_STOP = frozenset(
        "کا کی کے کو نے سے میں پر اور یا وہ یہ جو جس جن ہے ہیں تھا تھے "
        "ہو ہوں ہوگا نہیں نہ بھی تو تک صرف کیا کہ اگر جب تب پھر "
        "اپنے اپنی اپنا اس اسے ان انہیں".split()
    )

    @staticmethod
    # FYP STUDY GUIDE: Static tokenizer - lowercases English, keeps Latin + Arabic
    # letters, drops tokens shorter than 2 chars.
    # WHY: shared tokenization for the translator so EN and UR text are counted
    # identically; the character class keeps both scripts while dropping digits
    # and punctuation.
    def _tokenize(text: str, lang: str) -> list[str]:
        import re
        text = text.lower() if lang == "en" else text
        # Keep letters (Latin + Arabic blocks), drop digits/punctuation
        toks = re.findall(r"[a-zA-Z\u0600-\u06FF]+", text)
        return [t for t in toks if len(t) >= 2]

    # FYP STUDY GUIDE: EN<->UR translation via co-occurrence in 6,236 parallel ayat
    # (IDF-weighted), plus example ayat and an everyday-dictionary fallback.
    # WHY: transparent statistics (simplified IBM Model 1 intuition) an examiner can
    # audit - not a black box; the examples prove each translation in real Quranic
    # context; the dictionary covers non-Quranic words.
    def translate_word(self, word: str, direction: str = "en2ur",
                       limit: int = 8) -> dict:
        """Translate a word/phrase EN<->UR from parallel Quran translations.

        Finds ayat containing the word in the source language, then ranks
        target-language tokens by co-occurrence frequency (simple,
        transparent statistical hint — not a certified dictionary).
        Returns translation candidates + example ayat (Quran context).
        Falls back to a small everyday dictionary for non-Quranic words.

        FYP STUDY GUIDE: why co-occurrence?
        - We have 6,236 ayat with EN and UR side by side (parallel corpus).
        - If "mercy" appears in 50 EN ayat, the UR words appearing most
          often in those SAME 50 ayat are very likely its translation.
        - This is the same intuition behind IBM Model 1 (word alignment),
          simplified to unigram co-occurrence — easy to defend in viva.

        FYP STUDY GUIDE: why we strip HTML tags from the word
        - The endpoint echoes the query word back in the JSON response
          ("word": ...). If a user types <script>...</script>, raw tags in
          the response would be a reflected-XSS vector if any client ever
          injects that field into the page. Same defence: remove <...>
          tags at the engine boundary so echoed input can never carry markup.
        """
        import re
        word = (word or "").strip()
        word = re.sub(r"<[^>]*>", "", word).strip()  # strip HTML tags (XSS guard)
        if not word or not self.ready:
            return {"word": word, "direction": direction,
                    "candidates": [], "examples": [], "source": "none"}
        direction = direction if direction in ("en2ur", "ur2en") else "en2ur"
        src_lang, tgt_lang = ("en", "ur") if direction == "en2ur" else ("ur", "en")
        stop_src = self._EN_STOP if src_lang == "en" else self._UR_STOP
        stop_tgt = self._UR_STOP if tgt_lang == "ur" else self._EN_STOP

        if src_lang == "en":
            pat = re.compile(r"\b" + re.escape(word.lower()) + r"\b")
            hit = lambda t: bool(pat.search(t.lower()))
        else:
            hit = lambda t: word in t  # Urdu: substring (morphology varies)

        matched = []  # (key, src_text, tgt_text)
        for key, tr in self.translations.items():
            src = tr.get(src_lang, "")
            if src and hit(src):
                matched.append((key, src, tr.get(tgt_lang, "")))
                if len(matched) >= 60:
                    break

        candidates: list[dict] = []
        examples: list[dict] = []
        if matched:
            from collections import Counter
            import math
            # IDF weighting: demote words that are common everywhere
            # (e.g. خدا/تم appear in most ayat, so they outrank رحمت).
            # Built once, cached on the instance.
            df_attr = f"_idf_df_{tgt_lang}"
            df = getattr(self, df_attr, None)
            if df is None:
                df = Counter()
                n_docs = 0
                for _key, _tr in self.translations.items():
                    toks = set(self._tokenize(_tr.get(tgt_lang, ""), tgt_lang))
                    toks = {t for t in toks if t not in stop_tgt}
                    for t in toks:
                        df[t] += 1
                    n_docs += 1
                setattr(self, df_attr, df)
                setattr(self, f"_idf_n_{tgt_lang}", n_docs)
            n_docs = getattr(self, f"_idf_n_{tgt_lang}", 6236)
            cnt: Counter = Counter()
            for _, _, tgt in matched:
                for tok in self._tokenize(tgt, tgt_lang):
                    if tok not in stop_tgt:
                        cnt[tok] += 1
            total = len(matched)
            scored = []
            for tok, c in cnt.items():
                idf = math.log((n_docs + 1) / (df.get(tok, 1) + 1)) + 1.0
                scored.append((tok, (c / total) * idf, c / total))
            scored.sort(key=lambda x: -x[1])
            for tok, _s, raw in scored[:5]:
                candidates.append({"text": tok, "score": round(raw, 2)})
            for key, src, tgt in matched[:limit]:
                s, a = key.split(":")
                examples.append({
                    "surah": int(s), "ayah": int(a),
                    "source_text": src[:220], "target_text": tgt[:220],
                })
            source = "quran"
        else:
            # Fallback: everyday dictionary
            source = "dictionary"
            if direction == "en2ur":
                got = self._BASIC_EN2UR.get(word.lower())
                if got:
                    candidates = [{"text": got, "score": 1.0}]
            else:
                inv = {}
                for k, v in self._BASIC_EN2UR.items():
                    for part in v.split("/"):
                        inv.setdefault(part.strip(), k)
                got = inv.get(word.strip())
                if got:
                    candidates = [{"text": got, "score": 1.0}]

        return {
            "word": word,
            "direction": direction,
            "candidates": candidates,
            "examples": examples,
            "source": source,  # "quran" | "dictionary" | "none"
            "note": ("Quranic usage" if source == "quran"
                     else "Everyday word" if source == "dictionary"
                     else "No match found"),
        }
