"""Quran verse matching: fuzzy text alignment of ASR transcript to verses.

========================================================================
FYP STUDY GUIDE: How the Matcher Finds Quranic Verses
========================================================================

THE PROBLEM:
  ASR output is imperfect. Example:
    Correct:  "قل هو الله احد" (Qul huwa Allahu ahad)
    ASR heard: "قل هو الله اهد" (one letter wrong!)

  Exact string matching would FAIL. We need FUZZY matching.

WHAT IS FUZZY MATCHING?
  Instead of "is this exactly equal?", we ask "how SIMILAR is this?"
  Similarity is a score from 0-100:
    - 100 = identical
    - 90+ = very similar (probably the same verse with ASR errors)
    - 70-90 = somewhat similar (maybe correct, maybe not)
    - <70 = probably wrong verse

TECHNIQUES USED:

1. IDF-WEIGHTED SCORING (Information Retrieval concept!)
   IDF = Inverse Document Frequency
   - Common words ("الله", "من") appear in many verses -> low weight
   - Rare words ("الصمد", "كفوا") appear in few verses -> high weight
   - Why? If ASR hears "الصمد", it's a strong clue for Surah 112!
   - This is the same technique Google Search uses.

2. SURAH LOCK (reduces wrong-surah errors)
   - Once we get 3 consecutive matches from the same surah...
   - ...we "lock" to that surah for subsequent matches
   - Why? If you're reciting Al-Baqarah, you won't suddenly jump to An-Nas!
   - This kills the main failure mode: wrong-surah jumps on noisy audio.

3. SOFT RECOVERY (handles one wrong jump gracefully)
   - Old approach: hard cutoff - if we jump wrong, we're stuck forever
   - New approach: allow looking back up to 30 ayat with a score penalty
   - Why? One mistake shouldn't ruin the entire recitation.

4. CANDIDATE POOL (performance optimization)
   - Comparing against all 6,236 verses for every position is SLOW
   - Instead: use IDF to rank verses, take top 60 candidates
   - Then do expensive fuzzy matching only on those 60
   - 100x faster with no accuracy loss!

5. PARALLEL SCORING
   - rapidfuzz (C++ library) releases Python's GIL
   - We use 4 threads to score candidates in parallel
   - Real speedup on multi-core machines.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable

from .corpus import QuranCorpus, Verse
from .normalization import normalize_arabic, tokens

try:
    from rapidfuzz.fuzz import ratio as rf_ratio
except Exception:
    rf_ratio = None

@dataclass
# FYP STUDY GUIDE: One verse match - the verse, score/coverage/missing (0-100),
# sequence fit, transcript word position, status, and a human-readable reason.
# WHY: the single evidence object every label, coach card, and API response is
# built from - carrying the reason alongside the score makes verdicts auditable.
class Match:
    """A single verse match result.

    Attributes:
        verse: The matched Quranic verse (surah, ayah, text)
        score: Fuzzy similarity 0-100 (higher = more confident)
        coverage: % of transcript words covered by this match
        missing: Number of expected words not found
        sequence: How well this fits the expected order (0-100)
        start/length: Position in transcript (word indices)
        status: "MATCH" or "SEQUENCE RECOVERY"
        reason: Human-readable explanation
    """
    verse: Verse
    score: float
    coverage: float
    missing: float
    sequence: float
    start: int
    length: int
    status: str = "MATCH"
    reason: str = ""


# FYP STUDY GUIDE: Fuzzy string similarity 0-100 (rapidfuzz, difflib fallback)
# after Arabic normalization.
# WHY: ASR makes 1-letter errors ('اهد' vs 'احد') that exact matching would miss;
# the 0-100 scale is the project's universal confidence currency (the word-
# practice >=80 threshold uses it too).
def similarity(a: str, b: str) -> float:
    a = normalize_arabic(a); b = normalize_arabic(b)
    if not a or not b: return 0.0
    if rf_ratio:
        return float(rf_ratio(a, b))
    return SequenceMatcher(None, a, b).ratio() * 100


# FYP STUDY GUIDE: Percentage of shared word tokens between two texts (0-100).
# WHY: one of the four sub-scores blended in best_window - word overlap catches
# matches where letter-level similarity is diluted by ASR spelling wobble.
def token_overlap(a: str, b: str) -> float:
    A, B = set(tokens(a)), set(tokens(b))
    if not A or not B: return 0.0
    return 100.0 * len(A & B) / max(len(A), len(B))


# FYP STUDY GUIDE: True if a word - or a >=80-similar near-miss - is in the set.
# WHY: ASR near-misses ('اهدن' vs 'اهدنا') must not count as fully missing; this
# tolerance stops one spelling wobble from destroying coverage/missing scores.
def _fuzzy_contains(word: str, word_set: set[str], threshold: float = 80.0) -> bool:
    """Check if a word (or a close fuzzy match) is in the set.
    Professional: ASR often produces near-misses ("اهدن" vs "اهدنا").
    Counting these as completely missing destroys the score. A word with
    ≥80 fuzzy similarity counts as present."""
    if word in word_set:
        return True
    for w in word_set:
        if similarity(word, w) >= threshold:
            return True
    return False


# FYP STUDY GUIDE: % of transcript words covered by the verse (fuzzy-tolerant).
# WHY: VERIFIED demands coverage >=85 - a high similarity score alone isn't enough;
# the whole ayah must actually be heard, not just a distinctive fragment.
def coverage(a: str, b: str) -> float:
    A, B = tokens(a), set(tokens(b))
    if not A: return 0.0
    return 100.0 * sum(_fuzzy_contains(t, B) for t in A) / len(A)


# FYP STUDY GUIDE: % of the verse's words not found in the transcript.
# WHY: VERIFIED demands missing <=25 - the honest counterweight to coverage:
# 'what matched' and 'what's absent' are both measured before any strong claim.
def missing(a: str, b: str) -> float:
    B = tokens(b); A = set(tokens(a))
    if not B: return 0.0
    return 100.0 * sum(not _fuzzy_contains(t, A) for t in B) / len(B)


# FYP STUDY GUIDE: Finds the best transcript window for one verse across lengths
# and start offsets: 0.52*similarity + 0.28*overlap + 0.25*coverage - 0.12*missing.
# WHY: the ayah's exact position and length in the transcript are unknown - sliding
# windows plus the weighted blend absorb ASR length errors (a stutter makes the
# ayah longer than the canonical text).
def best_window(text: str, verse: Verse, max_start: int = 8) -> tuple[float, int, int, float, float]:
    parts = tokens(text); n = len(tokens(verse.text))
    if not parts or not verse.normalized: return 0.0, 0, 0, 0.0, 100.0
    lengths = sorted(set([max(1,n-5), n, n+1, n+2, n+4, min(max(8,n+12), 180)]))
    best = (0.0,0,n,0.0,100.0)
    for L in lengths:
        if L <= 0 or L > len(parts): continue
        start_limit = min(max(0, len(parts)-L), max_start)
        for i in range(start_limit+1):
            win = " ".join(parts[i:i+L])
            sim = similarity(win, verse.text)
            ov = token_overlap(win, verse.text)
            cov = coverage(win, verse.text)
            miss = missing(win, verse.text)
            score = max(0.0, min(100.0, 0.52*sim + 0.28*ov + 0.25*cov - 0.12*miss))
            if score > best[0]: best = (score,i,L,cov,miss)
            if score >= 99.8: return best
    return best


# FYP STUDY GUIDE: IDF-weighted ranking of all 6,236 verses -> top 240 candidates
# for a text window (length-normalized, with a never-empty fallback).
# WHY: scoring every verse per position is ~100x too slow; IDF lets rare words
# ('الصمد': 1 verse) outweigh common ones ('الله': 1,566 verses) so short but
# distinctive ayat are never cropped out - the same idea Google Search uses.
def candidate_pool(corpus: QuranCorpus, text: str, cap: int = 240) -> list[Verse]:
    """Rank candidates by IDF-weighted token overlap.

    A raw count lets ultra-common words ("الله": 1,566 verses) drown out the
    distinctive ones ("الصمد": 1 verse), so short-but-distinctive ayat such
    as 112:2 were cropped out of the pool entirely and could never match.
    Weighting by inverse document frequency fixes the ranking: rare tokens
    dominate, which is exactly what identifies an ayah.
    """
    import math
    n_docs = max(1, len(corpus.verses))
    scores: dict[str,float] = {}
    verse_lens: dict[str,int] = {}
    for tok in set(tokens(text)):
        verses = corpus.inverted.get(tok)
        if not verses:
            continue
        idf = math.log(n_docs / len(verses))
        for v in verses:
            scores[v.key] = scores.get(v.key, 0.0) + idf
            verse_lens[v.key] = len(tokens(v.normalized))
    if scores:
        # Length-normalize: a raw IDF sum lets long ayat drown out short but
        # distinctive ones ("يس" is a single ultra-rare token). Dividing by
        # sqrt(verse length) keeps rare-token matches competitive regardless
        # of ayah length — critical for long recitations where the 180-word
        # window would otherwise crop short opening ayat out of the pool.
        ranked = sorted(scores, key=lambda k: scores[k] / math.sqrt(max(1, verse_lens.get(k, 1))),
                        reverse=True)[:cap]
        return [corpus.by_key[k] for k in ranked]
    # Critical fallback: never return zero candidates just because an index token was missing.
    return corpus.verses


# FYP STUDY GUIDE: The main matching loop - 180-word sliding window, top-60 IDF
# candidates scored in parallel (4 threads), leftmost-near-best selection, surah
# lock after 3 strong same-surah matches, soft recovery looking back 30 ayat.
# WHY: the core 'Shazam' algorithm - the surah lock kills wrong-surah jumps (the
# main failure mode on noisy audio); soft recovery survives one bad jump instead
# of failing forever; rapidfuzz releases the GIL so threads give real speedup.
def align_transcript(corpus: QuranCorpus, transcript: str) -> list[Match]:
    if not corpus.ready: raise RuntimeError("Quran corpus is not ready; verification is blocked.")
    t = normalize_arabic(transcript)
    if not t: return []
    words = tokens(t)
    results: list[Match] = []
    prev_global = 0
    pos = 0
    max_loops = max(len(words) + 20, 40)
    # Surah lock: once 3 consecutive strong matches come from the same surah,
    # restrict candidates to that surah. This kills wrong-surah jumps (the
    # main failure mode on long noisy transcripts) and shrinks the pool.
    locked_surah = 0
    # One shared thread pool for parallel candidate scoring (rapidfuzz
    # releases the GIL, so threads help). Created once, not per-iteration.
    ex = ThreadPoolExecutor(max_workers=4)
    try:
      for _ in range(max_loops):
        if pos >= len(words): break
        window = " ".join(words[pos:pos+180])
        # candidate_pool returns IDF-ranked candidates (most distinctive first).
        # The true verse is overwhelmingly likely in the top ranks; running the
        # expensive best_window (rapidfuzz) on all 240 is wasteful. Score the
        # top 60 by pool rank — 4x fewer rapidfuzz calls. The top-12 selection
        # afterwards is unchanged.
        candidates = candidate_pool(corpus, window)[:60]
        # Professional: ALWAYS include the next sequential verses as candidates.
        # If we just matched 1:5, then 1:6 MUST be scored even if ASR errors
        # made its IDF rank low. Without this, ASR errors on distinctive words
        # cause the true next ayah to be cropped from the pool entirely.
        if prev_global:
            seq_keys = set()
            for v in corpus.verses:
                if prev_global < v.global_index <= prev_global + 3:
                    seq_keys.add(v.key)
            # Add missing sequential candidates at the front (highest priority)
            existing = {v.key for v in candidates}
            for v in corpus.verses:
                if v.key in seq_keys and v.key not in existing:
                    candidates.insert(0, v)
        if locked_surah:
            candidates = [v for v in candidates if v.surah == locked_surah]
            if not candidates:
                # Lock is wrong (no candidates) — release it and retry unfiltered.
                locked_surah = 0
                lock_streak = 0
                candidates = candidate_pool(corpus, window)[:60]
        # Parallel candidate scoring: best_window does ~24 rapidfuzz (C++)
        # comparisons per candidate; rapidfuzz releases the GIL, so threads
        # give a real speedup on multi-core machines.
        # FYP STUDY GUIDE: Per-candidate scorer inside align_transcript - best_window
        # blended with a sequence bonus (100 for the next ayah, 10 for backwards).
        # WHY: recitation order is evidence - the next canonical ayah gets full sequence
        # credit while a backward jump is penalized but not impossible (recovery needs it).
        def _score(v: Verse):
            # Soft recovery: instead of hard-excluding everything at/before
            # prev_global (which makes one wrong jump unrecoverable), allow
            # looking back up to 30 ayat with a heavy score penalty. Way-behind
            # candidates are still skipped for speed.
            if prev_global and v.global_index < prev_global - 30:
                return None
            s, st, L, cov, miss = best_window(window, v, max_start=10)
            if not s:
                return None
            distance = v.global_index - prev_global if prev_global else 1
            if not prev_global or distance == 1:
                seq = 100.0
            elif distance <= 0:
                seq = 10.0  # backwards: heavy penalty, but not impossible (recovery)
            else:
                seq = max(30.0, 100.0 - min(70.0, (distance-1)*15.0))
            combined = 0.64*s + 0.24*cov + 0.12*seq
            return (combined, v, st, L, cov, miss, seq)
        scored = [r for r in ex.map(_score, candidates) if r is not None]
        scored.sort(key=lambda x:(x[0], -x[2]), reverse=True)
        # Choose among the top candidates. Pure "highest score" can skip an
        # ayah: e.g. a stutter makes 1:3 score 100 at offset 3 while the true
        # 1:1 sits at offset 0 with 98.6 — picking 1:3 jumps over 1:1 forever.
        # Rule: among candidates within 25 points of the best, prefer the
        # leftmost (smallest start offset). A much weaker early false-positive
        # (e.g. 63 vs a true 95) still loses to the global best.
        chosen = None
        strong = [it for it in scored[:12] if it[0] >= 62]
        if strong:
            best = max(it[0] for it in strong)
            near_best = [it for it in strong if it[0] >= best - 25.0]
            near_best.sort(key=lambda it: (it[2], -it[0]))
            chosen = near_best[0]
        if chosen is None:
            # No strong match in this 180-word window. Advancing by 1 word
            # would re-score ~identically 180 times; stride 8 instead — the
            # window still overlaps heavily, so no ayah is skipped, but we do
            # 8x fewer expensive iterations through noisy regions.
            pos += 8
            continue
        combined,v,st,L,cov,miss,seq = chosen
        results.append(Match(v,combined,cov,miss,seq,pos+st,L))
        prev_global = v.global_index
        # Surah lock: once the last 3 matches are strong (>=75) and from the same
        # surah, lock future candidates to that surah. Kills wrong-surah jumps.
        # The lock releases automatically if it yields zero candidates (above).
        if len(results) >= 3:
            last3 = results[-3:]
            if len({m.verse.surah for m in last3}) == 1 and all(m.score >= 75.0 for m in last3):
                locked_surah = last3[0].verse.surah
        # Advance by the verse's own word count (n), NOT the matched window
        # length (L). L can be up to 180 words when a noisy window scores best
        # at a long length — advancing by L would skip over the ayat in
        # between. The verse occupies ~n words; the next iteration's 180-word
        # window will find what follows.
        n = len(tokens(v.normalized))
        pos = max(pos+1, pos+st+n)
    finally:
        ex.shutdown(wait=True)
    # de-dup and preserve Quran order
    uniq={m.verse.key:m for m in results}
    ordered=sorted(uniq.values(), key=lambda m:m.verse.global_index)
    return ordered


# FYP STUDY GUIDE: Inserts a SEQUENCE RECOVERY match when two strong (>=80)
# same-surah matches surround exactly one missing ayah.
# WHY: honest gap labelling - 'inferred from neighbors, ASR evidence incomplete';
# the score is capped at 82 so a recovered ayah can never become VERIFIED.
def recover_single_gap(corpus: QuranCorpus, matches: list[Match], transcript: str) -> list[Match]:
    if not matches: return []
    out=[]
    for i,m in enumerate(matches):
        out.append(m)
        if i+1 >= len(matches): continue
        nxt=matches[i+1]
        gap=nxt.verse.global_index-m.verse.global_index
        if gap == 2 and m.score >= 80 and nxt.score >= 80 and m.verse.surah == nxt.verse.surah:
            # Sequence inference: two strong matches surround exactly one
            # missing canonical ayah in the same surah. Labelled honestly as
            # SEQUENCE RECOVERY — never as a verified text match.
            middle = corpus.verses[m.verse.global_index]  # global_index is 1-based; the gap ayah is +1
            evidence = token_overlap(transcript, middle.text)
            out.append(Match(middle, min(82.0, 60+0.22*evidence), evidence, 100-evidence, 100, m.start+m.length, max(1,len(tokens(middle.text))), "SEQUENCE RECOVERY", "Inserted only because two strong adjacent matches surround exactly one missing canonical Ayah; ASR evidence is incomplete."))
    uniq={m.verse.key:m for m in out}
    return sorted(uniq.values(), key=lambda m:m.verse.global_index)
