from __future__ import annotations
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable

from .corpus import QuranCorpus, Verse
from .normalization import normalize_arabic, tokens

try:
    from rapidfuzz.fuzz import ratio as rf_ratio
except Exception:
    rf_ratio = None

@dataclass
class Match:
    verse: Verse
    score: float
    coverage: float
    missing: float
    sequence: float
    start: int
    length: int
    status: str = "MATCH"
    reason: str = ""


def similarity(a: str, b: str) -> float:
    a = normalize_arabic(a); b = normalize_arabic(b)
    if not a or not b: return 0.0
    if rf_ratio:
        return float(rf_ratio(a, b))
    return SequenceMatcher(None, a, b).ratio() * 100


def token_overlap(a: str, b: str) -> float:
    A, B = set(tokens(a)), set(tokens(b))
    if not A or not B: return 0.0
    return 100.0 * len(A & B) / max(len(A), len(B))


def coverage(a: str, b: str) -> float:
    A, B = tokens(a), set(tokens(b))
    if not A: return 0.0
    return 100.0 * sum(t in B for t in A) / len(A)


def missing(a: str, b: str) -> float:
    B = tokens(b); A = set(tokens(a))
    if not B: return 0.0
    return 100.0 * sum(t not in A for t in B) / len(B)


def best_window(text: str, verse: Verse, max_start: int = 8) -> tuple[float, int, int, float, float]:
    parts = tokens(text); n = len(tokens(verse.text))
    if not parts or not verse.normalized: return 0.0, 0, 0, 0.0, 100.0
    lengths = sorted(set([max(1,n-5), n, n+1, n+2, n+4, min(max(8,n+12), 180)]))
    best = (0.0,0,n,0.0,100.0)
    for L in lengths:
        if L <= 0 or L > len(parts): continue
        start_limit = min(max(0, len(parts)-L), max_start)
        for i in range(start_limit+1):
            win = " ".join(parts[i:i+L])
            sim = similarity(win, verse.text)
            ov = token_overlap(win, verse.text)
            cov = coverage(win, verse.text)
            miss = missing(win, verse.text)
            score = max(0.0, min(100.0, 0.52*sim + 0.28*ov + 0.25*cov - 0.12*miss))
            if score > best[0]: best = (score,i,L,cov,miss)
            if score >= 99.8: return best
    return best


def candidate_pool(corpus: QuranCorpus, text: str, cap: int = 240) -> list[Verse]:
    """Rank candidates by IDF-weighted token overlap.

    A raw count lets ultra-common words ("الله": 1,566 verses) drown out the
    distinctive ones ("الصمد": 1 verse), so short-but-distinctive ayat such
    as 112:2 were cropped out of the pool entirely and could never match.
    Weighting by inverse document frequency fixes the ranking: rare tokens
    dominate, which is exactly what identifies an ayah.
    """
    import math
    n_docs = max(1, len(corpus.verses))
    scores: dict[str,float] = {}
    for tok in set(tokens(text)):
        verses = corpus.inverted.get(tok)
        if not verses:
            continue
        idf = math.log(n_docs / len(verses))
        for v in verses:
            scores[v.key] = scores.get(v.key, 0.0) + idf
    if scores:
        ranked = sorted(scores, key=scores.get, reverse=True)[:cap]
        return [corpus.by_key[k] for k in ranked]
    # Critical fallback: never return zero candidates just because an index token was missing.
    return corpus.verses


def align_transcript(corpus: QuranCorpus, transcript: str) -> list[Match]:
    if not corpus.ready: raise RuntimeError("Quran corpus is not ready; verification is blocked.")
    t = normalize_arabic(transcript)
    if not t: return []
    words = tokens(t)
    results: list[Match] = []
    prev_global = 0
    pos = 0
    max_loops = max(len(words) + 20, 40)
    for _ in range(max_loops):
        if pos >= len(words): break
        window = " ".join(words[pos:pos+180])
        candidates = candidate_pool(corpus, window)
        scored=[]
        for v in candidates:
            s, st, L, cov, miss = best_window(window, v, max_start=8)
            if not s: continue
            distance = v.global_index - prev_global if prev_global else 1
            if prev_global and distance <= 0: continue
            seq = 100.0 if not prev_global or distance == 1 else max(30.0, 100.0 - min(70.0,(distance-1)*15.0))
            combined = 0.64*s + 0.24*cov + 0.12*seq
            scored.append((combined, v, st, L, cov, miss, seq))
        scored.sort(key=lambda x:(x[0], -x[2]), reverse=True)
        # Choose among the top candidates. Pure "highest score" can skip an
        # ayah: e.g. a stutter makes 1:3 score 100 at offset 3 while the true
        # 1:1 sits at offset 0 with 98.6 — picking 1:3 jumps over 1:1 forever.
        # Rule: among candidates within 25 points of the best, prefer the
        # leftmost (smallest start offset). A much weaker early false-positive
        # (e.g. 63 vs a true 95) still loses to the global best.
        chosen = None
        strong = [it for it in scored[:12] if it[0] >= 62]
        if strong:
            best = max(it[0] for it in strong)
            near_best = [it for it in strong if it[0] >= best - 25.0]
            near_best.sort(key=lambda it: (it[2], -it[0]))
            chosen = near_best[0]
        if chosen is None:
            pos += 1
            continue
        combined,v,st,L,cov,miss,seq = chosen
        results.append(Match(v,combined,cov,miss,seq,pos+st,L))
        prev_global = v.global_index
        pos = max(pos+1, pos+st+L)
    # de-dup and preserve Quran order
    uniq={m.verse.key:m for m in results}
    ordered=sorted(uniq.values(), key=lambda m:m.verse.global_index)
    return ordered


def recover_single_gap(corpus: QuranCorpus, matches: list[Match], transcript: str) -> list[Match]:
    if not matches: return []
    out=[]
    for i,m in enumerate(matches):
        out.append(m)
        if i+1 >= len(matches): continue
        nxt=matches[i+1]
        gap=nxt.verse.global_index-m.verse.global_index
        if gap == 2 and m.score >= 80 and nxt.score >= 80 and m.verse.surah == nxt.verse.surah:
            # Sequence inference: two strong matches surround exactly one
            # missing canonical ayah in the same surah. Labelled honestly as
            # SEQUENCE RECOVERY — never as a verified text match.
            middle = corpus.verses[m.verse.global_index]  # global_index is 1-based; the gap ayah is +1
            evidence = token_overlap(transcript, middle.text)
            out.append(Match(middle, min(82.0, 60+0.22*evidence), evidence, 100-evidence, 100, m.start+m.length, max(1,len(tokens(middle.text))), "SEQUENCE RECOVERY", "Inserted only because two strong adjacent matches surround exactly one missing canonical Ayah; ASR evidence is incomplete."))
    uniq={m.verse.key:m for m in out}
    return sorted(uniq.values(), key=lambda m:m.verse.global_index)
