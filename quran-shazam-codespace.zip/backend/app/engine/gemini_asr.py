"""Gemini second listen: an optional fallback transcriber for verify().

When the local Whisper result has zero VERIFIED ayat, the service asks
Gemini (gemini-3.8-flash) to transcribe the same audio and keeps whichever
result has more VERIFIED ayat. The local model always runs first.

Why Gemini: on the 2026-11-07 comparison (same 5 recordings, same matcher,
same thresholds) gemini-3.8-flash recovered 22/22 distinct ayat with 20
VERIFIED — including the first VERIFIED ever for the user's own Al-Fil
voice (105:1-5), where the local model scored 0/5. The dedicated
gemini-3.5-transcribe model was weaker (13/22) and Groq Whisper truncated
whole surahs, so only gemini-3.8-flash is wired as the fallback.

The key comes from the GEMINI_API_KEY environment variable and is never
logged or stored. No key means no fallback: the service behaves exactly
as before. The call uses only the standard library (urllib) so the
backend gains no new dependency.
"""
from __future__ import annotations

import base64
import io
import json
import logging
import time
import urllib.error
import urllib.request
import wave

import numpy as np

log = logging.getLogger("quran_shazam.gemini_asr")

_HOST = "generativelanguage.googleapis.com"

# Same prompt the comparison helper used: it produced the verified
# transcripts (22/22 distinct ayat). Asking for the recitation only, with
# no explanation or translation, keeps the output matchable.
_PROMPT = (
    "Transcribe this Quran recitation exactly, word for word. "
    "Output ONLY the Arabic text of the recitation, with no explanation, "
    "no translation, no headings."
)


class GeminiASRError(RuntimeError):
    """The Gemini transcription call failed in a way the caller should report."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise RuntimeError("redirect refused, verify the endpoint")


def wav_bytes_from_array(audio, sr: int) -> bytes:
    """Encode a mono float32 array (16 kHz) as 16-bit PCM WAV bytes.

    The service already decoded the audio to mono 16 kHz for the local
    model, so the fallback sends exactly the audio the local model heard.
    A 60 s clip is under 2 MB, well inside the API's inline-data limit.
    """
    pcm = np.clip(np.asarray(audio, dtype=np.float32), -1.0, 1.0)
    pcm16 = (pcm * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(int(sr))
        wav.writeframes(pcm16.tobytes())
    return buf.getvalue()


class GeminiASR:
    """Transcribe audio with a Gemini model over the generateContent API."""

    def __init__(self, api_key: str, model: str = "gemini-3.8-flash"):
        if not api_key or not api_key.strip():
            raise ValueError("GeminiASR needs a GEMINI_API_KEY")
        self._api_key = api_key.strip()
        self.model = model

    def transcribe_array(self, audio, sr: int) -> dict:
        """Transcribe a mono float32 array. Returns {"text", "seconds"}.

        Retries 429/500/502/503 twice with waits (20 s, 60 s) because the
        free tier overloads (503) under demand. Any other failure raises
        GeminiASRError so the caller can fall back to the local result.
        """
        wav_bytes = wav_bytes_from_array(audio, sr)
        data = base64.b64encode(wav_bytes).decode()
        body = json.dumps({
            "contents": [{"parts": [
                {"text": _PROMPT},
                {"inlineData": {"mimeType": "audio/wav", "data": data}},
            ]}],
        }).encode()
        url = f"https://{_HOST}/v1beta/models/{self.model}:generateContent"
        last_error: Exception | None = None
        t0 = time.perf_counter()
        for attempt, wait in enumerate([0, 20, 60]):
            if wait:
                log.info("gemini_asr retry=%d after %ds", attempt, wait)
                time.sleep(wait)
            request = urllib.request.Request(
                url, data=body, headers={"Content-Type": "application/json",
                                         "x-goog-api-key": self._api_key})
            try:
                with urllib.request.build_opener(NoRedirect()).open(
                        request, timeout=180) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                try:
                    text = payload["candidates"][0]["content"]["parts"][0]["text"].strip()
                except (KeyError, IndexError, TypeError):
                    raise GeminiASRError(
                        f"unexpected Gemini response: {json.dumps(payload)[:300]}")
                return {"text": text, "seconds": round(time.perf_counter() - t0, 1)}
            except urllib.error.HTTPError as exc:
                last_error = exc
                if exc.code in (429, 500, 502, 503) and attempt < 2:
                    continue
                raise GeminiASRError(
                    f"Gemini API HTTP {exc.code}: {exc.read().decode(errors='replace')[:200]}"
                ) from exc
            except (urllib.error.URLError, TimeoutError) as exc:
                last_error = exc
                if attempt < 2:
                    continue
                raise GeminiASRError(f"Gemini API unreachable: {exc}") from exc
        raise GeminiASRError(f"Gemini API failed: {last_error}")
