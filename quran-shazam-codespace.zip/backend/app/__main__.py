"""Allow `python -m app` from the backend/ directory."""
from .main import run

if __name__ == "__main__":
    run()
