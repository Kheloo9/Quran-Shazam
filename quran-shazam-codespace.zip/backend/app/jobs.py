"""Async verification jobs: submit -> background workers -> poll/SSE for result.

Why this exists
---------------
A full verification (FFmpeg decode + Whisper transcription on CPU + Quran
matching) takes a while. Holding a single HTTP connection open for that long
is fragile: proxies and tunnels routinely kill idle/long responses (the user
sees a 502) even though the server finished fine. It also blocks the ASGI
event loop while the synchronous CPU work runs.

Instead:
  * ``POST /api/verify`` validates the upload, stores it, and immediately
    returns ``202 {"job_id": ...}``.
  * A pool of background worker threads (``JOB_WORKERS``, default 1)
    processes jobs and records stage/progress/ETA. A page refresh never
    loses a job: ``GET /api/jobs/{job_id}`` (or the SSE stream) recovers it.
  * The browser polls ``GET /api/jobs/{job_id}`` or subscribes to
    ``GET /api/jobs/{job_id}/events`` (Server-Sent Events) — every poll is
    a short, cheap request that survives flaky networks.

Job hygiene: completed jobs are kept for ``JOB_TTL_SECONDS`` so the result
can be fetched, then evicted; the store is capped at ``JOB_MAX_COUNT``.
Uploaded temp files are always deleted once the worker finishes a job.
"""
from __future__ import annotations

import collections
import logging
import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

log = logging.getLogger("quran_shazam.jobs")

JOB_TTL_SECONDS = 30 * 60      # keep finished jobs for 30 minutes
JOB_MAX_COUNT = 100            # hard cap on stored jobs
_JOB_ID_RE = re.compile(r"^[a-f0-9]{16}$")

# Terminal states a client may stop polling on.
DONE = "done"
ERROR = "error"
CANCELLED = "cancelled"


@dataclass
# FYP STUDY GUIDE: Dataclass holding one verification job's mutable state -
# status/stage, progress %, live partial transcript, ETA, queue position,
# result or error, and the cancel flag.
# WHY: one shared object lets the web routes (poll/SSE) and the worker thread
# see the same job lifecycle - the basis of 'a page refresh never loses a job'.
class Job:
    job_id: str
    request_id: str
    tmp_path: Path
    status: str = "queued"          # queued | processing | done | error | cancelled
    stage: str = "Waiting in queue…"
    progress: float = 2.0
    partial_text: str = ""          # live transcript so far (streamed to UI)
    eta_seconds: float | None = None
    queue_position: int | None = None
    result: dict | None = None
    error: str | None = None
    cancel_requested: bool = False
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    started_at: float | None = None

    # FYP STUDY GUIDE: Refreshes updated_at to 'now'.
    # WHY: the sweeper evicts jobs idle for 30 min - touching on every poll keeps
    # a job the user is still watching alive while dead ones are reclaimed.
    def touch(self) -> None:
        self.updated_at = time.time()

    # FYP STUDY GUIDE: Updates stage text, clamps progress to 0-99, and estimates
    # ETA from the measured completion rate (elapsed vs percent done).
    # WHY: powers the live progress bar and 'time remaining' in the UI - the ETA
    # is grounded in this job's actual transcription speed, not a guess.
    def set_progress(self, stage: str, pct: float) -> None:
        self.stage = stage
        self.progress = max(0.0, min(99.0, pct))
        if self.started_at and pct > 3:
            elapsed = time.time() - self.started_at
            rate = pct / max(elapsed, 0.1)
            remaining = max(0.0, 100.0 - pct)
            self.eta_seconds = round(remaining / max(rate, 1e-6), 0)
        self.touch()

    # FYP STUDY GUIDE: Stores the tail (last 4000 chars) of the running transcript.
    # WHY: the UI streams the transcript live as Whisper works; capping the size
    # keeps every poll/SSE payload small even for hour-long recitations.
    def set_partial(self, text: str) -> None:
        # Keep the payload small: tail of the running transcript.
        self.partial_text = text[-4000:]
        self.touch()


# FYP STUDY GUIDE: Internal exception raised inside the worker when the user
# cancels a job.
# WHY: exceptions unwind deep call stacks (transcribe loop -> progress callback)
# cleanly - one raise aborts the whole pipeline without cancel checks in
# every ASR function.
class JobCancelledByUser(Exception):
    """Internal: raised inside the worker when the user cancels a job."""


# FYP STUDY GUIDE: Thread-safe job registry plus a pool of background worker
# threads that run verifications off the ASGI event loop.
# WHY: Whisper transcription is heavy synchronous CPU work - running it in the
# event loop would block every request. Background threads + 202/job_id polling
# make verification survive flaky networks and page refreshes.
class JobStore:
    """Thread-safe job registry with a pool of background workers."""

    # FYP STUDY GUIDE: Builds the registry, queue, lock, and spawns the worker
    # threads (JOB_WORKERS, default 1).
    # WHY: 1 worker is safest on small free-tier machines where the 74M model
    # already fills RAM; bigger hardware can raise JOB_WORKERS for concurrent jobs.
    def __init__(self, verify_fn: Callable[..., dict], workers: int = 1):
        """
        verify_fn: callable ``(tmp_path, request_id, progress, on_partial) -> dict``.
        """
        self._verify_fn = verify_fn
        self._jobs: dict[str, Job] = {}
        self._queue: queue.Queue[str] = queue.Queue()
        self._queued_order: collections.deque[str] = collections.deque()
        self._lock = threading.Lock()
        self._workers: list[threading.Thread] = []
        for i in range(max(1, workers)):
            t = threading.Thread(target=self._worker_loop,
                                 name=f"qs-job-worker-{i}", daemon=True)
            t.start()
            self._workers.append(t)
        log.info("job_store_init workers=%d", len(self._workers))

    # ------------------------------------------------------------ public
    # FYP STUDY GUIDE: Creates a Job with a random 16-hex id, registers it, sweeps
    # expired jobs, and queues it for a worker; returns the id immediately.
    # WHY: the HTTP request returns 202 at once instead of waiting minutes; the
    # sweep on submit bounds memory so finished jobs can't accumulate forever.
    def submit(self, tmp_path: Path, request_id: str) -> str:
        job_id = uuid.uuid4().hex[:16]
        job = Job(job_id=job_id, request_id=request_id, tmp_path=tmp_path)
        with self._lock:
            self._sweep_locked()
            self._jobs[job_id] = job
            self._queued_order.append(job_id)
            self._refresh_positions_locked()
        self._queue.put(job_id)
        log.info("req=%s job=%s submitted", request_id, job_id)
        return job_id

    # FYP STUDY GUIDE: Looks up a job by id; rejects malformed ids with a regex,
    # and touches jobs that are found.
    # WHY: regex validation blocks crafted-id probing; touching refreshes the TTL
    # so a job the UI is actively polling is never evicted mid-watch.
    def get(self, job_id: str) -> Job | None:
        if not _JOB_ID_RE.match(job_id or ""):
            return None
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.touch()
            return job

    # FYP STUDY GUIDE: Flags a job cancelled - queued jobs die instantly (and their
    # temp upload file is deleted here), processing jobs abort at the next
    # progress check.
    # WHY: deleting the queued job's file at cancel time fixed a real 2026-10-22
    # disk-exhaustion bug (cancelled jobs used to leak up to 200MB each) -
    # cleanup ownership can't fall through cracks.
    def cancel(self, job_id: str) -> bool:
        """Cancel a queued or running job. Returns False if unknown/finished."""
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.status in (DONE, ERROR, CANCELLED):
                return False
            job.cancel_requested = True
            if job.status == "queued":
                try:
                    self._queued_order.remove(job_id)
                except ValueError:
                    pass
                # Drain it from the queue; the worker skips cancelled jobs.
                job.status = CANCELLED
                job.stage = "Cancelled"
                job.touch()
                # FYP STUDY GUIDE: the cancelled-job temp-file bug (fixed 2026-10-22)
                # - Symptom: every cancelled-while-queued job left its uploaded
                #   audio file on disk forever (up to 200 MB each) — a slow
                #   disk-exhaustion leak an attacker could trigger with
                #   upload -> DELETE /api/jobs/{id} loops.
                # - Root cause: the upload's temp file is deleted in _process()'s
                #   finally block — but a queued job that gets cancelled never
                #   reaches _process(), so nobody ever deleted its file.
                # - Fix: delete the temp file HERE, at the exact moment the
                #   job dies, so ownership of cleanup can't fall through cracks.
                try:
                    job.tmp_path.unlink(missing_ok=True)
                except OSError:
                    log.warning("req=%s job=%s cancelled tmp cleanup failed",
                                job.request_id, job_id)
                self._refresh_positions_locked()
                log.info("req=%s job=%s cancelled while queued", job.request_id, job_id)
            else:
                log.info("req=%s job=%s cancel requested (processing)", job.request_id, job_id)
            return True

    # FYP STUDY GUIDE: Returns stored/queued/worker counts grouped by job status.
    # WHY: feeds /api/diagnostics so ops can see queue pressure (e.g. 40 queued on
    # 1 worker explains slow jobs) without exposing any user data.
    def stats(self) -> dict:
        with self._lock:
            counts: dict[str, int] = {}
            for j in self._jobs.values():
                counts[j.status] = counts.get(j.status, 0) + 1
            return {"stored": len(self._jobs), "queued": self._queue.qsize(),
                    "workers": len(self._workers), "by_status": counts}

    # ---------------------------------------------------------- internal
    # FYP STUDY GUIDE: Recomputes queue_position (1..n) for every queued job.
    # WHY: lets the UI say 'You are #3 in the queue' instead of a frozen spinner -
    # visible fairness reduces perceived wait time.
    def _refresh_positions_locked(self) -> None:
        for i, jid in enumerate(self._queued_order):
            job = self._jobs.get(jid)
            if job is not None and job.status == "queued":
                job.queue_position = i + 1

    # FYP STUDY GUIDE: Deletes jobs older than JOB_TTL_SECONDS (30 min) and enforces
    # the 100-job cap - never dropping live (queued/processing) work.
    # WHY: results must stay fetchable after finishing (the user may refresh), but
    # unbounded storage leaks RAM on a free-tier server; finished results are
    # disposable after 30 minutes.
    def _sweep_locked(self) -> None:
        """Evict expired jobs and enforce the hard cap. Caller holds _lock."""
        now = time.time()
        expired = [jid for jid, j in self._jobs.items()
                   if j.status in (DONE, ERROR, CANCELLED) and now - j.updated_at > JOB_TTL_SECONDS]
        for jid in expired:
            del self._jobs[jid]
        if len(self._jobs) > JOB_MAX_COUNT:
            ordered = sorted(self._jobs.values(),
                             key=lambda j: (j.status not in (DONE, ERROR, CANCELLED), j.updated_at))
            for j in ordered[: len(self._jobs) - JOB_MAX_COUNT]:
                if j.status in ("queued", "processing"):
                    continue  # never drop live work; cap is soft in that case
                del self._jobs[j.job_id]

    # FYP STUDY GUIDE: Infinite per-thread loop: take a job id from the queue, skip
    # cancelled/gone jobs, hand the rest to _process(); one try/except guards it all.
    # WHY: a worker thread must never die - without the guard, a single crashed job
    # would silently kill the pipeline for every job behind it.
    def _worker_loop(self) -> None:
        while True:
            job_id = self._queue.get()
            try:
                with self._lock:
                    job = self._jobs.get(job_id)
                    if job is None or job.status == CANCELLED:
                        continue
                    try:
                        self._queued_order.remove(job_id)
                    except ValueError:
                        pass
                    self._refresh_positions_locked()
                self._process(job)
            except Exception:  # never let a worker thread die
                log.exception("job worker loop error")
            finally:
                self._queue.task_done()

    # FYP STUDY GUIDE: Runs the verify function for one job with progress/cancel
    # callbacks, records done/error/cancelled, and ALWAYS deletes the temp upload.
    # WHY: centralizes the lifecycle - cancellation becomes JobCancelledByUser,
    # unexpected errors become client-safe messages (no stack traces), and the
    # finally-block guarantees temp files never leak to disk.
    def _process(self, job: Job) -> None:
        job.status = "processing"
        job.queue_position = None
        job.started_at = time.time()
        job.set_progress("Starting verification…", 4)
        log.info("req=%s job=%s processing", job.request_id, job.job_id)

        # FYP STUDY GUIDE: Per-job progress callback handed to the verify function;
        # raises JobCancelledByUser the moment the user cancels.
        # WHY: this is how cancellation crosses from the web layer into the ASR loop -
        # each chunk's progress check aborts promptly instead of wasting minutes
        # transcribing an upload nobody wants anymore.
        def progress(stage: str, pct: float) -> None:
            if job.cancel_requested:
                raise JobCancelledByUser()
            job.set_progress(stage, pct)

        try:
            result = self._verify_fn(
                job.tmp_path,
                request_id=job.request_id,
                progress=progress,
                on_partial=job.set_partial,
            )
        except JobCancelledByUser:
            job.status = CANCELLED
            job.stage = "Cancelled"
            job.error = None
            log.info("req=%s job=%s cancelled by user", job.request_id, job.job_id)
        except (RuntimeError, ValueError) as exc:
            job.error = str(exc)
            job.status = ERROR
            log.warning("req=%s job=%s failed: %s", job.request_id, job.job_id, str(exc)[:200])
        except Exception:
            log.exception("req=%s job=%s crashed", job.request_id, job.job_id)
            job.error = "An unexpected error occurred during verification. Please try again."
            job.status = ERROR
        else:
            job.result = result
            job.status = DONE
            job.progress = 100.0
            job.eta_seconds = 0
            job.stage = "Done"
            log.info("req=%s job=%s done results=%d", job.request_id, job.job_id,
                     len((result or {}).get("results", [])))
        finally:
            try:
                job.tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
            job.touch()
