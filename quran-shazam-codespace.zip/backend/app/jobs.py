"""Async verification jobs: submit -> background worker -> poll for result.

Why this exists
---------------
A full verification (FFmpeg decode + Whisper transcription on CPU + Quran
matching) takes minutes. Holding a single HTTP connection open for that long
is fragile: proxies and tunnels routinely kill idle/long responses (the user
sees a 502) even though the server finished fine. It also blocks the ASGI
event loop for every other request while the synchronous CPU work runs.

Instead:
  * ``POST /api/verify`` validates the upload, stores it, and immediately
    returns ``202 {"job_id": ...}``.
  * A dedicated worker thread processes jobs strictly one at a time (the ASR
    pipeline is not thread-safe) and records stage/progress.
  * The browser polls ``GET /api/jobs/{job_id}`` — every poll is a short,
    cheap request that survives flaky networks; a failed poll is simply
    retried while the job keeps running server-side.

Job hygiene: completed jobs are kept for ``JOB_TTL_SECONDS`` so the result
can be fetched, then evicted; the store is capped at ``JOB_MAX_COUNT``.
Uploaded temp files are always deleted once the worker finishes a job.
"""
from __future__ import annotations

import logging
import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

log = logging.getLogger("quran_shazam.jobs")

JOB_TTL_SECONDS = 30 * 60      # keep finished jobs for 30 minutes
JOB_MAX_COUNT = 100            # hard cap on stored jobs
_JOB_ID_RE = re.compile(r"^[a-f0-9]{16}$")

# Terminal states a client may stop polling on.
DONE = "done"
ERROR = "error"


@dataclass
class Job:
    job_id: str
    request_id: str
    tmp_path: Path
    status: str = "queued"          # queued | processing | done | error
    stage: str = "Waiting in queue…"
    progress: float = 2.0
    result: dict | None = None
    error: str | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def touch(self) -> None:
        self.updated_at = time.time()

    def set_progress(self, stage: str, pct: float) -> None:
        self.stage = stage
        self.progress = max(0.0, min(99.0, pct))
        self.touch()


class JobStore:
    """Thread-safe job registry with a single background worker."""

    def __init__(self, verify_fn: Callable[..., dict]):
        """
        verify_fn: callable ``(tmp_path: Path, request_id: str,
                   progress: Callable[[str, float], None]) -> dict``.
        """
        self._verify_fn = verify_fn
        self._jobs: dict[str, Job] = {}
        self._queue: queue.Queue[str] = queue.Queue()
        self._lock = threading.Lock()
        self._worker = threading.Thread(
            target=self._worker_loop, name="qs-job-worker", daemon=True
        )
        self._worker.start()

    # ------------------------------------------------------------ public
    def submit(self, tmp_path: Path, request_id: str) -> str:
        job_id = uuid.uuid4().hex[:16]
        job = Job(job_id=job_id, request_id=request_id, tmp_path=tmp_path)
        with self._lock:
            self._sweep_locked()
            self._jobs[job_id] = job
        self._queue.put(job_id)
        log.info("req=%s job=%s submitted", request_id, job_id)
        return job_id

    def get(self, job_id: str) -> Job | None:
        if not _JOB_ID_RE.match(job_id or ""):
            return None
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None:
                job.touch()
            return job

    def stats(self) -> dict:
        with self._lock:
            counts: dict[str, int] = {}
            for j in self._jobs.values():
                counts[j.status] = counts.get(j.status, 0) + 1
            return {"stored": len(self._jobs), "queued": self._queue.qsize(),
                    "by_status": counts}

    # ---------------------------------------------------------- internal
    def _sweep_locked(self) -> None:
        """Evict expired jobs and enforce the hard cap. Caller holds _lock."""
        now = time.time()
        expired = [jid for jid, j in self._jobs.items()
                   if j.status in (DONE, ERROR) and now - j.updated_at > JOB_TTL_SECONDS]
        for jid in expired:
            del self._jobs[jid]
        if len(self._jobs) > JOB_MAX_COUNT:
            # Evict oldest finished jobs first, then oldest overall.
            ordered = sorted(self._jobs.values(), key=lambda j: (j.status not in (DONE, ERROR), j.updated_at))
            for j in ordered[: len(self._jobs) - JOB_MAX_COUNT]:
                if j.status in ("queued", "processing"):
                    continue  # never drop live work; cap is soft in that case
                del self._jobs[j.job_id]

    def _worker_loop(self) -> None:
        while True:
            job_id = self._queue.get()
            try:
                with self._lock:
                    job = self._jobs.get(job_id)
                if job is None:
                    continue
                self._process(job)
            except Exception:  # never let the worker thread die
                log.exception("job worker loop error")
            finally:
                self._queue.task_done()

    def _process(self, job: Job) -> None:
        job.status = "processing"
        job.set_progress("Starting verification…", 4)
        log.info("req=%s job=%s processing", job.request_id, job.job_id)
        try:
            result = self._verify_fn(
                job.tmp_path,
                request_id=job.request_id,
                progress=job.set_progress,
            )
        except (RuntimeError, ValueError) as exc:
            # Expected failure modes (bad audio, no transcript): client-safe.
            job.error = str(exc)
            job.status = ERROR
            log.warning("req=%s job=%s failed: %s", job.request_id, job.job_id, str(exc)[:200])
        except Exception:
            log.exception("req=%s job=%s crashed", job.request_id, job.job_id)
            job.error = "An unexpected error occurred during verification. Please try again."
            job.status = ERROR
        else:
            job.result = result
            job.status = DONE
            job.progress = 100.0
            job.stage = "Done"
            log.info("req=%s job=%s done results=%d", job.request_id, job.job_id,
                     len((result or {}).get("results", [])))
        finally:
            try:
                job.tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
            job.touch()
