"""Quran Shazam — production web service.

Run:
    python -m app              # from the backend/ directory
    # or: uvicorn app.main:app --host 0.0.0.0 --port 8000

Request flow (async jobs — v2.1+):
  * POST /api/verify  validates the upload, stores it, and immediately
    returns 202 {"job_id": ...}. A full verification takes minutes; holding
    one HTTP connection open that long is fragile behind proxies/tunnels
    (the client sees a 502 even though the server finished fine) and the
    synchronous CPU work would block the event loop for everyone else.
  * A dedicated worker thread processes jobs one at a time and records
    stage/progress.
  * GET /api/jobs/{job_id} is polled by the browser — short, cheap requests
    that survive flaky networks; a failed poll is retried while the job
    keeps running server-side.

Security posture (see also SECURITY.md and app/security.py):
  * Fail-closed verification: jobs are refused unless the canonical Quran
    corpus (6,236 ayat / 114 surahs) is healthy.
  * Uploads: extension allow-list, magic-byte sniffing, streaming byte cap,
    uuid temp names, guaranteed cleanup, FFmpeg as authoritative validator.
  * Rate limiting on expensive endpoints; optional API key via API_KEY.
  * Security headers, request ids, no stack traces or internal paths in
    client-facing errors; /docs disabled in production.
"""
from __future__ import annotations

import logging
import sys
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Request, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from slowapi.errors import RateLimitExceeded

from .engine.config import settings
from .engine.service import VerificationService
from .jobs import JobStore
from .security import (
    RequestIdMiddleware,
    SecurityHeadersMiddleware,
    check_signature_or_raise,
    limiter,
    peek_signature,
    require_api_key,
    safe_temp_path,
    validate_upload,
)

# ------------------------------------------------------------------ logging
logging.basicConfig(
    level=settings.log_level,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("quran_shazam")

BASE = Path(__file__).resolve().parents[1]          # backend/
DATA_DIR = BASE / "data"

# ------------------------------------------------------------------ service
# The heavy service (corpus + AI model) is built once in a background thread
# at startup so the first user never pays the cold-start cost mid-request.
# Importing this module stays cheap: fast boot, cheap --help, and unit tests
# that stub the engine.
_service: VerificationService | None = None
_service_error: str | None = None
_service_lock = threading.Lock()


def _warmup() -> None:
    """Build the service and preload the ASR model. Runs in a daemon thread."""
    global _service, _service_error
    try:
        svc = VerificationService(DATA_DIR)
        if svc.corpus.ready:
            # Preload the transcription model now (downloads on first deploy)
            # instead of making the first verification request wait for it.
            svc.asr._load()
            log.info("warmup_ok asr_device=%s", svc.asr.device)
        else:
            log.error("warmup corpus not ready: %s", svc.startup_error)
    except Exception as exc:  # fail-closed: recorded, surfaced via /api/health
        _service_error = str(exc)[:300]
        log.error("warmup_failed error=%r", _service_error)
        return
    with _service_lock:
        _service = svc


def get_service() -> VerificationService | None:
    """Return the warmed-up service, or None while it is still starting."""
    with _service_lock:
        return _service


def _run_verification(tmp_path: Path, request_id: str, progress) -> dict:
    """Adapter so the job worker resolves the (possibly stubbed) service lazily."""
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise RuntimeError(
            "The verification engine is still warming up. Please try again in a minute."
        )
    return svc.verify(tmp_path, request_id=request_id, progress=progress)


_jobs = JobStore(_run_verification)


@asynccontextmanager
async def lifespan(app: FastAPI):
    thread = threading.Thread(target=_warmup, name="qs-warmup", daemon=True)
    thread.start()
    log.info("startup warmup thread launched")
    yield
    # daemon threads (warmup, job worker) exit with the process; nothing to join.


app = FastAPI(
    title="Quran Shazam",
    description="Identify Quranic recitation from audio/video with a text-evidence verification engine.",
    version="2.1.0",
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None if settings.is_production else "/redoc",
    openapi_url=None if settings.is_production else "/openapi.json",
    lifespan=lifespan,
)
app.state.limiter = limiter

# ------------------------------------------------------------- middleware
app.add_middleware(RequestIdMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=list(settings.trusted_hosts),
)
if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "X-API-Key"],
        max_age=600,
    )

# ------------------------------------------------------------ static/pages
app.mount("/static", StaticFiles(directory=str(BASE / "app" / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "app" / "templates"))


def _page(request: Request, name: str) -> HTMLResponse:
    """Render a template across Starlette versions.

    Starlette >= 0.37: TemplateResponse(request, name, context).
    Older:             TemplateResponse(name, {"request": request}).
    """
    context = {"active_page": request.url.path}
    try:
        return templates.TemplateResponse(request, name, context)
    except TypeError:
        return templates.TemplateResponse(name, {"request": request, **context})


@app.exception_handler(RateLimitExceeded)
async def _rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=429,
        content={"detail": "Too many requests. Please slow down and try again shortly.",
                 "request_id": getattr(request.state, "request_id", "-")},
    )


@app.exception_handler(Exception)
async def _unhandled_handler(request: Request, exc: Exception) -> JSONResponse:
    # Never leak stack traces, file paths or model internals to clients.
    request_id = getattr(request.state, "request_id", "-")
    log.exception("req=%s unhandled_error path=%s", request_id, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again.",
                 "request_id": request_id},
    )


# ------------------------------------------------------------------ pages
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return _page(request, "index.html")


@app.get("/verify", response_class=HTMLResponse)
async def verify_page(request: Request):
    return _page(request, "verify.html")


@app.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    return _page(request, "about.html")


@app.get("/security", response_class=HTMLResponse)
async def security_page(request: Request):
    return _page(request, "security.html")


# -------------------------------------------------------------------- api
@app.get("/api/health")
async def health():
    """Liveness/readiness probe. Safe to expose; reveals no secrets.

    Returns immediately even while the engine warms up — it never blocks.
    """
    svc = get_service()
    if svc is None:
        return {
            "ready": False,
            "warming_up": True,
            "corpus": {"ready": False, "checks": []},
            "asr_model": settings.asr_model,
            "asr_loaded": False,
            "error": _service_error,
        }
    return svc.health()


@app.get("/api/diagnostics", dependencies=[Depends(require_api_key)])
async def diagnostics():
    svc = get_service()
    diag = svc.diagnostics() if svc else {"ready": False, "warming_up": True}
    diag["jobs"] = _jobs.stats()
    return diag


@app.post("/api/verify", dependencies=[Depends(require_api_key)], status_code=202)
@limiter.limit(settings.rate_limit_verify)
async def verify(request: Request, file: UploadFile = File(...)):
    """Accept an upload and queue a verification job.

    Returns 202 {"job_id": ...} immediately. Poll GET /api/jobs/{job_id}
    for stage/progress and the final result. Upload validation failures
    (415/413/400) are still answered synchronously.
    """
    request_id = getattr(request.state, "request_id", "-")
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise HTTPException(
            status_code=503,
            detail="The verification engine is warming up. Please try again in a minute.",
        )
    ext = validate_upload(file)
    head = await peek_signature(file)
    check_signature_or_raise(head)

    tmp = safe_temp_path(DATA_DIR, ext)
    max_bytes = settings.max_upload_mb * 1024 * 1024
    size = 0
    try:
        with tmp.open("wb") as out:
            while True:
                chunk = await file.read(4 * 1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Upload exceeds the {settings.max_upload_mb} MB limit.",
                    )
                out.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="The uploaded file is empty.")
        log.info("req=%s upload_ok bytes=%d ext=%s", request_id, size, ext)
        # Ownership of tmp passes to the job; the worker deletes it when done.
        job_id = _jobs.submit(tmp, request_id)
        return {"job_id": job_id, "status": "queued", "request_id": request_id}
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


@app.get("/api/jobs/{job_id}", dependencies=[Depends(require_api_key)])
async def job_status(job_id: str):
    """Poll a verification job. Short, cheap, safe to retry on network blips."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(
            status_code=404,
            detail="Unknown or expired verification. Please upload your audio again.",
        )
    payload = {
        "job_id": job.job_id,
        "status": job.status,
        "stage": job.stage,
        "progress": round(job.progress, 1),
        "request_id": job.request_id,
    }
    if job.status == "done":
        payload["result"] = job.result
    elif job.status == "error":
        payload["error"] = job.error
    return payload


# ------------------------------------------------------------------- run
def run() -> None:
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(__import__("os").getenv("PORT", "8000")),
        workers=1,  # keep 1: the ASR model is heavy; scale with containers instead
        proxy_headers=settings.proxy_headers,
        forwarded_allow_ips="*" if settings.proxy_headers else "127.0.0.1",
        access_log=True,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    run()
