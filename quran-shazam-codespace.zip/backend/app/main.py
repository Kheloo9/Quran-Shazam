"""Quran Shazam — production web service.

Run:
    python -m app              # from the backend/ directory
    # or: uvicorn app.main:app --host 0.0.0.0 --port 8000

Request flow (async jobs — v2.1+):
  * POST /api/verify  validates the upload, stores it, and immediately
    returns 202 {"job_id": ...}. A full verification takes minutes; holding
    one HTTP connection open that long is fragile behind proxies/tunnels
    (the client sees a 502 even though the server finished fine) and the
    synchronous CPU work would block the event loop for everyone else.
  * A dedicated worker thread processes jobs one at a time and records
    stage/progress.
  * GET /api/jobs/{job_id} is polled by the browser — short, cheap requests
    that survive flaky networks; a failed poll is retried while the job
    keeps running server-side.

Security posture (see also SECURITY.md and app/security.py):
  * Fail-closed verification: jobs are refused unless the canonical Quran
    corpus (6,236 ayat / 114 surahs) is healthy.
  * Uploads: extension allow-list, magic-byte sniffing, streaming byte cap,
    uuid temp names, guaranteed cleanup, FFmpeg as authoritative validator.
  * Rate limiting on expensive endpoints; optional API key via API_KEY.
  * Security headers, request ids, no stack traces or internal paths in
    client-facing errors; /docs disabled in production.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sys
import threading
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from slowapi.errors import RateLimitExceeded

from .engine.config import settings
from .engine.coach import word_practice_match
from .engine.duas import DUAS
from .engine.export import EXPORTERS, MEDIA_TYPES
from .engine.media import MediaError, decode_to_mono16k_with_quality
from .engine.normalization import normalize_arabic
from .engine.quran_reader import QuranReader
from .engine.service import VerificationService
from .jobs import JobStore
from .security import (
    PerfBudgetMiddleware,
    RequestIdMiddleware,
    SecurityHeadersMiddleware,
    check_signature_or_raise,
    limiter,
    peek_signature,
    require_api_key,
    safe_temp_path,
    validate_upload,
)

# ------------------------------------------------------------------ logging
logging.basicConfig(
    level=settings.log_level,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("quran_shazam")

BASE = Path(__file__).resolve().parents[1]          # backend/
DATA_DIR = BASE / "data"

# ------------------------------------------------------------------ service
# The heavy service (corpus + AI model) is built once in a background thread
# at startup so the first user never pays the cold-start cost mid-request.
# Importing this module stays cheap: fast boot, cheap --help, and unit tests
# that stub the engine.
_service: VerificationService | None = None
_service_error: str | None = None
_service_lock = threading.Lock()


# FYP STUDY GUIDE: Builds VerificationService (corpus + ASR model) in a daemon
# thread at startup; records failures in _service_error instead of crashing.
# WHY: the first model load takes 2-4 minutes - warming up in the background
# means the first user never pays that cold-start cost mid-request, and
# /api/health surfaces the failure (fail-closed) instead of hanging.
def _warmup() -> None:
    """Build the service and preload the ASR model. Runs in a daemon thread."""
    global _service, _service_error
    try:
        svc = VerificationService(DATA_DIR)
        if svc.corpus.ready:
            # Preload the transcription model now (downloads on first deploy)
            # instead of making the first verification request wait for it.
            svc.asr._load()
            log.info("warmup_ok asr_device=%s", svc.asr.device)
        else:
            log.error("warmup corpus not ready: %s", svc.startup_error)
    except Exception as exc:  # fail-closed: recorded, surfaced via /api/health
        _service_error = str(exc)[:300]
        log.error("warmup_failed error=%r", _service_error)
        return
    with _service_lock:
        _service = svc


# FYP STUDY GUIDE: Thread-safe getter returning the warmed-up service, or None
# while it is still warming up.
# WHY: routes must answer 503 ('warming up') gracefully during the load window;
# the lock guarantees no route ever sees a half-constructed service.
def get_service() -> VerificationService | None:
    """Return the warmed-up service, or None while it is still starting."""
    with _service_lock:
        return _service


# FYP STUDY GUIDE: Adapter the JobStore calls - resolves the (possibly
# test-stubbed) service lazily, then runs svc.verify(...).
# WHY: lazy resolution keeps module import cheap (fast --help, cheap unit tests
# that stub the engine) while the real app gets the warmed-up service.
def _run_verification(tmp_path: Path, request_id: str, progress,
                      on_partial=None) -> dict:
    """Adapter so the job worker resolves the (possibly stubbed) service lazily."""
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise RuntimeError(
            "The verification engine is still warming up. Please try again in a minute."
        )
    return svc.verify(tmp_path, request_id=request_id, progress=progress,
                      on_partial=on_partial)


_jobs = JobStore(_run_verification, workers=settings.job_workers)

# ------------------------------------------------------------ quran reader
# The full Quran reader (Arabic + EN/UR translations + tafseer). Built lazily
# from the warmed-up corpus so startup stays fast.
_reader: QuranReader | None = None


# FYP STUDY GUIDE: Builds the QuranReader once, lazily, reusing the warmed-up
# corpus.
# WHY: translations + tafseer JSON are heavy - building once on first use keeps
# startup fast and avoids loading data that no request may ever need.
def get_reader() -> QuranReader | None:
    global _reader
    if _reader is None:
        svc = get_service()
        if svc is not None and svc.corpus.ready:
            _reader = QuranReader(DATA_DIR, svc.corpus)
    return _reader


@asynccontextmanager
# FYP STUDY GUIDE: FastAPI lifespan - launches the warmup thread on startup;
# daemon threads exit with the process, so nothing needs joining.
# WHY: model loading must not block the server binding its port (health checks
# need an instant answer); daemon threads keep shutdown simple and safe.
async def lifespan(app: FastAPI):
    thread = threading.Thread(target=_warmup, name="qs-warmup", daemon=True)
    thread.start()
    log.info("startup warmup thread launched")
    yield
    # daemon threads (warmup, job worker) exit with the process; nothing to join.


app = FastAPI(
    title="Quran Shazam",
    description="Identify Quranic recitation from audio/video with a text-evidence verification engine.",
    version="2.1.0",
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None if settings.is_production else "/redoc",
    openapi_url=None if settings.is_production else "/openapi.json",
    lifespan=lifespan,
)
app.state.limiter = limiter

# ------------------------------------------------------------- middleware
app.add_middleware(PerfBudgetMiddleware)
app.add_middleware(RequestIdMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=list(settings.trusted_hosts),
)
if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "X-API-Key"],
        max_age=600,
    )

# ------------------------------------------------------------ static/pages
app.mount("/static", StaticFiles(directory=str(BASE / "app" / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "app" / "templates"))

# TEAM 11 (2026-10-19): automatic JS cache-busting. The client's phone kept
# serving STALE cached quran.js after deploys (no ?v= on script tags), so
# fixes appeared "not working". asset_v = max mtime of the JS bundle, so
# every deploy with changed JS automatically invalidates phone caches.
# FYP STUDY GUIDE: JS cache-busting version = max mtime of the static JS bundle.
# WHY: real 2026-10-19 bug - phones kept serving STALE cached quran.js after
# deploys, so fixes looked 'not working'. Any deploy with changed JS now
# automatically invalidates phone caches via ?v=.
def _asset_version() -> str:
    try:
        js_dir = BASE / "app" / "static" / "js"
        mtimes = [p.stat().st_mtime for p in js_dir.glob("*.js")]
        return str(int(max(mtimes))) if mtimes else "1"
    except Exception:
        return "1"


# FYP STUDY GUIDE: Renders a Jinja template, handling the Starlette >= 0.37
# TemplateResponse argument-order change (with fallback for older versions).
# WHY: without this compat shim the app crashes on some Starlette versions
# with 'TypeError: unhashable type: dict'; every page route funnels through it.
def _page(request: Request, name: str) -> HTMLResponse:
    """Render a template across Starlette versions.

    Starlette >= 0.37: TemplateResponse(request, name, context).
    Older:             TemplateResponse(name, {"request": request}).
    """
    context = {"active_page": request.url.path, "asset_v": _asset_version()}
    try:
        return templates.TemplateResponse(request, name, context)
    except TypeError:
        return templates.TemplateResponse(name, {"request": request, **context})


@app.exception_handler(RateLimitExceeded)
# FYP STUDY GUIDE: Converts slowapi's RateLimitExceeded into a friendly JSON 429
# carrying the request_id.
# WHY: the UI and API clients expect JSON, not slowapi's default plain-text
# error; the request id lets the user reference the event in a support message.
async def _rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=429,
        content={"detail": "Too many requests. Please slow down and try again shortly.",
                 "request_id": getattr(request.state, "request_id", "-")},
    )


@app.exception_handler(Exception)
# FYP STUDY GUIDE: Global exception handler - logs the full error server-side,
# returns a generic 500 to the client.
# WHY: stack traces, file paths, and model internals must never leak to clients
# (security); full detail stays in the logs where engineers can debug it.
async def _unhandled_handler(request: Request, exc: Exception) -> JSONResponse:
    # Never leak stack traces, file paths or model internals to clients.
    request_id = getattr(request.state, "request_id", "-")
    log.exception("req=%s unhandled_error path=%s", request_id, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again.",
                 "request_id": request_id},
    )


# ------------------------------------------------------------------ pages
@app.get("/", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves the landing page (index.html) - hero + feature overview.
# WHY: the entry point that explains what Quran Shazam does; rendered through
# _page() so template-version compatibility is handled in exactly one place.
async def home(request: Request):
    return _page(request, "index.html")


@app.get("/verify", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves verify.html - the upload/record UI with live job
# progress (poll/SSE) and results.
# WHY: this is the core product screen (audio in -> verdict out); all heavy work
# behind it runs as async jobs so the page stays responsive.
async def verify_page(request: Request):
    return _page(request, "verify.html")


@app.get("/about", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves about.html - how the 4-stage pipeline and the honest
# labelling policy work.
# WHY: transparency page for users and viva examiners - it documents what the
# engine claims (text evidence only) and what it never claims.
async def about(request: Request):
    return _page(request, "about.html")


@app.get("/security", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves security.html - privacy and security promises
# (what is stored, upload limits, rate limits).
# WHY: users upload personal recitations; stating the guarantees up front
# (results expire in 30 min, audio deleted after verification) builds trust.
async def security_page(request: Request):
    return _page(request, "security.html")


@app.get("/quran", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves quran.html - the Quran Reader UI (Arabic + EN/UR
# translations, on-demand tafseer).
# WHY: the reader is the app's second pillar (study, not just verify); heavy
# tafseer arrives per-ayah via API so the page itself loads fast on mobile.
async def quran_page(request: Request):
    return _page(request, "quran.html")


@app.get("/duas", response_class=HTMLResponse)
# FYP STUDY GUIDE: Serves duas.html with the masnoon dua collection rendered
# server-side (Starlette-version-safe, like _page()).
# WHY: duas are static reference content - server-rendering avoids an extra API
# round trip on mobile; it injects the DUAS list into the template context
# directly instead of going through _page().
async def duas_page(request: Request):
    """Masnoon duas collection."""
    # FYP STUDY GUIDE: Starlette >= 0.37 changed TemplateResponse arg order
    # from (name, context) to (request, name, context). The _page() helper
    # handles both; this route must use the same pattern or it crashes with
    # "TypeError: unhashable type: 'dict'" (the context dict becomes the
    # template name in Jinja2's cache key).
    context = {"active_page": "/duas", "duas": DUAS, "asset_v": _asset_version()}
    try:
        return templates.TemplateResponse(request, "duas.html", context)
    except TypeError:
        return templates.TemplateResponse("duas.html", {"request": request, **context})


@app.get("/api/duas")
# FYP STUDY GUIDE: Returns the masnoon dua collection as JSON (count + list).
# WHY: the HTML page existed but API consumers and tests had no JSON route -
# added after 200-user testing exposed the gap.
async def list_duas():
    """Masnoon duas as JSON (for API consumers and testing).

    Professional: the /duas HTML page existed but there was no JSON API.
    Added 2026-10-18 after 200-user testing found the gap.
    """
    return {"count": len(DUAS), "duas": DUAS}


# ------------------------------------------------------- quran reader api
@app.get("/api/quran/surahs")
# FYP STUDY GUIDE: Lists all 114 surahs with metadata (names, ayah counts,
# Makki/Madani).
# WHY: powers the reader's surah index; answers 503 while warming up instead
# of serving partial data - never a half-loaded Quran.
async def quran_surahs():
    """List all 114 surahs with metadata."""
    reader = get_reader()
    if reader is None:
        raise HTTPException(status_code=503, detail="Quran reader is warming up.")
    return {"surahs": reader.surah_list()}


@app.get("/api/quran/surah/{n}")
# FYP STUDY GUIDE: Full surah - Arabic + EN/UR translations per ayah, with
# has_tafseer flags instead of the tafseer text itself.
# WHY: tafseer is 13KB+/ayah; bundling it made Al-Baqarah's JSON several MB.
# Flags enable the tap-to-load design - the surah opens in ~0.3s on mobile.
async def quran_surah(n: int):
    """Full surah: Arabic + English/Urdu translations (tafseer on-demand)."""
    reader = get_reader()
    if reader is None:
        raise HTTPException(status_code=503, detail="Quran reader is warming up.")
    data = reader.get_surah(n)
    if data is None:
        raise HTTPException(status_code=404, detail="Surah not found (1-114).")
    return data


@app.get("/api/quran/tafseer/{surah}/{ayah}")
# FYP STUDY GUIDE: EN (Ibn Kathir) + UR (Bayan-ul-Quran) tafseer for ONE ayah,
# on demand, validated against the surah's real ayah count.
# WHY: the lazy-load fix (2026-10-18) - users download tafseer only for ayat
# they open; per-surah validation returns 400 'invalid ayah' (not a confusing
# 404) for e.g. 99/99.
async def quran_tafseer(surah: int, ayah: int):
    """Fetch tafseer (EN + UR) for a single ayah, on-demand.

    Professional: tafseer is large (13KB+/ayah). Loading it for all ayat
    at once makes surah pages slow. This endpoint fetches it only when
    the user taps "Tafseer parhein" on a specific ayah.

    FYP STUDY GUIDE: The slow-surah fix (fixed 2026-10-18)
    - Symptom: opening a surah hung on "Loading..." — Al-Baqarah (286 ayat)
      sent several MB of JSON because EVERY ayah carried full English AND
      Urdu tafseer, which the user had not even asked to see.
    - Root cause: bundling rarely-viewed heavy data into the default
      response. Mobile users paid the download cost for tafseer they
      might never open.
    - Fix: the surah response now carries only small has_tafseer flags;
      this endpoint serves tafseer per-ayah on tap. Al-Baqarah opens in
      ~0.3s; tafseer loads in the background only when requested.
    - Viva line: "We applied lazy loading to the API itself — the default
      response carries what the screen needs now, and heavy content moves
      to an on-demand endpoint."
    """
    reader = get_reader()
    if reader is None:
        raise HTTPException(status_code=503, detail="Quran reader is warming up.")
    if not (1 <= surah <= 114):
        raise HTTPException(status_code=400, detail="Invalid surah/ayah number.")
    meta = reader.surah_meta(surah)
    max_ayah = meta["ayahs"] if meta else 286
    # Validate against the actual surah's ayah count (not the global max 286):
    # 99/99 must be 400 "invalid ayah", not 404 "tafseer not found".
    if not (1 <= ayah <= max_ayah):
        raise HTTPException(status_code=400, detail="Invalid surah/ayah number.")
    data = reader.get_tafseer(surah, ayah)
    if data is None:
        raise HTTPException(status_code=404, detail="Tafseer not found for this ayah.")
    return data


# In-memory cache for proxied tilawat audio: (surah, ayah, qari) -> (bytes, fetched_at).
# TEAM 5 (2026-10-18): the Codespace server -> everyayah.com hop is the fragile
# part of playback (throttled/blocked in some regions). The browser already got
# Cache-Control, but the SERVER re-fetched everyayah on every tap — so one slow
# upstream meant a slow/failed play. Caching bytes server-side makes repeat
# plays instant and upstream-independent. Bounded FIFO: ~500 MP3s max.
_AUDIO_CACHE: dict = {}
_AUDIO_CACHE_TTL = 86400  # 24 h (tilawat recordings never change)
_AUDIO_CACHE_MAX = 500


# FYP STUDY GUIDE: Returns cached MP3 bytes for (surah, ayah, qari) if present
# and unexpired (24h TTL); evicts expired entries.
# WHY: repeat plays skip the fragile codespace->everyayah.com hop entirely -
# instant playback that no longer depends on upstream availability.
def _audio_cache_get(key):
    entry = _AUDIO_CACHE.get(key)
    if entry and (time.time() - entry[1] < _AUDIO_CACHE_TTL):
        return entry[0]
    if entry:
        _AUDIO_CACHE.pop(key, None)  # expired
    return None


# FYP STUDY GUIDE: Stores fetched MP3 bytes in the bounded FIFO cache
# (500 entries max, oldest evicted first).
# WHY: tilawat recordings never change, so caching is safe; the FIFO bound
# stops the cache growing without limit on a free-tier server.
def _audio_cache_put(key, data: bytes):
    if len(_AUDIO_CACHE) >= _AUDIO_CACHE_MAX:
        _AUDIO_CACHE.pop(next(iter(_AUDIO_CACHE)))  # evict oldest (FIFO)
    _AUDIO_CACHE[key] = (data, time.time())


@app.get("/api/quran/qaris")
# FYP STUDY GUIDE: Lists the 6 verified qaris (everyayah ids), each tested with
# HTTP 200, with Mishary Alafasy as default.
# WHY: project rule - ayat audio must be real QARI recitation (AI TTS is only
# for EN/UR); the frontend selector needs the id, display name, and style.
async def list_qaris():
    """List available reciters (Qaris) for tilawat audio.

    Professional: 6 verified Qaris from everyayah.com, each tested with
    HTTP 200 on 001001.mp3. The frontend shows these in a selector.
    """
    return {
        "qaris": [
            {"id": "Alafasy_128kbps", "name": "Mishary Rashid Alafasy", "style": "Murattal — clear & popular"},
            {"id": "Husary_128kbps", "name": "Mahmoud Khalil Al-Husary", "style": "Murattal — classic tartil"},
            {"id": "Abdullah_Basfar_192kbps", "name": "Abdullah Basfar", "style": "High quality 192kbps"},
            {"id": "Abu_Bakr_Ash-Shaatree_128kbps", "name": "Abu Bakr Al-Shatri", "style": "Murattal — emotional"},
            {"id": "Nasser_Alqatami_128kbps", "name": "Nasser Alqatami", "style": "Murattal — beautiful voice"},
            {"id": "Yasser_Ad-Dussary_128kbps", "name": "Yasser Ad-Dussary", "style": "Murattal — melodious"},
        ],
        "default": "Alafasy_128kbps",
    }


@app.get("/api/quran/search")
# FYP STUDY GUIDE: Searches EN/UR translations (lang=en|ur) via the reader.
# WHY: find-by-meaning ('patience') for users who don't know the Arabic -
# the discovery half of the reader feature, next to the Arabic text itself.
async def quran_search(q: str, lang: str = "en"):
    """Search translations (lang=en|ur)."""
    reader = get_reader()
    if reader is None:
        raise HTTPException(status_code=503, detail="Quran reader is warming up.")
    if lang not in ("en", "ur"):
        raise HTTPException(status_code=400, detail="lang must be en or ur.")
    return {"results": reader.search(q, lang=lang)}


@app.get("/api/quran/translate")
# FYP STUDY GUIDE: EN<->UR word translation from parallel Quran translations via
# co-occurrence statistics (word 2-100 chars, direction validated).
# WHY: transparent statistics an examiner can audit - not a black box; falls
# back to an everyday dictionary for non-Quranic words.
async def quran_translate(q: str, direction: str = "en2ur"):
    """Translate a word/phrase EN<->UR using parallel Quran translations.

    direction: "en2ur" | "ur2en". Returns translation candidates derived
    from co-occurrence in 6,236 parallel ayat, plus example ayat showing
    the word in Quranic context. Falls back to an everyday dictionary.

    FYP STUDY GUIDE: this is transparent statistics, not a black box —
    candidates come from counting which target-language words appear most
    in the same ayat as the query word (see QuranReader.translate_word).
    """
    reader = get_reader()
    if reader is None:
        raise HTTPException(status_code=503, detail="Quran reader is warming up.")
    q = (q or "").strip()
    if len(q) < 2 or len(q) > 100:
        raise HTTPException(status_code=400, detail="Word must be 2-100 characters.")
    if direction not in ("en2ur", "ur2en"):
        raise HTTPException(status_code=400, detail="direction must be en2ur or ur2en.")
    return reader.translate_word(q, direction=direction)


@app.get("/api/audio/{surah}/{ayah}")
# FYP STUDY GUIDE: Fetches an ayah's MP3 from everyayah.com (server-side cache
# first) and streams it same-origin with the correct audio/mpeg type.
# WHY: some mobile networks block or throttle everyayah.com; the proxy removes
# CORS issues and makes playback reliable. The qari allowlist blocks SSRF
# (user input never reaches the upstream URL) and ranges are validated.
async def proxy_tilawat_audio(surah: int, ayah: int, qari: str = "Alafasy_128kbps"):
    """Proxy tilawat audio through our server (fallback when everyayah.com is blocked/slow).

    FYP STUDY GUIDE: Why a proxy?
    - Some mobile networks block or throttle everyayah.com
    - Direct browser -> everyayah.com can fail silently (CORS/network)
    - Our server fetches the MP3 and streams it to the browser
    - The browser sees it as same-origin: no CORS issues, reliable playback
    - We validate surah/ayah ranges to prevent abuse (SSRF protection)

    FYP STUDY GUIDE: The audio content-type bug (fixed 2026-10-18)
    - Symptom: tapping the speaker button showed "Audio nahi chal saka"
      even though the server WAS returning real MP3 bytes.
    - Root cause: our security middleware stamped every response with
      Content-Type: application/json and X-Content-Type-Options: nosniff.
      With nosniff, the browser TRUSTS the declared type and refuses to
      play MP3 bytes labeled as JSON.
    - Fix has two parts: (1) this endpoint returns StreamingResponse with
      media_type="audio/mpeg" so the declared type is correct, and
      (2) security.py skips nosniff/CSP headers for audio/video responses
      (CSP does not apply to media anyway).
    - Viva line: "We learned that with nosniff, a wrong Content-Type is not
      a warning — it is a hard block. So media responses must declare their
      real type, and security headers must not touch them."

    FYP STUDY GUIDE: Qari selection (added 2026-10-18)
    - Users can choose their favorite reciter (Qari) from 6 verified options.
    - The qari param is validated against an allowlist to prevent SSRF
      (we never put raw user input into the upstream URL).
    - Available: Mishary Alafasy, Husary, Basfar, Al-Shatri, Alqatami, Dussary.
    """
    # Validate ranges (Quran has 114 surahs; longest surah has 286 ayat)
    if not (1 <= surah <= 114 and 1 <= ayah <= 286):
        raise HTTPException(status_code=400, detail="Invalid surah/ayah number.")
    # Professional: validate ayah against THIS surah's actual count
    # (e.g. surah 99 has only 8 ayat, so 99/99 must be 400 not 502).
    reader = get_reader()
    if reader is not None:
        meta = reader.surah_meta(surah)
        if meta and ayah > meta["ayahs"]:
            raise HTTPException(
                status_code=400,
                detail=f"Surah {surah} has only {meta['ayahs']} ayat.",
            )
    # Professional: allowlist validation prevents SSRF (never trust raw input in URL)
    ALLOWED_QARIS = {
        "Alafasy_128kbps": "Mishary Rashid Alafasy",
        "Husary_128kbps": "Mahmoud Khalil Al-Husary",
        "Abdullah_Basfar_192kbps": "Abdullah Basfar",
        "Abu_Bakr_Ash-Shaatree_128kbps": "Abu Bakr Al-Shatri",
        "Nasser_Alqatami_128kbps": "Nasser Alqatami",
        "Yasser_Ad-Dussary_128kbps": "Yasser Ad-Dussary",
    }
    if qari not in ALLOWED_QARIS:
        qari = "Alafasy_128kbps"  # safe default
    url = f"https://everyayah.com/data/{qari}/{surah:03d}{ayah:03d}.mp3"
    cache_key = (surah, ayah, qari)
    # TEAM 5: repeat plays skip the everyayah round-trip entirely (server-side
    # cache). The browser's Cache-Control stays as a second layer.
    audio_data = _audio_cache_get(cache_key)
    try:
        import httpx
        if audio_data is None:
            # Professional: try direct connection first (works in most deployments),
            # fall back to env proxy settings (needed in some sandboxes).
            # The old code used trust_env=False only, which broke in proxied envs.
            for trust in (False, True):
                try:
                    async with httpx.AsyncClient(timeout=30.0, trust_env=trust) as client:
                        resp = await client.get(url)
                        if resp.status_code == 200:
                            audio_data = resp.content
                            break
                except Exception:
                    continue
            if audio_data is None:
                raise HTTPException(status_code=502, detail="Audio source unavailable.")
            _audio_cache_put(cache_key, audio_data)
        # Professional: use StreamingResponse with explicit content-type header.
        # Plain Response with media_type was being overridden to application/json
        # by the middleware chain, causing browsers to refuse playback
        # (X-Content-Type-Options: nosniff + wrong type = no audio).
        from fastapi.responses import StreamingResponse
        import io
        return StreamingResponse(
            io.BytesIO(audio_data),
            media_type="audio/mpeg",
            headers={
                "Cache-Control": "public, max-age=86400",  # cache 1 day
                "Content-Disposition": f"inline; filename={surah:03d}{ayah:03d}.mp3",
                "Content-Length": str(len(audio_data)),
            },
        )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Audio source timed out.")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=502, detail="Could not fetch audio.")


# FYP STUDY GUIDE: Pydantic model for /api/rematch - a single transcript string.
# WHY: request shape validated by the framework before any logic runs - a
# malformed body fails fast with a clear 422 instead of crashing the matcher.
class RematchRequest(BaseModel):
    transcript: str


@app.post("/api/rematch")
# FYP STUDY GUIDE: Re-runs the matcher + coaching on a user-corrected transcript -
# no re-recording needed.
# WHY: ASR errors are fixable by hand; rematch turns 'AI ne ghalat suna' into a
# self-service fix, reusing the exact same honest-label thresholds as verify().
async def rematch_transcript(req: RematchRequest):
    """Re-match a (possibly corrected) transcript against the Quran.

    Lets the user fix ASR errors and get fresh results without re-recording.
    """
    from .engine.matcher import align_transcript, recover_single_gap
    from .engine.coach import build_coaching
    svc = get_service()
    corpus = svc.corpus if svc else None
    if corpus is None or not corpus.ready:
        raise HTTPException(status_code=503, detail="Corpus not ready.")
    t = req.transcript.strip()
    if len(t) < 2 or len(t) > 20000:
        raise HTTPException(status_code=400, detail="Transcript must be 2-20000 characters.")
    matches = align_transcript(corpus, t)
    matches = recover_single_gap(corpus, matches, t)
    results = []
    for m in matches:
        if m.status == "SEQUENCE RECOVERY":
            label = "SEQUENCE RECOVERY / INCOMPLETE AUDIO EVIDENCE"
        elif (m.score >= settings.verified_score
              and m.coverage >= settings.verified_coverage
              and m.missing <= settings.verified_missing
              and m.length >= 3):
            label = "VERIFIED TEXT MATCH"
        elif m.score >= 80 and m.length >= 3:
            label = "GOOD TEXT MATCH"
        elif m.score >= 70:
            label = "POSSIBLE MATCH"
        else:
            label = "LOW CONFIDENCE"
        results.append({
            "surah": m.verse.surah,
            "ayah": m.verse.ayah,
            "key": m.verse.key,
            "text": m.verse.text,
            "translation_en": corpus.translations_en.get(m.verse.key, ""),
            "translation_ur": corpus.translations_ur.get(m.verse.key, ""),
            "confidence": round(m.score, 1),
            "coverage": round(m.coverage, 1),
            "missing": round(m.missing, 1),
            "sequence": round(getattr(m, 'sequence', 0), 1),
            "label": label,
            "reason": m.reason,
            "transcript_start": m.start,
            "transcript_length": m.length,
        })
    verified = sum(r["label"] == "VERIFIED TEXT MATCH" for r in results)
    return {
        "results": results,
        "coaching": build_coaching(t, results),
        "verified_count": verified,
        "count": len(results),
        "transcript": t,
    }


# -------------------------------------------------------------------- api
@app.get("/api/health")
# FYP STUDY GUIDE: Liveness/readiness probe - returns immediately even
# mid-warmup, with corpus/ASR status; reveals no secrets.
# WHY: load balancers and the wake-link checker need an instant answer; it never
# blocks on the model and delegates to svc.health() once warmed up.
async def health():
    """Liveness/readiness probe. Safe to expose; reveals no secrets.

    Returns immediately even while the engine warms up — it never blocks.
    """
    svc = get_service()
    if svc is None:
        return {
            "ready": False,
            "warming_up": True,
            "corpus": {"ready": False, "checks": []},
            "asr_model": settings.asr_model,
            "asr_loaded": False,
            "error": _service_error,
        }
    return svc.health()


@app.get("/api/diagnostics", dependencies=[Depends(require_api_key)])
# FYP STUDY GUIDE: API-key-gated internals - engine health plus job-queue stats.
# WHY: exposes operational detail (worker counts, queue depth) that must not be
# public; the require_api_key dependency keeps it private.
async def diagnostics():
    svc = get_service()
    diag = svc.diagnostics() if svc else {"ready": False, "warming_up": True}
    diag["jobs"] = _jobs.stats()
    return diag


@app.post("/api/verify", dependencies=[Depends(require_api_key)], status_code=202)
@limiter.limit(settings.rate_limit_verify)
# FYP STUDY GUIDE: POST /api/verify - validates the upload (extension, magic
# bytes, streaming size cap), saves to a uuid temp path, submits a job, and
# returns 202 {job_id} immediately.
# WHY: the core entry point - validation failures (415/413/400) are answered
# synchronously, while the minutes-long work runs async so flaky networks and
# page refreshes never lose a verification; temp-file ownership passes to the
# worker, which deletes it when done.
async def verify(request: Request, file: UploadFile = File(...)):
    """Accept an upload and queue a verification job.

    Returns 202 {"job_id": ...} immediately. Poll GET /api/jobs/{job_id}
    for stage/progress and the final result. Upload validation failures
    (415/413/400) are still answered synchronously.
    """
    request_id = getattr(request.state, "request_id", "-")
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise HTTPException(
            status_code=503,
            detail="The verification engine is warming up. Please try again in a minute.",
        )
    ext = validate_upload(file)
    head = await peek_signature(file)
    check_signature_or_raise(head)

    tmp = safe_temp_path(DATA_DIR, ext)
    max_bytes = settings.max_upload_mb * 1024 * 1024
    size = 0
    try:
        with tmp.open("wb") as out:
            while True:
                chunk = await file.read(4 * 1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Upload exceeds the {settings.max_upload_mb} MB limit.",
                    )
                out.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="The uploaded file is empty.")
        log.info("req=%s upload_ok bytes=%d ext=%s", request_id, size, ext)
        # Ownership of tmp passes to the job; the worker deletes it when done.
        job_id = _jobs.submit(tmp, request_id)
        return {"job_id": job_id, "status": "queued", "request_id": request_id}
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


@app.post("/api/identify", dependencies=[Depends(require_api_key)])
@limiter.limit(settings.rate_limit_verify)
# FYP STUDY GUIDE: Quick surah ID - validates the upload, then runs svc.identify
# (3 short samples, ~60s transcribed) in a worker thread via asyncio.to_thread.
# WHY: answers 'which surah is this?' in seconds, not the minutes a full verify
# needs; to_thread keeps the ASGI event loop free during FFmpeg/CPU work, and a
# MediaError becomes a clean 400 instead of an attacker-triggerable 500.
async def identify(request: Request, file: UploadFile = File(...)):
    """Quick surah identification — no full listen.

    Upload audio; the engine samples 3 short clips (start/middle/end, ~60s
    total), transcribes only those, and returns the identified surah in
    seconds. For ayah-by-ayah verification, use POST /api/verify.
    Synchronous (fast) — no job queue.
    """
    request_id = getattr(request.state, "request_id", "-")
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise HTTPException(
            status_code=503,
            detail="The engine is warming up. Please try again in a minute.",
        )
    ext = validate_upload(file)
    head = await peek_signature(file)
    check_signature_or_raise(head)

    tmp = safe_temp_path(DATA_DIR, ext)
    max_bytes = settings.max_upload_mb * 1024 * 1024
    size = 0
    try:
        with tmp.open("wb") as out:
            while True:
                chunk = await file.read(4 * 1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(status_code=413, detail="Upload too large.")
                out.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="Empty file.")
        # Run in a worker thread so the event loop never blocks.
        # FYP STUDY GUIDE: svc.identify() runs FFmpeg decode first, and a file
        # with valid magic bytes can still be undecodable garbage — decode
        # raises MediaError (already client-safe) for that. Convert it to
        # HTTP 400 here. Uncaught, it reaches the global exception handler
        # and comes back as HTTP 500, letting an attacker trigger 500s at
        # will with ~100-byte requests. (Found 2026-10-22, Team 7 audit.)
        try:
            result = await asyncio.to_thread(svc.identify, tmp, request_id)
        except MediaError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return result
    finally:
        tmp.unlink(missing_ok=True)


@app.post("/api/practice-word", dependencies=[Depends(require_api_key)])
@limiter.limit("30/minute")
# FYP STUDY GUIDE: Word practice - the user records ONE word; the clip is decoded
# (max 10s), transcribed, and fuzzy-compared (>=80/100) against the expected word.
# WHY: the Coach's per-word check as a standalone drill; a tiny synchronous
# endpoint because a 2-4s clip transcribes in seconds on CPU; the 5MB cap and
# 10s decode bound match the short-clip use case.
async def practice_word(request: Request, file: UploadFile = File(...),
                        expected: str = Form("")):
    """Word practice: the user records ONE word; we check if they said it right.

    FYP STUDY GUIDE: tiny synchronous endpoint — a 2-4s practice clip
    transcribes in seconds on CPU. The honesty rule from Coach applies:
    the word counts as correct only if the transcript fuzzy-matches the
    expected word (>=80/100, same bar Coach uses for near-misses).
    Upload validation mirrors /api/verify (type + signature + size cap).
    """
    request_id = getattr(request.state, "request_id", "-")
    svc = get_service()
    if svc is None or not svc.corpus.ready:
        raise HTTPException(
            status_code=503,
            detail="The engine is warming up. Please try again in a minute.",
        )
    exp_norm = normalize_arabic(expected or "").strip()
    if not exp_norm:
        raise HTTPException(status_code=400, detail="Expected word is required.")
    ext = validate_upload(file)
    head = await peek_signature(file)
    check_signature_or_raise(head)

    tmp = safe_temp_path(DATA_DIR, ext)
    max_bytes = 5 * 1024 * 1024  # practice clips are seconds long; 5MB is plenty
    size = 0
    try:
        with tmp.open("wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(
                        status_code=413, detail="Practice clip too large (5MB max).")
                out.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="Empty file.")
        # Short practice clip: decode (max 10s) and transcribe in a worker thread.
        # FYP STUDY GUIDE: FFmpeg is the authoritative content validator — a
        # file with valid magic bytes can still be undecodable garbage, and
        # decode raises MediaError (already client-safe) for that. Convert it
        # to HTTP 400 here; uncaught it escapes as HTTP 500 via the global
        # handler, letting an attacker trigger 500s at will with ~100-byte
        # requests. (Found 2026-10-22, Team 7 audit.)
        try:
            audio, sr, _quality = decode_to_mono16k_with_quality(tmp, max_seconds=10)
        except MediaError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if audio.size == 0:
            raise HTTPException(
                status_code=400, detail="No audio could be decoded.")
        res = await asyncio.to_thread(svc.asr.transcribe_array, audio, sr)
        heard = res.get("text", "") or ""
        match, sim = word_practice_match(exp_norm, heard)
        log.info("req=%s practice_word expected=%s match=%s sim=%s",
                 request_id, exp_norm, match, sim)
        return {"expected": exp_norm, "heard": heard.strip(),
                "match": match, "similarity": sim}
    finally:
        tmp.unlink(missing_ok=True)


@app.get("/api/jobs/{job_id}", dependencies=[Depends(require_api_key)])
# FYP STUDY GUIDE: GET /api/jobs/{job_id} - cheap poll returning status, stage,
# progress, ETA, partial text, and the final result or error.
# WHY: short requests survive proxies that kill long connections - this is the
# front half of the async-verify design; unknown/expired ids get a clear 404.
async def job_status(job_id: str):
    """Poll a verification job. Short, cheap, safe to retry on network blips."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(
            status_code=404,
            detail="Unknown or expired verification. Please upload your audio again.",
        )
    payload = {
        "job_id": job.job_id,
        "status": job.status,
        "stage": job.stage,
        "progress": round(job.progress, 1),
        "request_id": job.request_id,
    }
    if job.queue_position is not None:
        payload["queue_position"] = job.queue_position
    if job.eta_seconds is not None:
        payload["eta_seconds"] = job.eta_seconds
    if job.partial_text:
        payload["partial_text"] = job.partial_text
    if job.status == "done":
        payload["result"] = job.result
    elif job.status == "error":
        payload["error"] = job.error
    elif job.status == "cancelled":
        payload["cancelled"] = True
    return payload


@app.get("/api/jobs/{job_id}/events", dependencies=[Depends(require_api_key)])
# FYP STUDY GUIDE: Server-Sent Events stream of live job updates (progress, ETA,
# partial text), preferred over polling.
# WHY: push instead of poll - fewer requests and instant UI updates; plain-HTTP
# SSE works through the Codespaces port forwarder with no WebSocket upgrade.
async def job_events(job_id: str):
    """Server-Sent Events: live job updates (progress, ETA, partial text).

    The browser should prefer this over polling; if the stream drops, fall
    back to GET /api/jobs/{job_id}. Works through the Codespaces port
    forwarder (plain HTTP, no WebSocket upgrade needed).
    """
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(
            status_code=404,
            detail="Unknown or expired verification. Please upload your audio again.",
        )

    # FYP STUDY GUIDE: Async generator behind the SSE stream - re-reads the job each
    # second and yields a data: event only when status/progress/stage changed.
    # WHY: emitting on change keeps the stream cheap; returning on done/error/
    # cancelled (or 'gone' if the job vanished) closes the connection cleanly so
    # the browser never hangs on a dead stream.
    async def gen():
        last_sig = None
        while True:
            j = _jobs.get(job_id)
            if j is None:
                yield 'event: gone\ndata: {"status":"gone"}\n\n'
                return
            payload = {
                "job_id": j.job_id,
                "status": j.status,
                "stage": j.stage,
                "progress": round(j.progress, 1),
            }
            if j.queue_position is not None:
                payload["queue_position"] = j.queue_position
            if j.eta_seconds is not None:
                payload["eta_seconds"] = j.eta_seconds
            if j.partial_text:
                payload["partial_text"] = j.partial_text
            if j.status == "done":
                payload["result"] = j.result
            elif j.status == "error":
                payload["error"] = j.error
            elif j.status == "cancelled":
                payload["cancelled"] = True
            sig = (payload["status"], payload["progress"], payload["stage"],
                   payload.get("partial_text", "")[-200:])
            if sig != last_sig:
                last_sig = sig
                yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
            if j.status in ("done", "error", "cancelled"):
                return
            await asyncio.sleep(1.0)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.delete("/api/jobs/{job_id}", dependencies=[Depends(require_api_key)])
# FYP STUDY GUIDE: DELETE /api/jobs/{job_id} - cancels a queued or running job;
# already-finished jobs return their state instead of erroring.
# WHY: the user-facing half of cancellation - idempotent by design, and the
# worker aborts a running job at its next progress check via JobCancelledByUser.
async def job_cancel(job_id: str):
    """Cancel a queued or running verification job."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(
            status_code=404,
            detail="Unknown or expired verification.",
        )
    if job.status in ("done", "error", "cancelled"):
        return {"job_id": job_id, "status": job.status,
                "detail": "Job already finished."}
    ok = _jobs.cancel(job_id)
    return {"job_id": job_id, "cancelled": ok,
            "status": _jobs.get(job_id).status if ok else job.status}


@app.get("/api/jobs/{job_id}/transcript.{fmt}", dependencies=[Depends(require_api_key)])
# FYP STUDY GUIDE: Downloads a finished job's transcript as txt/srt/vtt/json
# with the correct media type and a download filename.
# WHY: users keep their recitation transcript; the four formats cover plain
# text, subtitles (SRT/VTT), and machine-readable JSON - all built from the
# same time-aligned segments the ASR produced. 409 until the job is done.
async def job_transcript(job_id: str, fmt: str):
    """Download the transcript of a finished job: txt / srt / vtt / json."""
    fmt = fmt.lower()
    if fmt not in EXPORTERS:
        raise HTTPException(status_code=404, detail="Format must be txt, srt, vtt or json.")
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(
            status_code=404,
            detail="Unknown or expired verification. Please upload your audio again.",
        )
    if job.status != "done" or not job.result:
        raise HTTPException(
            status_code=409,
            detail="Transcript is only available after the job finishes.",
        )
    segments = job.result.get("segments") or []
    body = EXPORTERS[fmt](segments)
    return PlainTextResponse(
        body,
        media_type=MEDIA_TYPES[fmt],
        headers={"Content-Disposition":
                 f'attachment; filename="quran-shazam-{job_id}.{fmt}"'},
    )


# ------------------------------------------------------------------- run
# FYP STUDY GUIDE: Uvicorn entry point - 0.0.0.0, PORT env, single worker,
# proxy-header handling from settings.
# WHY: workers=1 is deliberate - each forked worker would load its own copy of
# the heavy ASR model; scale with containers, not processes.
def run() -> None:
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(__import__("os").getenv("PORT", "8000")),
        workers=1,  # keep 1: the ASR model is heavy; scale with containers instead
        proxy_headers=settings.proxy_headers,
        forwarded_allow_ips="*" if settings.proxy_headers else "127.0.0.1",
        access_log=True,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    run()
