#!/usr/bin/env python3
"""Generate the Quran-referenced dua clips at deploy time.

WHY THIS SCRIPT EXISTS (QS-16): the dua button must play EXACTLY the dua
text on the card — no more, no less (user AUDIO RULE, 2026-10-23).
everyayah.com ships only whole-ayah MP3s, and AI-TTS is forbidden for
Quranic Arabic, so Quran-referenced duas need pre-clipped MP3s cut from the
Qari's everyayah recitation. Shipping those derived clips in the release
raises an everyayah redistribution question, so this script generates them
on the deploy target instead: download the source ayah MP3s, cut the exact
dua word spans with ffmpeg, write the clips to the static audio dir.

The cuts are DETERMINISTIC and need no ML model at deploy time: start/end
times live in dua_clip_cuts.json next to this script (re-derived 2026-10-24
with Whisper word-timestamps and verified against the previously shipped
clips: duration within 0.15 s, re-transcription matching the dua text).

BEHAVIOUR:
- Idempotent: a clip that already exists and is a valid MP3 is never
  overwritten (use --force to regenerate).
- Per-clip failure isolation: one failed download/cut never deletes or
  damages other clips; the failure is logged and the script moves on.
- Exit code: 0 only if every clip exists and is valid at the end,
  otherwise 1 (so a deploy step can fail loudly instead of shipping a
  half-working duas page).

REQUIREMENTS: ffmpeg + ffprobe on PATH, outbound HTTPS to everyayah.com.
Standard library only — no project dependencies, so it runs before (or
without) the app's virtualenv.

USAGE:
    python backend/scripts/build_dua_clips.py [--out-dir DIR] [--force]
    [--qari QARI_ID] [--cuts FILE]
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_OUT_DIR = SCRIPT_DIR.parent / "app" / "static" / "audio" / "duas"
DEFAULT_CUTS = SCRIPT_DIR / "dua_clip_cuts.json"
EVERYAYAH_URL = "https://everyayah.com/data/{qari}/{surah:03d}{ayah:03d}.mp3"


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL,
                   stderr=subprocess.PIPE, text=True)


def valid_mp3(path: Path) -> bool:
    """True if path exists and ffprobe reports a positive duration."""
    if not path.is_file() or path.stat().st_size == 0:
        return False
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=30, check=True).stdout.strip()
        return float(out) > 0
    except Exception:
        return False


def download(url: str, dest: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "QuranShazam/1.0"})
    with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "wb") as f:
        shutil.copyfileobj(resp, f)
    if dest.stat().st_size == 0:
        raise RuntimeError(f"empty download from {url}")


def build_clip(clip: dict, cuts: dict, out_dir: Path, tmp: Path, force: bool) -> str:
    """Build one clip. Returns 'skipped' | 'built' | raises on failure."""
    target = out_dir / clip["file"]
    if not force and valid_mp3(target):
        return "skipped"
    pad = float(cuts.get("pad_seconds", 0.05))
    qari = cuts.get("qari", "Alafasy_128kbps")
    srcs = clip["sources"]

    # 1. Fetch source ayah MP3(s).
    local_srcs = []
    for i, s in enumerate(srcs):
        url = EVERYAYAH_URL.format(qari=qari, surah=s["surah"], ayah=s["ayah"])
        dest = tmp / f"src{i}_{s['surah']:03d}{s['ayah']:03d}.mp3"
        download(url, dest)
        local_srcs.append(dest)

    # 2. Multi-ayah duas (20:25-26) need one concatenated timeline first,
    #    because the cut span crosses the ayah boundary.
    if len(local_srcs) > 1:
        concat = tmp / f"{clip['file']}.concat.mp3"
        inputs: list[str] = []
        for p in local_srcs:
            inputs += ["-i", str(p)]
        filt = "".join(f"[{i}:a]" for i in range(len(local_srcs)))
        filt += f"concat=n={len(local_srcs)}:v=0:a=1[out]"
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs,
             "-filter_complex", filt, "-map", "[out]", str(concat)])
        source = concat
    else:
        source = local_srcs[0]

    # 3. Cut the dua span (small pad each side, start clamped at 0).
    start = max(0.0, float(clip["start"]) - pad)
    end = float(clip["end"]) + pad
    tmp_out = tmp / clip["file"]
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
         "-ss", f"{start:.2f}", "-i", str(source), "-t", f"{end - start:.2f}",
         "-c:a", "libmp3lame", "-q:a", "4", str(tmp_out)])
    if not valid_mp3(tmp_out):
        raise RuntimeError(f"ffmpeg produced an invalid MP3 for {clip['file']}")
    shutil.move(str(tmp_out), str(target))
    return "built"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out-dir", default=str(DEFAULT_OUT_DIR),
                    help="where clips are written (default: static audio dir)")
    ap.add_argument("--cuts", default=str(DEFAULT_CUTS),
                    help="cuts JSON (default: next to this script)")
    ap.add_argument("--qari", default=None,
                    help="override the everyayah qari id from the cuts file")
    ap.add_argument("--force", action="store_true",
                    help="regenerate even clips that already exist")
    args = ap.parse_args()

    for tool in ("ffmpeg", "ffprobe"):
        if shutil.which(tool) is None:
            print(f"ERROR: {tool} not found on PATH", file=sys.stderr)
            return 1

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cuts = json.loads(Path(args.cuts).read_text(encoding="utf-8"))
    if args.qari:
        cuts["qari"] = args.qari

    failed: list[str] = []
    with tempfile.TemporaryDirectory(prefix="dua_clips_") as td:
        tmp = Path(td)
        for clip in cuts["clips"]:
            try:
                status = build_clip(clip, cuts, out_dir, tmp, args.force)
                print(f"{clip['file']}: {status}")
            except Exception as exc:  # per-clip isolation: keep going
                print(f"{clip['file']}: FAILED ({exc})", file=sys.stderr)
                failed.append(clip["file"])

    # Final gate: every clip must exist and be valid, or the deploy step fails.
    missing = [c["file"] for c in cuts["clips"]
               if not valid_mp3(out_dir / c["file"])]
    if missing:
        print(f"ERROR: {len(missing)} clip(s) still missing/invalid: "
              f"{', '.join(missing)}", file=sys.stderr)
        return 1
    if failed:
        print(f"WARNING: {len(failed)} clip(s) failed to build but all clips "
              f"are present (pre-existing files kept)", file=sys.stderr)
    print(f"OK: all {len(cuts['clips'])} dua clips present in {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
