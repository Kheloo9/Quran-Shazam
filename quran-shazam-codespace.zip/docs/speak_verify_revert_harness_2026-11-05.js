/* Speak-verify SINGLE-SHOT revert harness — 2026-11-05.
 * Runs the REAL backend/app/static/js/verify.js in a node vm with DOM
 * stubs and a capturable FakeSpeechRecognition, driven ONLY through the
 * real buttons / text element. /api/rematch is stubbed; the matcher and
 * renderResults are NOT under test beyond "does not throw".
 *
 * Single-shot semantics under test (v116, restored 2026-11-05):
 *  one Mic tap = one session; continuous=false; the session ends by
 *  itself (onend auto-commits once, plain join, NO dedup); NO
 *  auto-restart on any path; errors stop the mic; Clear wipes and
 *  stale events never resurrect text; Verify posts exactly the finals.
 *
 * 2026-11-07 dictation-concept change (user order): the live box is a
 * textarea now — interim is written INLINE (no faint span), and a wrong
 * word can be fixed by hand (input syncs to committed text when not
 * listening). The checks below read .value, not .textContent.
 *
 * Run: node docs/speak_verify_revert_harness_2026-11-05.js
 * Exit 0 = ALL PASS, 1 = any FAIL. Gate only — the user's phone test
 * is the only verdict. */
'use strict';
const vm = require('vm');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(
  path.join(__dirname, '..', 'backend', 'app', 'static', 'js', 'verify.js'), 'utf8');

let pass = 0, fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('PASS  ' + name + (extra !== undefined ? '  [' + extra + ']' : '')); }
  else { fail++; console.log('FAIL  ' + name + (extra !== undefined ? '  [' + extra + ']' : '')); }
}

/* ---------------- stubs ---------------- */
function makeEl(id) {
  const el = {
    id: id || '',
    disabled: false,
    innerHTML: '',
    style: {},
    value: '',
    files: [],
    className: '',
    dataset: {},
    _handlers: {},
    _children: [],
    addEventListener(type, fn) { (this._handlers[type] = this._handlers[type] || []).push(fn); },
    removeEventListener() {},
    appendChild(child) { this._children.push(child); return child; },
    removeChild(child) { const i = this._children.indexOf(child); if (i >= 0) this._children.splice(i, 1); return child; },
    setAttribute() {},
    getAttribute() { return null; },
    removeAttribute() {},
    scrollIntoView() {},
    querySelector() { return makeEl('q'); },
    querySelectorAll() { return []; },
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    click() { (this._handlers.click || []).slice().forEach(fn => fn({})); },
  };
  let _text = '';
  Object.defineProperty(el, 'textContent', {
    get() {
      if (this._children.length) return this._children.map(c => (c && c.textContent) || '').join('');
      return _text;
    },
    set(v) { _text = String(v); this._children = []; },
  });
  return el;
}

const elements = {};
const documentStub = {
  getElementById(id) { return elements[id] || (elements[id] = makeEl(id)); },
  querySelector() { return makeEl('q'); },
  querySelectorAll() { return []; },
  createElement(tag) { return makeEl(tag); },
  createTextNode(text) { return { textContent: text }; },
  body: makeEl('body'),
  execCommand() { return false; },
};

const store = {};
const fetchCalls = [];
const instances = [];

class FakeSR {
  constructor() {
    this.lang = '';
    this.interimResults = false;
    this.continuous = false;
    this.onresult = null;
    this.onerror = null;
    this.onend = null;
    this.startCount = 0;
    this.stopCount = 0;
    instances.push(this);
  }
  start() { this.startCount++; }
  stop() { this.stopCount++; }
  // Drive one result event: finals[] + optional interim string.
  result(finals, interim) {
    const results = [];
    finals.forEach(t => results.push({ isFinal: true, 0: { transcript: t } }));
    if (interim) results.push({ isFinal: false, 0: { transcript: interim } });
    if (this.onresult) this.onresult({ results });
  }
  end() { if (this.onend) this.onend(); }
  error(code) { if (this.onerror) this.onerror({ error: code }); }
}

const sandbox = {
  document: documentStub,
  localStorage: {
    getItem: k => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: k => { delete store[k]; },
  },
  navigator: {},
  fetch: async (url, opts) => {
    fetchCalls.push({ url, opts });
    return {
      ok: true,
      json: async () => ({
        transcript: JSON.parse(opts.body).transcript,
        results: [],
        coaching: null,
        verified_count: 0,
        count: 0,
      }),
    };
  },
  SpeechRecognition: FakeSR,
  webkitSpeechRecognition: undefined,
  innerWidth: 1024,
  console,
  setTimeout, clearTimeout, setInterval, clearInterval,
  Date, JSON, Math, Array, Object, Promise, Error, RegExp, String, Number, Boolean, Map, Set,
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

vm.runInContext(SRC, sandbox);

/* ---------------- helpers ---------------- */
const btn = id => elements[id];
const text = () => elements['speak-verify-text'].value;
const status = () => elements['speak-verify-status'].textContent;
function fireInput(el) { (el._handlers.input || []).slice().forEach(fn => fn({})); }
const BISMILLAH = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ';
const AYAH1 = 'قُلْ هُوَ اللَّهُ أَحَدٌ';

function micTap() { btn('btn-speak-verify-start').click(); }
function lastInstance() { return instances[instances.length - 1]; }

/* ---------------- static checks on the real source ---------------- */
// Comment text is documentation, not behaviour: strip block comments
// before testing for live code (the revert header itself mentions
// "rec.continuous = true" as history).
const CODE = SRC.replace(/\/\*[\s\S]*?\*\//g, '');
check('no continuous=true anywhere in code', !/rec\.continuous\s*=\s*true/.test(CODE));
check('rec.continuous = false present', /rec\.continuous\s*=\s*false/.test(CODE));
check('no auto-restart counter', !SRC.includes('restartsWithoutFinal'));
check('no overlap/dedup helpers', !SRC.includes('appendOverlapAware') && !SRC.includes('normalizeWord') && !SRC.includes('commitSessionFinals'));
/* 2026-11-07: scope to SPEAK-VERIFY's own onend. The file now also has
   setupDictation (ported from v116 on 2026-11-06), whose rec.onend comes
   first in the file — an unscoped slice from it reaches the
   "function startSession()" DEFINITION within 1200 chars and trips this
   check as a false positive. A definition is not a call; the check's
   intent is that no onend CALLS startSession (auto-restart). */
const SV_SRC = SRC.slice(SRC.indexOf('(function setupSpeakVerify'));
check('no startSession() call inside onend (no auto-restart)', !/onend[\s\S]{0,1200}startSession\(\)/.test(SV_SRC.slice(SV_SRC.indexOf('rec.onend'))));
check('no faint interim span in JS anymore', !SRC.includes('speak-verify-interim'));
const TEMPLATE = fs.readFileSync(
  path.join(__dirname, '..', 'backend', 'app', 'templates', 'verify.html'), 'utf8');
check('live box is a textarea (editable)', /<textarea[^>]*id="speak-verify-text"/.test(TEMPLATE));
check('live box is NOT a div anymore', !/<div[^>]*id="speak-verify-text"/.test(TEMPLATE));
/* 2026-11-07 Coach-in-every-case fix (user order): renderResults used to
   `return` on zero results, so renderCoach never ran and the Coach card
   never appeared — against the 2026-10-30 rule. Now the empty branch is
   an if/else (no early return) and renderCoach + the progress hide always
   run. The empty Coach state prefers the backend's own summary
   ("No ayat to coach on yet") over the generic "unavailable" text. */
const RR = CODE.slice(CODE.indexOf('function renderResults'));
const EMPTY_IDX = RR.indexOf("if (!d.results || !d.results.length)");
const COACH_IDX = RR.indexOf('renderCoach(d.coaching)', EMPTY_IDX);
check('Coach renders even on zero results (no early return)', EMPTY_IDX >= 0 && COACH_IDX > EMPTY_IDX && !/return;/.test(RR.slice(EMPTY_IDX, COACH_IDX)));
check('progress bar hides even on zero results', RR.indexOf("progressEl.style.display = 'none'", COACH_IDX) > COACH_IDX);
const RC = CODE.slice(CODE.indexOf('function renderCoach'));
check('empty Coach state prefers backend summary', /if \(!coaching \|\| !coaching\.ayat[\s\S]{0,800}s\.message_en \|\| 'Coach feedback is unavailable/.test(RC));

/* ---------------- behaviour ---------------- */
(async () => {
  // 1. Single utterance: one tap, one final, onend auto-commits and
  //    the mic stops BY ITSELF. No second instance is ever created.
  micTap();
  check('continuous=false on the live session', lastInstance().continuous === false);
  check('Mic disabled while listening', btn('btn-speak-verify-start').disabled === true);
  lastInstance().result([BISMILLAH]);
  check('final shows live before onend', text() === BISMILLAH, text());
  lastInstance().end();
  check('single utterance committed exactly', text() === BISMILLAH, text());
  check('mic re-enabled after auto-stop', btn('btn-speak-verify-start').disabled === false);
  check('NO auto-restart instance created', instances.length === 1, 'instances=' + instances.length);
  check('auto-stop status tells user to re-tap', status().includes('dobara Mic on par click farmayen'), status());

  // 2. Second tap accumulates exactly, no duplication.
  micTap();
  check('second tap creates exactly one new session', instances.length === 2);
  lastInstance().result([AYAH1]);
  lastInstance().end();
  check('two taps accumulate exactly, no repeats', text() === BISMILLAH + ' ' + AYAH1, text());

  // 3. Empty onend: no finals, mic stops, no restart.
  micTap();
  lastInstance().end();
  check('empty onend keeps old text', text() === BISMILLAH + ' ' + AYAH1);
  check('empty onend creates no new session', instances.length === 3, 'instances=' + instances.length);
  check('empty onend status is re-tap', status().includes('Mic band ho gaya hai'));

  // 4. Interim-only: Verify stays disabled; interim never becomes final.
  btn('btn-speak-verify-clear').click();
  check('Clear wipes text', text() === '');
  check('Verify disabled with no finals', btn('btn-speak-verify-check').disabled === true);
  micTap();
  lastInstance().result([], 'قُلْ');
  check('Verify still disabled on interim-only', btn('btn-speak-verify-check').disabled === true);
  lastInstance().end();
  check('interim discarded on auto-stop, no finals', text() === '');
  check('Verify still disabled after interim-only session', btn('btn-speak-verify-check').disabled === true);

  // 5. Transient error stops the mic, no restart.
  micTap();
  const nBefore = instances.length;
  lastInstance().error('network');
  check('transient error stops mic', btn('btn-speak-verify-start').disabled === false);
  check('transient error creates no new session', instances.length === nBefore);
  check('transient error status tells user to re-tap', status().includes('dobara Mic on par click farmayen'));

  // 6. Permission error stops the mic, no restart.
  micTap();
  lastInstance().error('not-allowed');
  check('permission error stops mic', btn('btn-speak-verify-start').disabled === false);
  check('permission error creates no new session', instances.length === nBefore + 1);
  check('permission error status', status().includes('ijazat'));

  // 7. Clear + stale events: cleared text never resurrects.
  micTap();
  lastInstance().result([BISMILLAH]);
  check('text present before Clear', text() === BISMILLAH);
  btn('btn-speak-verify-clear').click();
  check('Clear wipes live text', text() === '');
  const dead = lastInstance();
  dead.result([AYAH1]);
  dead.end();
  check('stale result after Clear resurrects nothing', text() === '');
  check('stale onend after Clear creates no session', instances.length === nBefore + 2);

  // 8. Rok dein mid-session commits finals and stops; late onend is inert.
  micTap();
  lastInstance().result([BISMILLAH]);
  btn('btn-speak-verify-stop').click();
  check('Rok dein commits the spoken final', text() === BISMILLAH, text());
  check('Rok dein status', status() === 'Rok diya gaya.');
  const stopped = lastInstance();
  stopped.end();
  check('late onend after Rok dein changes nothing', text() === BISMILLAH);

  // 9. Verify posts EXACTLY the spoken finals, once.
  const callsBefore = fetchCalls.length;
  btn('btn-speak-verify-check').click();
  await new Promise(r => setTimeout(r, 50));
  check('Verify posts exactly once', fetchCalls.length === callsBefore + 1, 'calls=' + fetchCalls.length);
  const body = JSON.parse(fetchCalls[fetchCalls.length - 1].opts.body);
  check('Verify posts exactly the spoken finals', body.transcript === BISMILLAH, body.transcript);

  // 10. Deliberate repetition is KEPT (plain join, no dedup): the same
  //     ayah spoken on two taps appears twice.
  btn('btn-speak-verify-clear').click();
  micTap(); lastInstance().result([AYAH1]); lastInstance().end();
  micTap(); lastInstance().result([AYAH1]); lastInstance().end();
  check('same ayah on two taps appears twice (no dedup)', text() === AYAH1 + ' ' + AYAH1, text());

  // 11. Interim is written INLINE into the box (dictation-style), not a
  //     separate span — visible while speaking, gone on stop.
  btn('btn-speak-verify-clear').click();
  micTap();
  lastInstance().result([], 'قُلْ');
  check('interim shows inline in the box while speaking', text() === 'قُلْ', text());
  lastInstance().result([AYAH1], 'هُوَ');
  check('final + interim both inline in the box', text() === AYAH1 + ' هُوَ', text());
  lastInstance().end();
  check('interim stripped on auto-stop, final kept', text() === AYAH1, text());

  // 12. A wrong word can be fixed by hand — delete just that word, no
  //     Clear needed — and Verify posts exactly the fixed text.
  micTap(); lastInstance().result([BISMILLAH]); lastInstance().end();
  check('two segments accumulated for the edit test', text() === AYAH1 + ' ' + BISMILLAH, text());
  btn('speak-verify-text').value = AYAH1; // user deletes the wrong second segment by hand
  fireInput(btn('speak-verify-text'));
  check('hand edit syncs to committed text', text() === AYAH1, text());
  check('Verify enabled after hand edit (finals remain)', btn('btn-speak-verify-check').disabled === false);
  const callsBeforeEdit = fetchCalls.length;
  btn('btn-speak-verify-check').click();
  await new Promise(r => setTimeout(r, 50));
  const bodyEdit = JSON.parse(fetchCalls[fetchCalls.length - 1].opts.body);
  check('Verify posts the hand-fixed text, not the old text', fetchCalls.length === callsBeforeEdit + 1 && bodyEdit.transcript === AYAH1, bodyEdit.transcript);

  // 13. Edit WHILE listening is not synced (dictation parity): the next
  //     result rebuild overwrites it.
  btn('btn-speak-verify-clear').click();
  micTap();
  lastInstance().result([BISMILLAH]);
  btn('speak-verify-text').value = 'EDITED';
  fireInput(btn('speak-verify-text'));
  lastInstance().result([AYAH1]);
  check('mid-session hand edit is overwritten by next result', text() === AYAH1, text());
  lastInstance().end();

  console.log(fail === 0 ? '\nALL CHECKS PASSED' : `\n${fail} CHECK(S) FAILED`);
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('HARNESS ERROR:', e); process.exit(1); });
