# Duas audio-clip fix — PORT from v116, COMPLETE, NOT deployed

**Date:** 2026-11-05 · **Copy:** `~/workspace/quran-shazam/` (Nov 4 working copy) ·
**Source:** `~/workspace/quran-shazam-v116/` (preferred live lineage; fix2 has the same files) ·
**User's rule (2026-10-23):** the 🔊 button must play EXACTLY the dua text on the card — no more, no less. Short cards stay short; the audio is clipped, never the text lengthened.

## Diagnosis (parent-verified, confirmed here)

This copy never received the Oct 23 fix2 clip fix: `duas.js` played Quranic duas via
FULL-AYAH everyayah MP3s (`playQariForDua` → whole ayah), `duas.py` had NO `clip`
fields, and `backend/app/static/audio/duas/` did not exist. User's screenshot
(`Screenshot_20261105-135733.png`) shows Hasbunallahu (Quran 3:173) playing — its
displayed dua is 3 words while the full ayah is 17 words, so the whole-ayah audio
was audibly longer than the text. The fix existed in both other lineages.

## What was ported

| File | Change |
|---|---|
| `backend/app/engine/duas.py` | Header AUDIO RULE + QS-16 comment; `clip` fields on the 5 Quranic duas; 14:41 typo fix (card said رَبِّ, Quran 14:41 says رَبَّنَا — the clip recites رَبَّنَا, so the card now matches the ayah exactly, audio == text). **File is now byte-identical to v116's.** |
| `backend/app/templates/duas.html` | Say button renders `{% if d.clip %}data-dua-clip="{{ d.clip }}"{% endif %}`. Heading kept `h3`, wording kept "Suno" (v116's `h2` / "Suniye" are separate changes — see below). |
| `backend/app/static/js/duas.js` | New `playDuaClip()` (plays `/static/audio/duas/<clip>`, same stop/toggle + `duaGen` stale-guard machinery); click handler now prefers the clip over the whole-ayah stream. Wording kept "Rok do / Stop" to match this copy. `quran.js` untouched; TEAM 2 qari-routing (Quran ref → Qari, hadith-only duas → Arabic TTS) untouched. |
| `backend/app/static/audio/duas/` (new) | 5 MP3s copied from v116, **byte-identical (md5-verified)**: `dua_0_2_201.mp3`, `dua_1_14_41.mp3`, `dua_3_3_173.mp3`, `dua_4_20_25_26.mp3`, `dua_7_21_87.mp3`. |
| `backend/scripts/build_dua_clips.py` + `dua_clip_cuts.json` (new) | The deploy-time clip generator (stdlib-only, idempotent) + its deterministic cut table — ported so this copy can regenerate the clips; it is what the `duas.py` QS-16 comment references. |
| `tests/test_duas_audio.py` (new) | Ported from v116 **verbatim** (identical diff): the clip invariant — Quran duas carry `clip`, clip files exist + are valid MP3s, hadith duas carry NO clip, references valid vs corpus, backend/frontend reference grammar in sync. |

## Deliberately NOT ported (separate fixes, out of scope)

- `h2` vs `h3` dua title heading (v116) and the "Suniye / Rokiye" formal wording — cosmetic changes from other fixes; this copy keeps `h3` / "Suno / Rok do".
- The progress-aware stall watchdog in v116's `playQariForDua` (TASK 2, Oct 23 audit) — a different bug in the whole-ayah fallback path, which is now nearly dead code (every Quran dua has a clip; hadith duas use TTS).

## Verification (all run by the coordinator)

- **MP3 validity (ffprobe):** all 5 are MP3, durations vs `dua_clip_cuts.json` expected:
  2:201 12.64s (exp 12.64), 14:41 10.53s (exp 10.53), 3:173 3.80s (exp 3.73, +0.07),
  20:25-26 6.98s (exp 6.83, +0.15), 21:87 12.60s (exp 12.51, +0.09) — all within
  the 0.15 s tolerance v116 verified against. Sizes 67–216 KB (all > 10 KB).
- **Template render check (Jinja2, no server):** `data-dua-clip` appears exactly
  5 times (the 5 Quranic duas) across 8 say buttons — hadith duas correctly get none.
- **`node --check` duas.js:** OK. **`py_compile`:** duas.py, build_dua_clips.py, test file — OK.
- **New tests:** `tests/test_duas_audio.py` — **5/5 passed**.
- **Full suite:** **154 passed** (was 149 + 5 new), 21 s, no regressions.
- **Residual diff vs v116:** `duas.py` identical; `duas.html`/`duas.js` differ only in
  the deliberately-not-ported items above; test file identical.

## Flags for the parent (decisions, not blockers)

1. **QS-16 zip policy:** v116's comment says the clips are NEVER shipped in release
   zips / deploy tarballs / Docker images and are instead generated at deploy time
   by `build_dua_clips.py`. This port copied the MP3s into the working copy per the
   parent's order, AND ported the generator — so either path works. Before the next
   zip/deploy, confirm whether the zip exclusions keep or drop
   `backend/app/static/audio/duas/` (if dropped, the deploy step must run the
   generator; if kept, the MP3s ride along as they do in v116's live codespace).
2. **Pre-existing quirk (both lineages, NOT fixed):** the say button is disabled
   when `speechSynthesis` is unavailable — even though clip playback does not need
   TTS. On the user's Chrome phone this does not trigger; left as-is.

## What remains UNVERIFIED — phone test is the ONLY verdict

No live test possible here (no engine on this VM; server stopped by the user's own
order, untouched). In particular, **no clip has actually been heard here** — file
validity, durations, wiring and tests are verified, but whether Hasbunallahu plays
only ~3.8 s of "Hasbunallahu wa ni'mal-wakil" (and nothing more) can only be proven
on his phone after a deploy he orders.

**Phone-test steps:** open /duas → ▶️ on Hasbunallahu (Quran 3:173) — should last
~3.8 s and stop, no extra words → ▶️ on Rabbana Aatina (~12.6 s) → tap again
mid-play = stop → a hadith dua (e.g. Allahumma Ajirni) still speaks via Arabic
TTS → 14:41 card now reads رَبَّنَا اغْفِرْ لِي...

**NOT deployed. No codespace touched, no server started.**
