# Record-live removal — FINAL REPORT (2026-11-04)

**Scope kept:** all work in `~/workspace/quran-shazam/` (the Nov 4 working copy) only.
`~/workspace/quran-shazam-v116/` was never touched (sanity-checked after the edit:
its `verify.html` still contains the old record-live buttons — proof it was left alone).
No deploy, no codespace touch, no server started, no public link, no Python/backend
change, no `style.css` change, no home-page change.

**User decision (Roman Urdu, quoted):** "Es recording sy results koi bhi thk nhi aty
to mujy lagta esy hata dyna thk rahy ga qk es ka kaam bhi voice ly ka osy text ma
convert krna hy woo opr wala mic card bhi kr dyta hy" — Record live should go:
recording results never come out correct, and the speak-verify mic card above
already does voice-to-text.

## 1. What was removed

### `backend/app/templates/verify.html` — 204 → 159 lines (−46 lines, old L59–103)
Inside the "Your recitation" card, the ENTIRE first `<div class="field">` was removed:
- "🎙️ Record live" label + recorder box (`recorder-box`, `rec-dot`, `rec-timer`,
  `btn-start`, `btn-pause`, `btn-stop`)
- the microphone-permission hint tied to recording
- `mic-meter-wrap` (`mic-meter`, `mic-label`)
- the Tips `<details class="tips-box">` block
- `rec-preview` (`rec-audio`) + its hint

After the edit the card reads cleanly: heading → "📁 Or upload a file" field directly
(verified: `verify.html` L57 heading, L59 upload label, L61 dropzone).

### `backend/app/static/js/verify.js` — 1750 → 1491 lines (−259 lines)
- The entire recording section (old L194–410, ~10.5 KB): `pickMimeType`,
  `extFromMime`, `startLevelMeter`, `stopLevelMeter`, `setRecUI`, `resetRecording`,
  and the `btn-start` / `btn-pause` / `btn-stop` handlers with MediaRecorder setup,
  recording timer, meter driving, preview handling, and the silent-mic guard.
- `micErrorMessage()` (old L157–169) — its only caller was the removed Start handler.
- File-change handler: dropped 3 recorder-only lines (`recordedBlob = null`,
  `rec-preview` hide, `btn-start` text reset); the rest untouched.
- Verify handler: dropped the `'recording'` branch and the
  `'recording' + recordedExt` default filename; the upload branch is unchanged.
- `audioSource` narrowed to upload-only (`'upload' | null`, new L28) with an
  explanatory comment; `refreshVerifyButton()` logic itself is untouched.
- Stale comments reworded to upload-only wording (old P1 two-source comment,
  old `refreshVerifyButton` record-stop comment).

### Consequential retargets (required by the grep=0 rule, flagged honestly)
Two kept handlers referenced the removed recorder element behind a null guard, so
they would not have thrown — but they would have failed the zero-reference grep
and scrolled nowhere. Both now scroll to the upload dropzone instead:
- `fb-rerecord` ("Record a clearer clip" button in the results fallback banner;
  its HTML label was kept per scope): now scrolls to `$('dropzone')` and its status
  line says "upload a shorter, clearer clip" (new L594–600, with an explanatory
  comment).
- Coach "Dobara parhein" retry (new L977/986): now scrolls to the upload area
  with the hint "Ek ayat akeli upload karein, phir Verify dabayein."
- No null guards were added anywhere — removal only, as preferred.

## 2. What was kept and why

- **Card + "Your recitation" heading, "📁 Or upload a file" field** (dropzone,
  `#file` input, `dz-filecard`, `dz-error`, upload hint), **`#btn-verify`**,
  `#btn-cancel`, `#progress`, `#status`, `#live-transcript` — the upload path is
  the surviving audio-evidence route, so all of it stays.
- **Speak-verify card + entire `setupSpeakVerify` block** — untouched by region
  comparison; `rec.continuous = true` still present (new L1326). This is the mic
  path the user pointed to, and its 2026-11-04 continuous-mic behaviour is intact.
- **Upload/dropzone/waveform handling, verify-job flow, transcript edit/rematch,
  coach/history rendering** — untouched; the Verify click still posts the file
  through the existing XHR/`FormData` → `/api/verify` → `attachToJob` flow.
- **Coach word-practice recorder** (`practiceRec`, its own `MediaRecorder` /
  `getUserMedia` at ~L1061+) — a separate, self-contained recorder, NOT the
  removed Record-live one; it uses none of the removed IDs, so it stays.
- **Shared helper `fmtTime`** — kept: still used by `statusLine` (ETA display).
  `extFromMime` was NOT shared (only used in the removed `onstop`), so it was
  removed — verified by grep, not assumed.
- **`audioSource` mechanism** — kept in upload-only form: `refreshVerifyButton()`
  is untouched in logic (`ready = !polling && audioSource !== null && engineReady`,
  new L60) and still drives both `#btn-verify` and the sticky bar.
- **`style.css`, home-page copy, backend** — untouched per scope. Home-page step 1
  still says "Record or upload" (see follow-ups below).

## 3. Verification evidence (lead re-checked, not taken on trust)

All commands run by the lead against `~/workspace/quran-shazam/` after the edit:

- `node --check backend/app/static/js/verify.js` → **PASS**.
- Removed-ID grep (`btn-start|btn-pause|btn-stop|rec-timer|rec-dot|recorder-box|
  mic-meter|mic-label|mic-meter-wrap|rec-preview|rec-audio`):
  - `verify.html` → **exit 1, zero matches**.
  - `verify.js` → **exit 1, zero matches**.
  - All other templates (`--exclude=verify.html`) → **exit 1, zero matches**.
- Leftover-recorder-variable grep (`recordedBlob|recordedExt|mediaRecorder|
  recStream|recTimer|recSeconds|pickMimeType|extFromMime|startLevelMeter|
  stopLevelMeter|setRecUI|resetRecording|micErrorMessage`) → **one hit only**:
  the word `recordedBlob` inside the new historical comment at `verify.js` L22
  explaining the removal — comment-only, no executable reference.
- Upload-flow code-read (new line numbers): change handler L203–211 sets
  `audioSource = 'upload'` only if a file survives `showFileCard` validation, then
  calls `refreshVerifyButton()`; Verify handler L351 takes
  `file = fileInput.files[0]` when `audioSource === 'upload'` and returns if no
  file; `dz-remove` handler (L195) clears `audioSource` when the upload is
  removed. Conclusion: **upload alone enables "Verify recitation" + the sticky
  bar** (subject to the pre-existing engine-ready gate), and the Verify click
  posts the uploaded file via the unchanged job flow.
- Speak-verify intact: card at `verify.html` L32 ("🎤 Awaz se foran verify
  karein"), `setupSpeakVerify` at `verify.js` L1134, `rec.continuous = true`
  at L1326.
- **No live/browser test was run** (no server per constraints). `node --check` +
  grep + code-read is the evidence available here; a phone test after a deploy
  the user orders remains the real verdict, as usual.

## 4. Two honest notes for the user (do not hide these)

1. **Removal does NOT improve accuracy.** An uploaded recording goes through the
   exact same Whisper pipeline as a live recording did. The same audio yields the
   same transcript either way — so if a recording's results were wrong, the cause
   was the audio itself (pace, noise, mic distance, unclear words), not the
   record button. Removing Record live removes a way to supply audio; it does not
   fix transcription quality. The tips that used to guide good recordings
   (quiet room, 15–20 cm, one ayah at a time) went away with the block.
2. **The speak-verify card above is a text-only quick check, NOT audio-evidence
   verification.** It uses the browser's speech service (Google in Chrome) to
   dictate text, then matches that text — it never verifies audio evidence.
   After this removal, **real audio verification survives only via file upload**:
   record in another app, upload the file, press Verify.

## 5. Follow-ups the user may order (not done, by scope)

- Home-page step 1 still says "Record or upload" — now only "upload" is true on
  /verify. Updating that copy is a separate small change.
- The results fallback banner button still reads "🎙️ Record a clearer clip" in
  HTML (its handler now correctly scrolls to upload); renaming the label is a
  follow-up.
- The speak-verify card's own hint still says "mukammal audio evidence ke liye
  Record/upload istemal karein" — left untouched per the do-not-touch constraint;
  it now slightly over-promises (upload is the only audio-evidence route).
- `style.css` still contains now-inert `.rec-dot` rules (L192–193, L309) and a
  comment mentioning `#mic-meter-wrap` (L308); harmless (they style elements
  that no longer exist), droppable in a future CSS cleanup.

## 6. End state

Fixed copy + this report, **NOT deployed, server NOT started**. Deploy only on
the user's explicit order, from `~/workspace/quran-shazam/` (the same deploy
could also carry the earlier Q&A removal, Resume hero-top move, promo-heading
fix, and speak-verify continuous port already in this copy — only if he orders
them together).
