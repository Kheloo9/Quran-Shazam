# ADR 0005 — Honest confidence labels (never claim certainty)

- **Status:** Accepted (2026-10-12, standing rule)
- **Context:** This is the Quran. A false "VERIFIED" on a wrong ayah would be a
  religious-integrity failure, not just a software bug. ASR is imperfect, so
  some uncertainty is unavoidable.
- **Decision:** Labels describe *evidence strength only*: VERIFIED TEXT MATCH
  (score≥90, coverage≥85, missing≤25, ≥3 words), GOOD (≥80), POSSIBLE (≥70),
  LOW (<70), SEQUENCE RECOVERY (inferred, not heard). 200-user campaign:
  196/200 PASS with **0 false VERIFIED**; 50-user recording loop: 0 false
  VERIFIED. The no-speech gate rejects <3-word clips rather than guessing.
- **Consequences:** (+) Trustworthy for a religious text; defensible in viva.
  (−) Users sometimes see POSSIBLE/LOW on correct recitations — mitigated by
  Edit + Re-match and the uncertainty banner, never by inflating scores.
