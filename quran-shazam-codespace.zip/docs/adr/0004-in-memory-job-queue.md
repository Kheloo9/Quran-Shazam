# ADR 0004 — In-memory job queue (not Celery/Redis)

- **Status:** Accepted (2026-10-18)
- **Context:** Verification takes 10–120s; HTTP requests must return instantly
  (202 + polling), so jobs need a queue. Options: in-memory store, Celery+Redis,
  or a hosted queue.
- **Decision:** In-memory `JobStore` with configurable worker threads
  (`JOB_WORKERS`, default 1), results expiring after 30 minutes, uploads
  deleted after verification.
- **Consequences:** (+) Zero extra infrastructure — runs on free Codespaces;
  privacy-friendly (nothing persists). (−) Jobs die on restart; no horizontal
  scaling. Acceptable: single-user FYP scope. Migrate to Redis only if
  concurrent-user load demands it.
