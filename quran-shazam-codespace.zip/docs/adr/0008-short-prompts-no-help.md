# ADR-0008: Short per-candidate prompts don't help (Stage 3 negative result)

Date: 2026-10-21
Status: ACCEPTED (experiment concluded — do NOT integrate)

## Context

ADR-0003 proved FULL-SURAH initial_prompts HURT Whisper (guided 2/7 vs
unguided 7/7 ayat). The 15-IT-team study suggested a narrower variant —
Stage 3: SHORT per-candidate prompts (first ~8 words of the candidate
ayah) to rescue hard clips. This experiment tested it honestly,
including an anti-hallucination control.

## Method

scripts/test_short_prompt.py — 3 hard clips (hus_fatihah_003 = the
22x NO-MATCH clip, falaq_noisy, asr_fast). Each transcribed 3 ways:
(a) no prompt, (b) short TRUE prompt, (c) short WRONG prompt
(112:1-2 text on non-112 audio — must NOT hallucinate 112's words).

## Results

- hus_fatihah_003: all 3 runs byte-identical ("الرحمن الر حين والمؤمنين",
  4 words). The true prompt did NOT rescue the clip.
- falaq_noisy / asr_fast: tiny tail-word differences between runs, but
  uncorrelated with the prompt — within the model's known run-to-run
  variance (see ADR-0006).
- Control: wrong prompt never injected the wrong ayah's words
  ("احد"/"الصمد" absent everywhere) — no hallucination, but also no help.

## Decision

**Do NOT integrate prompt-constrained re-transcription.** Two
independent experiments (ADR-0003 full-surah, this ADR short prompts)
now agree: initial_prompt does not improve Quranic ASR on this model.
The hard clips are hard because of acoustics (short/fast/noisy), not
because the decoder lacks context.

FYP STUDY GUIDE: a negative result is a result. We spent real compute
to kill an attractive idea before it could waste more — that is what
"professional" means.

## Consequences

- `ASR_GUIDED` stays OFF; no prompt path in the pipeline.
- Hard-clip strategy remains: honest NO-MATCH / LOW labels (never
  force a match), single-ayah re-record guidance in Coach.
- Revisit only if the ASR model itself changes.
