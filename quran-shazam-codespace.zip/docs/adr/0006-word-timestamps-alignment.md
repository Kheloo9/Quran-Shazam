# ADR-0006: Word-level timestamps for forced alignment (Coach Stage 4-lite)

Date: 2026-10-21
Status: ACCEPTED (validated on real audio)

## Context

The 15-IT-team design study (PROFESSIONAL_VERIFY_REDESIGN.txt) recommended
Stage 4: forced alignment — telling apart a MISSED word from a
MISPRONOUNCED (substituted) word per ayah, instead of the old flat
"missed words" list. The cheapest honest primitive is the ASR model's own
word timestamps (faster-whisper `word_timestamps=True`).

## Decision

- Enable `word_timestamps=True` in `QuranASR._transcribe_chunk` (asr.py).
- Extract per-word `{w, start, end}` from `seg.words`; shift by chunk
  offset in the merge loop; expose via `segments[].words` in the verify
  result (service.py already passed `segments` through).
- `coach.align_words()` (coach.py): difflib alignment of expected ayah
  words vs heard words -> per-word status
  `matched | substituted | missed | extra`, with timestamps taken ONLY
  from the model's own word timings. Words the overlap-dedup dropped get
  `t_start=None` — timings are never invented.
- Near-miss tolerance (>=80 similarity, same as `_is_heard`) keeps
  "matched" vs "substituted" consistent with the old missed-words logic.
- Frontend (verify.js + style.css): substituted words render as
  `expected → heard` chips under the existing missed-word chips.

## Validation (honest A/B on the golden Al-Fatihah file, real model)

1. First comparison LOOKED like a regression: new run = 42 words /
   8 results (extra 2:1 POSSIBLE from tail garbage) vs old run = 36
   words / 7 results.
2. Re-ran the OLD code (flag off) a second time: it ALSO produced
   42 words / 8 results. Conclusion: the difference was the model's
   **pre-existing run-to-run variance**, NOT the flag. No phantom fix
   was shipped.
3. Core metrics stable across runs: **4 VERIFIED** every time,
   0 false VERIFIED.
4. Alignment quality on the real run: ayah 1:1 all 4 words matched with
   real timestamps (e.g. بسم 5.68–7.08s); 31 aligned words, 29 with
   timestamps, 3 substituted / 2 missed — all plausible.
5. Unit tests: 10 new tests in tests/test_word_alignment.py
   (substitution/deletion/insertion/near-miss/timestamp mapping/RECOVERY
   safety/backward compat). Full suite: 71/71 green.

## Consequences

- Coach feedback is now genuinely word-level: "chhoota lafz" vs
  "ghalat lafz" are distinguished, with timings — the core of the
  15-team Stage 4 recommendation, at ~zero inference-cost increase
  (word timestamps ride on the existing decode).
- The honesty architecture is unchanged: labels, gates and thresholds
  untouched; alignment is evidence display, not a new verdict.
- Known: transcription has inherent run variance (36–42 words on the
  same file); the honest labels absorb it. Not caused by this change.
