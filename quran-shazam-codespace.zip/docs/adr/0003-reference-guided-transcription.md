# ADR 0003 — Reference-guided transcription (two-stage verify)

- **Status:** REJECTED after validation (2026-10-19). Code kept behind
  `ASR_GUIDED` flag (default OFF) for future experiments.
- **Context:** Blind transcription invents non-Quranic words ("كذبير"). The
  professional idea: condition Whisper on the expected surah's ayat via
  `initial_prompt`. Implemented as two-stage verify (Stage A: transcribe first
  ~15s → identify surah with score ≥ 70 gate; Stage B: full transcribe with
  the surah's ayat as prompt).
- **Decision:** Do NOT enable. Validated head-to-head on the client's real
  Al-Fatihah MP3 through the production pipeline:
  unguided: 36 words, 7/7 ayat, 4 VERIFIED · guided: 34 words, **2/7 ayat**,
  0 VERIFIED (matched to wrong surahs 27:30, 45:36).
- **Root cause:** the full-surah prompt pushed the decoder into "Quran mode",
  and it HALLUCINATED an isti'adha opening ("واوذ بالله من الشيطان الرجيم")
  that isn't cleanly in the audio. The strip patterns missed the spelling
  variant ("واوذ" vs "أعوذ"), the leading garbage derailed the matcher —
  the same failure mode ADR-fixed for real isti'adha, now self-inflicted.
- **Consequences:** A prompt containing the *expected answer* can derail
  Whisper rather than help it. Future work: try a SHORT style-hint prompt
  (1–2 phrases) instead of the full surah text — but only with the same
  honest head-to-head validation before enabling.
