# ADR-0007: Confidence thresholds validated — no change (Stage 5)

Date: 2026-10-21
Status: ACCEPTED (validated, thresholds UNCHANGED)

## Context

The 15-IT-team study recommended Stage 5: calibrate the verdict
thresholds (config.py: verified_score=90, verified_coverage=85,
verified_missing=25, GOOD>=80, POSSIBLE>=70) against real outcomes
instead of hand-set values.

## Method

Calibration script over the genuine 20-user campaign feedback
(FEEDBACK_20USER_AZ.json): 31 usable attempts (11 network ERRORs
excluded), 80 individual matches, each with ground-truth
(expected_surah/expected_ayat) vs the label+score the pipeline assigned.

## Results

| Label    | Precision      |
|----------|----------------|
| VERIFIED | 43/43 = 100%   |
| GOOD     | 7/7   = 100%   |
| POSSIBLE | 21/21 = 100%   |
| LOW      | 6/9   = 66.7%  |

- Wrong matches labeled VERIFIED or GOOD: **0**.
- Score-band precision: 70–100 bands all 100%; 60–69 band 66.7%
  (correctly labeled LOW — "don't trust this").

## Decision

**Do NOT change the thresholds.** They are already well-calibrated:
100% precision where it matters (VERIFIED/GOOD), and the weak band is
honestly labeled LOW. Tightening further would trade recall for no
precision gain; loosening would risk the first-ever false VERIFIED.

FYP STUDY GUIDE: calibration means "check your grading rubric against
real answer sheets". Our rubric already grades correctly — so the
professional move is to document the proof, not to fiddle with it.

## Consequences

- Thresholds stay: 90/85/25 (VERIFIED), 80 (GOOD), 70 (POSSIBLE).
- Re-run this calibration after any matcher/ASR change (script:
  /tmp/calibrate.py pattern — promote to tests/scripts if reused).
- The 5h-loop aggregates (307 FULL-VERIFIED, 0 WRONG-MATCH) independently
  confirm the same picture at larger scale.
