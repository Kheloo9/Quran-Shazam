# ADR-0010: Word-confidence "uncertain" status (don't punish AI's doubt)

Date: 2026-10-21
Status: ACCEPTED (validated on real audio)

## Context

User's question: "AI ghalat sunta hai — agar lafz wohi bola gaya tha to
kya solution hai?" The honest answer has two layers: (1) make the AI
hear better (already done: Quran-tuned model, raw mic feed, VAD tuning,
beam search — prompts and bigger models proven useless in ADR-0003/
ADR-0008), and (2) **never punish the reciter for the AI's own
uncertainty**. This ADR implements layer 2.

## Decision

- asr.py `_words_of` now captures each word's model probability `p`
  (0..1), carried through segments into the verify result.
- coach.py `align_words`: a "substituted" word with `p < 0.70` becomes
  **"uncertain"** — the AI probably misheard. It is NOT counted in
  `missed_words`, does NOT break "perfect" status, and renders as a
  blue "?" chip ("AI khud sure nahi — aapki ghalti nahi").
- `prob=None` (no data) keeps the old "substituted" behavior — we never
  assume doubt without evidence.
- Verdict labels (VERIFIED/GOOD/POSSIBLE/LOW) are UNTOUCHED — this is
  Coach-display honesty, not verdict inflation.

## Calibration (golden Al-Fatihah file, real model)

| Word | ref → hyp | p | Status |
|------|-----------|---|--------|
| 1:6 المستقيم → المسلقين | 0.917 | substituted (model confident — genuine feedback) |
| 1:7 عليهم → عذين | 0.674 | **uncertain** (model unsure — not blamed) |
| 1:7 ولا → وللضالين | 0.827 | substituted (model confident) |
| 25 matched words | med 1.00 | matched (one at 0.30 stays matched — it agrees with text) |

Threshold 0.70 is conservative and documented; re-validate if the ASR
model changes.

## Validation

- 6 new unit tests (uncertain/high-conf/no-prob/boundary/missed-
  exclusion/prob-passthrough); full suite 77+6 = 83 green.
- Live run: labels identical before/after (4 VERIFIED, 3 POSSIBLE,
  1 GOOD) — the change only reclassifies Coach evidence, never verdicts.
- Bug caught during implementation: the merge loop dropped `p`
  (rebuilt words without it) — fixed, covered by prob-passthrough test.

## Consequences

- FYP STUDY GUIDE: this is "epistemic humility" in code — the system
  reports what it knows AND what it doesn't. In the viva: "jab AI ko
  khud doubt ho to woh reciter ko ghalat nahi kehta."
- Future: the same `p` values can feed label calibration (ADR-0007
  rerun) if needed.
