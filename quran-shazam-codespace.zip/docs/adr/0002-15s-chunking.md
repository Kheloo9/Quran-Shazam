# ADR 0002 — 15-second ASR chunks (not 60s)

- **Status:** Accepted (2026-10-19)
- **Context:** Full-surah uploads lost their tail: Al-Fatihah MP3 gave 27 words,
  ayat 6–7 missing entirely ("ولا الضالين" never transcribed).
- **Decision:** Chunk audio into 15s windows with 3s overlap (was 60s/2s).
- **Evidence:** On the client's file: 60s chunk → 27 words, tail missing;
  20s → 27 words, tail missing; **15s → 35 words, 7/7 ayat recovered**
  (1:1 VERIFIED 98%, 1:2 100%, 1:4 96%, 1:5 92%). Root cause: a long chunk
  forces two internal 30s Whisper windows in one decode; the 2nd under-generates.
- **Consequences:** (+) Complete transcripts. (−) ~1.6x ASR time (still seconds).
  Configurable via `ASR_CHUNK_SECONDS` / `ASR_OVERLAP_SECONDS`.
