# ADR 0001 — Keep whisper-base-ar-quran (74M) instead of larger models

- **Status:** Accepted (2026-10-19)
- **Context:** Transcription word-errors ("كذبير") suggested a bigger model might
  fix quality. Three models were tested head-to-head on the client's real
  Al-Fatihah MP3 through the identical production pipeline.
- **Decision:** Keep `tarteel-ai/whisper-base-ar-quran` (74M, 277MB) as default.
- **Evidence:** base: 36 words, 7/7 ayat, 4 VERIFIED, 7.0s · small-quran (244M):
  35 words, 23.3s (3.3x slower, no real gain) · large-v3-turbo-ar-quran (809M):
  27 words, **5/7 ayat** (loses 1:2, 1:3 under the production noise gate), 64.5s,
  1.6GB. Full numbers: `BIGGER_MODEL_TEST.txt`.
- **Consequences:** (+) Fast CPU inference, small download, best ayat recovery.
  (−) Residual word-level errors are honestly labelled, not hidden. Revisit if a
  Quran-tuned model beats base on *ayat recovery* (not just WER) in production.
