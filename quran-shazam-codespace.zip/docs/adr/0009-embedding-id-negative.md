# ADR-0009: Embedding ID validated — generic wav2vec2 NOT ayah-discriminative

Date: 2026-10-21
Status: ACCEPTED (experiment concluded — module stays ADVISORY-ONLY)

## Context

The 15-IT-team study recommended Stage 2: identify the ayah from an
audio fingerprint (wav2vec2 embedding) instead of transcribed words.
`engine/embed_id.py` implements it; this ADR records the honest
validation (scripts/validate_embed_id.py, 34 real per-ayah clips,
6 qaris, facebook/wav2vec2-base, mean-pooled 768-dim, cosine).

## Results

(a) Strict cross-qari (index = ONE qari's clips, query = other qaris):
    top-1 2/2 = 100% — but N=2 (only 1:1 and 1:5 had 2 qaris). Weak evidence.

(b) Leave-one-clip-out (query vs ALL other clips, mixed qaris):
    top-1 0/34 = 0.0%, top-3 0/34 = 0.0%.

The failure pattern is the finding: misses are almost always the SAME
qari's NEIGHBORING ayah (114:1→114:2 @0.93, 113:2→113:3 @0.95,
1:2→1:3 @0.93…). Mean-pooled wav2vec2-base fingerprints capture
SPEAKER + SURAH style very well, but NOT ayah-level distinctions —
same-voice neighbors (sim 0.86–0.96) outrank the true ayah.

## Decision

**Do NOT promote embedding ID beyond advisory.** The generic,
non-Quran-tuned wav2vec2-base fails the study's own bar (top-1 ≥93%).
This confirms the study's Risk #1: the embedding model must be
validated for Quranic Arabic — and this one isn't.

FYP STUDY GUIDE: this is why we validate before integrating. A
fingerprint that "sounds similar" is not the same as "same ayah" —
the model hears *who* is reciting more clearly than *what* is recited.

## Consequences

- `engine/embed_id.py` + the `embedding_candidates` field stay as
  ADVISORY-ONLY infrastructure (fail-open, zero cost when the index is
  absent). They never touch verdicts.
- The stale 34-clip validation index was deleted; a production index
  must be rebuilt from full reference audio IF a better embedding
  model is ever validated.
- Path forward (future work, not now): a Quran-fine-tuned embedding
  model, or temporal (non-mean-pooled) matching. Both need their own
  validation like this one.
- The text-matcher pipeline remains the primary ID — it gets
  ayah-level right where generic embeddings fail (0 false VERIFIED
  across 750+ attempts).
