# Voice Q&A Removal + Resume Relocation — Fix Report (2026-11-04)

Copy fixed: `~/workspace/quran-shazam/` (the Nov 4 copy) ONLY.
`~/workspace/quran-shazam-v116/` was never touched. NOT deployed.
No server was started, no codespace was touched, no link was published.
The live site was stopped at the time of this work; deploying this fix
needs the user's explicit order.

## 0. Why the feature was still showing

On 2026-10-24 the user ordered "AI wala hata do" and v11_14 removed
Voice Q&A entirely — but that removal lived only in the v11x snapshot
lineage (v116 is clean). The Nov 4 work and deploy used the different
directory `~/workspace/quran-shazam/`, which never received the removal,
so the Nov 4 GitHub-sync deploy resurrected the feature live. This fix
applies the v11_14 removal recipe to THIS copy. A second task from the
user, sequenced into the same merge to avoid `quran.html` conflicts, is
covered in §6 (Resume relocation).

## 1. What was removed — Voice Q&A ("Ask about the Quran")

### 1.1 Template — `backend/app/templates/quran.html`
- Deleted the Q&A card (old lines 32–46): `<section class="card voice-qa
  reveal">`, the `🎙️ Ask about the Quran` heading, the intro paragraph,
  `#qa-chips`, the `.voice-row` holding `#voice-btn` / `#qa-input` /
  `#qa-ask`, `#voice-status`, `#qa-answer`, `#qa-history`, and the
  section closer.
- The translator block was NOT deleted (see §2) — it was re-homed as its
  own plain section in the same position (now lines 32–49).
- Script tag swapped (now line 177): `voice_qa.js` → `translator.js`
  (cache-buster `?v={{ asset_v }}` kept).
- No other section touched: bookmarks, collections, notes, progress,
  parah, surah grid, reader all intact in place.

### 1.2 Frontend JS — `backend/app/static/js/voice_qa.js` DELETED
- The 955-line file is gone from disk (confirmed by `ls`).
- Its Q&A code (askQuestion, qa-chips/history, sayBar,
  `/api/quran/ask` fetch) is gone with it. The translator portion was
  extracted first (see §2) — nothing else was salvaged from it.

### 1.3 CSS — `backend/app/static/css/style.css` (904 → 869 lines)
- Removed Q&A-only rules: `.voice-qa`, `#voice-btn` / `.listening` /
  `.pulse-dot` + `@keyframes qs-pulse-dot`, `.qa-chips`, `.qa-chip`,
  `.qa-answer`, `.qa-q`, `.qa-card` (+ variants), `.qa-actions`,
  `.qa-hit` (+ variants), `.qa-loading`, `.qa-spinner` +
  `@keyframes qs-spin`, `.qa-error`, `.qa-suggest`, `.qa-history`,
  `.qa-hist-title`, `.qa-hist-item` (+ variants). The `.qa-card` token
  was also removed from three shared selector lists; the other
  selectors in those lists are untouched.
- Kept: all `.voice-row` rules (the translator uses them), all
  `.translator-block` / `.tr-*` rules, and everything else.
- Brace balance after edit: 449 open / 449 close.

### 1.4 Backend — `backend/app/main.py`
- Deleted the import (old line 54):
  `from .engine.quran_qa import QuranQA`.
- Deleted the endpoint block (old lines 495–509 + trailing blanks):
  `@app.get("/api/quran/ask")` and the `quran_ask` function.
- Untouched and verified still present: `/api/quran/search` and
  `/api/quran/translate` (`quran_translate` intact). Post-edit grep for
  `QuranQA` / `quran_qa` in `main.py` = 0.
- `python -m py_compile` on `main.py` passes.

### 1.5 Engine — `backend/app/engine/quran_qa.py` DELETED
- The 370-line file is gone from disk (confirmed by `ls`).
- `backend/app/engine/__init__.py` was verified empty (0 bytes) — no
  import of it existed to remove.
- `backend/app/engine/quran_reader.py`: one dangling comment reworded
  (old lines 464–466, "Same defence as QuranQA _clean_topic…" → generic
  wording). No logic changed. This removes the last `QuranQA`
  reference in backend Python code.

### 1.6 Docs — `backend/app/templates/about.html`
- Removed old line 40 from the API list:
  `GET /api/quran/ask?q=... # voice Q&A about the Quran`.
- `security.html`, `README.md`, `SECURITY.md`, `docs/*.md` were grepped:
  zero references to the Q&A feature (the only `docs/adr/` hit is about
  ASR mishearing, unrelated, kept). No unrelated docs were rewritten.

### 1.7 Tests — `tests/test_qa_removed.py` (NEW, 4 tests)
- No existing test referenced `quran/ask` or `QuranQA` (verified), so
  there was nothing to convert — the new file IS the repoint, and its
  header documents this.
- Tests: `test_quran_ask_route_is_gone` (GET with query → 404),
  `test_quran_ask_route_is_gone_without_query` (→ 404),
  `test_no_ask_route_in_route_table`,
  `test_translate_route_still_present` (guard against over-deletion).

## 2. What was preserved — Word Translator (WANTED, do not remove)

The translator is a separate, wanted feature (EN↔UR word translation
with Quranic context). It was preserved by extraction, not by keeping
`voice_qa.js`:
- NEW `backend/app/static/js/translator.js` (129 lines): the translator
  body extracted verbatim from old `voice_qa.js` lines 865–954 (the
  "word translator (Issue 5 + 6)" section, `/api/quran/translate` call
  intact), plus the helpers it needs carried over verbatim: `$` + `esc`
  (old lines 29–35) and `copyText` (old lines 754–768, generic clipboard
  code the translator's copy buttons call — not Q&A logic).
- One deliberate addition: an `if (!trInput) return;` guard replacing
  the old `if (!voiceBtn) return;` early-exit, which would otherwise
  have killed the translator now that `#voice-btn` is gone.
- Asserted during extraction: no `askQuestion`, `qaInput`, `voiceBtn`,
  `qaAnswer`, `qaChips`, or `/api/quran/ask` in the new file.
- Template side: the `.translator-block` (heading, direction tabs,
  `#tr-voice-btn` / `#tr-input` / `#tr-go`, `#tr-status`, `#tr-result`)
  is byte-identical, same position (directly after the hero, directly
  before bookmarks).

## 3. What was preserved — everything else (regression check)

- The 5 Nov 4 features are untouched: `qs-notes.js`,
  `qs-collections.js`, `qs-resume.js` (header comments only — see §6),
  `qs-filter.js`, `qs-parah.js`. All five serve HTTP 200 in the local
  smoke check (§4).
- CSS polish, bookmarks, tafseer, audio proxy: untouched. The full
  suite passing (§4) covers corpus, engine, coach, translator, word
  alignment, security edges, and jobs.
- Content rule kept: the site shows only Quran text + scholars'
  translations/tafseer. No AI-composed answers remain anywhere in live
  code (the rule-based `QuranQA` engine is deleted, not disabled).

## 4. Verification evidence

### 4.1 Greps — live references are ZERO
Run over `backend/app` + `tests/` (excluding `__pycache__` and the
asserted-absent test file):
- `qa-ask`, `qa-input`, `qa-chips`, `qa-answer`, `qa-history`,
  `voice-qa`, `voice_qa.js` (as a loaded script or element id),
  `quran_qa`, `/api/quran/ask`, `QuranQA` → 0 live references.
- `quran.html` forbidden greps: `qa-ask` 0, `qa-input` 0, `qa-chips` 0,
  `qa-answer` 0, `qa-history` 0, `voice-qa` 0, `voice_qa.js` 0.
- `quran.html` required greps: `tr-voice-btn` 1, `tr-input` 1,
  `tr-go` 1, `tr-result` 1, `translator-block` 1, `translator.js` 1.
- Deliberately kept, inert, reported (NOT live references):
  - `translator.js` header comment (lines 4–5) noting the extraction
    and that the Q&A feature was removed — a comment, not a string
    shown anywhere.
  - `verify.js` prose comments (lines ~598, 938, 960, 989) mentioning
    `voice_qa.js` as a pattern reference — comments only.
  - `test_qa_removed.py` header + assertions mentioning
    `/api/quran/ask` / `QuranQA` — these assert ABSENCE, not the feature.
  - Historical feedback logs (`FEEDBACK_NOTES.md`,
    `FEEDBACK_50SCHOLAR_SUMMARY.txt`,
    `TESTING_CAMPAIGN_MERGE_2026-10-22.txt`) mentioning `quran_qa.py`
    as completed past work — history records, not rewritten.

### 4.2 Syntax / node checks — all pass
- `node --check` on `translator.js` (new), `quran.js`, `bookmarks.js`,
  and all five `qs-*.js` files → OK.
- `python -m py_compile` on `main.py`, `quran_reader.py`,
  `test_qa_removed.py` → OK.

### 4.3 Test suite — 149 passed, 0 failed, 0 skipped
- Full suite re-run by the coordinator: `python3 -m pytest tests/ -q`
  → **149 passed** in ~20s (1 pre-existing Starlette TestClient
  deprecation warning, unrelated).
- Targeted: `test_qa_removed.py` + `test_translator.py` → 10 passed
  (4 new + 6 translator). Collection grew by the 4 new tests; no test
  was deleted and no failing test was silently dropped.

### 4.4 Local-only smoke check (this VM, NOT the codespace, no link)
Run with FastAPI TestClient against this copy's code:
- `GET /api/quran/ask?q=What is Surah Al-Ikhlas?` → **404** (endpoint
  gone, not merely hidden).
- `GET /quran` → 200: contains `translator-block`, `tr-input`, and
  loads `translator.js`; does NOT contain "Ask about the Quran",
  `qa-ask`, or `voice_qa.js`.
- `GET /static/js/translator.js` → 200;
  `GET /static/js/voice_qa.js` → 404.
- `GET /static/js/qs-notes.js`, `qs-collections.js`, `qs-resume.js`,
  `qs-filter.js`, `qs-parah.js` → all 200.
- `GET /api/quran/translate?q=mercy&direction=en2ur` → **200** with
  candidates (e.g. رحمت) once the app is fully warmed — see the
  warmup note below. Translator unit tests (6) pass independently.

### 4.5 Warmup note (honest, not a regression)
- Under the system `python3` on this VM, warmup fails with "The fast
  transcription engine is not installed (faster-whisper)" — so the
  reader stays in "warming up" and `/api/quran/translate` returns 503
  in that sandbox. This is an environment gap, NOT a change made here:
  no worker touched warmup, service, ASR, corpus, or reader code, and
  the pre-removal tree would 503 identically (the ask endpoint needed
  the same reader).
- Re-run under the full-dependency venv on this VM: warmup OK
  (`asr_device=cpu`, health `ready=True`, corpus 6236/114, ASR
  loaded), then `/api/quran/translate?q=mercy` → 200 with candidates.
  Translator end-to-end behaviour is therefore verified on the fixed
  tree.

## 5. Residuals (honest, not fixed here)

- **Live browser / phone test remains the final verdict.** The
  coordinator (a generic subagent) cannot operate the live browser, so
  no browser rendering was checked. After deploy, the phone check is:
  open /quran → no "Ask about the Quran" card anywhere; the Word
  Translator block works (type/speak a word → translation + ayat);
  Resume card placement per §6.
- A dead `qa` perf-budget key remains in the `/api/health` output
  (`perf_budgets` includes `qa: 10.0`). It exposes no feature and
  changes no UI; removing it was out of scope and left untouched.
- CSS comments mentioning Q&A history only (a rename note, a grammar
  note) were kept — comments, not rules.
- The translator block's divider styling is unchanged; it now sits at
  the top of its own card rather than inside the Q&A card. Cosmetically
  fine; restyling was out of scope.

## 6. Follow-up in the same merge — Resume relocation (user's request)

The user said the Resume / "Continue reading" feature sits on the home
page and would probably be better on the Quran page, above the Quran.
This is a RELOCATION, not a duplication.

### 6.1 What moved (exact placement)
- `backend/app/templates/quran.html`: added, immediately before the
  Surah list —
  - line 94: `<div id="resume-card" hidden></div>`
  - line 97: `<section id="surah-grid-section">`
  - Between them sits only the `<!-- Surah grid -->` comment. The div
    is therefore the last element before the Surah list, directly
    above it and directly below the Parah section. If the user wanted
    it higher (e.g. right under the hero), that is a one-line move —
    say so and it will be moved.
- `backend/app/templates/index.html`: the `#resume-card` div (old
  lines 15–17) and the `qs-resume.js` script tag (old line 61) are BOTH
  removed. Home now has **zero** `resume` references (verified by
  grep). The script tag was safe to drop: the only callers of
  `window.qsResume` are in `quran.js` (the Reader, loaded on /quran),
  and `qs-resume.js` is already loaded on /quran (now line 181) —
  nothing on home referenced it.
- `backend/app/static/js/qs-resume.js`: header comments ONLY updated
  ("home page" → "Quran page, directly above the Surah list";
  "Safe to load on BOTH / and /quran" → "Loaded on /quran";
  "Self-render on the home page" → "Self-render on the Quran page";
  the "(e.g. on /quran)" no-card example corrected). NO logic changed:
  storage key stays `qs-last-read`, link format stays
  `/quran?surah=N&ayah=A`, jump behaviour untouched.

### 6.2 Verification (local-only)
- `node --check qs-resume.js` → OK.
- Served HTML (TestClient): home → 200, no `resume-card`, no
  `qs-resume.js`; /quran → 200, `resume-card` present, `qs-resume.js`
  loaded, resume div positioned before `surah-grid-section`.
- Render logic exercised with a DOM stub (node, no browser):
  saved position `{surah: 2, ayah: 255}` → card visible with link
  `/quran?surah=2&ayah=255` and "Continue reading"; no position →
  hidden + empty; invalid position → hidden + empty.
- Jump behaviour verified by code read (untouched): `quran.js` reads
  `?surah=` and `?ayah=` from the URL, scrolls to the ayah element and
  highlights it.
- Live card visibility with a real saved position (browser
  localStorage) remains for the phone test after deploy.

## 7. Next step (parent acts on the user's order — NOT done here)

Deploy from THIS copy (`~/workspace/quran-shazam/`) — not from
`quran-shazam-v116/` — on the user's explicit order. The deploy must
carry both §1 (Q&A removal) and §6 (Resume relocation). Until then:
fixed copy + this report only, server NOT started, nothing live.
