# Speak-verify dictation-concept report — 2026-11-07 ~00:10 PKT

## Order
User (00:00–00:10 PKT, side chat): make the top mic ("Awaz se foran verify
karein" card) work on the SAME concept as the edit-section dictation mic —
"jase woo sunta or text likhta wasa hi" — with NO button changes. Then added:
in the live box above, a wrong word cannot be removed alone — the whole box
has to be cleared ("woo akla word remove nhi hota pora box clear krna prdta"),
so fix that too. Then: "Kr do shro kaam" (go-ahead). He asked to be told the
plan first; plan was given (interim inline, buttons unchanged, text stays in
the card's own box) and he approved it with the added single-word fix.

## What was different (measured, not assumed)
Dictation (`setupDictation`) and speak-verify (`setupSpeakVerify`) were already
identical on: single-shot (`continuous=false`), `interimResults=true`,
`lang='ar-SA'`, rebuild-from-base per result event, stale-session guards.
The ONE writing difference: dictation writes interim words INLINE into its
(textarea) box as you speak; speak-verify showed interim in a separate
faint-italic span (`.speak-verify-interim`), finals only in the main text.
And the live box was a read-only `<div>` — a wrong word could only be removed
via Clear (whole box).

## Change (working copy only, NOT deployed)
- `backend/app/templates/verify.html`
  - `#speak-verify-text`: `<div>` → `<textarea>` (rows=3, RTL, placeholder
    "Yahan live text zahir hoga…", `aria-label` noting hand-fixing).
  - Card hint gains: "Ghalat lafz aaye to usay isi box mein theek kar lein
    — poora box saaf karne ki zaroorat nahi."
- `backend/app/static/js/verify.js` (`setupSpeakVerify` only)
  - `renderSpoken(interim)`: writes finals + interim INLINE into the
    textarea value (`finals + ' ' + interim`), dictation-style. No span,
    no `createTextNode`. Empty state = empty value (placeholder shows).
  - NEW `input` listener on the textarea: while NOT listening, the box is
    the truth — its content becomes the new `committedFinal`, so Verify
    posts exactly what the user fixed (single word deletable, no Clear).
    While listening the mic owns the box (same as dictation: a mid-session
    edit is overwritten by the next result rebuild), so edits then are
    not synced.
  - UNCHANGED: all four buttons (Mic on karein / Rok dein / Verify karein /
    Clear), card position/design, single-shot, onend auto-commit, Verify
    commit-then-stop (posts finals only — interim is cleared on stop),
    `spokenText()` gating (Verify disabled until finals exist), stale
    guards, no auto-restart, no dedup (same ayah on two taps still appears
    twice, deliberate v116 semantics).
- `backend/app/static/css/style.css`: removed the now-unused
  `.speak-verify-interim` rule + its comment.

## Verification (gate only — phone test is the only verdict)
- `node --check` verify.js: OK.
- Harness `docs/speak_verify_revert_harness_2026-11-05.js`: **49/49 PASS**
  (was 38; +3 static checks: textarea present, no div, no interim span in
  JS; +8 new behaviour checks: interim inline while speaking, interim
  stripped on auto-stop, hand edit syncs, Verify posts the hand-fixed
  text, mid-session edit overwritten). One failure found during the run
  and fixed in the HARNESS (not the site): the "no startSession() in
  onend" static check sliced from the FIRST `rec.onend` in the file, which
  is now dictation's (ported 2026-11-06) — it reached the `function
  startSession()` DEFINITION within 1200 chars (false positive). Scoped
  to speak-verify's own onend; the next `startSession()` call there is
  1509 chars away, so the check passes on its merits.
- Full pytest suite: **154 passed**.

## Not deployed
Server + codespace stopped on his order. The change lives only in
`~/workspace/quran-shazam/`. Phone test after the next deploy he orders is
the verdict — especially: speak, watch interim appear inline, fix one wrong
word by hand, Verify, and confirm the fixed text is what gets verified.
