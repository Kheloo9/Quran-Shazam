/* Parah button-fix harness — 2026-11-05.
 *
 * Loads the REAL backend/app/static/js/qs-parah.js in a Node vm sandbox
 * (no browser, no server) and checks it against the REAL corpus
 * backend/data/quran.json:
 *   1. JUZ table: 30 juz, every start/end inside its surah's real ayah
 *      count, global-index walk with 0 gaps / 0 overlaps, total 6,236.
 *   2. Picker: renderParahList paints 30 cards; Juz 1 = 1:1–2:141,
 *      Juz 30 = 78:1–114:6; the /api/quran/surahs fetch upgrades cards
 *      with English names (fail-soft stub).
 *   3. collectJuzAyahs (the real slicing code): Juz 1 = 148 ayat,
 *      Juz 30 = expected count, all 30 juz = 6,236 ayat.
 *   4. buildParahHtml (the real render code): right card counts,
 *      one surah header per touched surah, unique ayah ids, Bismillah
 *      rule (shown only when a segment starts at ayah 1, never for
 *      surah 9), tafseer button only when a flag is set, lang filter.
 *
 * Run:  node docs/parah_harness_2026-11-05.js   (from ~/workspace/quran-shazam)
 * Exit 0 = all checks pass. No server, no network, no writes.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const code = fs.readFileSync(path.join(ROOT, 'backend/app/static/js/qs-parah.js'), 'utf8');
const corpus = JSON.parse(fs.readFileSync(path.join(ROOT, 'backend/data/quran.json'), 'utf8'));

let failures = 0;
function check(name, ok, extra) {
  console.log((ok ? 'PASS' : 'FAIL') + '  ' + name + (extra !== undefined ? '  [' + extra + ']' : ''));
  if (!ok) failures++;
}

// ---- API-shaped surah payloads, built from the real corpus ------------
function surahPayload(n, tafseerOn) {
  const s = corpus[n - 1];
  return {
    number: n,
    english: s.transliteration,
    arabic: s.name,
    ayah_count: s.total_verses,
    revelation: s.type === 'meccan' ? 'Makki' : 'Madani',
    ayahs: s.verses.map(v => ({
      ayah: v.id,
      arabic: v.text,
      translation_en: 'EN ' + n + ':' + v.id,
      translation_ur: 'UR ' + n + ':' + v.id,
      has_tafseer: !!tafseerOn,
      has_tafseer_ur: !!tafseerOn,
      transliteration: ''
    }))
  };
}
// Global ayah index (1-based): idx(s,a) = ayat before surah s + a.
function idx(s, a) {
  let n = a;
  for (let i = 1; i < s; i++) n += corpus[i - 1].total_verses;
  return n;
}

// ---- Load the real qs-parah.js in a sandbox ---------------------------
const fakeSurahs = corpus.map(s => ({
  number: s.id, english: s.transliteration, arabic: s.name,
  ayahs: s.total_verses, revelation: s.type === 'meccan' ? 'Makki' : 'Madani'
}));
const sandbox = {
  window: {},
  console,
  setTimeout,
  fetch: async () => ({ ok: true, json: async () => ({ surahs: fakeSurahs }) })
};
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'qs-parah.js' });
const qs = sandbox.window.qsParah;
check('module loads, window.qsParah exported', !!qs && Array.isArray(qs.JUZ));
check('test seams exported', typeof qs._collectJuzAyahs === 'function'
  && typeof qs._buildParahHtml === 'function');

// ---- 1. JUZ table vs corpus -------------------------------------------
const JUZ = qs.JUZ;
check('JUZ table has 30 entries', JUZ.length === 30, 'got ' + JUZ.length);
let total = 0, tableOk = true, tableNotes = [];
for (let i = 0; i < JUZ.length; i++) {
  const j = JUZ[i];
  const sCount = corpus[j.start.s - 1].total_verses;
  const eCount = corpus[j.end.s - 1].total_verses;
  if (j.n !== i + 1) { tableOk = false; tableNotes.push('n!=' + (i + 1)); }
  if (j.start.a < 1 || j.start.a > sCount) { tableOk = false; tableNotes.push('juz ' + j.n + ' start out of range'); }
  if (j.end.a < 1 || j.end.a > eCount) { tableOk = false; tableNotes.push('juz ' + j.n + ' end out of range'); }
  if (idx(j.start.s, j.start.a) > idx(j.end.s, j.end.a)) { tableOk = false; tableNotes.push('juz ' + j.n + ' start after end'); }
  if (i === 0 && idx(j.start.s, j.start.a) !== 1) { tableOk = false; tableNotes.push('juz 1 does not start at 1:1'); }
  if (i === JUZ.length - 1 && idx(j.end.s, j.end.a) !== 6236) { tableOk = false; tableNotes.push('juz 30 does not end at 114:6'); }
  if (i > 0 && idx(j.start.s, j.start.a) !== idx(JUZ[i - 1].end.s, JUZ[i - 1].end.a) + 1) {
    tableOk = false; tableNotes.push('gap/overlap before juz ' + j.n);
  }
  total += idx(j.end.s, j.end.a) - idx(j.start.s, j.start.a) + 1;
}
check('JUZ table: bounds + 0 gaps/overlaps + starts 1:1 + ends 114:6', tableOk, tableNotes.join('; ') || 'clean');
check('JUZ table covers exactly 6,236 ayat', total === 6236, 'got ' + total);

// ---- 2. Picker ---------------------------------------------------------
const container = { innerHTML: '', querySelectorAll: () => [] };
qs.renderParahList(container);
const cardCount = (container.innerHTML.match(/parah-card/g) || []).length;
check('picker paints 30 parah cards', cardCount === 30, 'got ' + cardCount);
check('picker Juz 1 range reads 1:1 – 2:141',
  container.innerHTML.includes('1:1') && container.innerHTML.includes('2:141'));
check('picker Juz 30 range reads 78:1 – 114:6',
  container.innerHTML.includes('78:1') && container.innerHTML.includes('114:6'));

// ---- 3. collectJuzAyahs (real slicing code) ---------------------------
function juzGroups(n) {
  const j = JUZ[n - 1];
  const datas = [];
  for (let s = j.start.s; s <= j.end.s; s++) datas.push(surahPayload(s));
  return { juz: j, groups: qs._collectJuzAyahs(j, datas) };
}
function countAyat(groups) {
  return groups.reduce((t, g) => t + g.ayahs.length, 0);
}
const j1 = juzGroups(1);
check('Juz 1 slices to 148 ayat (1:1–2:141)', countAyat(j1.groups) === 148, 'got ' + countAyat(j1.groups));
check('Juz 1 touches exactly surahs 1 and 2', j1.groups.length === 2
  && j1.groups[0].surah.number === 1 && j1.groups[1].surah.number === 2);
const j30 = juzGroups(30);
const j30Expected = idx(114, 6) - idx(78, 1) + 1;
check('Juz 30 slices to ' + j30Expected + ' ayat (78:1–114:6)', countAyat(j30.groups) === j30Expected,
  'got ' + countAyat(j30.groups));
check('Juz 30 touches surahs 78–114 (37 surahs)', j30.groups.length === 37
  && j30.groups[0].surah.number === 78 && j30.groups[36].surah.number === 114);
let allTotal = 0, sliceOk = true;
for (let n = 1; n <= 30; n++) {
  const { juz, groups } = juzGroups(n);
  const got = countAyat(groups);
  const want = idx(juz.end.s, juz.end.a) - idx(juz.start.s, juz.start.a) + 1;
  if (got !== want) { sliceOk = false; console.log('  juz ' + n + ': got ' + got + ', want ' + want); }
  allTotal += got;
}
check('all 30 juz slice to 6,236 ayat in total', sliceOk && allTotal === 6236, 'got ' + allTotal);

// ---- 4. buildParahHtml (real render code) ------------------------------
function ids(html) {
  const out = [];
  const re = /id="parah-ayah-(\d+-\d+)"/g;
  let m;
  while ((m = re.exec(html)) !== null) out.push(m[1]);
  return out;
}
const html30 = qs._buildParahHtml(j30.groups, j30.juz, 'both');
const ids30 = ids(html30);
check('Juz 30 HTML has ' + j30Expected + ' ayah cards', ids30.length === j30Expected, 'got ' + ids30.length);
check('Juz 30 ayah ids are unique', new Set(ids30).size === ids30.length);
check('Juz 30 HTML has 37 surah headers', (html30.match(/parah-surah-head/g) || []).length === 37);
check('Juz 30 HTML shows surah refs like 78:1 and 114:6',
  html30.includes('78:1') && html30.includes('114:6'));
const html1 = qs._buildParahHtml(j1.groups, j1.juz, 'both');
check('Juz 1 HTML has 148 ayah cards', ids(html1).length === 148, 'got ' + ids(html1).length);
check('Juz 1 HTML has 2 surah headers', (html1.match(/parah-surah-head/g) || []).length === 2);
check('Juz 1 HTML shows Bismillah (segment starts at ayah 1)', html1.includes('﷽'));
const j2 = juzGroups(2); // starts 2:142, mid-surah
check('Juz 2 HTML shows NO Bismillah (starts mid-surah)',
  !qs._buildParahHtml(j2.groups, j2.juz, 'both').includes('﷽'));
const j11 = juzGroups(11); // 9:93 – 11:5; surah 9 has no Bismillah,
// but surah 10 starts at ayah 1 inside this juz, so ITS header must
// still show one. Check per-header, not whole-HTML.
const html11 = qs._buildParahHtml(j11.groups, j11.juz, 'both');
const heads11 = html11.split('parah-surah-head').slice(1);
const head9 = heads11.find(h => h.includes('>9. '));
const head10 = heads11.find(h => h.includes('>10. '));
check('Juz 11: surah 9 header has NO Bismillah', !!head9 && !head9.includes('﷽'));
check('Juz 11: surah 10 header HAS Bismillah (starts at ayah 1)', !!head10 && head10.includes('﷽'));
const htmlNoTaf = qs._buildParahHtml(juzGroups(30).groups, juzGroups(30).juz, 'both');
check('no tafseer button when has_tafseer is false', !htmlNoTaf.includes('tafseer-btn'));
const tafGroups = [{ surah: surahPayload(112), ayahs: surahPayload(112, true).ayahs.slice(0, 1) }];
check('tafseer button present when has_tafseer is true',
  qs._buildParahHtml(tafGroups, JUZ[29], 'both').includes('tafseer-btn'));
const htmlEn = qs._buildParahHtml(j1.groups, j1.juz, 'en');
check("lang 'en' shows English, hides Urdu", htmlEn.includes('ayah-en') && !htmlEn.includes('ayah-ur'));
const htmlUr = qs._buildParahHtml(j1.groups, j1.juz, 'ur');
check("lang 'ur' shows Urdu, hides English", htmlUr.includes('ayah-ur') && !htmlUr.includes('ayah-en'));

// ---- 5. Play Full Parah queue order (via _queueFromGroups) -----------
check('queue seam exported', typeof qs._queueFromGroups === 'function');
function queueOf(n) {
  const { groups } = juzGroups(n);
  return qs._queueFromGroups(groups);
}
const q1 = queueOf(1);
check('Juz 1 queue has 148 entries in order', q1.length === 148
  && q1[0].s === 1 && q1[0].a === 1 && q1[147].s === 2 && q1[147].a === 141,
  'got ' + q1.length);
const q30 = queueOf(30);
check('Juz 30 queue has 564 entries in order', q30.length === 564
  && q30[0].s === 78 && q30[0].a === 1 && q30[563].s === 114 && q30[563].a === 6,
  'got ' + q30.length);
let queueOrdered = true;
for (let n = 1; n <= 30; n++) {
  const q = queueOf(n);
  for (let i = 1; i < q.length; i++) {
    if (idx(q[i].s, q[i].a) !== idx(q[i - 1].s, q[i - 1].a) + 1) { queueOrdered = false; }
  }
}
check('all 30 juz queues are strictly consecutive (no skip/repeat)', queueOrdered);

// ---- 6. Static: Play Full Parah UI present, audio is Qari-only --------
const parahSrc = fs.readFileSync(path.join(ROOT, 'backend/app/static/js/qs-parah.js'), 'utf8');
const quranHtml = fs.readFileSync(path.join(ROOT, 'backend/app/templates/quran.html'), 'utf8');
check('qs-parah.js has the Play Full Parah engine',
  parahSrc.includes('Play Full Parah') && parahSrc.includes('play-parah-btn')
  && parahSrc.includes('PARAH_STALL_MS') && parahSrc.includes('parahQueue'));
check('quran.html has Play Full Parah button + progress line',
  quranHtml.includes('id="play-parah-btn"') && quranHtml.includes('id="parah-progress"')
  && quranHtml.includes('Play Full Parah'));
check('NO TTS anywhere in the parah audio path (Qari MP3s only)',
  !/speechSynthesis|SpeechSynthesis|utterance/i.test(parahSrc));
check('parah audio uses proxy-first + everyayah fallback URLs',
  parahSrc.includes('/api/audio/') && parahSrc.includes('everyayah.com/data/'));
check('Play Full Parah button is wired exactly once',
  (quranHtml.match(/id="play-parah-btn"/g) || []).length === 1
  && (parahSrc.match(/play-parah-btn/g) || []).length >= 2);

// ---- 7. Names upgrade (async fetch path) -------------------------------
(async () => {
  await new Promise(r => setTimeout(r, 100));
  check('picker upgrades cards with English surah names after fetch',
    container.innerHTML.includes('Al-Fatihah') && container.innerHTML.includes('Al-Baqarah'));
  console.log(failures === 0 ? '\nALL CHECKS PASSED' : '\n' + failures + ' CHECK(S) FAILED');
  process.exit(failures === 0 ? 0 : 1);
})();
