/* Translator mic harness — 2026-11-07.
 * Runs the REAL backend/app/static/js/translator.js in a node vm with DOM
 * stubs and a capturable FakeSpeechRecognition, driven ONLY through the
 * real Speak button / input / direction tabs. /api/quran/translate is
 * stubbed; the matcher is NOT under test beyond "does not throw".
 *
 * Mic semantics under test (dictation concept, rebuilt 2026-11-07):
 *  one tap = one single-shot session (continuous=false); interim words
 *  show LIVE in the input as you speak; only a FINAL result translates;
 *  tap again to stop; stale results never rewrite the input; errors
 *  carry specific messages (permission / no-speech / language).
 *
 * Run: node docs/translator_mic_harness_2026-11-07.js
 * Exit 0 = ALL PASS, 1 = any FAIL. Gate only — the user's phone test
 * is the only verdict. */
'use strict';
const vm = require('vm');
const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(
  path.join(__dirname, '..', 'backend', 'app', 'static', 'js', 'translator.js'), 'utf8');

let pass = 0, fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('PASS  ' + name + (extra !== undefined ? '  [' + extra + ']' : '')); }
  else { fail++; console.log('FAIL  ' + name + (extra !== undefined ? '  [' + extra + ']' : '')); }
}

/* ---------------- stubs ---------------- */
function makeEl(id) {
  const el = {
    id: id || '',
    disabled: false,
    innerHTML: '',
    hidden: false,
    style: {},
    value: '',
    dir: '',
    placeholder: '',
    files: [],
    className: '',
    dataset: {},
    _handlers: {},
    _children: [],
    addEventListener(type, fn) { (this._handlers[type] = this._handlers[type] || []).push(fn); },
    removeEventListener() {},
    appendChild(child) { this._children.push(child); return child; },
    removeChild(child) { const i = this._children.indexOf(child); if (i >= 0) this._children.splice(i, 1); return child; },
    setAttribute() {},
    getAttribute() { return null; },
    removeAttribute() {},
    scrollIntoView() {},
    querySelector() { return makeEl('q'); },
    querySelectorAll() { return []; },
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    click() { (this._handlers.click || []).slice().forEach(fn => fn({})); },
  };
  let _text = '';
  Object.defineProperty(el, 'textContent', {
    get() {
      if (this._children.length) return this._children.map(c => (c && c.textContent) || '').join('');
      return _text;
    },
    set(v) { _text = String(v); this._children = []; },
  });
  return el;
}

const elements = {};
const tabEn = makeEl('tab-en'); tabEn.dataset.dir = 'en2ur';
const tabUr = makeEl('tab-ur'); tabUr.dataset.dir = 'ur2en';
const tabs = [tabEn, tabUr];
const documentStub = {
  getElementById(id) { return elements[id] || (elements[id] = makeEl(id)); },
  querySelector() { return makeEl('q'); },
  querySelectorAll(sel) { return sel === '.tr-dir-btn' ? tabs : []; },
  createElement(tag) { return makeEl(tag); },
  createTextNode(text) { return { textContent: text }; },
  body: makeEl('body'),
  execCommand() { return false; },
};

const fetchCalls = [];
const instances = [];

class FakeSR {
  constructor() {
    this.lang = '';
    this.interimResults = false;
    this.continuous = false;
    this.onresult = null;
    this.onerror = null;
    this.onend = null;
    this.startCount = 0;
    this.stopCount = 0;
    instances.push(this);
  }
  start() { this.startCount++; }
  stop() { this.stopCount++; }
  result(finals, interim) {
    const results = [];
    finals.forEach(t => results.push({ isFinal: true, 0: { transcript: t } }));
    if (interim) results.push({ isFinal: false, 0: { transcript: interim } });
    if (this.onresult) this.onresult({ results });
  }
  end() { if (this.onend) this.onend(); }
  error(code) { if (this.onerror) this.onerror({ error: code }); }
}

const sandbox = {
  document: documentStub,
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  navigator: {},
  fetch: async (url) => {
    fetchCalls.push({ url });
    return {
      ok: true,
      json: async () => ({ candidates: [{ text: 'رحم' }], note: 'Urdu', examples: [] }),
    };
  },
  SpeechRecognition: FakeSR,
  webkitSpeechRecognition: undefined,
  innerWidth: 1024,
  console,
  setTimeout, clearTimeout, setInterval, clearInterval,
  Date, JSON, Math, Array, Object, Promise, Error, RegExp, String, Number, Boolean, Map, Set,
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

vm.runInContext(SRC, sandbox);

/* ---------------- helpers ---------------- */
const btn = id => elements[id];
// The Speak button's <span> must persist across querySelector calls,
// so the Speak/Stop toggle can be asserted.
const voiceSpan = makeEl('span');
voiceSpan.textContent = 'Speak';
btn('tr-voice-btn').querySelector = sel => (sel === 'span' ? voiceSpan : makeEl('q'));
const input = () => btn('tr-input').value;
const status = () => btn('tr-status').textContent;
const spanText = () => voiceSpan.textContent;
function tapSpeak() { btn('tr-voice-btn').click(); }
function lastInstance() { return instances[instances.length - 1]; }

/* ---------------- static checks on the real source ---------------- */
check('interimResults = true present', /rec\.interimResults\s*=\s*true/.test(SRC));
check('rec.continuous = false present', /rec\.continuous\s*=\s*false/.test(SRC));
check('old single-result read ev.results[0][0] is gone', !SRC.includes('ev.results[0][0]'));
check('stale-session guard on shared trRec', SRC.includes('trRec !== myRec'));
check('tap-again-to-stop toggle present', SRC.includes("span.textContent = 'Stop'"));

/* ---------------- behaviour ---------------- */
(async () => {
  // 1. Tap Speak: listens in English (default direction), button flips to Stop.
  tapSpeak();
  check('one session created', instances.length === 1, 'instances=' + instances.length);
  check('rec.lang is en-US by default', lastInstance().lang === 'en-US', lastInstance().lang);
  check('status names the listening language', status().includes('English'), status());
  check('button flips to Stop while listening', spanText() === 'Stop', spanText());

  // 2. Interim shows LIVE in the input; nothing translates yet.
  lastInstance().result([], 'mer');
  check('interim shows live in the input', input() === 'mer', input());
  check('no translate on interim', fetchCalls.length === 0, 'calls=' + fetchCalls.length);

  // 3. Final translates exactly once, with the right query + direction.
  lastInstance().result(['mercy']);
  check('final lands in the input', input() === 'mercy', input());
  check('final triggers exactly one translate', fetchCalls.length === 1, 'calls=' + fetchCalls.length);
  check('translate query is the spoken word', fetchCalls[0].url.includes('q=mercy'), fetchCalls[0].url);
  check('translate direction is en2ur', fetchCalls[0].url.includes('direction=en2ur'), fetchCalls[0].url);
  check('button back to Speak after final', spanText() === 'Speak', spanText());

  // 4. Double-tap while listening stops the mic — no parallel session.
  tapSpeak();
  check('second tap starts a new session', instances.length === 2);
  tapSpeak(); // tap again = stop
  check('tap-again stops, no third session', instances.length === 2, 'instances=' + instances.length);
  check('button back to Speak after toggle-stop', spanText() === 'Speak', spanText());
  check('toggle-stop triggers no translate', fetchCalls.length === 1, 'calls=' + fetchCalls.length);

  // 5. Stale result from the stopped session rewrites nothing.
  const dead = lastInstance();
  dead.result(['stale']);
  check('stale result rewrites nothing', input() === 'mercy', input());
  check('stale result triggers no translate', fetchCalls.length === 1, 'calls=' + fetchCalls.length);
  dead.end();
  check('stale onend changes nothing', input() === 'mercy');

  // 6. no-speech error: specific message, mic stopped, re-tap works.
  tapSpeak();
  check('re-tap after stop starts a fresh session', instances.length === 3);
  lastInstance().error('no-speech');
  check('no-speech message is specific', status().includes('sunai nahi diya'), status());
  check('mic stopped after no-speech', spanText() === 'Speak', spanText());
  tapSpeak();
  check('mic restarts after error', instances.length === 4);

  // 7. Permission error: specific message, no translate.
  lastInstance().error('not-allowed');
  check('permission message is specific', status().includes('ijazat'), status());
  check('permission error triggers no translate', fetchCalls.length === 1, 'calls=' + fetchCalls.length);

  // 8. Language-not-supported error: specific message.
  tapSpeak();
  lastInstance().error('language-not-supported');
  check('language message is specific', status().includes('supported nahi'), status());

  // 9. Urdu direction: listens in Urdu, translates with direction=ur2en.
  tabUr.click();
  tapSpeak();
  check('Urdu direction uses ur-PK', lastInstance().lang === 'ur-PK', lastInstance().lang);
  check('status names Urdu', status().includes('Urdu'), status());
  lastInstance().result(['sabr']);
  check('Urdu final lands in the input', input() === 'sabr', input());
  check('Urdu translate uses direction=ur2en', fetchCalls[fetchCalls.length - 1].url.includes('direction=ur2en'), fetchCalls[fetchCalls.length - 1].url);
  check('Urdu translate query is the spoken word', fetchCalls[fetchCalls.length - 1].url.includes('q=sabr'), fetchCalls[fetchCalls.length - 1].url);

  // 10. onend with an empty input: message shown, nothing translates.
  const callsBefore = fetchCalls.length;
  btn('tr-input').value = '';
  tapSpeak();
  lastInstance().end();
  check('empty onend shows a message', status().includes('sunai nahi diya'), status());
  check('empty onend triggers no translate', fetchCalls.length === callsBefore, 'calls=' + fetchCalls.length);

  console.log(fail === 0 ? '\nALL CHECKS PASSED' : `\n${fail} CHECK(S) FAILED`);
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('HARNESS ERROR:', e); process.exit(1); });
