# Hallmark Design Audit — Quran Shazam (working copy)

**Date:** 2026-11-06 · **Scope:** frontend only — `backend/app/templates/` (6 pages) + `backend/app/static/css/style.css` (892 lines) · **Mode:** AUDIT ONLY, no fixes applied.
**Auditor:** hand audit against the Hallmark README criteria (see Method). No file in the working copy was edited except this report.

## Summary

**8 findings: 3 medium, 5 low. Zero Floor-gate failures.**

The site is in better shape than a typical AI-generated page: all of Hallmark's hard Floor gates pass (contrast, focus, reduced motion, invented facts, phone layout), there are no invented marketing numbers anywhere, and the Nov 4 Impeccable-style polish is visible in the rhythm, spacing and focus-ring unification. The genuine defects are small and specific — the two medium ones are both plain oversights, not taste issues:

1. The Quran Reader hero Bismillah is clipped on phones by a CSS source-order bug (the mobile font-size rules are dead).
2. The Duas and About pages use a `.page-hero` class that has no CSS rule at all, so their heroes are unstyled and inconsistent with the rest of the site.

## Verdict on a Hallmark redesign pass

**Do the small fixes (F1, F2, F7) after the phone test — do NOT do a full Hallmark redesign now.**

- A full redesign now would mix with the still-undeployed, still-unverified changes (5 Reader features, speak-verify single-shot revert, duas clip fix) and muddy the phone-test verdict. The standing rule is: phone test first, then polish.
- The remaining items (F3–F6) are polish-level and mostly deliberate brand choices (dark/gold theme, Inter, purple accents). A Hallmark pass would be reasonable only after the current fixes are deployed and phone-tested — and even then as a **polish** (keep layout, fix tells), not a rebuild. The site does not need a new design system; it needs the two oversights fixed.

## Method (and its limits)

- **Skill install failed (VM network, not the skill):** `npx skills add nutlope/hallmark -g` ran 15+ minutes with zero output; `git clone https://github.com/Nutlope/hallmark` failed with `fetch-pack: unexpected disconnect`. This VM's egress proxy blocks the npm registry and GitHub git traffic. Node v24.22.1 is present (needs 18+). The audit criteria were therefore taken from the Hallmark README fetched live via browser (49,229 stars at check) plus the reel's sloplint criteria: Floor gates (contrast, focus, reduced motion, invented facts, broken phone layout); Reflex tells (eyebrow above every heading, tracked-capital labels, one coloured word in a headline, a page of empty frames / nothing but photographs, a hero that misses its screen, an email sign-up at the end of every page, a form that says thanks without sending anything); plus the reel's tells (purple gradients, overused Inter, invented numbers, useless borders, poor contrast, generic cards, oversized headings).
- **Rendering:** all 6 templates rendered with Jinja2 to static files and screenshotted with headless Chromium at 390 px and 1280 px (index, verify, quran, duas, about). Contrast ratios computed programmatically for 18 text/background pairs (see Appendix).
- **Caveats:** Google Fonts (Amiri Quran, Inter) do not load in this VM, so screenshots show fallback fonts. The Bismillah clip (F1) was verified by DOM measurement (scrollWidth vs clientWidth), not just pixels, so it stands regardless of font. The engine is absent (`/api/quran` 503), so API-driven content (surah grid, results, Reader ayah cards) could not be screenshotted — this audit covers static design only.
- **Screenshot artifact, ruled out:** early screenshots showed dim/faded sections (hero, step cards, Duas/About heroes). Verified as a headless-timing artifact, NOT a defect: a DOM dump shows IntersectionObserver does add `.visible` to in-viewport `.reveal` elements, and re-shooting with `--force-prefers-reduced-motion` renders everything fully crisp. The reveal system works; the screenshots were simply taken mid-transition.
- **Per the standing audit rule, every finding below was verified as a genuine defect** (observed in files and/or screenshots, and checked against intent — e.g. the mobile Bismillah size is stated twice in the code, so its override is a bug, not a choice). Deliberate brand decisions (dark/gold theme, Arabic styling) were not flagged as defects.

## Findings

### F1 — MEDIUM — Quran Reader hero Bismillah clipped on phones (CSS source-order bug)

- **Location:** `backend/app/static/css/style.css:328` (base rule) defeats `:277` and `:289` (mobile rules).
- **Evidence:** The mobile rules inside `@media(max-width:560px)` set `.calligraphy` to 2.4rem (`:277`) then 2.2rem (`:289`). But the base rule `.calligraphy{font-size:3.2rem;…}` sits at `:328`, *after* the media-query block (which closes at `:304`). Same specificity `(0,1,0)`, so later source order wins and phones get 3.2rem. Measured at a 390 px viewport: computed font-size **51.2 px**, `scrollWidth` **370 px** vs `clientWidth` **291 px** — the ﷽ ligature overflows by ~79 px and is cut at the right edge by `overflow-x:clip` (see `quran-390` screenshot). This is the same source-order trap class as the documented BUG 6 (`.nav-toggle`, `.sticky-verify-bar`) — the comments warn about it, but this rule slipped through because the base definition lives in the later "Quran Reader" section.
- **Suggested fix (one line):** move the base `.calligraphy` rule (line 328) above the `@media(max-width:560px)` block, or restate `font-size:2.2rem` for `.calligraphy` in a `max-width:560px` query placed after line 328.
- **Note (latent, same pattern, not a visible defect):** the same trap exists for `.surah-grid` (mobile `1fr` at `:277` vs base `repeat(auto-fill,minmax(250px,1fr))` after the media block) and `.ayah` padding (mobile 16 px vs base 22 px after the block). Neither overflows in practice at 360–390 px (250 px min track still fits one column; 22 px padding is just roomier), so they are not findings — but whoever fixes F1 should check source order for these too.

### F2 — MEDIUM — `.page-hero` has no CSS rule; Duas + About heroes are unstyled and inconsistent

- **Location:** `backend/app/templates/duas.html:4` and `about.html:4` use `<section class="page-hero reveal">`; `style.css` contains **0 references** to `.page-hero` (verified by grep). `security.html:4` has the same plain treatment with a bare `<h1>`.
- **Evidence:** screenshots (`duas-1280`, `about-1280`, re-checked at full opacity) show a left-aligned default-size heading with no hero padding or centering — visibly plainer than the designed `.hero` (Home, Quran Reader) and the styled `.verify-hero` card (Verify). The three secondary pages look like they belong to a different, plainer site.
- **Suggested fix:** add one `.page-hero` rule in the site's hero language (centered, generous top padding, muted subtitle) and apply the class to `security.html`'s heading too.

### F3 — MEDIUM — Card monotony: every section wears identical card chrome

- **Location:** `index.html` (3 step cards + "Honest by design" + "Built for trust" + Quran promo) and `quran.html` (Translator, Bookmarks, Collections, Notes, Reading Progress — five stacked identical cards).
- **Evidence:** screenshots show sections that differ only by their heading emoji; the card gradient, 1 px `line-soft` border and 14 px radius repeat everywhere. The Nov 4 polish added vertical rhythm and spacing but no visual differentiation between section types.
- **Suggested fix (polish only):** differentiate by section role — e.g. keep the card for actions (Translator, Verify) but render the utility lists (Bookmarks / Collections / Notes / Progress) as plain sections with a heading and divider, reserving card chrome for content that needs containment.

### F4 — LOW — Inter is the UI font (Hallmark's most-cited tell)

- **Location:** `style.css:12` (`--font:'Inter',system-ui,sans-serif`); `base.html:10` loads Inter 400–800.
- **Evidence:** Inter is the default AI font. Mitigated: the site's character comes from Amiri Quran + gold, not from Inter, so the page does not *read* as generic. 
- **Suggested fix (redesign-only, optional):** keep Inter, or swap for a more distinctive Latin face in a future redesign pass. Not a fix by itself.

### F5 — LOW — Purple-heavy gradients are the closest thing to the "purple gradient everywhere" tell

- **Location:** `style.css:35-40` (body: three radial gradients, purple glow top-left), `.card` vertical gradient, `.verify-hero` radial purple, `.progress` purple→gold gradient.
- **Evidence:** purple is the deliberate brand ("royal dark-purple theme", `style.css:1`) and is used consistently with gold — not the generic purple-gradient landing page. The glow is restrained on desktop and the gold primary buttons carry the accent.
- **Suggested fix:** none required. If a redesign happens, reduce the body background to one radial glow instead of three.

### F6 — LOW — Tracked-caps micro-labels + gold headline accent (Hallmark reflex tells, mitigated)

- **Location:** `.coach-group-label` (uppercase, letter-spacing, `style.css` ~line 760), `.qari-picker-label` (uppercase, `.06em`), status pills uppercase in markup (`index.html`: "VERIFIED TEXT MATCH"); hero gold second line (`index.html:7`, `verify.html:7`).
- **Evidence:** the labels are functional (status pills, group headings, picker label), not decorative eyebrows above headings; the gold line is the consistent brand accent across pages, not a random single coloured word.
- **Suggested fix:** none required.

### F7 — LOW — Collections empty state repeats the Bookmarks empty-state copy

- **Location:** `quran.html` Collections section; rendered by `qs-collections.js`. Seen in the `quran-1280` screenshot.
- **Evidence:** the Collections card shows both "No bookmarks yet. Tap the bookmark button on any ayah to save it here." *and* "No collections yet. Create one and add bookmarks to it." — the first line duplicates the message already shown in the Bookmarks card directly above it.
- **Suggested fix:** in Collections, drop the first line and keep only "No collections yet…" (the Bookmarks card above already explains bookmarking).

### F8 — LOW — Reveal-on-scroll hides content when JavaScript is off/blocked

- **Location:** `style.css` `.reveal{opacity:0;…}` + the IntersectionObserver script in `base.html`.
- **Evidence:** `.reveal` starts at `opacity:0` and only becomes visible via JS (IO adds `.visible`; the no-IO fallback also adds it — but both need JS). With JS disabled or blocked, every `.reveal` section on Home/About/Duas stays invisible. Impact is limited because Verify and the Reader need JS anyway.
- **Suggested fix:** add `<noscript><style>.reveal{opacity:1;transform:none}</style></noscript>` to `base.html`.

## Passes (explicitly verified, not findings)

- **Contrast (Floor gate):** all 18 computed pairs pass WCAG AA — lowest is 5.52:1 (`.tafseer-src` at 0.8 opacity); body text 7.96–15.97:1. No contrast failure anywhere.
- **Focus (Floor gate):** `:focus-visible` gold ring exists, with higher-specificity restatements for search/jump/voice/qari inputs; skip link present.
- **Reduced motion (Floor gate):** full `prefers-reduced-motion` block (animations/transitions `.01ms`, reveal forced visible, pulses off).
- **Invented facts (Floor gate):** none found. Every number on the pages traces to a real value: 6,236 ayat / 114 surahs (corpus), 200 MB file cap, 30 min duration cap, 20/min rate limit, 60-second ASR chunks, VERIFIED thresholds (≥95 score, ≥90 coverage, ≥3 words), 15–20 cm mic distance. No "10K+ users / 99.9% uptime" style marketing stats anywhere.
- **Phone layout (Floor gate):** 390 px screenshots are clean — no horizontal overflow, no clipped buttons, hamburger nav works, sticky verify bar reserves space. Only exception is F1 (Bismillah clip).
- **Reflex tells:** no eyebrow above any heading; no email sign-up; no thanks-without-sending form; no page of empty frames (the site has no photographs at all — appropriate for Quran content); heroes fit their screens; headings are not oversized (h1 `clamp(2.2rem,5vw,3.4rem)`, h2 `1.4rem`); card borders are the card system, not useless decoration.
- **JS-hook classes verified present:** `.parah-play-btn`, `.parah-bm-btn`, `.parah-note-btn`, `.parah-retry-btn`, `.play-btn`, `.share-btn` all carry styled base classes (`.icon-btn` / `.btn.btn-ghost`) — they are hooks, not missing styles.
- **Nov 4 polish held:** the append-only polish block (scroll-padding, card rhythm, desktop Arabic line-heights, focus-ring unification, touch hover-lift off) is intact and the findings above are what remains after it.

## Appendix

- **Contrast table (foreground on background):** muted `#b7a6d8` on card `#1e1039` 7.96:1; on bg `#0f0722` 8.81:1; on `#170c2d` 8.39:1; ayah EN `#d8cdb4` 11.20:1; tafseer `#cfc4a8` 10.19:1; `#b9a8d0` 8.67:1; ink `#f7f1ff` 15.97:1; gold `#d4af6a` 8.53:1 (card) / 9.44:1 (bg); pill ok `#9fe0bd` 8.17:1; btn-primary text `#1a1206` on gold 8.95:1; nav active `#1a0f2e` on gold-soft 11.15:1; muted at 0.8 opacity ≈5.52:1; translation `#e9e2cf` 13.67:1; Arabic `#f5ecd7` 15.03:1; warn `#f0cd8a` 11.62:1; info `#a9cdf0` 10.67:1; bad `#f0a3a8` 8.84:1.
- **Screenshots (in `/tmp/audit-shots/`, not shipped):** `index-1280/390`, `verify-1280/390`, `quran-1280/390`, `duas-1280`, `about-1280`, plus reduced-motion re-shoots `index-1280-rm`, `duas-1280-rm`. Rendered from Jinja2 templates with sample data; Google Fonts not loaded (fallback fonts); engine absent so API-driven regions show loading/empty states.
- **Counts:** templates 6 (759 lines), `style.css` 892 lines, classes used 239, classes with no rule 3 real ones (`.page-hero` = F2; `.dz-inner`, `.dua-list` = plain wrappers, no visual impact).
