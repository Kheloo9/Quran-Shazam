# Record-live restore — COMPLETE, NOT deployed (2026-11-04)

User order (Roman Urdu, quoted): "Ase kro jase tha phala tha recording wala woo wapas ly ayeo"
— bring back the recording feature as it was before. The user reversed
tonight's removal decision.

Scope kept: only `~/workspace/quran-shazam/`, only two files.
`~/workspace/quran-shazam-v116/` was read-only reference, never written
(its files still carry 2026-10-30 mtimes). No deploy, no codespace touch,
no server start, no public link, no backend change, no home-page change,
no `style.css` change.

## 1. Honest substitution note (read this first)

This is the **v116 LIVE version, NOT a byte-exact restore of this copy's
own pre-removal state** — that is impossible: this copy is not a git repo
and no backup of its own pre-removal files exists. The restoration source
is the version that was actually live (the one in the user's screenshots,
with the mic-check box). One deliberate consequence: **mic-check is
included**, even though this copy's own pre-removal version lacked it —
that was an explicit order, not scope creep.

## 2. What was restored

### Files changed (before → after)

- `backend/app/templates/verify.html`: **159 → 230 lines** (+71)
- `backend/app/static/js/verify.js`: **1491 → 1943 lines** (+452)

### HTML — new first field inside the "Your recitation" card, BEFORE "📁 Or upload a file"

Copied from v116 `backend/app/templates/verify.html` ~L59–132, in order
(Record live label now L64, upload label now L130):

- `🎙️ Record live` label (`for="btn-start"`)
- Mic-check box: `mic-check-box`, `btn-mic-check`, `mic-check-status`,
  `mic-check-meter-wrap`, `mic-check-meter`, `mic-check-label`,
  `mic-check-warning`
- Recorder box: `recorder-box`, `rec-dot`, `rec-timer`, `btn-start`,
  `btn-pause`, `btn-stop`
- Permission hint, verbatim v116 wording: "Your browser will ask for
  microphone permission. Recording stays on your device until you verify."
- `mic-meter-wrap` (`mic-meter`, `mic-label`)
- Tips block (`details.tips-box`, open by default, all 9 v116 tips)
- `rec-preview` (`rec-audio`) + hint "👆 Your recording — listen, then
  press Verify recitation below."

### JS — recorder code re-added to `backend/app/static/js/verify.js`

From v116 `backend/app/static/js/verify.js`, adapted only where noted:

- `micErrorMessage`; mic-check block (`stopMicCheckStream`,
  `stopMicCheck`, `evaluateMicCheck`, `setupMicCheck` IIFE — 3-second
  room-noise sample, quiet/moderate/high thresholds, never blocks
  recording, never sets `audioSource`)
- Recording section: `pickMimeType`, `extFromMime`, `startLevelMeter`,
  `stopLevelMeter`, `setRecUI`, `resetRecording`, `btn-start` handler
  (raw mic constraints, double-tap guard, confirm-before-discard,
  64 kbps Opus, 1 s timeslices, timer, silent-mic guard),
  `btn-pause`, `btn-stop` handlers
- Top declarations restored: `audioSource = null // 'upload' |
  'recording' | null`, `recordedBlob`, `recordedExt`, `mediaRecorder`,
  `recStream`, `recTimer`, `recSeconds`, `audioCtx`/`analyser`/
  `levelRAF`/`meterSrc`, `recPeakPct`
- File-change handler: v116 order — validate via `showFileCard` FIRST,
  discard the recording only when a valid file remains
  (`recordedBlob = null`, `audioSource = 'upload'`, preview hidden,
  Start label reset)
- Verify handler: `filename = 'recording' + recordedExt` default, plus
  the `'recording'` branch (`file = recordedBlob`); upload branch
  unchanged
- Retargets reverted: results-fallback `fb-rerecord` ("Record a clearer
  clip") and Coach "Dobara parhein" retry scroll to `recorder-box`
  again with recording wording

### Preserved, untouched in behaviour

- Upload/dropzone path (dropzone, file input, `dz-filecard`, `dz-error`,
  waveform), `refreshVerifyButton` logic (extended back to both sources),
  transcript edit/rematch, coach/history rendering, sticky verify bar
- **Entire `setupSpeakVerify` block**: `rec.continuous = true` intact
  (current L1778, same `// CONTINUOUS (2026-11-04 change)` comment),
  finals-only commit, overlap-aware append, interim-never-committed
  rendering. The restored recorder code shares no variables with it
  (coach `practiceRec` is separate and untouched)
- Shared helpers `fmtTime` and `extFromMime` exist again for the paths
  that need them

## 3. Verification evidence (lead re-checked, not taken on trust)

- `node --check` on `verify.js` → **PASS** (lead re-run after the
  implementation team's delivery).
- Line counts confirmed by lead: verify.html 230, verify.js 1943.
- Recorder IDs present in HTML and referenced by JS, counts confirmed
  by lead: btn-start 11 refs, btn-pause 3, btn-stop 2, rec-timer 4,
  rec-dot 2, recorder-box 3, mic-meter 2, mic-label 1, mic-meter-wrap 2,
  rec-preview 4, rec-audio 1, btn-mic-check 3, mic-check-status 6,
  mic-check-warning 4. `mic-check-box` has 0 JS refs — faithful to v116,
  where it is also a styling container only. Reverse check by the team:
  zero `$('…')` IDs in `verify.js` missing from `verify.html`.
- Field order confirmed by lead: Record live label L64, upload label
  L130 — recording is before upload, as before.
- No leftover removal-era wording: grep for `upload-only|Upload-only|
  RECORD-LIVE REMOVAL|Record live removed|recording removed` across
  both files → **zero matches** (lead re-run; only clearly-labelled
  `RECORD-LIVE RESTORE (2026-11-04)` history comments remain).
- Code-read flow checks (lead confirmed the key lines):
  - Recording: Start → `getUserMedia` → `MediaRecorder` → Stop →
    `onstop` sets `audioSource = 'recording'`, shows `rec-preview` →
    `refreshVerifyButton()` enables Verify + sticky bar → Verify posts
    the blob as `recording + recordedExt`.
  - Upload: file → change handler sets `audioSource = 'upload'` →
    Verify enabled → Verify posts the file with its own name.
- v116 untouched: its verify.html/verify.js still carry 2026-10-30
  mtimes.

## 4. Behavioural differences vs the pre-removal state (could not reproduce / deliberate)

1. **`revokeDzAudio` adapted, not verbatim:** v116's version revoked a
   stored upload blob URL, but this copy's `showFileCard` never stores
   one (it creates the URL inline). The restored helper therefore
   clears the `dz-audio` src instead of revoking — same teardown
   intent, no behaviour regression (this copy leaked that URL before,
   too). `revokeRecPreview` is verbatim v116.
2. **Tartil-guidance box left out:** v116's field also contains a
   `#tartil-guidance` box, but it was not in the ordered restore list
   nor in the removal report's inventory, so it was deliberately not
   restored. It can be added in one small edit on the user's word.
3. **Engine-health fetch kept as-is:** v116 re-polls `/api/health`
   every 15 s while warming; this copy fetches once. That difference
   predates this task and was not touched per scope.
4. **No `style.css` change needed:** verified first — `.recorder`,
   `.rec-dot` (+`.live`/`.paused`), `.timer`, `.tips-box`, `.btn-danger`
   were all already present.
5. **Not claimed:** no deploy, no live test, no phone test. The real
   verdict remains the user's phone test after a deploy he orders.

## 5. End state + next step

- Fixed copy + this report, **NOT deployed, server NOT started**.
- Deploy only on the user's explicit order, from
  `~/workspace/quran-shazam/` (the same deploy could also carry the
  earlier Q&A removal, Resume hero-top move, promo-heading fix, and
  speak-verify continuous port already in this copy — only if he
  orders them together).
- Two honest reminders carried over from the removal (still true after
  the restore): removal/restoration changes nothing about accuracy —
  a recording and an upload of the same audio go through the same
  Whisper pipeline; and the speak-verify card above remains a
  text-only quick check, not audio-evidence verification.
