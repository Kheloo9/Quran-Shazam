# Speak-verify revert to single-shot — 2026-11-05

**Status: REVERTED + HARNESS-GREEN (38/38) in the working copy. NOT deployed.
Server is STOPPED by the user's own order. NO codespace touched. NO public link.**

**The user's phone test is the ONLY verdict.** Everything below is simulation
(a gate, never a completion claim). Real Android Chrome speech behaviour
can only be confirmed on his phone. Do not call this fixed until his
phone test passes.

## 0. User order + phone-test evidence (why this revert happened)

User order (2026-11-05 ~14:01, Roman Urdu):

> "Server bnd hona ka bd esy phala jasa hi kr dyna ak tak open rahy pher
> dabna pr next continue ma bohat repeat word aty"

"Make it like before" — one tap opens the mic, then tap again for the
next (continue); the continuous version produces far too many repeated
words.

Phone-test evidence: his screenshot
(`workspace/user/media_library/image/Screenshot_20261105-135623.png`,
13:56 PKT, Android Chrome) shows the speak-verify transcript box full of
massive repetition — "Bismillah" repeated many times, "qul huwallahu
ahad" and "lam yalid wa lam yulad" repeated over and over. This is the
SAME Android Chrome replay/tokenization failure that killed continuous
mode twice before (Fix 1 / Fix 2, Oct 2026) and that the 2026-11-04
overlap-aware design was built to survive. It did not survive it on the
real phone: the harness (13/13) was simulation only, and the real Chrome
replay shapes beat the dedup rules in practice.

## 1. What was reverted (scope kept tight)

Scope: `~/workspace/quran-shazam/` ONLY (the Nov 4 working copy).
`~/workspace/quran-shazam-v116/` was read as reference only — its
`verify.js` / `verify.html` mtimes are still 2026-10-30, untouched.

Reverted ONLY the speak-verify listening behaviour in
`backend/app/static/js/verify.js` (1943 → **1833 lines**, −110). Nothing
else on the page was touched: Record-live, tartil box, mic-check, Verify
button, upload flow, Re-match handler, Coach, translator voice input —
all untouched (splice replaced only the setupSpeakVerify span, old lines
1526–1930; boundaries re-read and verified clean).

Removed:
- `rec.continuous = true` → `rec.continuous = false` (single-shot).
- Bounded auto-restart (max 5): `onend` no longer calls `startSession()`;
  it auto-commits once and stops. `restartsWithoutFinal` deleted.
- Overlap/dedup logic, entirely: `appendOverlapAware`, `normalizeWord`,
  `splitWords`, `commitSessionFinals` — all deleted. No dedup of any
  kind remains in the speak-verify path (per the revert order).
- Continuous-mode `onerror` behaviour (transient errors kept the mic
  alive): all errors now stop the mic.

Restored (v116 "SPEAK-VERIFY REBUILD", 2026-10-30, verbatim semantics):
- One Mic tap = one single-shot session. The mic stops by itself at the
  end of the utterance; the next ayah needs a fresh Mic tap.
- `onend` AUTO-STOP: commits the session's finals once with a plain
  single-space join, re-enables Mic, starts no new session. Empty
  session → "Mic band ho gaya hai — dobara Mic on par click farmayen."
- `onerror` stops on EVERY error: permission → permission message;
  no-speech → "Kuch sunai nahi diya"; any other error → transient
  message. No auto-restart, ever.
- `stopSpeak` (Rok dein): plain-join commit (`committedFinal =
  spokenText()`), generation bump, mic stop.
- `recGen`/`myRec` stale-session guards kept (v116 had them too).
- In-session rebuild from cumulative `e.results` kept (finals +
  interim separated; interim never committed, never enables Verify).

Deliberately KEPT vs v116 (from the 2026-11-04 port, not part of the
revert): Verify-tap commit-then-stop — Verify FIRST commits-then-stops
the mic so the posted text is exactly the committed finals and no live
session can append words after posting. The committed text itself is
kept, so Mic on again only adds the next segment. This does not change
listening behaviour; it only makes the posted text exact.

Kept: the ported card itself (deleting it would remove the feature from
the next deploy again) and the `.speak-verify-interim` CSS.

## 2. Files changed (all in ~/workspace/quran-shazam/)

1. `backend/app/static/js/verify.js` — 1943 → **1833 lines**. The whole
   setupSpeakVerify span (header comment + IIFE) was replaced with the
   single-shot version; `node --check`: OK.
2. `backend/app/templates/verify.html` — 237 → **239 lines**. ONLY the
   port comment above the card (lines 19–24) updated to record the
   revert; no UI text, IDs, or buttons changed.
3. `docs/speak_verify_revert_harness_2026-11-05.js` — NEW harness
   (the 2026-11-04 harness lived in /tmp and is gone). Full-file vm
   run of the real `verify.js` with DOM stubs + FakeSpeechRecognition,
   driven only through the real buttons/text element. Run:
   `node docs/speak_verify_revert_harness_2026-11-05.js`
4. `docs/SPEAK_VERIFY_REVERT_REPORT_2026-11-05.md` — this report.

No backend, matcher, verify flow, `renderResults`, tests, CSS, or other
copy was modified.

## 3. Harness results — 38/38 PASS (this VM only — GATE, not verdict)

Method: full-file vm, real 1833-line `verify.js`, DOM stubs,
capturable FakeSpeechRecognition, `/api/rematch` stubbed (matcher and
renderResults not under test beyond "does not throw"). Fixtures:
Bismillah + 112:1.

Static (on the real source, comments stripped):
- No `rec.continuous = true` in code; `rec.continuous = false` present.
- No `restartsWithoutFinal`, `appendOverlapAware`, `normalizeWord`,
  `commitSessionFinals` anywhere in the file or any other file.
- No `startSession()` call inside `onend` (no auto-restart path).

Behaviour:
1. Single utterance auto-stops: one tap → final → onend → text exactly
   Bismillah, Mic re-enabled, exactly 1 recognition instance (no
   restart), status "Ye hissa mehfooz ho gaya hai — agli ayat ke liye
   dobara Mic on par click farmayen."
2. Two taps accumulate exactly (Bismillah + 112:1), no repeats.
3. Empty onend: old text kept, no new session, re-tap status.
4. Interim-only: Verify stays disabled; interim discarded on auto-stop.
5. Transient error (`network`): mic stops, no new session, re-tap status.
6. Permission error (`not-allowed`): mic stops, no new session.
7. Clear + stale events: cleared text never resurrects; stale onend
   creates no session.
8. Rok dein mid-session commits the final; late onend is inert.
9. Verify posts exactly once, body transcript exactly the spoken
   finals. (Total fetch calls observed = 2: one load-time `/api/health`
   check + the one rematch post.)
10. Deliberate repetition is KEPT (plain join, no dedup): the same ayah
    spoken on two taps appears twice — this is v116 semantics, and is
    the specified trade-off of removing dedup.

## 4. Honest residuals and limitations

- **Phone test is the only verdict.** The harness drives fake
  recognition events, not Chrome. Single-shot has no restart boundary
  and no replay window by construction, and it is the design the user
  was happy with before — but only his phone can prove the repetition
  is gone.
- **Deliberate repetition is no longer dropped.** With dedup removed,
  a genuinely re-recited identical ayah on a later tap appears twice,
  exactly as spoken. That is the v116 behaviour the user asked to
  restore ("pehla jaisa hi"), not a bug.
- **Matcher/renderResults not under test** beyond not throwing; this
  copy's `renderResults` still predates the v116 parity fixes (out of
  scope, as before).

## 5. Phone test pattern (exact — the only verdict)

On the deployed link (after a deploy the user orders), on his Android
Chrome phone:

1. Open **/verify**. First card is "🎤 Awaz se foran verify karein".
2. Tap **Mic on karein ONCE**, recite **Bismillah only**, let the mic
   stop by itself. Text must be exactly Bismillah, once. Mic button
   must be enabled again.
3. Tap **Mic on karein again**, recite **112:1 only**, let it stop.
   Text must be exactly Bismillah + 112:1, each once, in order.
4. Tap **Verify karein**, confirm results render for the spoken text.
5. Separately: Mic on, say nothing → "Mic band ho gaya hai" status,
   Verify stays disabled; Clear → placeholder, Verify disabled.

Pass = all of the above, with NO repeated words anywhere. Anything else
= fail — report exactly what the box showed (screenshot + which words
repeated).

## 6. Out of scope — flagged, not touched

The user's second message (2026-11-05 ~14:01, second screenshot, duas
page) reports a SEPARATE issue: duas audio also produces extra/repeated
words ("sri dua jub parhi extra ata hy"). That is the duas audio path
(`duas.js` / `backend/app/static/audio/duas/`), NOT speak-verify, and
was not investigated or changed in this task. It needs its own
investigation (the duas files were modified today by separate work —
see `docs/DUAS_CLIP_PORT_REPORT_2026-11-05.md`).

## 7. Next step (parent acts only on the user's explicit order)

**Deploy from `~/workspace/quran-shazam/`** when the user orders it
(server is currently STOPPED by his own order — do not start anything
for this task). The deploy carries this revert plus everything already
in the copy (Parah button fix, Nov 4 evening fixes, deploy 3ba2663
already live once today).
