# Deploy Report — 2026-11-05 (PARTIAL: GitHub sync done, in-codespace steps need the browser route)

**Status: NOT LIVE YET.** The code is synced to GitHub (commit `3ba2663`), the
codespace is woken to **Available**, but commands inside the codespace could
NOT be run from this VM — `gh codespace ssh` fails with the same RPC error as
2026-11-04. The remaining steps must run in the VS Code web terminal
(browser route, exactly as on 2026-11-04). Exact commands are in
§ "Remaining steps" below.

## What is DONE
- **GitHub sync (this VM, `gh` as Kheloo9):** commit `3ba2663` pushed to
  `Kheloo9/Quran-Shazam` `main` (HEAD confirmed via ls-remote).
  - `Deploy: Nov 5 parah button fix + Nov 4 evening fixes (QA removal, resume
    to /quran, speak-verify continuous, record-live restore)`
  - Files changed vs previous HEAD `75ee75f`: `style.css`, `qs-parah.js`
    (628 lines — button fix), `qs-resume.js` (comments only, resume move),
    `index.html` (resume card removed from home), `quran.html`,
    `quran-shazam-codespace.zip` (1,141,630 → 5,227,362 bytes).
  - The diffs for `qs-resume.js` / `index.html` were reviewed before commit:
    they are exactly the Nov 4 evening resume relocation (home → /quran).
- **Fresh zip built:** `/tmp/Quran-Shazam-2026-11-05.zip` (127 files,
  5,227,362 bytes) from `~/workspace/quran-shazam/` with the standing
  exclusions (models, `tafseer_*_real.json`, caches, FEEDBACK junk,
  `hidden_files`, `*.log`). Verified: no models, no `voice_qa.js`, no
  `quran_qa.py`; `translator.js` + Parah report present. This zip is what
  was committed as `quran-shazam-codespace.zip`.
- **Codespace woken:** `curly-umbrella-7rr99xjppvpfxp4q` was Shutdown; the
  first `gh codespace ssh` attempt woke it — state is now **Available**
  (confirmed twice via `gh codespace list`). It was NOT stopped afterwards.
- **Public URL checked anonymously (plain curl, no login):** `/` → 404,
  `/api/health` → 404. Expected: no server is running yet. The tunnel
  itself answers, so the codespace is reachable.

## What is BLOCKED (and why)
- `gh codespace ssh` (4 attempts: plain ×2, `--config`, `-d`) fails at
  "getting ssh server details" with:
  `failed to invoke SSH RPC: rpc error: code = Unavailable desc =
  connection error: desc = "error reading server preface: raw-read tcp
  127.0.0.1:xxxxx->127.0.0.1:yyyyy: use of closed network connection"`.
  A no-proxy attempt fails earlier (TLS handshake timeout to api.github.com
  — direct egress is blocked). Loopback TCP in this VM works, so the failure
  is in gh's SSH relay path, not the VM. This is the EXACT failure recorded
  on 2026-11-04, which was resolved then via the browser / VS Code web route.
- `gh codespace ports` (API path) works but lists no forwarded ports yet
  (nothing is listening). Port visibility can be set from this VM once the
  server is up: `gh codespace ports visibility 8000:public -c
  curly-umbrella-7rr99xjppvpfxp4q` — or in the VS Code Ports panel.

## Remaining steps (run in the VS Code web terminal of "curly umbrella")
Open https://github.com/codespaces/curly-umbrella-7rr99xjppvpfxp4q
(or github.com → Codespaces → curly umbrella → Open in browser).

```bash
cd /workspaces/Quran-Shazam
git status --short | head -20        # expect: no tracked files modified
git pull origin main                 # brings 3ba2663 (6 files)
ls backend/data/models/ | head       # MUST still exist (pre-converted ct2 model)
unzip -o quran-shazam-codespace.zip  # fresh app files over the tree (zip has no models dir, so models/ is untouched)
rm -f backend/app/static/js/voice_qa.js backend/app/engine/quran_qa.py
grep -rn "voice_qa\|quran_qa\|/api/quran/ask" backend/app/ | grep -v ".pyc" || echo "QA CLEAN"
grep -c "Parah (30 Juz)" backend/app/templates/quran.html        # expect >= 1
grep -c "rec.continuous = true" backend/app/static/js/verify.js  # expect >= 1
ls backend/app/static/js/translator.js backend/app/static/js/qs-parah.js
ps aux | grep -i uvicorn | grep -v grep || echo "no server running"
cd /workspaces/Quran-Shazam/backend && nohup python -m app > /tmp/qs_server.log 2>&1 &
sleep 5; tail -20 /tmp/qs_server.log
curl -s -m 10 -o /dev/null -w "health local: %{http_code}\n" http://127.0.0.1:8000/api/health
```

Then set forwarded port 8000 to **Public** (VS Code Ports panel, or from this
VM: `gh codespace ports visibility 8000:public -c
curly-umbrella-7rr99xjppvpfxp4q`). Wait ~5 min for warm-up (ASR model load
takes 2–4 min on first run), then verify ANONYMOUSLY (plain curl, no login):

```bash
curl -s -m 15 -o /dev/null -w "home: %{http_code}\n" https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/
curl -s -m 15 https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/api/health
curl -s -m 15 -o /dev/null -w "quran: %{http_code}\n" https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/quran
curl -s -m 15 https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/quran | grep -c "Parah (30 Juz)"
curl -s -m 15 -o /dev/null -w "qs-parah.js: %{http_code}\n" https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/static/js/qs-parah.js
curl -s -m 15 -o /dev/null -w "ask-404: %{http_code}\n" -X POST https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/api/quran/ask
```

Expected: home 200, health 200 with `corpus 6236/114` and ASR warm,
/quran 200 containing the Parah button, qs-parah.js 200, ask 404.
If anonymous 404 persists while the panel reads Public → toggle
Private→Public; if that fails → full Codespace stop+start for a fresh tunnel.

## What remains UNVERIFIED
- Everything inside the codespace (pull, unzip, stale-file deletion, server
  start, port Public) and every anonymous check above — none of it has run
  yet. **Do NOT send the user a live link until the anonymous checks pass.**
- The user's phone test is still the only verdict for the Reader-data
  interactions and the Parah whole-juz view / Play Full Parah audio.
- Standing caveat unchanged: the codespace idles/sleeps after ~30 min, so
  the link may need a wake on his order later.

## Links / refs
- Public URL (NOT live yet): https://curly-umbrella-7rr99xjppvpfxp4q-8000.app.github.dev/
- Repo: https://github.com/Kheloo9/Quran-Shazam (main @ 3ba2663)
- Source copy: `~/workspace/quran-shazam/` — deploy exactly this copy.
