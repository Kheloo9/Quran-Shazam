# Parah Button Fix — Report (2026-11-05)

## Headline

**Decision (parent's call, user delegated it): BUTTON idea — Parah is NOT removed.**
The complaint was about the click *behaviour*, not the feature: tapping a parah
jumped into the surah/ayah view instead of showing the whole parah. The fix
replaces the full-width 30-card grid with one **"📖 Parah (30 Juz)"** button;
tapping a parah now opens a **dedicated Parah view that renders the WHOLE juz**
— every ayah in order, with a surah header at each boundary — plus **Qari
audio: per-ayah play AND "▶️ Play Full Parah" continuous tilawat**.

**Status: COMPLETE, NOT deployed. No live test was possible here (no engine
on this VM; `/api/quran` returns 503). The user's phone test after a deploy
he orders is the ONLY verdict.**

## User's question, answered

> "Parah wale section me sunane ka option hoga?"

**HAAN — zaroor hai, do tareeqon se:**
1. **Har ayah ke saath ▶️ button** — us ayah ki Qari tilawat (everyayah MP3).
2. **"▶️ Play Full Parah" button** — poora juz aik ke baad aik, musalsal
   tilawat, "Ayah X/N" progress ke saath (jaise Reader mein "Play Full
   Surah" hai).

**Audio rule kept:** jahan bhi ayah suni ja sake, **QARI ki recitation**
bajti hai. Ayah audio ke liye **AI TTS kahin istemal nahi hota** — is
feature mein `speechSynthesis` / TTS ka code sirre se mojood hi nahi
(harness check #33 ne verify kiya). Qari wohi jo Reader mein muntakhib
hai (`localStorage 'qs-qari'`, default Mishary Rashid Alafasy).

## What changed (all in `~/workspace/quran-shazam/`, NOT deployed)

### 1. `backend/app/templates/quran.html` (229 lines)
- **REMOVED:** the full-width `<section id="parah-section">` 30-card grid
  (was between Reading Progress and the Surah grid).
- **ADDED L95:** single Parah button under the "Surahs (114)" heading,
  above the filter row — filter input, Makki/Madani chips, count + Clear
  untouched:
  `<button id="parah-open-btn" class="btn btn-ghost">📖 Parah (30 Juz)</button>`
- **ADDED L115–121:** hidden picker `<section id="parah-picker">` with
  back button + `<div id="parah-picker-grid" class="surah-grid">`.
  Rendered **lazily on first open**, so the surah-name fetch only runs
  when the user taps Parah.
- **ADDED L125–141:** hidden `<section id="parah-view">` with back button
  (`← Surahs`), title/meta, **"▶️ Play Full Parah" button
  (`#play-parah-btn`, L135) + progress line (`#parah-progress`, L137–139,
  reusing the Reader's `.surah-progress` classes)**, and
  `<div id="parah-ayah-list">`.
- **Wiring L~216:** the lead script now calls `window.qsParah.init()`
  instead of rendering into the deleted `#parah-grid`.
- Untouched: hero, hero-top resume card (`#resume-card`), translator,
  bookmarks, collections, notes, progress, surah grid/filter, Reader
  section.

### 2. `backend/app/static/js/qs-parah.js` (198 → 740 lines)
- **JUZ table (L82–~110): UNTOUCHED, byte-identical.** Verified again
  against the corpus (see checks): 30 juz, 6,236 ayat, 0 gaps/overlaps.
- **REMOVED:** `openParah()` — the old jump-to-starting-surah behaviour.
  No reference to `window.qsOpenSurah` remains in this file.
- **Picker:** `renderParahList()` now paints into the picker grid; card
  tap → `openParahView(n)`. English surah names still load best-effort
  from `/api/quran/surahs`, fail-soft (numbers-only list stays).
- **`openParahView(n)` (L340):** fetches every surah the juz touches via
  the existing `/api/quran/surah/{n}` endpoint (`Promise.all`, no new
  backend endpoint), slices with `collectJuzAyahs()` (L249), renders with
  `buildParahHtml()` (L273). Any fetch failure → honest error + **Retry
  button — never a partial juz**. Also records the juz start in Resume
  (`qsResume.savePosition`, guarded).
- **Parah view HTML:** per surah boundary a `.parah-surah-head` header
  (surah number + English + Arabic name + ayah count + Makki/Madani) with
  a ﷽ line only when that segment starts at ayah 1 — **never for Surah 9**
  (same rule as the Reader). Every ayah card reuses the Reader's classes
  (`.ayah-card`, `.ayah-arabic`, `.ayah-en`, `.ayah-ur`, `.tafseer-*`) with
  a `S:A` pill ref (`.parah-ayah-ref` — `.ayah-num` is a 34px circle and
  "2:142" does not fit in it), unique ids `parah-ayah-S-A`.
- **Per-ayah features (delegated listener, one per list):**
  - ▶️ play — simple single-ayah Qari player (proxy `/api/audio/S/A`
    first, everyayah direct as fallback; ⏳ while loading; ⏸️ while playing).
  - 🔖 bookmark — same `localStorage 'qs-bookmarks'` contract as the
    Reader, so parah bookmarks appear in My Bookmarks / Collections;
    refreshes via `window.qsRenderBookmarksRich()` (guarded).
  - 📝 note — opens `qsNotes.openNoteEditor("S:A")` (exposed API); active
    state via `qsNotes.hasNote()` (guarded).
  - 📖 tafseer — on-demand from `/api/quran/tafseer/S/A`, EN/UR tabs,
    same panel markup as the Reader; button only when `has_tafseer` /
    `has_tafseer_ur` is set.
  - **NOT included: Share-as-image.** `shareAyah()` lives closed inside
    `quran.js` and reads cards by `id="ayah-N"`; porting it was out of
    scope for this fix. Said plainly, not faked.
- **"Play Full Parah" (L400–548) — reuse analysis, read this:**
  - **Direct reuse of the Reader's Play Full Surah engine was NOT
    cleanly possible.** That engine lives closed inside `quran.js`'s
    IIFE and is hard-wired to ONE surah: `currentSurah`,
    `lastData.ayahs`, `#play-surah-btn` / `#surah-progress` elements,
    and `data-ayah-card` selectors. Generalising it would have meant
    surgery on the verified playback engine with no live test available
    here. **`quran.js` was left completely untouched — zero regression
    risk to the surah reader.**
  - **What was done instead:** the *same flow* is re-implemented in
    `qs-parah.js`, scoped to the juz — same proxy-first/direct-fallback
    URLs, same qari choice, same progress-aware stall watchdog
    (no bytes for 20 s = stuck, 90 s hard cap — slow mobile data keeps
    resetting it), same generation token (stale elements can never
    hijack a newer play), same **Play → Pause → Resume** cycle (pause
    keeps queue + position, never restarts the juz), same **"Ayah X/N"**
    progress line + per-ayah ⏸️ icon on the ayah now playing, same
    auto-scroll + gold `now-playing` highlight per ayah.
  - Queue order comes from `queueFromGroups()` (L417): the juz's ayat
    flattened to `[{s, a}, …]` in order. A failed ayah tries the
    fallback URL once, then skips to the next ayah (same as the Reader).
  - Single-ayah taps and the queue share one audio element + generation
    token: tapping the current queue ayah's own ▶️/⏸️ pauses/resumes
    the queue (same rule as the Reader); any other tap stops the queue
    first. Leaving the view, switching juz, or changing the language
    stops all parah audio (no audio can keep playing under another
    screen). **Qari audio only — no TTS path exists.**
- **Language toggle:** the hero EN/UR toggle re-renders an open parah
  view with the same choice as the surah Reader.
- **Fail-soft / escaping:** every dynamic string through `esc()`; missing
  containers, missing `fetch`, missing optional modules (`qsNotes`,
  `qsRenderBookmarksRich`) are silent no-ops, never throws. No new user
  data stored or sent (only the Reader's existing localStorage keys).
- **Test seams** (harness only): `_collectJuzAyahs`, `_buildParahHtml`,
  `_queueFromGroups`.

### 3. `backend/app/static/css/style.css` (append-only, end of file)
- New: `.parah-btn-row`, `.parah-surah-head`, `.parah-ayah-ref` (gold
  pill). Dark/gold theme unchanged; no existing rule edited. Braces
  457/457 balanced.
- **No new CSS was needed for Play Full Parah** — it reuses the Reader's
  existing `.audio-controls`, `.btn-primary`, `.surah-progress`,
  `.surah-progress-track`, `.surah-progress-fill`.

### 4. `backend/app/static/js/quran.js` — UNTOUCHED
Deliberate: the surah reader and its playback engine carry zero risk
from this change.

### 5. `docs/parah_harness_2026-11-05.js` (new)
Node harness (vm sandbox, real `qs-parah.js` + real corpus, no server,
no network). Run: `node docs/parah_harness_2026-11-05.js`.

## Checks run + results

| Check | Result |
|---|---|
| `node --check` qs-parah.js | OK |
| `node --check` quran.js (untouched) | OK |
| CSS braces | 457 / 457 balanced |
| Harness `node docs/parah_harness_2026-11-05.js` | **37 / 37 PASS** |
| JUZ table vs corpus | 30 juz, bounds OK, 0 gaps/overlaps, 6,236 ayat |
| Picker | 30 cards; Juz 1 = 1:1–2:141; Juz 30 = 78:1–114:6; names upgrade adds Al-Fatihah |
| Slicing (real code) | Juz 1 = 148 ayat; Juz 30 = 564 ayat (78:1–114:6); all 30 = 6,236 |
| Render (real code) | Juz 30 = 564 cards, 37 surah headers, unique ids; Juz 1 = 148 cards, 2 headers |
| Bismillah rule | Juz 1 ✓ shown; Juz 2 ✗ (mid-surah); Juz 11 surah 9 ✗, surah 10 ✓ |
| Tafseer button | absent when flags false; present when true |
| Lang filter | 'en' hides Urdu; 'ur' hides English; 'both' shows both |
| **Play Full Parah queue order** | Juz 1 queue 148 in order (1:1→2:141); Juz 30 queue 564 in order (78:1→114:6); all 30 queues strictly consecutive, no skip/repeat |
| **Play Full Parah UI** | button + progress line present in quran.html; engine present in qs-parah.js; button wired exactly once |
| **Qari-only proof** | NO `speechSynthesis`/`utterance` in qs-parah.js; audio URLs are proxy `/api/audio/` + `everyayah.com/data/` only |
| Dead refs | No `parah-section`, no `parah-grid` id, no `openParah(`, no `qsOpenSurah` in qs-parah.js (only two historical comments mention the removed grid) |
| Duplicate IDs in quran.html | none (incl. `play-parah-btn`, `parah-progress` once each) |
| Python | no Python touched (`main.py` py_compile OK as sanity check) |

One harness assertion was fixed during the run (not the code): the first
version asserted Juz 11 HTML contains no ﷽ at all — wrong, because
Surah 10 starts at ayah 1 inside Juz 11 and its header correctly shows
one. The check now asserts per-header (surah 9 ✗, surah 10 ✓).

## What remains UNVERIFIED (phone test is the only verdict)

- **LIVE TEST NOT POSSIBLE HERE.** No engine on this VM; `/api/quran`
  returns 503. Everything above is structure/harness verification, not
  a live run.
- **Play Full Parah continuous playback has never played a single real
  ayah here** — the queue order, watchdog constants, and UI wiring are
  verified; the actual audio flow (proxy MP3 → next ayah → surah
  boundary crossing → end of juz) can only be proven on the phone.
- Same for: picker tap → whole-juz render, per-ayah play/bookmark/note/
  tafseer in the parah view, back buttons, lang toggle inside the view.

## Phone test steps (after a deploy the user orders)

1. Open `/quran` → under "Surahs (114)" there is ONE **"📖 Parah
   (30 Juz)"** button; the old 30-card grid is gone; filter + count +
   Clear still work; Resume card still at hero-top.
2. Tap the Parah button → picker lists **30 parahs with ranges**
   (Juz 1: 1:1–2:141; Juz 30: 78:1–114:6).
3. Tap **Parah 30** → whole juz renders: **564 ayat**, surah headers
   for 78–114, Arabic + English + Urdu on each ayah; title "Parah 30".
4. Tap **"▶️ Play Full Parah"** → Qari tilawat starts at 78:1, plays
   continuously across the surah boundary into 79, progress shows
   "Ayah X/564"; tap again → pauses (position kept); tap again →
   resumes from the same ayah (NOT from the start). Let it run a few
   ayat and confirm no hang on slow data.
5. Tap a single ayah's ▶️ → only that ayah plays (queue stops if it
   was running); 🔖 → appears in My Bookmarks; 📝 → note saves;
   📖 Tafseer → EN/UR tafseer loads.
6. **"← Surahs"** → back to the grid; surah grid still opens a surah
   exactly as before.
7. **Parah 1** → 148 ayat (1:1–2:141), Bismillah shown; **Parah 2** →
   starts 2:142, NO Bismillah line at the top.

## Known limitations (stated plainly)

- Share-as-image is NOT in the parah view (see above).
- After saving a note from a parah ayah, the 📝 button's active state
  refreshes on the next render (open/reopen or lang toggle), not
  instantly — `qsNotes` refreshes only `#ayah-list` buttons.
- The parah view follows the hero lang toggle but has no font-size
  (A+/A−) control of its own; Arabic renders at the default size.
- If any surah in a juz fails to load, the whole juz shows an error +
  Retry (never a partial juz) — on flaky data this means one retry tap.
- Play Full Parah has no "jump to ayah" input inside the view (the
  surah Reader has one); scrolling is the way to move inside a juz.
