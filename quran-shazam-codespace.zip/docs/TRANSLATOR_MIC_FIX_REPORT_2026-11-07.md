# Translator mic fix report — 2026-11-07 ~00:20 PKT

## Order
User (00:19 PKT, side chat): "joo translation wala mic hy woo bhi sai kaam
nhi krta osy bhi thk kro" — the Word Translator mic (Quran page, 🎙️ Speak
button next to the translate input) doesn't work properly; fix it too.

## Diagnosis (measured from code, working copy vs v116)
The mic code was IDENTICAL in both copies (no lineage gap this time) and the
button exists in `quran.html`, no `<form>` around it, script loads on the
Quran page. The implementation itself was the defect — it predates the
dictation discipline and lacks everything the other two mics gained:
1. **Silence while speaking** — no `interimResults`: the user speaks into
   nothing; the word only appears at the very end (or never).
2. **No stop/toggle** — once started it cannot be stopped; a double-tap
   spawns parallel recognizers that race.
3. **No stale-session guard** — a late result from an old session could
   overwrite the input (the F2 bug class fixed in dictation/speak-verify
   on 2026-10-29/30).
4. **Only `results[0][0]` read** — if the word arrives across segments,
   only the first is taken; no `isFinal` check.
5. **One generic error line** — every failure says "Could not hear",
   including permission denied and unsupported language, so the user
   cannot tell WHY it failed.
6. **Language invisible** — the mic listens in the direction tab's language
   but never says which; speaking Urdu on the default English tab fails
   silently.

## Change (working copy only, NOT deployed)
`backend/app/static/js/translator.js` — mic block rebuilt on the SAME
dictation concept (`setupDictation`, verify.js), no other translator
behaviour touched (typing, direction tabs, results, ayah links unchanged):
- `interimResults = true`, `continuous = false` (single-shot).
- Interim words shown LIVE in the input as you speak; results rebuilt from
  ALL segments each event.
- Only a FINAL result translates (once per session, `translated` flag).
- Tap again to stop (button flips Speak ↔ Stop); `trStopMic` nulls the
  shared `trRec` so a dead session's late results are stale and inert.
- Specific errors: permission → mic-permission message; no-speech →
  "kuch sunai nahi diya"; language-not-supported → language message with
  direction/type fallback hint; network/other → generic line.
- Status names the listening language: "🎙️ Listening in English… /
  Listening in Urdu…".

## Verification (gate only — phone test is the only verdict)
- `node --check` translator.js: OK.
- NEW harness `docs/translator_mic_harness_2026-11-07.js` (real file in a
  node vm, fake SpeechRecognition, stubbed /api/quran/translate):
  **37/37 PASS** — static (interim/continuous/stale-guard/toggle, old
  `ev.results[0][0]` gone) + behaviour (interim live, no translate on
  interim, final translates once with right q + direction, toggle-stop
  spawns no parallel session, stale result/onend inert, specific
  no-speech / permission / language messages, Urdu direction uses ur-PK,
  empty onend translates nothing).
- Full pytest suite: **154 passed**.

## Not deployed
Server + codespace stopped on his order. The fix lives only in
`~/workspace/quran-shazam/`. Phone test after the next deploy he orders is
the verdict — especially: tap Speak, watch the word appear live, speak an
Urdu word on the Urdu tab, and deny mic permission once to see the
specific message.
