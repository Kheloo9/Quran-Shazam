# Speak-verify continuous mic — PORT + CHANGE — 2026-11-04

**Status: IMPLEMENTED + HARNESS-GREEN (13/13) in the working copy. NOT deployed.
NOT started on any server. NO codespace touched. NO public link.**

**The user's phone test is the ONLY verdict.** Everything below is simulation
(a gate, never a completion claim). Real Android Chrome replay shapes,
tokenization, hamza spelling, merge/split behaviour and `onend` timing across
pauses can only be confirmed on his phone. Do not call this fixed until his
phone test passes.

## 0. User request (Roman Urdu, quoted)

> "Yaa mic ak dafa bolna ka bd rok jata asa hu sakta hy jitni dr bolta rahy
> banda bolta rahy utni dar on hi rahy or jitna insan boly utna hi text lekha
> kuch extra nhi"

The speak-verify mic (the "Awaz se foran verify karein" card on /verify:
"Mic on karein / Rok dein / Verify karein / Clear") stops after one
utterance. The user wants: as long as the person keeps speaking, the mic
stays ON; and the transcript must contain exactly what was spoken, nothing
extra.

## 1. Inventory of THIS copy first — the feature did not exist here

Scope: `~/workspace/quran-shazam/` ONLY (the Nov 4 working copy).
`~/workspace/quran-shazam-v116/` was read as reference only and is untouched
(mtimes still 2026-10-30 on all three source files). No other copy touched.

Verified by the lead before any team was briefed (targeted greps + a
whole-tree grep, which returned zero hits in this copy):

- This copy's `backend/app/templates/verify.html` was 167 lines: hero,
  "Your recitation" (Record live + upload), Verify button, live-transcript,
  transcript card, results card, history card, sticky bar. **No
  speak-verify card, no "Awaz se foran verify karein", no "Mic on karein".**
- This copy's `backend/app/static/js/verify.js` was 1344 lines with **no
  SpeechRecognition code at all**. The only SR code in the copy was the
  translator's voice input (`translator.js`) — untouched by this work.
- The card in the user's screenshot exists only in the v116 lineage:
  `v116/backend/app/templates/verify.html` lines 26–46 and
  `v116/backend/app/static/js/verify.js` setupSpeakVerify (~line 1672,
  "SPEAK-VERIFY REBUILD" 2026-10-30: per-tap single-shot,
  `continuous=false`, no auto-restart, no dedup).

**Consequence (stated plainly): this job was a PORT + CHANGE, not an edit.**
Without the port, the next deploy from this copy would have DELETED the
live card the user is complaining about. The port removes that deletion
risk. The port also means this copy's /verify is still NOT reconciled with
v116 in general (parity fixes, texting fixes, gap fixes are still
v116-only) — this report covers the speak-verify card only.

Port feasibility (checked before porting): this copy already had the
`$` helper (`verify.js` line 13), `renderResults(d, jobId)` (line 863),
the `/api/rematch` endpoint (`main.py` line 635), and the Re-match
handler's render payload shape — all reused verbatim for the Verify tap.

## 2. Files changed (all in ~/workspace/quran-shazam/)

1. `backend/app/templates/verify.html` — 167 → **204 lines**. Speak-verify
   card inserted at lines 19–55 (port-note comment + verbatim v116 card,
   `div#speak-verify-card` at line 32), immediately after the verify-hero
   `</section>` and before "Your recitation". All 8 IDs present exactly
   once each (lead-verified by grep): `speak-verify-card`,
   `btn-speak-verify-start` ("🎤 Mic on karein"),
   `btn-speak-verify-stop` ("Rok dein", disabled),
   `btn-speak-verify-check` ("✨ Verify karein"),
   `btn-speak-verify-clear` ("🗑️ Clear"), `speak-verify-status`,
   `speak-verify-check-hint`, `speak-verify-text`
   ("Yahan live text zahir hoga…"). Heading, Quick-check hint, long hint
   and privacy hint verbatim from v116. Note: the static HTML long hint
   still contains "dabayein" ("Verify karein dabayein") — verbatim v116
   HTML; the no-"dabayein" rule applies to JS strings only, and no new
   JS string uses it.
2. `backend/app/static/js/verify.js` — 1344 → **1750 lines**. New nested
   `(function setupSpeakVerify(){...})()` (header comment + section),
   inserted before the `init` section, after the Re-match handler, using
   the outer IIFE's `$` helper. Final sha256:
   `16204ad23816db0515543a17f7c34ab0f04e9956fb00501185b1c5ff15eac41c`.
   `node --check`: OK.
3. `backend/app/static/css/style.css` — 876 → **882 lines**.
   `.speak-verify-interim{opacity:.55;font-style:italic}` (dated comment),
   placed after the quran-promo block. Braces balanced 452/452.

No backend, matcher, verify flow, `renderResults` itself, main Record-live
mic, translator voice input, tests, or other copy was modified.

## 3. Behaviour as implemented (speak-verify card ONLY)

- **Continuous listening:** `rec.continuous = true`, `lang='ar-SA'`,
  `interimResults=true`. The mic keeps listening across natural pauses
  until the user taps "Rok dein" (commit partial + stop) or "Verify
  karein" (commit + stop + post). No per-utterance stop, no re-taps.
- **Finals only, ever:** `spokenText()` = committed + current-session
  finals, single-space joined. Interim renders in the faint
  `.speak-verify-interim` span only: never committed, never in
  `spokenText()`, never enables Verify.
- **In-session rebuild (v116 semantics kept):** on every `onresult`,
  session finals are rebuilt from scratch from that session's cumulative
  `e.results` (finals + interim separated). Nothing is appended across
  events inside a session, so a result can never count twice in-session.
- **Overlap-aware commit (the "nothing extra" gate):** session finals
  move into `committedFinal` ONLY at session end / Rok dein / Verify,
  through `appendOverlapAware()`:
  - Rule 1: incoming words fully contained as one contiguous subsequence
    of committed words (normalized comparison) → dropped entirely.
  - Rule 1b: re-tokenized FULL replay — normalized concatenation of
    incoming words is a substring of normalized committed concatenation
    → dropped entirely (covers merged "بسمالله" / split "و الله"
    tokenizations that word lists cannot see).
  - Rule 2: otherwise strip the LONGEST suffix of committed words equal
    to a prefix of incoming words, then append only the remainder.
  - Comparison is word-level on normalized words; appended words are
    the original, unaltered incoming words.
- **Comparison-only normalization** (`normalizeWord`): strips Arabic
  harakat/diacritics and punctuation for comparison, then canonicalizes
  hamza variants (`أ/إ/آ` → `ا`, `ؤ` → `و`, `ئ` → `ي`). Stored words
  are never altered. A token normalizing to empty falls back to raw, so
  empty can never falsely equal empty. Deliberately NOT mapped: `ة/ه`
  and `ى/ي` — those can distinguish genuinely different words.
- **Bounded auto-restart, no replay machinery:** if recognition ends
  unexpectedly while user intent (`listening`) is still true, the session
  commits once, then a new session starts WITHOUT re-committing
  anything. Hard bound: max 5 consecutive auto-restarts with no final
  result (counter resets on any final and on fresh Mic-on). Never
  restarts after user Stop/Clear/Verify or on permission errors
  (`not-allowed`/`service-not-allowed` stop immediately, no restart).
  Non-permission errors (no-speech/network/audio-capture) show
  transiently and let `onend` drive the bounded restart, because in
  continuous mode a pause must not kill listening. While auto-restart is
  active the status never tells the user to re-tap. On hitting the
  bound: "Mic band ho gaya hai — dobara Mic on par click farmayen."
- **Stale-session guards (v116 kept):** `recGen`/`myRec` guards on
  `onresult`/`onerror`/`onend` — late events from a stopped/cleared
  session can never write text or resurrect cleared text.
- **Preserved:** Clear wipes committed + session + stops mic; Verify
  disabled until `spokenText().length >= 2` (plus `checkBusy` during
  fetch, button shows "⏳ Matching…") with the always-visible static
  hint; Verify posts finals only to `/api/rematch` and renders with
  `renderResults` in exactly the Re-match payload shape
  (`transcript/results/coaching/verified_count/recognized_words/
  duration: 0/coverage: null`), then scrolls to `transcript-card`.
- **Deliberate deviations from v116 (all in the card only):**
  `continuous=true` (was `false`); overlap-aware commit (was plain
  join); bounded auto-restart (was none); Verify-tap commit-then-stop
  (v116 left the mic running across Verify, so a live session could
  append words after posting); non-permission `onerror` no longer stops
  the mic (v116 stopped on every error).

## 4. Why this handles the replay problem where exact dedup failed

History (do not repeat it): continuous mode was tried twice (Fix 1,
Fix 2) and FAILED on the user's Android Chrome phone — Chrome replays
segments with different tokenization, producing repeated/extra words
(Bismillah repeated, early ayat multiplied), and naive exact-match
dedup scored 0.

Exact dedup fails for three distinct reasons, and this design answers
each separately:

1. **Same words, same tokens, delivered twice** → Rule 1
   (contiguous-subsequence drop) and in-session rebuild catch it.
2. **Same words, different spelling** (harakat present vs absent,
   punctuation added, hamza spelled `أ` vs `ا`) → comparison-only
   normalization makes the replay recognizable WITHOUT changing the
   displayed words. This was a real harness failure (case 3a) before the
   hamza mapping was added.
3. **Same words, different token boundaries** (merged/split tokens) →
   Rule 1b concatenation comparison catches full replays that no
   word-list comparison can see.

What exact dedup could never do — recognize a replay it had never seen
in byte-identical form — the normalized + overlap + concatenation
comparison does, while still never inventing, filling, or altering a
word: every appended word is an original incoming word, and every
dropped word is one already present in committed text.

## 5. Harness results (node vm, this VM only — GATE, not verdict)

- Harness: `/tmp/speak-verify-harness.js` (only file the harness team
  wrote; app code read-only to them). Method: **full-file vm** —
  `vm.runInContext` on the real 1728-line `verify.js` (pre-lead-fix
  byte count; re-runs below used the current file), with DOM stubs and
  a capturable `FakeSpeechRecognition`, driven ONLY through the real
  buttons/text element. `/api/rematch` stubbed, body captured;
  matcher/renderResults NOT under test. Node v24.22.1. Fixtures:
  Bismillah + 112:1–4.
- **First run: 11/13.** Failures: 3a (hamza-variant replay appended
  wholesale) and 3b (merged-token replay appended) — both in the
  Chrome-replay path, as the implementation team had predicted for 3b.
- **Lead fix 1 (hamza canonicalization) → re-run: 12/13.** 3a passed.
- **Lead fix 2 (Rule 1b concatenation containment) → re-run: 13/13.**
  `node --check`: OK on the final file.

### Final per-case results (13/13 PASS)

1. **Multi-utterance continuous — PASS.** 1× Mic-on; session 1 finals
   [Bismillah] → [Bismillah, 112:1]; `onend` auto-restart; session 2
   finals [112:2] → [112:2, 112:3] → [112:2, 112:3, 112:4]; Rok dein.
   Transcript exactly the full 5-segment text, in order; mid-commit
   after the pause exactly Bismillah+112:1; no restart after Stop.
2. **Chrome replay, exact duplicate — PASS.** Session 2 repeats
   session 1 finals identically; second copy dropped entirely.
3a. **Chrome replay, re-tokenized (no harakat, +punctuation) — PASS
   (after hamza fix).** Vowelled session 1, unvowelled + trailing `،`
   replay in session 2; replay dropped, text once.
3b. **Chrome replay, merged tokens — PASS (after Rule 1b).**
   Session 1 [`بسم الله`], session 2 [`بسمالله`]; merged replay
   dropped, text once.
4. **Overlapping finals — PASS.** Session 2 starts with session 1's
   tail ([112:1, 112:2, 112:3] after [Bismillah, 112:1, 112:2]);
   overlap stripped, full text once.
5. **Interim-then-final — PASS.** Interim-only event: finals empty,
   interim shown, Verify disabled. After finals: words once, interim
   gone.
6. **Single utterance — PASS.** One final [112:1], Rok dein: exact text.
7. **Empty session — PASS.** Mic-on, `onend` with zero results:
   placeholder text, Verify disabled. (By design, the empty `onend`
   auto-restarts — mic still listening, no text created.)
8. **Rok dein mid-utterance — PASS.** Finals [Bismillah] + interim
   pending, Rok dein, late `onend`: transcript exactly Bismillah,
   interim discarded, mic stopped, no restart.
9. **Clear + stale-event probe — PASS.** Clear while listening, then
   late `onresult`+`onend` on the dead session: placeholder held,
   Verify disabled, nothing resurrected; fresh Mic-on adds only new
   text.
10. **Restart bound — PASS.** 10× unexpected `onend` with zero finals:
    exactly 6 instances total (original + 5 restarts), then bound
    status, placeholder, Verify disabled; further `onend`s create
    nothing.
11. **Permission errors — PASS.** `not-allowed` then
    `service-not-allowed`: immediate stop, zero restarts, permission
    status in both cases.
12. **Verify gating + posted transcript — PASS.** Verify disabled at
    load and interim-only (0 fetches in both states); enabled with
    finals; exactly 1 post with body
    `{"transcript":"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"}` (interim
    excluded); no restart after Verify.

## 6. Honest residuals and limitations (read before the phone test)

- **Phone test is the only verdict.** Simulated recognition events are
  not Chrome. If his phone test still shows extras, see §8 before
  changing anything else.
- **Partial merged/split overlap remains open.** Rule 1b drops only
  FULL re-tokenized replays. A chunk that is part replay (merged/split
  tokens) + part genuinely new words in one delivery may still
  duplicate its replayed part, because mapping a concatenated match
  back to word boundaries could split a word. Word-level partial
  overlaps ARE handled (case 4); only tokenization-changed partial
  overlaps are not.
- **Legitimate repetition is dropped by design (spec trade-off).**
  Rule 1 drops ANY fully-contained subsequence — including a genuinely
  re-recited identical ayah later in the same accumulated text (e.g.
  a repeated verse). This is the price of the specified "nothing
  extra" rule, not a bug in its implementation; it applies equally to
  the word-level rules and was accepted in the brief.
- **`ة/ه` and `ى/ي` variants are NOT canonicalized** (deliberate, §3):
  a replay differing only in those letters may still duplicate.
- **Matcher/renderResults not under test.** `/api/rematch` response
  shape is assumed identical to this copy's Re-match handler, and
  `renderResults`' own display was not re-verified (untouched by
  design). This copy's `renderResults` still predates the v116 parity
  fixes — empty-result display behaviour on this copy is whatever the
  pre-parity code does, and is out of this task's scope.
- **Implementation-team overlap unit tests (11/11)** were run on
  functions extracted from the edited file (normalizer range bug
  caught and fixed there: a literal-character range starting at U+0610
  had swallowed Arabic base letters). The full-file harness above is
  the authoritative gate, not those unit tests.

## 7. Phone test pattern (exact — the only verdict)

On the deployed link, on his Android Chrome phone, after the deploy
he orders:

1. Open **/verify**. Confirm the FIRST card is "🎤 Awaz se foran
   verify karein" with buttons Mic on karein / Rok dein / Verify
   karein / Clear.
2. Tap **Mic on karein ONCE — and do not tap it again**.
3. Recite **Bismillah + Surah Al-Ikhlas 112:1–4 with natural pauses**
   between ayat, at normal tartil pace, without re-tapping anything.
4. Check the live text box: it must equal **exactly** the spoken
   words, in order — no repeated Bismillah, no multiplied early ayat,
   no extra words, no dropped ayat. Interim (faint) words mid-recitation
   are expected; only the final committed text counts.
5. Tap **Rok dein**, confirm the text is unchanged and the mic stops.
6. Tap **Verify karein**, confirm results render for the spoken text.
7. Separately: tap Mic on, say nothing / Clear, confirm Verify stays
   disabled and cleared text never comes back.

Pass = all of the above. Anything else = fail, report exactly what the
box showed (screenshot + which words repeated), and use §8.

## 8. Revert path (if his phone test still shows extras)

Restore single-shot behaviour in `verify.js` ONLY (keep the ported card
and CSS):

1. In `startSession()`: set `rec.continuous = false`.
2. In `onend`: remove the auto-restart branch — commit once via
   `commitSessionFinals()`, set `listening = false`, `setUI()`, and
   show the v116-style status ("Ye hissa mehfooz ho gaya hai — agli
   ayat ke liye dobara Mic on par click farmayen."). Keep the bound
   counter harmless (it will never increment without restarts).
3. Optionally simplify `commitSessionFinals()` to the v116 plain join
   (replace the `appendOverlapAware` call with direct join) — but
   keeping the overlap-aware commit under single-shot is harmless and
   preserves replay protection across taps, so prefer keeping it.
4. Re-run `node --check` and the harness (`/tmp/speak-verify-harness.js`;
   cases 1/3/10 expectations change under single-shot: multi-utterance
   will require re-taps, and the restart-bound case becomes vacuous).
5. Do NOT revert the card port: deleting the card would remove the
   feature from the next deploy again.

## 9. Next step (parent acts only on the user's explicit order)

**Deploy from `~/workspace/quran-shazam/`** carrying the port +
continuous change (plus the earlier Q&A removal, Resume relocation and
promo-heading fix already in this copy — separate items, same deploy
only if the user orders them together). End state now: fixed copy +
this report, NOT deployed, server NOT started.
