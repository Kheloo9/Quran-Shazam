# Quran Shazam — FREE hosting on Hugging Face Spaces

Hugging Face Spaces gives you **free hosting with 16 GB RAM** (enough for the
AI model) and a **free permanent web address** like:

`https://YOURNAME-quran-shazam.hf.space`

No credit card needed. Steps (one time, ~15 minutes):

## 1. Create a free account
Go to https://huggingface.co/join and sign up (email + password).

## 2. Create a new Space
- Go to https://huggingface.co/new-space
- **Space name:** `quran-shazam` (or anything you like)
- **SDK:** choose **Docker**
- **Hardware:** leave the free CPU tier selected
- Click **Create Space**.

## 3. Upload the project files
On your new Space page, click **Files** → **+ Add file** → **Upload files**,
then drag in the contents of the `quran-shazam-website.zip` from this package:
`requirements.txt`, the `backend/` folder, and the `deploy/` folder.

Then **rename** `deploy/huggingface-spaces/Dockerfile` to just `Dockerfile`
in the **root** of the Space (Spaces looks for `./Dockerfile`).
You can do this in the web UI: open the file → ⋮ menu → Rename.

So the Space root looks like:
```
Dockerfile            <- renamed from deploy/huggingface-spaces/Dockerfile
requirements.txt
backend/
deploy/
```

## 4. Wait for the build
The Space will build the Docker image automatically (takes ~10–20 minutes
the first time — it installs Python packages and FFmpeg). Watch the
**Logs** tab. When you see the app start and `/api/health` return ready,
your site is LIVE at `https://YOURNAME-quran-shazam.hf.space`.

## Notes
- The first verification after a cold start takes 2–4 minutes while the AI
  model loads into memory — this is normal.
- Free Spaces sleep after long inactivity and wake on the next visit
  (wake-up takes a couple of minutes). For an always-on site, HF's paid
  CPU upgrade (~$9/month) or a small VPS works.
- The Quran text corpus (`backend/data/quran.json`) is bundled, so the
  Space does not depend on any external download at boot.
- Never commit secrets: the app needs no API keys by default.
