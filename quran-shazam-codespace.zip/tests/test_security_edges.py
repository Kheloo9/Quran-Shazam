"""Security-module edge tests (Team 5, 2026-10-22).

Unit tests for the pure security helpers in backend/app/security.py that the
existing API-level tests don't cover:
  - validate_upload: traversal filenames, case tricks, double extensions,
    missing filenames, advisory-only MIME handling.
  - check_signature_or_raise / _has_known_signature: every supported magic
    signature positive, every hostile blob negative.
  - peek_signature: rewinds the upload so later reads see the full body.
  - safe_temp_path: uuid-based, unique per call, immune to traversal.
All synchronous/asynchronous via asyncio.run — no server, no model.
"""
import asyncio
import io
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException
from starlette.datastructures import Headers
from starlette.datastructures import UploadFile as StarletteUploadFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.security import (
    check_signature_or_raise,
    peek_signature,
    safe_temp_path,
    validate_upload,
)


def _upload(filename, content_type="audio/mpeg"):
    return StarletteUploadFile(
        file=io.BytesIO(b"\xff\xfb" + b"\x00" * 64),
        filename=filename,
        headers=Headers({"content-type": content_type}) if content_type else None,
    )


# ---------------------------------------------------- validate_upload ----
def test_traversal_filename_keeps_only_extension():
    # The filename is never trusted beyond its extension (safe_temp_path
    # ignores it entirely) — so even a traversal attempt must reduce to
    # the extension alone.
    ext = validate_upload(_upload("../../etc/passwd.mp3"))
    assert ext == ".mp3"


def test_uppercase_extension_normalized():
    assert validate_upload(_upload("voice.MP3")) == ".mp3"


def test_double_extension_uses_real_suffix():
    # "file.mp3.exe" is an .exe, not an .mp3 — must be rejected.
    with pytest.raises(HTTPException) as e:
        validate_upload(_upload("recording.mp3.exe"))
    assert e.value.status_code == 415


@pytest.mark.parametrize("filename", ["", None, "   "])
def test_missing_or_blank_filename_rejected(filename):
    with pytest.raises(HTTPException) as e:
        validate_upload(_upload(filename))
    assert e.value.status_code == 415


def test_extensionless_rejected():
    with pytest.raises(HTTPException) as e:
        validate_upload(_upload("noextension"))
    assert e.value.status_code == 415


def test_unknown_audio_extension_rejected():
    with pytest.raises(HTTPException) as e:
        validate_upload(_upload("clip.aacx"))
    assert e.value.status_code == 415


def test_wrong_client_mime_is_advisory_not_fatal():
    # Mobile pickers mislabel audio; the docstring says the MIME check is
    # advisory and must never block a valid file (magic bytes decide).
    assert validate_upload(_upload("clip.mp3", content_type="text/plain")) == ".mp3"
    assert validate_upload(_upload("clip.mp3", content_type="audio/x-mpeg3")) == ".mp3"
    assert validate_upload(_upload("clip.mp3", content_type=None)) == ".mp3"


# -------------------------------------- magic-byte signature sniffing ----
VALID_HEADS = [
    b"\xff\xfb\x90\x00" + b"\x00" * 12,          # MP3 frame sync (MPEG-1)
    b"\xff\xf3\x90\x00" + b"\x00" * 12,          # MP3 frame sync (MPEG-2)
    b"RIFF" + b"\x00" * 4 + b"WAVE",             # WAV
    b"\x00\x00\x00\x18ftypisom" + b"\x00" * 8,   # MP4/M4A (ftyp at offset 4)
    b"fLaC" + b"\x00" * 12,                      # FLAC
    b"OggS" + b"\x00" * 12,                      # OGG / Opus
    b"\x1a\x45\xdf\xa3" + b"\x00" * 12,          # Matroska / WebM
]


@pytest.mark.parametrize("head", VALID_HEADS)
def test_known_signatures_accepted(head):
    check_signature_or_raise(head)  # must not raise


HOSTILE_BLOBS = [
    b"",                                  # empty body
    b"\xff",                              # truncated single byte
    b"PK\x03\x04" + b"\x00" * 12,         # ZIP (renamed apk/docx attack)
    b"%PDF-1.4" + b"\x00" * 9,            # PDF
    b"MZ" + b"\x00" * 14,                 # Windows executable
    b"<?php echo 1;" + b" " * 6,          # script upload
    b"This is not audio at all. " + b"x" * 40,  # plain text
    b"\x00" * 16,                         # null blob
]


@pytest.mark.parametrize("blob", HOSTILE_BLOBS)
def test_hostile_blobs_rejected(blob):
    with pytest.raises(HTTPException) as e:
        check_signature_or_raise(blob)
    assert e.value.status_code == 415


# ------------------------------------------------------- peek_signature ----
def test_peek_signature_rewinds_for_later_reads():
    body = b"\xff\xfb" + b"\x00" * 64
    f = StarletteUploadFile(file=io.BytesIO(body), filename="x.mp3")

    head = asyncio.run(peek_signature(f, 16))
    assert head == body[:16]

    # After peeking, a fresh read must see the FULL body again.
    rest = asyncio.run(f.read())
    assert rest == body


# --------------------------------------------------------- safe_temp_path ----
def test_safe_temp_path_unique_and_contained(tmp_path):
    p1 = safe_temp_path(tmp_path, ".mp3")
    p2 = safe_temp_path(tmp_path, ".mp3")
    assert p1 != p2  # uuid -> no collisions
    assert str(p1).startswith(str(tmp_path))


def test_safe_temp_path_immune_to_traversal(tmp_path):
    # The real pipeline couples the two helpers: validate_upload returns
    # Path(filename).suffix, which can never contain a path separator, and
    # safe_temp_path only ever sees that suffix. A traversal filename must
    # therefore land safely inside the data dir end-to-end.
    ext = validate_upload(_upload("../../etc/passwd.mp3"))
    p = safe_temp_path(tmp_path, ext)
    assert p.parent == tmp_path
    assert p.resolve().parent == tmp_path.resolve()
    assert p.name.startswith("upload_") and p.suffix == ".mp3"
