from pathlib import Path
import json
import tempfile
from app.engine.corpus import QuranCorpus, CorpusError, EXPECTED_AYAT
from app.engine.normalization import normalize_arabic
from app.engine.matcher import align_transcript, recover_single_gap

IKHLAS=[
    {"verse":1,"text":"قُلْ هُوَ اللَّهُ أَحَدٌ"},
    {"verse":2,"text":"اللَّهُ الصَّمَدُ"},
    {"verse":3,"text":"لَمْ يَلِدْ وَلَمْ يُولَدْ"},
    {"verse":4,"text":"وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ"},
]

def fixture(tmp_path: Path):
    # 6236 is validated in production; this fixture is intentionally small for matcher unit tests.
    p=tmp_path/"quran.json"
    obj={"112":IKHLAS}
    p.write_text(json.dumps(obj,ensure_ascii=False),encoding="utf-8")
    c=QuranCorpus(tmp_path); c.path=p
    # Load through private loader then override ready for test-only corpus behavior.
    try: c._load_file(p)
    except CorpusError: pass
    # Build a small synthetic corpus manually.
    from app.engine.corpus import Verse
    c.verses=[Verse(f"112:{x['verse']}",112,x['verse'],x['text'],normalize_arabic(x['text']),i+1) for i,x in enumerate(IKHLAS)]
    c.by_key={v.key:v for v in c.verses}; c.by_surah={112:c.verses}; c.inverted={}
    for v in c.verses:
        for t in set(normalize_arabic(v.text).split()):
            if len(t)>=2: c.inverted.setdefault(t,[]).append(v)
    return c

def test_normalization():
    assert normalize_arabic("أَكْرَمَ") == "اكرم"

def test_repetition_is_preserved():
    # The matcher uses normalization only; no destructive phrase collapsing is allowed.
    text="قُلْ هُوَ اللَّهُ أَحَدٌ قُلْ هُوَ اللَّهُ أَحَدٌ"
    assert len(normalize_arabic(text).split())==8

def test_sequence_recovers_missing_middle_ayah(tmp_path, monkeypatch):
    import app.engine.corpus as corpus_mod
    monkeypatch.setattr(corpus_mod, "EXPECTED_AYAT", 4)
    monkeypatch.setattr(corpus_mod, "EXPECTED_SURAHS", 1)
    c=fixture(tmp_path)
    # ASR omitted the second Ayah but strongly recognized Ayat 1,3,4.
    transcript="قُل هو الله أحد لم يلد ولم يولد ولم يكن له كفوا أحد"
    matches=align_transcript(c, transcript)
    recovered=recover_single_gap(c,matches,transcript)
    keys=[m.verse.key for m in recovered]
    assert "112:1" in keys
    assert "112:3" in keys
    assert "112:4" in keys
    # The second Ayah can be surfaced only as sequence recovery, never silently promoted.
    if "112:2" in keys:
        m=next(x for x in recovered if x.verse.key=="112:2")
        assert m.status=="SEQUENCE RECOVERY"

def test_empty_corpus_is_not_ready(tmp_path, monkeypatch):
    # Fail-closed: with no local corpus and no network, ensure() must raise
    # and the corpus must stay not-ready (verification stays blocked).
    import app.engine.corpus as corpus_mod

    def _no_network(*a, **k):
        raise ConnectionError("network unavailable (test)")

    monkeypatch.setattr(corpus_mod.requests, "get", _no_network)
    c = QuranCorpus(tmp_path)
    assert not c.ready
    try:
        c.ensure()
    except Exception:
        pass
    assert not c.ready

def test_exporters_roundtrip():
    from app.engine.export import to_txt, to_srt, to_vtt, to_json
    segs = [
        {"start": 0.0, "end": 2.5, "text": "قل هو الله أحد"},
        {"start": 3.0, "end": 5.25, "text": "الله الصمد"},
    ]
    assert "قل هو الله أحد" in to_txt(segs)
    srt = to_srt(segs)
    assert "1\n00:00:00,000 --> 00:00:02,500\nقل هو الله أحد" in srt
    vtt = to_vtt(segs)
    assert vtt.startswith("WEBVTT") and "00:00:03.000 --> 00:00:05.250" in vtt
    import json
    assert json.loads(to_json(segs))["segments"][1]["text"] == "الله الصمد"


def test_exporters_skip_empty_segments():
    from app.engine.export import to_srt
    segs = [{"start": 0.0, "end": 1.0, "text": "  "}, {"start": 1.0, "end": 2.0, "text": "نص"}]
    out = to_srt(segs)
    assert out.startswith("1\n") and "نص" in out and out.count("-->") == 1

def test_u0670_becomes_alef_not_stripped():
    # U+0670 (superscript alef) must become a regular alef, not disappear.
    # "الصِّرَٰطَ" should normalize to "الصراط", not "الصرط".
    assert normalize_arabic("ٱلصِّرَٰطَ") == "الصراط"

def test_ta_marbuta_normalized_to_ha():
    # ASR often outputs ه for ة — normalize so fuzzy matching works.
    assert normalize_arabic("الرحمة") == normalize_arabic("الرحمه")

def test_fuzzy_coverage_counts_near_misses():
    # "اهدن" (ASR error) should count as covering "اهدنا" (not 0% coverage).
    from app.engine.matcher import coverage, missing
    assert coverage("اهدن الصراط", "اهدنا الصراط") > 50.0
    assert missing("اهدنا الصراط", "اهدن الصراط") < 50.0

def test_short_verse_not_verified():
    # A 2-word match must NEVER get VERIFIED label (min 3 words required).
    # This prevents false VERIFIED on single distinctive words.
    # The label loop lives in _match_and_label (shared by the local path
    # and the Gemini fallback); verify() calls it, it does not inline it.
    import app.engine.service as svc
    import inspect
    src = inspect.getsource(svc.VerificationService._match_and_label)
    assert "m.length >= 3" in src
