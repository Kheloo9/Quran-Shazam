"""API security tests: upload validation, headers, error hygiene.

The real AI engine is stubbed out — these tests exercise the HTTP security
layer only (no model download, no FFmpeg, no corpus needed).
"""
import io

import pytest
from fastapi.testclient import TestClient

import app.main as main_module


class _StubCorpus:
    ready = True


class _StubService:
    corpus = _StubCorpus()

    def health(self):
        return {"ready": True, "corpus": {"ready": True}, "asr_model": "stub", "asr_loaded": False, "error": None}

    def diagnostics(self):
        return self.health()

    def verify(self, path, request_id="-", progress=None, on_partial=None):
        # Mimic production: undecodable media surfaces as a client-safe
        # error on the job (async API: POST returns 202, error is polled).
        raise RuntimeError("This file could not be decoded as audio/video.")


def _wait_for_job(client, job_id, timeout=20):
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = client.get(f"/api/jobs/{job_id}")
        assert r.status_code == 200, r.text
        data = r.json()
        if data["status"] in ("done", "error"):
            return data
        time.sleep(0.2)
    raise AssertionError("job did not reach a terminal state in time")


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setattr(main_module, "get_service", lambda: _StubService())
    # Reset the in-memory rate-limit counters so each test is deterministic
    # regardless of execution order (RATE_LIMIT_VERIFY=5/minute via conftest).
    main_module.limiter._storage.reset()
    with TestClient(main_module.app, raise_server_exceptions=False) as c:
        yield c


def _upload(client, filename, content: bytes, content_type="audio/mpeg"):
    return client.post(
        "/api/verify",
        files={"file": (filename, io.BytesIO(content), content_type)},
    )


# ------------------------------------------------------- upload validation
def test_rejects_disallowed_extension(client):
    r = _upload(client, "evil.exe", b"MZ" + b"\x00" * 64)
    assert r.status_code == 415


def test_rejects_missing_extension(client):
    r = _upload(client, "noextension", b"\xff\xfb" + b"\x00" * 64)
    assert r.status_code == 415


def test_rejects_bad_magic_bytes(client):
    # .mp3 extension but content is plain text -> magic-byte sniffing must catch it
    r = _upload(client, "fake.mp3", b"This is not audio at all, just text. " * 4)
    assert r.status_code == 415


def test_rejects_empty_file(client):
    # Zero bytes: fails magic-byte sniffing before any processing happens.
    r = _upload(client, "empty.wav", b"")
    assert r.status_code == 415


def test_handles_path_traversal_filename_safely(client):
    # The client filename is never used for the temp path (uuid name + only
    # the extension is taken), so a traversal name is harmless. Async API:
    # accepted, then the stubbed engine's decode failure surfaces on the job.
    # Must not 500 and must not touch anything outside the data dir.
    r = _upload(client, "../../etc/passwd.mp3", b"ID3" + b"\x00" * 64)
    assert r.status_code == 202
    job = _wait_for_job(client, r.json()["job_id"])
    assert job["status"] == "error"


def test_error_body_has_no_traceback(client):
    r = _upload(client, "fake.mp3", b"not audio")
    body = r.text.lower()
    assert "traceback" not in body
    assert ".py" not in body or "request_id" in r.json()


# ------------------------------------------- misreported client MIME types
def test_accepts_mislabeled_mime_with_valid_content(client):
    # Mobile file pickers/webviews often mislabel audio (audio/x-mpeg3,
    # audio/3gpp, ...). A valid .mp3 by magic bytes must not be rejected for
    # its MIME label. Async API: 202 accepted; the stubbed engine's decode
    # failure surfaces as a client-safe error on the polled job.
    r = _upload(client, "recitation.mp3", b"ID3" + b"\x00" * 64, content_type="audio/x-mpeg3")
    assert r.status_code == 202
    job = _wait_for_job(client, r.json()["job_id"])
    assert job["status"] == "error"
    assert "decoded" in job["error"]


def test_still_rejects_bad_content_despite_mislabeled_mime(client):
    # Softening the MIME check must not weaken the real content checks.
    r = _upload(client, "fake.mp3", b"This is not audio at all, just text. " * 4,
                content_type="audio/x-mpeg3")
    assert r.status_code == 415


# ------------------------------------------------------------- headers
def test_security_headers_present(client):
    r = client.get("/")
    assert r.status_code == 200
    assert r.headers["X-Frame-Options"] == "DENY"
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert "Content-Security-Policy" in r.headers
    assert "frame-ancestors 'none'" in r.headers["Content-Security-Policy"]
    assert r.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"


def test_request_id_header_present(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.headers.get("X-Request-Id")


def test_health_exposes_no_secrets(client):
    body = r = client.get("/api/health").json()
    flat = str(body).lower()
    assert "api_key" not in flat and "secret" not in flat


# ---------------------------------------------------------- rate limiting
def test_verify_rate_limit_enforced(client):
    # RATE_LIMIT_VERIFY=5/minute via conftest; 6 rapid rejected uploads -> 429
    last = None
    for _ in range(7):
        last = _upload(client, "fake.mp3", b"not audio")
    assert last.status_code == 429
    assert "request_id" in last.json()
