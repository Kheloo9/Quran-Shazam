"""Regression tests: dua audio must cover EXACTLY the displayed dua text.

User report (2026-10-23): on /duas, the Qari audio played MORE than the dua
text shown on the card (e.g. 2:201's everyayah MP3 starts with "wa minhum man
yaqoolu", 3:173 plays 13 extra narrative words before "hasbunallahu").

v11_6 fixed it by lengthening the cards to full ayat; the user rejected that
("baki kuch bhi nhi change krna") — cards stay SHORT, so the audio itself is
pre-clipped to exactly the dua words (Whisper word-timestamps + ffmpeg, cut
from the Qari's everyayah MP3s; AI-TTS stays forbidden for Quranic Arabic
per the project audio rule).

New invariant locked here: every dua with a "Quran S:A[-B]" reference
carries a `clip` field naming a pre-clipped MP3 under
backend/app/static/audio/duas/, and the frontend (static/js/duas.js) plays
that clip instead of the whole-ayah stream. Duas without a Quran reference
use Arabic AI-TTS (exact by construction) and must NOT carry a clip.
"""
import re
from pathlib import Path

from app.engine.corpus import QuranCorpus
from app.engine.duas import DUAS

BACKEND = Path(__file__).resolve().parents[1] / "backend"
CLIP_DIR = BACKEND / "app" / "static" / "audio" / "duas"


def _load_corpus():
    c = QuranCorpus(BACKEND / "data")
    c.ensure()
    assert c.ready, "corpus must load 6236 ayat / 114 surahs"
    return c


def _parse_quran_ref(reference):
    m = re.search(r"\bQuran\s+(\d{1,3}):(\d{1,3})(?:-(\d{1,3}))?", reference or "", re.I)
    if not m:
        return None
    s, a1 = int(m.group(1)), int(m.group(2))
    a2 = int(m.group(3)) if m.group(3) else a1
    return s, min(a1, a2), max(a1, a2)


def _quran_duas():
    return [d for d in DUAS if _parse_quran_ref(d["reference"])]


def test_quran_duas_carry_clip_field():
    quran_duas = _quran_duas()
    assert len(quran_duas) >= 5, "expected the Quranic duas to be present"
    for d in quran_duas:
        assert d.get("clip"), (
            f"dua {d['title']!r}: Quran-referenced dua must carry a pre-clipped "
            f"audio file in `clip` (audio would otherwise play more than shown)"
        )


def test_clip_files_exist_and_are_valid_mp3():
    for d in _quran_duas():
        p = CLIP_DIR / d["clip"]
        assert p.is_file(), f"dua {d['title']!r}: clip file missing: {p}"
        raw = p.read_bytes()
        # MP3 validity: non-trivial size + ID3 tag or MPEG frame sync.
        assert len(raw) > 10_000, f"dua {d['title']!r}: clip suspiciously small"
        assert raw[:3] == b"ID3" or (raw[0] == 0xFF and raw[1] & 0xE0 == 0xE0), (
            f"dua {d['title']!r}: clip is not a valid MP3"
        )


def test_hadith_duas_have_no_clip():
    for d in DUAS:
        if _parse_quran_ref(d["reference"]) is None:
            assert not d.get("clip"), (
                f"dua {d['title']!r}: non-Quranic dua must use Arabic AI-TTS, "
                f"not a Qari clip"
            )


def test_dua_references_are_valid():
    corpus = _load_corpus()
    for d in DUAS:
        parsed = _parse_quran_ref(d["reference"])
        if parsed is None:
            # Non-Quran reference (hadith collection) -> Arabic AI-TTS path,
            # which speaks exactly the displayed text. Just require a reference.
            assert d["reference"], f"dua {d['title']!r} has no reference at all"
            continue
        s, a1, a2 = parsed
        assert 1 <= s <= 114, f"dua {d['title']!r}: bad surah {s}"
        assert f"{s}:{a1}" in corpus.by_key, f"dua {d['title']!r}: ayah {s}:{a1} missing"
        assert f"{s}:{a2}" in corpus.by_key, f"dua {d['title']!r}: ayah {s}:{a2} missing"


def test_dua_audio_range_matches_js_parser():
    # The frontend (static/js/duas.js parseQuranRef) routes the 🔊 button by
    # the SAME "Quran S:A[-B]" grammar; keep the backend test grammar in sync
    # so a reference the test accepts is one the player will route to the Qari.
    for d in DUAS:
        ref = d["reference"]
        js_would_route_to_qari = bool(
            re.search(r"\bQuran\s+(\d{1,3}):(\d{1,3})(?:-(\d{1,3}))?", ref or "", re.I)
        )
        assert js_would_route_to_qari == (_parse_quran_ref(ref) is not None), (
            f"dua {d['title']!r}: backend/frontend reference grammar mismatch"
        )
