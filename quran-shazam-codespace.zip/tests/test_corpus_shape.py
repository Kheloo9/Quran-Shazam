"""Regression test: the loader must parse the real quran-json dataset shape.

quran-json 3.1.2 ships quran.json / quran_en.json / quran_ur.json as a LIST of
114 surah objects, each with a nested "verses" list — not a dict keyed by
surah. A loader that only handles the dict shape silently loads 0 verses and
(fail-closed) blocks all verification. This test locks in the real shape.
"""
import json
from pathlib import Path

from app.engine.corpus import QuranCorpus


def _write_nested(tmp_path: Path, n_surahs: int = 2, ayat_each: int = 3) -> Path:
    obj = [
        {
            "id": s,
            "name": f"Surah {s}",
            "verses": [{"id": a, "text": f"نص الآية {s}:{a} بِسْمِ"} for a in range(1, ayat_each + 1)],
        }
        for s in range(1, n_surahs + 1)
    ]
    p = tmp_path / "quran.json"
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
    return p


def test_nested_surah_list_shape_parses(tmp_path, monkeypatch):
    import app.engine.corpus as corpus_mod

    monkeypatch.setattr(corpus_mod, "EXPECTED_AYAT", 6)
    monkeypatch.setattr(corpus_mod, "EXPECTED_SURAHS", 2)
    p = _write_nested(tmp_path)
    c = QuranCorpus(tmp_path)
    c.path = p
    c._load_file(p)
    assert len(c.verses) == 6
    assert c.by_key["1:1"].surah == 1 and c.by_key["2:3"].ayah == 3
    assert c.ready


def test_translations_nested_shape_parses(tmp_path, monkeypatch):
    import app.engine.corpus as corpus_mod

    monkeypatch.setattr(corpus_mod, "EXPECTED_AYAT", 6)
    monkeypatch.setattr(corpus_mod, "EXPECTED_SURAHS", 2)
    _write_nested(tmp_path)
    c = QuranCorpus(tmp_path)
    c.path = tmp_path / "quran.json"
    c._load_file(c.path)

    class _Resp:
        def raise_for_status(self): pass

        def json(self):
            return [
                {"id": 1, "verses": [{"id": 1, "translation": "In the name of God"}]},
                {"id": 2, "verses": [{"id": 3, "translation": "Third verse"}]},
            ]

    monkeypatch.setattr(corpus_mod.requests, "get", lambda *a, **k: _Resp())
    c.load_translations()
    assert c.translations_en["1:1"] == "In the name of God"
    assert c.translations_en["2:3"] == "Third verse"
