"""Tests for word-level forced alignment (coach.py align_words).

PROFESSIONAL REDESIGN Stage 4-lite (2026-10-21): Coach must tell apart
MISSED words from SUBSTITUTED (mispronounced) words, with honest
timestamps from the ASR's own word timings. No model needed — synthetic.
"""
from app.engine.coach import align_words, build_coaching, _time_map
from app.engine.normalization import normalize_arabic, tokens

# Al-Fatihah 1:6 normalized -> اهدنا الصراط المستقيم (3 words)
A6 = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ"
REF6 = tokens(A6)
assert len(REF6) == 3, REF6


def _segs(words_with_times):
    # words_with_times: list of (word, start, end)
    return [{"start": 0.0, "end": 9.0, "text": "x",
             "words": [{"w": w, "start": s, "end": e}
                       for w, s, e in words_with_times]}]


def test_perfect_alignment_all_matched():
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(REF6)])
    al = align_words(A6, list(REF6), segs[0]["words"])
    assert len(al) == 3
    assert all(a["status"] == "matched" for a in al)
    assert al[0]["t_start"] == 0.0 and al[2]["t_end"] == 2.5
    assert [a["ref"] for a in al] == REF6


def test_substitution_detected_not_missed():
    # Reciter said a DIFFERENT word in the middle -> substituted, not missed.
    heard = [REF6[0], "الصراط", "الضالين"]  # wrong 3rd word
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(heard)])
    al = align_words(A6, heard, segs[0]["words"])
    by_ref = {a["ref"]: a for a in al if a["ref"]}
    assert by_ref[REF6[0]]["status"] == "matched"
    sub = by_ref[REF6[2]]
    assert sub["status"] == "substituted"
    assert sub["hyp"] == "الضالين"
    assert sub["t_start"] == 2.0  # timestamp of the HEARD wrong word


def test_deletion_is_missed_no_timestamp():
    heard = [REF6[0], REF6[2]]  # middle word missing
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(heard)])
    al = align_words(A6, heard, segs[0]["words"])
    by_ref = {a["ref"]: a for a in al if a["ref"]}
    assert by_ref[REF6[1]]["status"] == "missed"
    assert by_ref[REF6[1]]["hyp"] is None
    assert by_ref[REF6[1]]["t_start"] is None  # never invent timings


def test_insertion_is_extra():
    heard = REF6 + ["زيادة"]
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(heard)])
    al = align_words(A6, heard, segs[0]["words"])
    extras = [a for a in al if a["status"] == "extra"]
    assert len(extras) == 1 and extras[0]["hyp"] == "زيادة"
    assert extras[0]["t_start"] == 3.0


def test_near_miss_stays_matched_not_substituted():
    # ASR spelling wobble (اهدن vs اهدنا, similarity >= 80) must NOT be
    # punished as a mispronunciation — consistent with _is_heard.
    heard = ["اهدن", REF6[1], REF6[2]]
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(heard)])
    al = align_words(A6, heard, segs[0]["words"])
    assert al[0]["status"] == "matched"


def test_dropped_word_gets_no_timestamp():
    # Overlap-dedup dropped the middle word from segments: alignment must
    # still work and give None instead of shifting every timestamp.
    heard = list(REF6)
    seg_words = [{"w": REF6[0], "start": 0.0, "end": 0.5},
                 {"w": REF6[2], "start": 2.0, "end": 2.5}]
    times = _time_map(heard, seg_words)
    assert times[0][:2] == (0.0, 0.5)
    assert times[1][:2] == (None, None)
    assert times[2][:2] == (2.0, 2.5)


def test_empty_heard_marks_all_missed():
    al = align_words(A6, [], [])
    assert len(al) == 3
    assert all(a["status"] == "missed" for a in al)


def test_build_coaching_carries_alignment():
    transcript = " ".join(REF6)
    segs = _segs([(w, float(i), float(i) + 0.5) for i, w in enumerate(REF6)])
    results = [{"surah": 1, "ayah": 6, "key": "1:6", "text": A6,
                "label": "VERIFIED TEXT MATCH",
                "transcript_start": 0, "transcript_length": 3}]
    out = build_coaching(transcript, results, segs)
    item = out["ayat"][0]
    assert len(item["word_alignment"]) == 3
    assert item["substituted_words"] == []
    assert all(a["status"] == "matched" for a in item["word_alignment"])


def test_build_coaching_recovery_has_empty_alignment():
    out = build_coaching("", [{"surah": 1, "ayah": 2, "key": "1:2",
                               "text": "الحمد لله رب العالمين",
                               "label": "SEQUENCE RECOVERY",
                               "transcript_start": 0,
                               "transcript_length": 0}], [])
    item = out["ayat"][0]
    assert item["word_alignment"] == []  # nothing heard — don't fake it
    assert item["status"] == "missing"


def test_build_coaching_without_segments_still_works():
    # Backward compatible: old callers pass no segments.
    transcript = " ".join(REF6)
    results = [{"surah": 1, "ayah": 6, "key": "1:6", "text": A6,
                "label": "VERIFIED TEXT MATCH",
                "transcript_start": 0, "transcript_length": 3}]
    out = build_coaching(transcript, results)
    item = out["ayat"][0]
    assert all(a["status"] == "matched" for a in item["word_alignment"])
    assert all(a["t_start"] is None for a in item["word_alignment"])


# ---------------------------------------------------------------------
# WORD CONFIDENCE / "uncertain" status (ADR-0010, 2026-10-21)
# A substituted word the model itself doubts (prob < 0.70) must NOT
# blame the reciter — it becomes "uncertain", not "substituted".
# ---------------------------------------------------------------------
from app.engine.coach import _UNCERTAIN_PROB_THRESHOLD  # noqa: E402


def _segs_p(pairs):
    # pairs: list of (word, prob)
    return [{"w": w, "start": float(i), "end": float(i) + 0.5, "p": p}
            for i, (w, p) in enumerate(pairs)]


def test_low_confidence_substitution_is_uncertain():
    heard = [REF6[0], REF6[1], "الضالين"]
    seg = _segs_p([(w, 0.99) for w in heard[:2]] + [("الضالين", 0.50)])
    al = align_words(A6, heard, seg)
    sub = [a for a in al if a["ref"] == REF6[2]][0]
    assert sub["status"] == "uncertain"
    assert sub["prob"] == 0.50


def test_high_confidence_substitution_stays():
    heard = [REF6[0], REF6[1], "الضالين"]
    seg = _segs_p([(w, 0.99) for w in heard[:2]] + [("الضالين", 0.95)])
    al = align_words(A6, heard, seg)
    sub = [a for a in al if a["ref"] == REF6[2]][0]
    assert sub["status"] == "substituted"


def test_no_prob_keeps_old_behavior():
    # prob=None (old data / model gave nothing) -> substituted, not uncertain
    heard = [REF6[0], REF6[1], "الضالين"]
    seg = [{"w": w, "start": float(i), "end": float(i) + 0.5}
           for i, w in enumerate(heard)]
    al = align_words(A6, heard, seg)
    sub = [a for a in al if a["ref"] == REF6[2]][0]
    assert sub["status"] == "substituted"
    assert sub["prob"] is None


def test_threshold_boundary():
    assert 0.5 <= _UNCERTAIN_PROB_THRESHOLD <= 0.8


def test_uncertain_excluded_from_missed_words():
    transcript = " ".join([REF6[0], REF6[1], "الضالين"])
    segw = _segs_p([("x", 0.99), ("x", 0.99), ("الضالين", 0.50)])
    # fix words to match transcript order
    segw = [{"w": w, "start": float(i), "end": float(i) + 0.5, "p": p}
            for i, (w, p) in enumerate(
                [(REF6[0], 0.99), (REF6[1], 0.99), ("الضالين", 0.50)])]
    segs = [{"start": 0.0, "end": 9.0, "text": "x", "words": segw}]
    results = [{"surah": 1, "ayah": 6, "key": "1:6", "text": A6,
                "label": "POSSIBLE MATCH",
                "transcript_start": 0, "transcript_length": 3}]
    out = build_coaching(transcript, results, segs)
    item = out["ayat"][0]
    assert len(item["uncertain_words"]) == 1
    assert item["uncertain_words"][0][0] == REF6[2]  # ref word
    # the uncertain word must NOT appear in missed_words
    assert REF6[2] not in item["missed_words"]
    # ...but it IS still visible in the alignment for honesty
    assert any(a["status"] == "uncertain" for a in item["word_alignment"])


def test_prob_flows_into_alignment_records():
    seg = _segs_p([(w, 0.91) for w in REF6])
    al = align_words(A6, list(REF6), seg)
    assert all(a["prob"] == 0.91 for a in al)
