"""Voice Q&A removal regression test (Worker B, 2026-11-04).

REPOINT NOTE — read before editing: no test in tests/ ever referenced
/api/quran/ask or QuranQA (verified by grep before this file was added),
so there was no ask test to convert. This file is the repoint itself:
the Voice Q&A feature ("Ask about the Quran") was ordered removed on
2026-10-24, and its backend endpoint plus the engine module
(backend/app/engine/quran_qa.py) were deleted from this copy on
2026-11-04. These tests pin that removal: the route must not exist at
all, so any request to it returns FastAPI's 404 — not a 400/503 from a
half-removed handler, and not a 200 from a resurrected one.

Deliberately NOT asserted here: the Word Translator (/api/quran/translate)
is a separate, wanted feature and is covered by tests/test_translator.py;
the frontend voice_qa.js file is Worker A's half and is out of scope for
this backend test.
"""
import pytest
from fastapi.testclient import TestClient

import app.main as main_module


class _StubService:
    corpus = type("C", (), {"ready": True})()

    def health(self):
        return {"ready": True, "corpus": {"ready": True}, "asr_model": "stub", "asr_loaded": False, "error": None}


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setattr(main_module, "get_service", lambda: _StubService())
    main_module.limiter._storage.reset()
    with TestClient(main_module.app, raise_server_exceptions=False) as c:
        yield c


def test_quran_ask_route_is_gone(client):
    """GET /api/quran/ask must return 404 — the route was removed."""
    r = client.get("/api/quran/ask", params={"q": "What does patience mean?"})
    assert r.status_code == 404, r.text


def test_quran_ask_route_is_gone_without_query(client):
    """No query string either: a missing route 404s before validation."""
    r = client.get("/api/quran/ask")
    assert r.status_code == 404, r.text


def test_no_ask_route_in_route_table():
    """The app's route table must contain no /api/quran/ask path."""
    paths = [getattr(route, "path", None) for route in main_module.app.routes]
    assert "/api/quran/ask" not in paths


def test_translate_route_still_present():
    """Guard against over-deletion: the wanted translator route stays."""
    paths = [getattr(route, "path", None) for route in main_module.app.routes]
    assert "/api/quran/translate" in paths
