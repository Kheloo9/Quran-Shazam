"""Async job API tests: submit -> poll -> terminal state.

The real AI engine is stubbed out — these tests exercise the job lifecycle,
polling contract, and upload validation (no model download, no FFmpeg).
"""
import io
import time

import pytest
from fastapi.testclient import TestClient

import app.main as main_module


class _StubCorpus:
    ready = True


class _StubService:
    corpus = _StubCorpus()

    def health(self):
        return {"ready": True, "corpus": {"ready": True}, "asr_model": "stub",
                "asr_loaded": False, "error": None}

    def diagnostics(self):
        return self.health()

    def verify(self, path, request_id="-", progress=None, on_partial=None):
        if progress:
            progress("Decoding audio…", 6)
            progress("Transcribing audio… (part 1 of 1)", 40)
            if on_partial:
                on_partial("قل هو الله")
            progress("Matching against the Quran…", 88)
        # Mimic a successful verification with one verified ayah.
        return {
            "request_id": request_id,
            "duration": 5.0,
            "transcript": "قل هو الله أحد",
            "segments": [{"start": 0.0, "end": 2.5, "text": "قل هو الله أحد"}],
            "recognized_words": 4,
            "results": [{
                "surah": 112, "ayah": 1, "key": "112:1", "text": "قُلْ هُوَ اللَّهُ أَحَدٌ",
                "translation_en": "Say: He is Allah, the One.",
                "translation_ur": "کہو: وہ اللہ ایک ہے۔",
                "confidence": 100.0, "coverage": 100.0, "missing": 0.0,
                "sequence": 100.0, "label": "VERIFIED TEXT MATCH", "reason": "",
                "transcript_start": 0, "transcript_length": 4,
            }],
            "verified_count": 1,
            "coverage": 100.0,
            "device": "cpu",
            "realtime": 1.0,
            "processing_seconds": 0.5,
        }


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setattr(main_module, "get_service", lambda: _StubService())
    main_module.limiter._storage.reset()
    with TestClient(main_module.app, raise_server_exceptions=False) as c:
        yield c


def _upload(client, filename, content: bytes, content_type="audio/mpeg"):
    return client.post("/api/verify", files={"file": (filename, io.BytesIO(content), content_type)})


def _wait_for_job(client, job_id, timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = client.get(f"/api/jobs/{job_id}")
        assert r.status_code == 200, r.text
        data = r.json()
        if data["status"] in ("done", "error"):
            return data
        time.sleep(0.2)
    raise AssertionError("job did not reach a terminal state in time")


# ------------------------------------------------------------- job lifecycle
def test_submit_returns_202_with_job_id(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    assert r.status_code == 202
    body = r.json()
    assert body["status"] == "queued"
    assert len(body["job_id"]) == 16


def test_job_reaches_done_with_result(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job = _wait_for_job(client, r.json()["job_id"])
    assert job["status"] == "done"
    assert job["progress"] == 100
    result = job["result"]
    assert result["verified_count"] == 1
    assert result["results"][0]["key"] == "112:1"
    assert result["results"][0]["label"] == "VERIFIED TEXT MATCH"


def test_job_poll_reports_stage_and_progress(client):
    # Submit and poll immediately: the contract guarantees stage/progress fields
    # even before the job finishes.
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job_id = r.json()["job_id"]
    first = client.get(f"/api/jobs/{job_id}").json()
    assert first["status"] in ("queued", "processing", "done")
    assert isinstance(first["progress"], (int, float))
    assert isinstance(first["stage"], str) and first["stage"]


def test_unknown_job_returns_404(client):
    r = client.get("/api/jobs/abcdef0123456789")
    assert r.status_code == 404
    assert "upload" in r.json()["detail"].lower()


def test_malformed_job_id_returns_404(client):
    assert client.get("/api/jobs/not-a-job!!!").status_code == 404
    assert client.get("/api/jobs/../../etc/passwd").status_code == 404


# ------------------------------------------------------- regression: magic bytes
def test_mpeg2_mp3_frame_sync_accepted(client):
    # Real-world MP3s often start with FF FA (MPEG-2) rather than FF FB/F3
    # (MPEG-1). The signature check must accept any MP3 frame sync.
    r = _upload(client, "rec.mp3", b"\xff\xfa\x91\x6c" + b"\x00" * 64)
    assert r.status_code == 202, r.text
    job = _wait_for_job(client, r.json()["job_id"])
    assert job["status"] == "done"


def test_id3_mp3_accepted(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    assert r.status_code == 202


def test_garbage_still_rejected_synchronously(client):
    # Content validation still happens BEFORE a job is created: no job, no
    # wasted worker time for obvious garbage.
    r = _upload(client, "fake.mp3", b"This is plain text, not audio." * 4)
    assert r.status_code == 415
    assert "job_id" not in r.text


# ------------------------------------------------------- engine not ready
def test_503_while_warming_up(client, monkeypatch):
    monkeypatch.setattr(main_module, "get_service", lambda: None)
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    assert r.status_code == 503
    assert "warming up" in r.json()["detail"].lower()


# ------------------------------------------- new: cancel, SSE, transcript export
def test_cancel_queued_job(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job_id = r.json()["job_id"]
    d = client.delete(f"/api/jobs/{job_id}")
    assert d.status_code == 200
    # Either cancelled while queued, or it already started (stub is instant).
    assert d.json()["status"] in ("cancelled", "processing", "done")


def test_cancel_unknown_job_404(client):
    assert client.delete("/api/jobs/abcdef0123456789").status_code == 404


def test_sse_endpoint_streams_events(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job_id = r.json()["job_id"]
    with client.stream("GET", f"/api/jobs/{job_id}/events") as s:
        assert s.status_code == 200
        assert "text/event-stream" in s.headers["content-type"]
        first = next(s.iter_lines())
        assert first.startswith("data:")
        assert '"job_id"' in first


def test_transcript_download_formats(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job = _wait_for_job(client, r.json()["job_id"])
    assert job["status"] == "done"
    job_id = job["job_id"]
    txt = client.get(f"/api/jobs/{job_id}/transcript.txt")
    assert txt.status_code == 200 and "قل هو الله أحد" in txt.text
    srt = client.get(f"/api/jobs/{job_id}/transcript.srt")
    assert srt.status_code == 200 and "-->" in srt.text and "00:00:00,000" in srt.text
    vtt = client.get(f"/api/jobs/{job_id}/transcript.vtt")
    assert vtt.status_code == 200 and vtt.text.startswith("WEBVTT")
    js = client.get(f"/api/jobs/{job_id}/transcript.json")
    assert js.status_code == 200 and js.json()["segments"][0]["text"] == "قل هو الله أحد"


def test_transcript_bad_format_404(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job = _wait_for_job(client, r.json()["job_id"])
    assert client.get(f"/api/jobs/{job['job_id']}/transcript.doc").status_code == 404


def test_job_status_has_queue_and_eta_fields(client):
    r = _upload(client, "rec.mp3", b"ID3" + b"\x00" * 64)
    job_id = r.json()["job_id"]
    data = client.get(f"/api/jobs/{job_id}").json()
    # Fields exist on the contract (values may be null when not queued).
    assert "queue_position" in data or data["status"] != "queued"
    assert data["status"] in ("queued", "processing", "done", "error", "cancelled")
