"""Tests for embed_id.py — model-free (synthetic vectors + fake index)."""
import numpy as np
import pytest

from app.engine.embed_id import EmbeddingIdentifier, MIN_SIMILARITY


def _unit(i, dim=8):
    v = np.zeros(dim, dtype=np.float32)
    v[i % dim] = 1.0
    return v


@pytest.fixture()
def ident(tmp_path):
    return EmbeddingIdentifier(tmp_path)


def test_identify_no_index_returns_empty(ident):
    assert ident.identify(tmp_path_unused := __import__("pathlib").Path("/nonexistent.mp3")) == []


def test_identify_ranks_by_cosine(ident):
    ident._index = {"112:1": _unit(0), "112:2": _unit(1), "112:3": _unit(2)}
    ident.load_index = lambda: True  # pretend index loaded
    ident.embed_file = lambda p, max_seconds=120: _unit(0)  # query ~= 112:1
    out = ident.identify(__import__("pathlib").Path("x.mp3"), top_k=3)
    assert out[0]["key"] == "112:1"
    assert out[0]["similarity"] == pytest.approx(1.0)


def test_min_similarity_filters_noise(ident):
    ident._index = {"112:1": _unit(0)}
    ident.load_index = lambda: True
    # query orthogonal to the only reference -> sim 0.0 < MIN_SIMILARITY
    ident.embed_file = lambda p, max_seconds=120: _unit(1)
    assert ident.identify(__import__("pathlib").Path("x.mp3")) == []


def test_top_k_limits_results(ident):
    ident._index = {f"1:{i}": _unit(0) for i in range(1, 8)}
    ident.load_index = lambda: True
    ident.embed_file = lambda p, max_seconds=120: _unit(0)
    out = ident.identify(__import__("pathlib").Path("x.mp3"), top_k=3)
    assert len(out) == 3


def test_missing_model_is_fail_open(tmp_path):
    ident = EmbeddingIdentifier(tmp_path)  # no models/wav2vec2-base dir
    assert ident.embed_file(__import__("pathlib").Path("x.mp3")) is None
    assert ident.identify(__import__("pathlib").Path("x.mp3")) == []


def test_min_similarity_sane():
    # Fingerprints of different ayat should rarely clear this bar;
    # same-ayah cross-qari sims in literature sit well above it.
    assert 0.4 <= MIN_SIMILARITY <= 0.7
