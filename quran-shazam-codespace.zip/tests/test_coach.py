"""Tests for the Quran Coach feature (coach.py).

The coach must reflect REAL matcher output — never invent missed words.
ASR model loading is NOT needed: we build synthetic result dicts the way
service.verify() produces them (transcript_start/length = word indices).
"""
from app.engine.coach import (
    build_coaching,
    missed_words_for_ayah,
    _status_for,
)
from app.engine.normalization import normalize_arabic

# Al-Fatihah 1:1 and 1:6 (diacritized, as stored in the corpus).
A1 = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
A6 = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ"


def _result(surah, ayah, text, label, start, length):
    return {
        "surah": surah, "ayah": ayah, "key": f"{surah}:{ayah}",
        "text": text, "label": label,
        "transcript_start": start, "transcript_length": length,
    }


def test_perfect_ayah_no_missed_words():
    """A VERIFIED ayah with all words heard -> perfect, encouraging."""
    heard = normalize_arabic(A1)  # transcript slice == the ayah itself
    r = _result(1, 1, A1, "VERIFIED TEXT MATCH", 0, len(heard.split()))
    c = build_coaching(heard, [r])
    item = c["ayat"][0]
    assert item["status"] == "perfect"
    assert item["missed_words"] == []
    assert "MashaAllah" in item["message_en"]
    assert c["summary"]["perfect"] == 1
    assert c["summary"]["total"] == 1


def test_missed_words_detected_honestly():
    """Words in the ayah but not in the heard slice are reported — real ones only."""
    # Transcript heard everything except "الصراط" (say it was mumbled).
    heard_words = ["اهدنا", "المستقيم"]
    heard = " ".join(heard_words)
    r = _result(1, 6, A6, "POSSIBLE MATCH", 0, 2)
    missed = missed_words_for_ayah(A6, heard_words)
    # "الصراط" normalized (alef-restored) must be reported missed…
    assert any("صراط" in w for w in missed), f"missed={missed}"
    # …and the heard words must NOT be reported.
    assert not any("مستقيم" in w for w in missed)
    c = build_coaching(heard, [r])
    item = c["ayat"][0]
    assert item["status"] == "needs_work"
    assert item["missed_words"] == missed  # same list, no invention
    assert "6" in item["message_en"]  # names the ayah


def test_fuzzy_near_miss_counts_as_heard():
    """ASR near-miss ('اهدن' vs 'اهدنا') must NOT be flagged as missed."""
    missed = missed_words_for_ayah(A6, ["اهدن", "الصراط", "المستقيم"])
    assert not any("اهدنا" in w for w in missed), f"near-miss flagged: {missed}"


def test_sequence_recovery_is_missing_not_faked():
    """SEQUENCE RECOVERY ayat: status missing, no invented word list."""
    r = _result(1, 4, "مَالِكِ يَوْمِ الدِّينِ",
                "SEQUENCE RECOVERY / INCOMPLETE AUDIO EVIDENCE", 10, 3)
    c = build_coaching("بسم الله الرحمن الرحيم الحمد لله رب العالمين", [r])
    item = c["ayat"][0]
    assert item["status"] == "missing"
    assert item["missed_words"] == []
    assert c["summary"]["missing"] == 1


def test_summary_counts_and_tone():
    """Mixed results -> honest counts, encouraging summary, never discouraging."""
    heard1 = normalize_arabic(A1)
    words1 = heard1.split()
    r1 = _result(1, 1, A1, "VERIFIED TEXT MATCH", 0, len(words1))
    r2 = _result(1, 6, A6, "LOW CONFIDENCE", len(words1), 1)  # only 1 word heard
    c = build_coaching(heard1 + " اهدنا", [r1, r2])
    s = c["summary"]
    assert s["total"] == 2 and s["perfect"] == 1 and s["needs_work"] == 1
    assert "1/2" in s["message_en"]
    # Grammar: singular "needs", plural "need".
    assert "1 needs a little more practice" in s["message_en"]
    c2 = build_coaching(heard1 + " اهدنا", [r1, r2, r2])
    assert "2 need a little more practice" in c2["summary"]["message_en"]
    # Respectful tone check: no harsh words anywhere.
    blob = (s["message_en"] + s["message_ur"] + "".join(
        i["message_en"] + i["message_ur"] for i in c["ayat"])).lower()
    for bad in ["wrong", "ghalat", "fail", "stupid", "bad"]:
        assert bad not in blob, f"discouraging word {bad!r} in coaching"


def test_empty_results_empty_coaching():
    c = build_coaching("", [])
    assert c["summary"]["total"] == 0
    assert c["ayat"] == []


def test_status_mapping():
    assert _status_for("VERIFIED TEXT MATCH", []) == "perfect"
    assert _status_for("GOOD TEXT MATCH", ["x", "y"]) == "needs_work"
    assert _status_for("POSSIBLE MATCH", []) == "needs_work"
    assert _status_for("LOW CONFIDENCE", []) == "needs_work"
    assert _status_for("SEQUENCE RECOVERY / INCOMPLETE AUDIO EVIDENCE", []) == "missing"


def test_every_coaching_item_carries_ayah_text_p3():
    """P3 (2026-10-21): every Coach card must have the ayah Arabic text —
    perfect, needs_work AND missing cards all show it."""
    heard1 = normalize_arabic(A1)
    heard6 = " ".join(["اهدنا", "المستقيم"])  # missed one word -> needs_work
    transcript = heard1 + " " + heard6
    r1 = _result(1, 1, A1, "VERIFIED TEXT MATCH", 0, len(heard1.split()))
    r6 = _result(1, 6, A6, "POSSIBLE MATCH",
                 len(heard1.split()), len(heard6.split()))
    r7 = _result(1, 7, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ",
                 "SEQUENCE RECOVERY", 0, 0)  # missing ayah, no text key? no—has text
    c = build_coaching(transcript, [r1, r6, r7])
    assert c["summary"]["total"] == 3
    for item in c["ayat"]:
        assert "text" in item, f"coaching item lacks 'text': {item['key']}"
    assert c["ayat"][0]["text"] == A1  # perfect card carries the Arabic
    assert c["ayat"][1]["text"] == A6  # needs_work card too
    assert c["ayat"][2]["status"] == "missing"
    assert c["ayat"][2]["text"]  # recovery card also shows the ayah text


def test_coaching_item_text_defaults_empty_p3():
    """P3: a result dict without 'text' must not crash — item gets '' and
    the frontend skips the Arabic line (guard in verify.js)."""
    r = {"surah": 1, "ayah": 1, "key": "1:1", "label": "VERIFIED TEXT MATCH",
         "transcript_start": 0, "transcript_length": 0}
    c = build_coaching("", [r])
    assert c["ayat"][0]["text"] == ""
