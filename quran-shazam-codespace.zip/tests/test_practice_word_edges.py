"""Practice-word endpoint edge tests (Team 5, 2026-10-22).

HTTP-level edges of POST /api/practice-word that test_practice_word.py
(which only checks the pure helper) does not cover:
  - wrong method (GET) -> 405
  - empty / non-Arabic expected word -> 400
  - bad magic bytes -> 415
  - oversized clip (>5MB) -> 413
  - success path with mocked decode + mocked ASR -> 200 + honest match/no-match
The real engine is stubbed (no model download, no FFmpeg); the limiter's
storage is reset per test so results are order-independent.
"""
import io

import pytest
from fastapi.testclient import TestClient

import app.main as main_module


class _StubCorpus:
    ready = True


class _StubASR:
    def __init__(self, text):
        self.text = text

    def transcribe_array(self, audio, sr):
        return {"text": self.text}


class _StubService:
    def __init__(self, heard_text="المستقيم"):
        self.corpus = _StubCorpus()
        self.asr = _StubASR(heard_text)


_MP3_HEAD = b"\xff\xfb\x90\x00"  # valid MP3 frame sync for the magic-byte check


def _fake_decode_ok(tmp, max_seconds=10):
    import numpy as np
    return np.zeros(16000, dtype="float32"), 16000, "ok"


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setattr(main_module, "get_service", lambda: _StubService())
    monkeypatch.setattr(main_module, "decode_to_mono16k_with_quality",
                        _fake_decode_ok)
    main_module.limiter._storage.reset()
    with TestClient(main_module.app, raise_server_exceptions=False) as c:
        yield c


def _post(client, expected, content, filename="word.mp3",
          content_type="audio/mpeg"):
    return client.post(
        "/api/practice-word",
        data={"expected": expected},
        files={"file": (filename, io.BytesIO(content), content_type)},
    )


# --------------------------------------------------------------- routing ----
def test_wrong_method_rejected(client):
    r = client.get("/api/practice-word")
    assert r.status_code == 405


# --------------------------------------------------------- expected word ----
def test_empty_expected_rejected(client):
    r = _post(client, "", _MP3_HEAD + b"\x00" * 64)
    assert r.status_code == 400
    assert "Expected word is required" in r.json()["detail"]


def test_non_arabic_expected_rejected(client):
    # normalize_arabic strips Latin entirely -> treated as missing word.
    r = _post(client, "hello", _MP3_HEAD + b"\x00" * 64)
    assert r.status_code == 400


# --------------------------------------------------------------- payload ----
def test_bad_magic_bytes_rejected(client):
    r = _post(client, "المستقيم",
              b"This is text, not audio. " * 8, filename="word.mp3")
    assert r.status_code == 415


def test_oversized_clip_rejected(client):
    # 6MB with a valid MP3 header -> must hit the 5MB practice cap (413),
    # not pass validation and blow up later.
    r = _post(client, "المستقيم", _MP3_HEAD + b"\x00" * (6 * 1024 * 1024))
    assert r.status_code == 413


# ---------------------------------------------------------- success path ----
def test_mocked_success_reports_match(client):
    # ASR hears exactly the expected word -> 200, match=true, sim=100.
    r = _post(client, "المستقيم", _MP3_HEAD + b"\x00" * 64)
    assert r.status_code == 200
    data = r.json()
    assert data["match"] is True
    assert data["similarity"] == 100.0
    assert data["expected"] == "المستقيم"
    assert data["heard"] == "المستقيم"


def test_mocked_wrong_word_reports_no_match(client, monkeypatch):
    monkeypatch.setattr(main_module, "get_service",
                        lambda: _StubService(heard_text="بسم الله الرحمن"))
    r = _post(client, "المستقيم", _MP3_HEAD + b"\x00" * 64)
    assert r.status_code == 200
    data = r.json()
    assert data["match"] is False
    assert data["similarity"] < 80.0
