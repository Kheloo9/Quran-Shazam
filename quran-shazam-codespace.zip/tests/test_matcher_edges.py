"""Matcher / normalization / coach edge tests (Team 5, 2026-10-22).

Covers untested boundaries the honesty guarantees rest on:
  - similarity(): empty/whitespace inputs, diacritic equivalence,
    normalization confusions (ta-marbuta/ha, superscript alef), and the
    exact 80.0 practice threshold boundary (inclusive >=).
  - normalize_arabic(): non-Arabic stripping, digit stripping.
  - missed_words_for_ayah(): empty expected / empty heard.
  - align_words(): the uncertainty rule — a substitution the model itself
    doubts (p < 0.70) becomes "uncertain"; p == 0.70 and p=None stay
    "substituted".
Pure unit tests — no model, no server, no corpus data needed.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.engine.coach import (
    _UNCERTAIN_PROB_THRESHOLD,
    align_words,
    missed_words_for_ayah,
    word_practice_match,
)
from app.engine.matcher import similarity
from app.engine.normalization import normalize_arabic


# ------------------------------------------------------------ similarity ----
def test_empty_and_whitespace_similarity_is_zero():
    assert similarity("", "بسم") == 0.0
    assert similarity("بسم", "") == 0.0
    assert similarity("", "") == 0.0
    assert similarity("   ", "  ") == 0.0  # whitespace normalizes to empty


def test_identical_strings_score_100():
    assert similarity("المستقيم", "المستقيم") == 100.0


def test_diacritics_do_not_change_score():
    # "with full tashkeel" vs bare text must score a perfect 100.
    assert similarity("بِسْمِ اللَّهِ", "بسم الله") == 100.0


def test_ta_marbuta_and_ha_equivalent():
    # The normalization treats ة and ه as the same (most common ASR confusion).
    assert similarity("الرحمة", "الرحمه") == 100.0


def test_superscript_alef_becomes_regular_alef():
    # U+0670 (superscript alef) must NOT be stripped — it becomes a plain ا.
    assert normalize_arabic("الصِّرٰط") == "الصراط"
    assert normalize_arabic("الصراط") == "الصراط"


def test_latin_and_digits_stripped_before_scoring():
    # Mixed-language leakage from ASR must not destroy the score.
    assert similarity("hello المستقيم", "المستقيم") == 100.0
    assert normalize_arabic("آية 123") == "ايه"


def test_practice_boundary_exactly_80_matches():
    # عليهم/عليهن scores exactly 80.0 — the bar is inclusive (>= 80),
    # so the boundary case counts as correct. Guard against an
    # accidental strict-'>' regression.
    ok, sim = word_practice_match("عليهم", "سمع عليهن")
    assert sim == 80.0
    assert ok is True


def test_practice_just_below_80_does_not_match():
    # المستقيم/المسلقين = 75.0 < 80: honest rejection, not a lucky guess.
    ok, sim = word_practice_match("المستقيم", "اهدنا الصراط المسلقين")
    assert sim == 75.0
    assert ok is False


def test_practice_non_arabic_expected_never_matches():
    # normalize_arabic strips Latin entirely -> empty expected -> no match.
    assert word_practice_match("hello", "المستقيم") == (False, 0.0)
    assert word_practice_match("hello 123", "المستقيم") == (False, 0.0)


def test_practice_best_word_wins_not_first():
    # The check takes the BEST heard word, so a correct word surrounded by
    # wrong ones still matches.
    ok, sim = word_practice_match("المستقيم", "بسم الله المستقيم")
    assert ok is True and sim == 100.0


# --------------------------------------------------- missed_words_for_ayah ----
def test_missed_words_empty_expected():
    assert missed_words_for_ayah("", ["بسم", "الله"]) == []
    assert missed_words_for_ayah("   ", ["بسم"]) == []


def test_missed_words_empty_heard_returns_everything():
    missed = missed_words_for_ayah("بسم الله الرحمن", [])
    assert missed == ["بسم", "الله", "الرحمن"]


def test_missed_words_all_heard_returns_nothing():
    assert missed_words_for_ayah("بسم الله", ["بسم", "الله"]) == []


def test_missed_words_fuzzy_heard_counts_as_heard():
    # ASR near-miss (المستقين vs المستقيم, 87.5 >= 80) is heard, not missed.
    assert missed_words_for_ayah("اهدنا الصراط المستقيم",
                                 ["اهدنا", "الصراط", "المستقين"]) == []


# ------------------------------------------------------------ align_words ----
def _seg(word, p):
    return [{"w": word, "start": 0.0, "end": 0.5, "p": p}]


def test_uncertain_word_not_blamed_when_model_doubts():
    # A substitution with model confidence BELOW 0.70 becomes "uncertain"
    # — the reciter is not punished for the AI's own doubt.
    rows = align_words("الله", ["بسم"], seg_words=_seg("بسم", 0.5))
    assert len(rows) == 1
    assert rows[0]["status"] == "uncertain"
    assert rows[0]["prob"] == 0.5


def test_confident_substitution_stays_substituted():
    rows = align_words("الله", ["بسم"], seg_words=_seg("بسم", 0.95))
    assert rows[0]["status"] == "substituted"


def test_boundary_prob_exactly_070_stays_substituted():
    # The rule is strictly p < 0.70; at exactly 0.70 it is NOT uncertain.
    assert _UNCERTAIN_PROB_THRESHOLD == 0.70
    rows = align_words("الله", ["بسم"], seg_words=_seg("بسم", 0.70))
    assert rows[0]["status"] == "substituted"


def test_missing_prob_stays_substituted():
    # p=None (no confidence reported) -> treated as confident: substituted.
    rows = align_words("الله", ["بسم"],
                       seg_words=[{"w": "بسم", "start": 0.0, "end": 0.5}])
    assert rows[0]["status"] == "substituted"


def test_near_miss_word_counts_as_matched():
    # ASR spelling wobble (>=80 fuzzy) is "matched", never punished.
    rows = align_words("المستقيم", ["المستقين"], seg_words=_seg("المستقين", 0.9))
    assert rows[0]["status"] == "matched"


def test_align_words_empty_ref_returns_empty():
    assert align_words("", ["بسم"]) == []
    assert align_words("   ", []) == []
