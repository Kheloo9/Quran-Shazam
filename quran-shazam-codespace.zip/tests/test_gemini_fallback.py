"""Gemini second listen (fallback) + diacritized A'udhu strip fix.

No real API calls, no real keys: the Gemini provider is stubbed, the
local ASR is stubbed, and the corpus is the real one (backend/data).
The stored transcripts below are the real outputs of the 2026-11-07
comparison legs (baseline.json / gemini.json), inlined so the tests do
not depend on the comparison work dir.
"""
import io
import json
import math
import wave
from pathlib import Path

import numpy as np
import pytest

from app.engine import gemini_asr
from app.engine.service import VerificationService

# Real leg transcripts, 2026-11-07 comparison (rescore.py scored them).
BASELINE_FEL = (
    "الم تر كيف فابرك في سحاب السيل الم يجاي الكيدان فتدقيل ليعصي بل همت "
    "ينعبون فكذليهم تجري العباقين ترمحم بهجره مسجيل قد المتهم خول والمؤمنين"
)
GEMINI_FEL = (
    "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n"
    "أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَابِ الْفِيلِ\n"
    "أَلَمْ يَجْعَلْ كَيْدَهُمْ فِي تَضْلِيلٍ\n"
    "وَأَرْسَلَ عَلَيْهِمْ طَيْرًا أَبَابِيلَ\n"
    "تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ\n"
    "فَجَعَلَهُمْ كَعَصْفٍ مَّأْكُولٍ"
)
GEMINI_FATIHA_TEST = (
    "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\n"
    "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n"
    "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ\n"
    "الرَّحْمَٰنِ الرَّحِيمِ\n"
    "مَالِكِ يَوْمِ الدِّينِ\n"
    "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ\n"
    "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ\n"
    "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ"
)
BASELINE_FATIHA = (
    "بسم الله الرحمن الرحيم الحمد لله رب الذي الحمد لله رب العالمين الرحمن "
    "الرحين مالك يوم الديني والمؤمنين تهدي اياك نعبد واييا كما استعين اهذنا "
    "الصراط المستقيم والمؤمنين صراط الذين انعمت عليهم غير المغضوب عذين "
    "وللضالين والمؤمنين الم وعيين"
)


@pytest.fixture
def svc():
    data_dir = Path(__file__).resolve().parents[1] / "backend" / "data"
    service = VerificationService(data_dir)
    assert service.corpus.ready
    return service


@pytest.fixture
def tone_wav(tmp_path):
    """A 2 s 440 Hz tone WAV: decodes fine, content never matters because
    the tests stub the ASR (local and Gemini) with canned transcripts."""
    path = tmp_path / "tone.wav"
    frames = (np.sin(2 * np.pi * 440 * np.arange(32000) / 16000) * 12000).astype(np.int16)
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(frames.tobytes())
    return path


def _stub_local_asr(svc, monkeypatch, text):
    def _local(audio, sr, **kwargs):
        return {"text": text, "device": "cpu", "realtime": 1.0, "segments": []}

    monkeypatch.setattr(svc.asr, "transcribe_array", _local)


class FakeGemini:
    """Stub Gemini provider: returns a canned transcript or raises."""

    def __init__(self, text=None, error=None):
        self.text = text
        self.error = error
        self.calls = 0

    def transcribe_array(self, audio, sr):
        self.calls += 1
        if self.error:
            raise RuntimeError(self.error)
        return {"text": self.text, "seconds": 4.2}


def _no_embed(svc, monkeypatch):
    # Advisory only; stubbing it keeps the test fast (no wav2vec2 load).
    monkeypatch.setattr(svc, "_embed_candidates", lambda *a, **k: [])


# ------------------------------------------------------- strip fix

def test_strip_removes_diacritized_audhu():
    # The exact Gemini transcript that scored 0/7 before the fix: the
    # A'udhu is present WITH tashkeel and the old literal pattern missed it.
    stripped = VerificationService._strip_opening_supplications(GEMINI_FATIHA_TEST)
    assert "أَعُوذُ" not in stripped
    assert stripped.startswith("بِسْمِ")
    # The Bismillah (1:1) is kept: it is Quran text, not a preamble.
    assert "الْحَمْدُ" in stripped


def test_strip_plain_audhu_still_works_and_no_audhu_unchanged():
    plain = "أعوذ بالله من الشيطان الرجيم بسم الله الرحمن الرحيم"
    assert VerificationService._strip_opening_supplications(plain).startswith("بسم")
    # No A'udhu at all: the text is returned unchanged.
    assert VerificationService._strip_opening_supplications(GEMINI_FEL) == GEMINI_FEL


# ------------------------------------------------- shared scorer

def test_match_and_label_gemini_fatiha_is_verified(svc):
    # Regression test for the 0/7 artifact: the same correct transcript
    # scored 0 VERIFIED before the strip fix (matcher derailed to 27:30,
    # 37:182). With the fix it matches its twin file: 6 VERIFIED.
    _, verified, _ = svc._match_and_label(svc._prepare_transcript(GEMINI_FATIHA_TEST))
    assert verified == 6


def test_match_and_label_baseline_fatiha_is_four_verified(svc):
    _, verified, _ = svc._match_and_label(svc._prepare_transcript(BASELINE_FATIHA))
    assert verified == 4


def test_match_and_label_baseline_fel_is_zero_verified(svc):
    _, verified, _ = svc._match_and_label(svc._prepare_transcript(BASELINE_FEL))
    assert verified == 0


# ------------------------------------------------------- fallback

def test_fallback_uses_gemini_when_local_has_zero_verified(svc, tone_wav, monkeypatch):
    _stub_local_asr(svc, monkeypatch, BASELINE_FEL)
    fake = FakeGemini(GEMINI_FEL)
    svc._gemini = fake
    _no_embed(svc, monkeypatch)
    out = svc.verify(tone_wav)
    assert fake.calls == 1
    assert out["fallback_used"] is True
    assert out["asr_source"] == "gemini"
    # 6 VERIFIED: Bismillah (1:1) + 105:1-5, all from the Gemini transcript.
    assert out["verified_count"] == 6
    assert {(r["surah"], r["ayah"]) for r in out["results"]
            if r["label"] == "VERIFIED TEXT MATCH"} >= {(105, 1), (105, 2), (105, 3), (105, 4), (105, 5)}
    assert out["transcript"].startswith("بِسْمِ")
    assert out["local_transcript"] == svc._prepare_transcript(BASELINE_FEL)
    assert out["gemini_transcript"] == svc._prepare_transcript(GEMINI_FEL)
    assert out["fallback_error"] is None


def test_no_fallback_when_local_is_verified(svc, tone_wav, monkeypatch):
    _stub_local_asr(svc, monkeypatch, BASELINE_FATIHA)
    fake = FakeGemini(GEMINI_FEL)
    svc._gemini = fake
    _no_embed(svc, monkeypatch)
    out = svc.verify(tone_wav)
    assert fake.calls == 0
    assert out["fallback_used"] is False
    assert out["asr_source"] == "local"
    assert out["verified_count"] == 4


def test_fallback_failure_keeps_local_result(svc, tone_wav, monkeypatch):
    _stub_local_asr(svc, monkeypatch, BASELINE_FEL)
    fake = FakeGemini(error="Gemini API HTTP 503")
    svc._gemini = fake
    _no_embed(svc, monkeypatch)
    out = svc.verify(tone_wav)
    assert out["fallback_used"] is True
    assert out["asr_source"] == "local"
    assert out["verified_count"] == 0
    assert "503" in (out["fallback_error"] or "")
    assert out["transcript"] == svc._prepare_transcript(BASELINE_FEL)


def test_gemini_unavailable_without_key(svc, tone_wav, monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setattr("app.engine.service.settings.gemini_api_key", "")
    monkeypatch.setattr("app.engine.service.settings.gemini_fallback", True)
    _stub_local_asr(svc, monkeypatch, BASELINE_FEL)
    _no_embed(svc, monkeypatch)
    assert svc._gemini_transcriber() is None
    out = svc.verify(tone_wav)
    assert out["fallback_used"] is False
    assert out["asr_source"] == "local"


# ------------------------------------------------------- gemini_asr module

class _FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def read(self):
        return json.dumps(self._payload).encode()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def test_gemini_asr_wav_roundtrip():
    audio = np.zeros(16000, dtype=np.float32)
    raw = gemini_asr.wav_bytes_from_array(audio, 16000)
    with wave.open(io.BytesIO(raw), "rb") as wav:
        assert wav.getnchannels() == 1
        assert wav.getframerate() == 16000
        assert wav.getnframes() == 16000


def test_gemini_asr_parses_text_and_retries_503(monkeypatch):
    # Retry waits are real sleeps in the module (20 s, 60 s): stub them
    # out so the test proves the retry COUNT, not the waiting.
    monkeypatch.setattr(gemini_asr.time, "sleep", lambda s: None)
    calls = {"n": 0}

    class _Opener:
        def open(self, request, timeout=None):
            calls["n"] += 1
            if calls["n"] < 3:
                import urllib.error
                raise urllib.error.HTTPError(
                    request.full_url, 503, "overloaded", {}, io.BytesIO(b""))
            return _FakeResponse({"candidates": [{"content": {"parts": [
                {"text": "بسم الله الرحمن الرحيم"}]}}]})

    monkeypatch.setattr("urllib.request.build_opener", lambda *a: _Opener())
    asr = gemini_asr.GeminiASR("dummy-key", "gemini-3.8-flash")
    out = asr.transcribe_array(np.zeros(16000, dtype=np.float32), 16000)
    assert out["text"] == "بسم الله الرحمن الرحيم"
    assert calls["n"] == 3


def test_gemini_asr_404_raises_without_retry(monkeypatch):
    calls = {"n": 0}

    class _Opener:
        def open(self, request, timeout=None):
            calls["n"] += 1
            import urllib.error
            raise urllib.error.HTTPError(
                request.full_url, 404, "not found", {}, io.BytesIO(b""))

    monkeypatch.setattr("urllib.request.build_opener", lambda *a: _Opener())
    asr = gemini_asr.GeminiASR("dummy-key", "gemini-3.8-flash")
    with pytest.raises(gemini_asr.GeminiASRError):
        asr.transcribe_array(np.zeros(16000, dtype=np.float32), 16000)
    assert calls["n"] == 1
