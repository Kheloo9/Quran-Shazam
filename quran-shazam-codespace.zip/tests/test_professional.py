"""Tests for the 2026-10-19 professional additions.

Covers: reference-guided prompt builder, audio quality gate, perf budgets.
ASR model loading is NOT needed here (prompt builder only needs the corpus).
"""
from pathlib import Path

import numpy as np
import pytest

from app.engine.corpus import QuranCorpus, Verse
from app.engine.normalization import normalize_arabic
from app.engine.service import VerificationService

FATIHAH = [
    "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    "الرَّحْمَٰنِ الرَّحِيمِ",
    "مَالِكِ يَوْمِ الدِّينِ",
    "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
    "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
    "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ",
]


def _stub_service():
    """Minimal stand-in with .corpus.by_surah for _build_guided_prompt."""
    verses = [Verse(f"1:{i+1}", 1, i + 1, t, normalize_arabic(t), i)
              for i, t in enumerate(FATIHAH)]
    # Fake a long surah 2 to test truncation (300 short ayat).
    long2 = [Verse(f"2:{i+1}", 2, i + 1, f"آية رقم {i+1} من سورة البقرة الطويلة",
                   normalize_arabic(f"آية رقم {i+1}"), 100 + i)
             for i in range(300)]
    corpus = QuranCorpus.__new__(QuranCorpus)
    corpus.by_surah = {1: verses, 2: long2}
    svc = VerificationService.__new__(VerificationService)
    svc.corpus = corpus
    return svc


def test_guided_prompt_contains_surah_text():
    """The guided prompt for surah 1 must contain Al-Fatihah vocabulary."""
    prompt = _stub_service()._build_guided_prompt(1)
    assert isinstance(prompt, str) and len(prompt) > 0
    assert "الرحمان" in prompt  # normalized basmala word (alef-restored)
    assert len(prompt) <= 600


def test_guided_prompt_truncates_long_surah():
    prompt = _stub_service()._build_guided_prompt(2)
    assert len(prompt) <= 600
    assert len(prompt) > 100  # still useful, not empty


def test_guided_prompt_unknown_surah():
    assert _stub_service()._build_guided_prompt(999) == ""


def test_quality_gate_clean_sine():
    """A clean tone with quiet background must NOT be flagged noisy."""
    from app.engine.media import assess_audio_quality
    sr = 16000
    t = np.arange(sr * 3) / sr
    sig = np.zeros(sr * 3, dtype=np.float32)
    sig[:sr] = 0.5 * np.sin(2 * np.pi * 440 * t[:sr]).astype(np.float32)
    sig[2 * sr:] = 0.5 * np.sin(2 * np.pi * 440 * t[:sr]).astype(np.float32)
    sig[sr:2 * sr] = 0.0005 * np.random.RandomState(0).randn(sr).astype(np.float32)
    q = assess_audio_quality(sig, sr)
    assert q["snr_db"] > 12.0, q
    assert q["noisy"] is False


def test_quality_gate_noisy():
    """Heavy background noise MUST be flagged."""
    from app.engine.media import assess_audio_quality
    sr = 16000
    rng = np.random.RandomState(1)
    speech = 0.3 * np.sin(2 * np.pi * 440 * np.arange(sr * 3) / sr).astype(np.float32)
    noise = 0.25 * rng.randn(sr * 3).astype(np.float32)  # nearly as loud as speech
    q = assess_audio_quality(speech + noise, sr)
    assert q["noisy"] is True, q
    assert "quiet room" in q["message"]


def test_quality_gate_short_audio():
    from app.engine.media import assess_audio_quality
    q = assess_audio_quality(np.zeros(100, dtype=np.float32), 16000)
    assert q["noisy"] is False  # too short: never flag


def test_perf_budgets_sane():
    from app.engine.config import settings
    b = settings.perf_budgets
    for key in ("surah_load", "tafseer", "audio_start", "qa",
                "translate", "verify_single_ayah"):
        assert key in b, f"missing budget {key}"
        assert 0 < b[key] <= 120, f"budget {key} out of range"


def test_asr_guided_flag_exists():
    from app.engine.config import settings
    assert isinstance(settings.asr_guided, bool)


def test_transcribe_array_accepts_prompt():
    """Signature check: transcribe_array must accept initial_prompt."""
    import inspect
    from app.engine.asr import QuranASR
    params = inspect.signature(QuranASR.transcribe_array).parameters
    assert "initial_prompt" in params
