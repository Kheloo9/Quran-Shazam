"""Tests for the word-practice feature (2026-10-22).

Covers: the pure word_practice_match() helper in coach.py (the honest fuzzy
check the /api/practice-word endpoint uses), and that the endpoint is wired
into the FastAPI app with the right method/path.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.engine.coach import word_practice_match, _PRACTICE_MATCH_THRESHOLD


def test_exact_word_matches():
    ok, sim = word_practice_match("المستقيم", "اهدنا الصراط المستقيم")
    assert ok is True and sim == 100.0


def test_wrong_word_does_not_match():
    ok, sim = word_practice_match("المستقيم", "بسم الله الرحمن")
    assert ok is False and sim < _PRACTICE_MATCH_THRESHOLD


def test_near_miss_below_bar_is_honest():
    # 75/100 < 80 bar -> NOT counted correct (same honesty as Coach)
    ok, sim = word_practice_match("المستقيم", "اهدنا الصراط المسلقين")
    assert sim < _PRACTICE_MATCH_THRESHOLD and ok is False


def test_empty_inputs_never_match():
    assert word_practice_match("", "بسم الله") == (False, 0.0)
    assert word_practice_match("المستقيم", "") == (False, 0.0)
    assert word_practice_match("   ", "   ") == (False, 0.0)


def test_normalization_applied():
    # diacritics / presentation forms still match after normalization
    ok, _ = word_practice_match("الضالين", "ولا الضالين")
    assert ok is True


def test_endpoint_wired():
    from app.main import app
    routes = [(r.path, sorted(r.methods or [])) for r in app.routes
              if getattr(r, "path", "") == "/api/practice-word"]
    assert routes, "/api/practice-word route missing"
    assert routes[0][1] == ["POST"], f"expected POST, got {routes[0][1]}"
