"""Tests for the EN<->UR word translator (QuranReader.translate_word).

Uses a tiny synthetic parallel corpus — no production data needed.
"""
import pytest
from app.engine.quran_reader import QuranReader


@pytest.fixture
def reader():
    r = QuranReader.__new__(QuranReader)
    r.translations = {
        "2:45": {"en": "Seek help through patience and prayer",
                 "ur": "صبر اور نماز سے مدد لیا کرو"},
        "2:153": {"en": "Indeed, Allah is with the patient",
                  "ur": "بے شک اللہ صبر کرنے والوں کے ساتھ ہے"},
        "3:200": {"en": "Be patient and persevere",
                  "ur": "صبر کرو اور ثابت قدم رہو"},
        "112:1": {"en": "Say: He is Allah, the One",
                  "ur": "کہو وہ اللہ ایک ہے"},
    }
    # ready is a property (corpus and corpus.ready) — stub both
    r.corpus = type("C", (), {"by_key": {}, "ready": True})()
    return r


def test_en2ur_finds_quranic_candidate(reader):
    d = reader.translate_word("patience", direction="en2ur")
    assert d["source"] == "quran"
    texts = [c["text"] for c in d["candidates"]]
    assert "صبر" in texts
    assert len(d["examples"]) >= 1  # whole-word "patience" hits 2:45 only


def test_ur2en_finds_quranic_candidate(reader):
    d = reader.translate_word("صبر", direction="ur2en")
    assert d["source"] == "quran"
    texts = [c["text"] for c in d["candidates"]]
    assert any(t in ("patience", "patient") for t in texts)


def test_dictionary_fallback_en2ur(reader):
    d = reader.translate_word("hello", direction="en2ur")
    assert d["source"] == "dictionary"
    assert d["candidates"], "dictionary should translate 'hello'"


def test_no_match_returns_empty(reader):
    d = reader.translate_word("zxqvkw", direction="en2ur")
    assert d["candidates"] == []
    assert d["examples"] == []


def test_invalid_direction_defaults(reader):
    d = reader.translate_word("patience", direction="xx")
    assert d["direction"] == "en2ur"


def test_empty_word_safe(reader):
    d = reader.translate_word(" ", direction="en2ur")
    assert d["candidates"] == [] and d["source"] == "none"
