"""Pytest setup: make `backend/` importable and stub the heavy engine."""
import os
import sys
from pathlib import Path

# Rate limit must be tiny for tests -> set BEFORE app modules are imported.
os.environ.setdefault("RATE_LIMIT_VERIFY", "5/minute")
os.environ.setdefault("ENV", "development")

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))
