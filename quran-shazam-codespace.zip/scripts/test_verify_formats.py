"""Test verification with different audio formats and ways."""
import http.client, json, time

def verify(path, filename, mime):
    boundary = "----FmtTest"
    with open(path, "rb") as f:
        data = f.read()
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f'Content-Type: {mime}\r\n\r\n').encode() + data + f'\r\n--{boundary}--\r\n'.encode()
    conn = http.client.HTTPConnection("localhost", 8000, timeout=120)
    conn.request("POST", "/api/verify", body,
                 {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = conn.getresponse()
    if r.status != 202:
        return None, f"Upload HTTP {r.status}"
    job_id = json.loads(r.read()).get("job_id")
    for _ in range(20):
        time.sleep(10)
        c2 = http.client.HTTPConnection("localhost", 8000, timeout=30)
        c2.request("GET", f"/api/jobs/{job_id}")
        d = json.loads(c2.getresponse().read())
        if d.get("status") in ("done", "error"):
            if d.get("status") == "error":
                return None, d.get("error", "unknown error")[:80]
            res = d.get("result", {})
            results = res.get("results", [])
            top = results[0] if results else {}
            return {
                "transcript": res.get("transcript", "")[:60],
                "match": f"{top.get('surah')}:{top.get('ayah')}",
                "label": top.get("label", "?"),
                "conf": top.get("confidence", 0),
            }, None
    return None, "poll timeout"

print("=== FORMAT TESTS (all should identify 112:1) ===")
for path, fn, mime in [
    ("/tmp/fmt_test.mp3", "t.mp3", "audio/mpeg"),
    ("/tmp/fmt_test.wav", "t.wav", "audio/wav"),
    ("/tmp/fmt_test.m4a", "t.m4a", "audio/mp4"),
    ("/tmp/fmt_test.ogg", "t.ogg", "audio/ogg"),
]:
    result, err = verify(path, fn, mime)
    if err:
        print(f"  ❌ {fn}: {err}")
    else:
        ok = result["match"] == "112:1"
        print(f"  {'✅' if ok else '❌'} {fn}: {result['match']} [{result['label']}] {result['conf']:.0f}% | '{result['transcript'][:40]}'")
