#!/usr/bin/env bash
# Quran Shazam — start script (Linux/macOS)
# Creates/uses .venv, installs requirements, runs preflight, starts the server.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d .venv ]; then
  echo "Creating virtual environment..."
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -q -r requirements.txt

echo "Running preflight checks..."
python scripts/preflight.py

echo "Starting Quran Shazam on http://127.0.0.1:${PORT:-8000}"
cd backend
exec python -m app
