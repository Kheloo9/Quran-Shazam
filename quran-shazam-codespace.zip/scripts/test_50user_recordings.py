"""50 users × 5 recordings: verify results match user expectations."""
import http.client, json, time, sys

RECORDINGS = [
    {"file": "/tmp/rec50/full_112.mp3", "name": "Full Surah Al-Ikhlas", "expected": [(112,1),(112,2),(112,3),(112,4)]},
    {"file": "/tmp/rec50/full_113.mp3", "name": "Full Surah Al-Falaq", "expected": [(113,1),(113,2),(113,3),(113,4),(113,5)]},
    {"file": "/tmp/rec50/full_114.mp3", "name": "Full Surah An-Nas", "expected": [(114,1),(114,2),(114,3),(114,4),(114,5),(114,6)]},
    {"file": "/tmp/rec50/full_001.mp3", "name": "Full Surah Al-Fatihah", "expected": [(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7)]},
    {"file": "/tmp/rec50/single_2_255.mp3", "name": "Ayat-ul-Kursi 2:255", "expected": [(2,255)]},
]

def verify(path):
    boundary = "----U50"
    with open(path, "rb") as f:
        data = f.read()
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="rec.mp3"\r\n'
            'Content-Type: audio/mpeg\r\n\r\n').encode() + data + f'\r\n--{boundary}--\r\n'.encode()
    conn = http.client.HTTPConnection("localhost", 8000, timeout=180)
    conn.request("POST", "/api/verify", body,
                 {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = conn.getresponse()
    if r.status != 202:
        return None, f"Upload HTTP {r.status}"
    job_id = json.loads(r.read()).get("job_id")
    for _ in range(30):
        time.sleep(15)
        c2 = http.client.HTTPConnection("localhost", 8000, timeout=30)
        c2.request("GET", f"/api/jobs/{job_id}")
        d = json.loads(c2.getresponse().read())
        if d.get("status") in ("done", "error"):
            if d.get("status") == "error":
                return None, d.get("error", "?")[:100]
            res = d.get("result", {})
            out = []
            for m in res.get("results", []):
                out.append({
                    "surah": m.get("surah"), "ayah": m.get("ayah"),
                    "label": m.get("label", "?"), "conf": round(m.get("confidence", 0)),
                })
            return {"transcript": res.get("transcript", "")[:80], "matches": out}, None
    return None, "poll timeout"

feedback = []
for ri, rec in enumerate(RECORDINGS):
    print(f"\n{'='*60}\nRECORDING {ri+1}: {rec['name']} (10 users)\n{'='*60}", flush=True)
    expected_set = set(rec["expected"])
    for u in range(10):
        user_id = ri * 10 + u + 1
        result, err = verify(rec["file"])
        if err:
            print(f"  User {user_id}: ❌ ERROR: {err}", flush=True)
            feedback.append({"user": user_id, "recording": rec["name"], "status": "error", "detail": err})
            continue
        found = set((m["surah"], m["ayah"]) for m in result["matches"])
        correct = len(found & expected_set)
        wrong = len(found - expected_set)
        missing = len(expected_set - found)
        verified = sum(1 for m in result["matches"] if "VERIFIED" in m["label"])
        good = sum(1 for m in result["matches"] if "GOOD" in m["label"] and "VERIFIED" not in m["label"])
        ok = (wrong == 0 and missing == 0)
        icon = "✅" if ok else ("⚠️" if correct > 0 else "❌")
        print(f"  User {user_id}: {icon} found {correct}/{len(expected_set)}, verified={verified}, good={good}, wrong={wrong}, missing={missing}", flush=True)
        feedback.append({
            "user": user_id, "recording": rec["name"], "status": "ok" if ok else "partial",
            "found": correct, "total": len(expected_set),
            "verified": verified, "good": good, "wrong": wrong, "missing": missing,
            "matches": result["matches"],
        })

with open("/tmp/50user_rec_feedback.json", "w") as f:
    json.dump(feedback, f, indent=2)

ok_count = sum(1 for fb in feedback if fb["status"] == "ok")
partial = sum(1 for fb in feedback if fb["status"] == "partial")
errors = sum(1 for fb in feedback if fb["status"] == "error")
print(f"\n{'='*60}\nSUMMARY: {ok_count}/50 perfect, {partial}/50 partial, {errors}/50 errors\n{'='*60}")
