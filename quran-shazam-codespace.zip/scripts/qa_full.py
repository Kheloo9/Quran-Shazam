#!/usr/bin/env python3
"""Full-Quran QA loop: verify all 114 surahs (one qari) end-to-end.

Resumable: results append to results.jsonl; completed surahs are skipped.
Each surah is concatenated from per-ayah MP3s, verified through the FULL
pipeline (decode -> faster-whisper -> matching), and scored against the
expected ayah set. Real results only — no synthetic data.

Usage:
    python scripts/qa_full.py --parts ~/workspace/bench-qa/full/parts
    python scripts/qa_full.py --parts ... --surahs 2,36,55   # subset
    python scripts/qa_full.py --parts ... --redo 36          # force re-run
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.engine.service import VerificationService

QARI = "Alafasy"


def sh(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, capture_output=True)


def concat_surah(parts: Path, surah: int, nayat: int, out: Path) -> Path:
    if out.exists() and out.stat().st_size > 0:
        return out
    lst = out.with_suffix(".txt")
    with lst.open("w") as f:
        for a in range(1, nayat + 1):
            p = parts / f"{surah:03d}{a:03d}.mp3"
            if not p.exists():
                raise FileNotFoundError(f"missing ayah file {p}")
            f.write(f"file '{p}'\n")
    sh(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "concat", "-safe", "0", "-i", str(lst),
        "-c:a", "libmp3lame", "-b:a", "96k", str(out)])
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--parts", required=True)
    ap.add_argument("--work", default=str(Path.home() / "workspace/bench-qa/full"))
    ap.add_argument("--surahs", default=None, help="comma list, e.g. 2,36,55")
    ap.add_argument("--redo", default=None, help="comma list to force re-run")
    ap.add_argument("--data-dir", default="backend/data")
    args = ap.parse_args()

    work = Path(args.work)
    parts = Path(args.parts)
    surah_dir = work / "surahs"
    surah_dir.mkdir(parents=True, exist_ok=True)
    log_path = work / "results.jsonl"

    struct: dict[str, int] = json.load(open("/tmp/surah_struct.json"))
    done: set[str] = set()
    if log_path.exists():
        for line in log_path.open():
            try:
                done.add(str(json.loads(line)["surah"]))
            except Exception:
                pass
    redo = set((args.redo or "").split(",")) - {""}
    only = set((args.surahs or "").split(",")) - {""}

    print("== warming up service ==", flush=True)
    svc = VerificationService(Path(args.data_dir))
    assert svc.corpus.ready
    t0 = time.perf_counter()
    svc.asr._load()
    print(f"model ready in {time.perf_counter()-t0:.1f}s "
          f"({svc.asr.device}/{svc.asr.compute_type})", flush=True)

    logf = log_path.open("a")
    for s_str, n in sorted(struct.items(), key=lambda x: int(x[0])):
        if only and s_str not in only:
            continue
        if s_str in done and s_str not in redo:
            print(f"surah {s_str}: skip (done)", flush=True)
            continue
        s = int(s_str)
        exp = {f"{s}:{i}" for i in range(1, n + 1)}
        rec: dict = {"surah": s, "expected": n, "qari": QARI, "ts": time.time()}
        try:
            mp3 = concat_surah(parts, s, n, surah_dir / f"{s:03d}.mp3")
            t0 = time.perf_counter()
            r = svc.verify(mp3, request_id=f"qafull-{s}")
            wall = time.perf_counter() - t0
            got = {m["key"]: m for m in r["results"]}
            verified = {k for k, m in got.items()
                        if m["label"] == "VERIFIED TEXT MATCH"} & exp
            wrong = sorted(k for k in got
                           if k.split(":")[0] != str(s)
                           and "RECOVERY" not in got[k]["label"])
            missing = sorted(exp - set(got), key=lambda k: int(k.split(":")[1]))
            rec.update({
                "identified": len(got), "verified": len(verified),
                "missing": missing, "n_missing": len(missing),
                "wrong": wrong, "n_wrong": len(wrong),
                "rtf": round(r["processing_seconds"] / r["duration"], 4) if r["duration"] else 0,
                "wall": round(wall, 1), "duration": r["duration"],
                "coverage": r["coverage"], "words": r["recognized_words"],
            })
            print(f"surah {s:3d}: id={len(got):3d}/{n:3d} ver={len(verified):3d} "
                  f"miss={len(missing):3d} wrong={len(wrong)} "
                  f"rtf={rec['rtf']:.3f} wall={wall:.0f}s cov={r['coverage']}%",
                  flush=True)
        except Exception:
            rec["error"] = traceback.format_exc(limit=5)
            print(f"surah {s:3d}: ERROR", flush=True)
            traceback.print_exc(limit=3)
        logf.write(json.dumps(rec, ensure_ascii=False) + "\n")
        logf.flush()
    logf.close()

    # summary
    rows = [json.loads(l) for l in log_path.open() if l.strip()]
    tot_exp = sum(r["expected"] for r in rows if "error" not in r)
    tot_ver = sum(r["verified"] for r in rows if "error" not in r)
    tot_miss = sum(r["n_missing"] for r in rows if "error" not in r)
    errs = sum(1 for r in rows if "error" in r)
    print(f"\nFULL-QURAN SUMMARY: surahs={len(rows)} ayat={tot_exp} "
          f"verified={tot_ver} ({100*tot_ver/max(1,tot_exp):.1f}%) "
          f"missing={tot_miss} errors={errs}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
