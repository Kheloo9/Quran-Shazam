@echo off
REM Quran Shazam - start script (Windows)
cd /d "%~dp0\.."
if not exist .venv (
  echo Creating virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
echo Running preflight checks...
python scripts\preflight.py
if errorlevel 1 exit /b 1
echo Starting Quran Shazam on http://127.0.0.1:8000
cd backend
python -m app
