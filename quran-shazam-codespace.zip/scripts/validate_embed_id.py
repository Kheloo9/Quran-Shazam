"""Validate embedding-based ayat ID (honest, two protocols).

(a) strict cross-qari: reference = FIRST qari's clips only,
    query = other qaris' clips of the same ayat.
(b) leave-one-clip-out: every clip queried against all OTHER clips'
    fingerprints (mixed qaris) — bigger N, easier test.

Each clip is embedded ONCE; the rest is numpy cosine math (fast).

Usage: python scripts/validate_embed_id.py
"""
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.engine.embed_id import EmbeddingIdentifier, MIN_SIMILARITY  # noqa: E402

CLIPS = Path.home() / "workspace/campaign20/clips"
DATA = Path(__file__).resolve().parents[1] / "backend" / "data"

NAMED = {"ikhlas": 112, "kawthar": 108, "falaq": 113, "nas": 114,
         "asr": 103, "fatihah": 1}


def parse(name: str):
    stem = Path(name).stem
    m = re.match(r"^([a-z]+)_([a-z]+)_(\d+)$", stem)
    if m and m.group(2) in NAMED:
        return m.group(1), NAMED[m.group(2)], int(m.group(3))
    m = re.match(r"^([a-z]+)_(\d)(\d+)$", stem)
    if m:
        return m.group(1), int(m.group(2)), int(m.group(3))
    m = re.match(r"^([a-z]+)_(\d+)$", stem)
    if m:
        q, digits = m.group(1), m.group(2)
        if len(digits) == 3 and digits.startswith("9"):
            return q, int(digits[:2]), int(digits[2:])
        if len(digits) == 3:
            return q, int(digits[0]), int(digits[1:])
        if len(digits) == 2:
            return q, int(digits[0]), int(digits[1:])
    return None


def rank(query_vec, refs):
    """refs: list of (key, vec) -> top-3 (key, sim) above MIN_SIMILARITY."""
    scored = []
    for key, vec in refs:
        sim = float(np.dot(query_vec, vec))
        if sim >= MIN_SIMILARITY:
            scored.append((key, sim))
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored[:3]


def main():
    clips = []
    for p in sorted(CLIPS.glob("*.*")):
        if p.suffix.lower() not in (".mp3", ".m4a", ".wav", ".ogg", ".webm"):
            continue
        parsed = parse(p.name)
        if parsed:
            q, s, a = parsed
            clips.append({"qari": q, "key": f"{s}:{a}", "path": p})
    print(f"parseable single-ayah clips: {len(clips)}", flush=True)

    ident = EmbeddingIdentifier(DATA)
    vecs = []
    for c in clips:
        v = ident.embed_file(c["path"])
        if v is None:
            print(f"  embed FAILED: {c['path'].name}"); return 1
        vecs.append((c, v))
        print(f"  embedded {c['qari']:4s} {c['key']:7s}", flush=True)

    by_ayah = defaultdict(list)
    for c, v in vecs:
        by_ayah[c["key"]].append((c, v))
    multi = {k: v for k, v in by_ayah.items()
             if len({c["qari"] for c, _ in v}) >= 2}
    print(f"\nayat with >=2 qaris: {len(multi)} -> {sorted(multi)}")

    # (a) strict cross-qari
    print("\n(a) strict cross-qari:")
    t1 = t3 = n = 0
    for key, items in sorted(multi.items()):
        qaris = sorted({c["qari"] for c, _ in items})
        refs = [(c["key"], v) for c, v in items if c["qari"] == qaris[0]]
        for c, v in items:
            if c["qari"] == qaris[0]:
                continue
            got = rank(v, refs)
            n += 1
            ok1 = got[:1] and got[0][0] == key
            ok3 = any(k == key for k, _ in got)
            t1 += int(bool(ok1)); t3 += int(bool(ok3))
            top = f"{got[0][0]}:{got[0][1]:.2f}" if got else "-"
            print(f"  query {c['qari']:4s} {key:7s} -> {top:12s} "
                  f"{'OK ' if ok1 else 'TOP3 ' if ok3 else 'MISS'}")
    print(f"RESULT [cross-qari]: top-1 {t1}/{n} = {100*t1/max(1,n):.1f}% | "
          f"top-3 {t3}/{n} = {100*t3/max(1,n):.1f}%")

    # (b) leave-one-clip-out
    print("\n(b) leave-one-clip-out:")
    t1 = t3 = n = 0
    for i, (c, v) in enumerate(vecs):
        refs = [(cc["key"], vv) for j, (cc, vv) in enumerate(vecs) if j != i]
        got = rank(v, refs)
        n += 1
        ok1 = got[:1] and got[0][0] == c["key"]
        ok3 = any(k == c["key"] for k, _ in got)
        t1 += int(bool(ok1)); t3 += int(bool(ok3))
        if not ok1:
            top = f"{got[0][0]}:{got[0][1]:.2f}" if got else "-"
            print(f"  MISS {c['qari']:4s} {c['key']:7s} -> {top}")
    print(f"RESULT [leave-one-clip-out]: top-1 {t1}/{n} = "
          f"{100*t1/max(1,n):.1f}% | top-3 {t3}/{n} = {100*t3/max(1,n):.1f}%")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
