#!/usr/bin/env python3
"""RTF benchmark for the Quran Shazam faster-whisper engine.

Measures the real-time factor:  RTF = processing_seconds / audio_seconds.
Target: RTF <= 1.0  (a 10-minute file transcribes in <= 10 minutes).

Usage:
    python scripts/benchmark_rtf.py --audio recitation.mp3
    python scripts/benchmark_rtf.py --audio recitation.mp3 --lang ar

The script loads the real engine (model conversion happens once, then the
CT2 model is cached), transcribes, and prints a timing breakdown.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

import numpy as np

from app.engine.asr import QuranASR
from app.engine.media import decode_to_mono16k


def main() -> int:
    ap = argparse.ArgumentParser(description="Quran Shazam RTF benchmark")
    ap.add_argument("--audio", required=True, help="Audio/video file to transcribe")
    ap.add_argument("--models-dir", default=None, help="CT2 model cache dir")
    ap.add_argument("--lang", default=None, help="Override ASR_LANGUAGE for this run")
    args = ap.parse_args()

    src = Path(args.audio)
    if not src.exists():
        print(f"Audio file not found: {src}", file=sys.stderr)
        return 2
    if args.lang:
        import os
        os.environ["ASR_LANGUAGE"] = args.lang

    print("== decoding ==")
    t0 = time.perf_counter()
    audio, sr = decode_to_mono16k(src, max_seconds=7200)
    decode_s = time.perf_counter() - t0
    audio_s = len(audio) / sr
    print(f"audio: {audio_s:.1f}s  decode: {decode_s:.1f}s")

    print("== loading model ==")
    asr = QuranASR(Path(args.models_dir) if args.models_dir else None)
    t0 = time.perf_counter()
    asr._load()
    load_s = time.perf_counter() - t0
    print(f"model: {asr.model_id}  device: {asr.device}  compute: {asr.compute_type}  "
          f"load: {load_s:.1f}s")

    print("== transcribing ==")
    marks: list[str] = []

    def progress(msg: str) -> None:
        marks.append(f"{time.perf_counter() - t0:7.1f}s  {msg}")
        print(marks[-1], flush=True)

    t0 = time.perf_counter()
    out = asr.transcribe_array(np.asarray(audio, dtype=np.float32), sr, progress=progress)
    proc_s = time.perf_counter() - t0

    rtf = proc_s / audio_s if audio_s else float("inf")
    words = len(out["text"].split())
    print()
    print(f"audio_seconds : {audio_s:.1f}")
    print(f"process_seconds: {proc_s:.1f}")
    print(f"RTF           : {rtf:.3f}   (target <= 1.0)  {'PASS' if rtf <= 1.0 else 'FAIL'}")
    print(f"words         : {words}")
    print(f"segments      : {len(out['segments'])}")
    print(f"transcript    : {out['text'][:160]}")
    return 0 if rtf <= 1.0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
