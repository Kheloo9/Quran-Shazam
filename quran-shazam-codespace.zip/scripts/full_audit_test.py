#!/usr/bin/env python3
"""
Quran Shazam — Professional A-to-Z Testing Loop
Tests every page, endpoint, feature. Logs all failures.
Run: python scripts/full_audit_test.py
"""
import json, sys, time, urllib.request, urllib.error
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

BASE = "http://localhost:8000"
results = {"passed": 0, "failed": 0, "errors": []}

def check(name, condition, detail=""):
    if condition:
        results["passed"] += 1
        print(f"  ✅ {name}")
    else:
        results["failed"] += 1
        results["errors"].append(f"{name}: {detail}")
        print(f"  ❌ {name} — {detail}")

def get(path, timeout=30):
    try:
        with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(e).encode()

print("=" * 60)
print("QURAN SHAZAM — FULL AUDIT TEST")
print("=" * 60)

# --- 1. Pages ---
print("\n[1] Pages (must return 200 HTML)")
for page in ["/", "/verify", "/quran", "/duas", "/about", "/security"]:
    status, body = get(page)
    is_html = b"<!doctype html" in body.lower() or b"<html" in body.lower()
    check(f"GET {page}", status == 200 and is_html, f"status={status}")

# --- 2. Health ---
print("\n[2] Health & dependencies")
status, body = get("/api/health")
try:
    h = json.loads(body)
    check("health ready", h.get("ready") == True, str(h.get("error")))
    check("corpus 6236", h.get("corpus", {}).get("verse_count") == 6236 or "6236" in str(body))
    deps = h.get("dependencies", {})
    check("soundfile installed", deps.get("soundfile") == True, "soundfile missing!")
    check("httpx installed", deps.get("httpx") == True, "httpx missing!")
except Exception as e:
    check("health JSON", False, str(e))

# --- 3. Quran Reader API ---
print("\n[3] Quran Reader API")
status, body = get("/api/quran/surahs")
try:
    d = json.loads(body)
    surahs = d.get("surahs", d) if isinstance(d, dict) else d
    check("114 surahs", len(surahs) == 114, f"got {len(surahs)}")
except Exception as e:
    check("surahs JSON", False, str(e))

# Test a few surahs for tafseer
for s in [1, 112, 2]:
    status, body = get(f"/api/quran/surah/{s}")
    try:
        d = json.loads(body)
        ayahs = d.get("ayahs", d.get("verses", []))
        check(f"surah {s} loads", len(ayahs) > 0, f"status={status}")
        if ayahs:
            a = ayahs[0]
            # Check tafseer exists (not empty). Short ayat may have brief
            # tafseer since scholars comment on verse groups.
            t_ur = a.get("tafseer_ur", "")
            t_en = a.get("tafseer", "")
            check(f"surah {s} Urdu tafseer exists", len(t_ur.strip()) > 20, f"len={len(t_ur)}")
            check(f"surah {s} English tafseer exists", len(t_en.strip()) > 20, f"len={len(t_en)}")
    except Exception as e:
        check(f"surah {s} JSON", False, str(e))

# --- 4. Search ---
print("\n[4] Search")
status, body = get("/api/quran/search?q=" + urllib.request.quote("mercy"))
try:
    d = json.loads(body)
    check("search works", status == 200, f"status={status}")
except Exception as e:
    check("search JSON", False, str(e))

# --- 5. Duas ---
print("\n[5] Duas page content")
status, body = get("/duas")
check("duas has content", b"Rabbana" in body or b"dua" in body.lower(), f"status={status}")

# --- 6. Audio proxy ---
print("\n[6] Audio proxy")
status, body = get("/api/audio/112/1", timeout=45)
check("audio proxy 112:1", status == 200 and len(body) > 1000, f"status={status}, len={len(body)}")
status, body = get("/api/audio/1/1", timeout=45)
check("audio proxy 1:1", status == 200 and len(body) > 1000, f"status={status}")
# Invalid ranges
status, _ = get("/api/audio/115/1")
check("audio proxy rejects bad surah", status == 400, f"status={status}")
status, _ = get("/api/audio/1/300")
check("audio proxy rejects bad ayah", status == 400, f"status={status}")

# --- 7. Ask API ---
print("\n[7] Q&A API")
status, body = get("/api/quran/ask?q=" + urllib.request.quote("What is Surah Al-Ikhlas?"))
check("ask API works", status == 200, f"status={status}")

# --- Summary ---
print("\n" + "=" * 60)
print(f"RESULTS: {results['passed']} passed, {results['failed']} failed")
if results["errors"]:
    print("\nFAILURES:")
    for e in results["errors"]:
        print(f"  - {e}")
print("=" * 60)
sys.exit(1 if results["failed"] > 0 else 0)
