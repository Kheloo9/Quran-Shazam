"""Edge cases: silence, noise, tone should be REJECTED (not matched)."""
import http.client, json, time

def verify(path, label):
    boundary = "----EdgeTest"
    with open(path, "rb") as f:
        data = f.read()
    ext = path.rsplit(".", 1)[-1]
    mime = {"wav": "audio/wav", "mp3": "audio/mpeg"}[ext]
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="t.{ext}"\r\n'
            f'Content-Type: {mime}\r\n\r\n').encode() + data + f'\r\n--{boundary}--\r\n'.encode()
    conn = http.client.HTTPConnection("localhost", 8000, timeout=120)
    conn.request("POST", "/api/verify", body,
                 {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = conn.getresponse()
    if r.status == 415:
        print(f"  ✅ {label}: correctly rejected at upload (415)")
        return True
    if r.status != 202:
        print(f"  ⚠️  {label}: Upload HTTP {r.status}")
        return None
    job_id = json.loads(r.read()).get("job_id")
    for _ in range(15):
        time.sleep(8)
        c2 = http.client.HTTPConnection("localhost", 8000, timeout=30)
        c2.request("GET", f"/api/jobs/{job_id}")
        d = json.loads(c2.getresponse().read())
        if d.get("status") in ("done", "error"):
            if d.get("status") == "error":
                print(f"  ✅ {label}: correctly rejected ({d.get('error', '?')[:70]})")
                return True
            res = d.get("result", {})
            results = res.get("results", [])
            # Check no VERIFIED false positive
            verified = [m for m in results if "VERIFIED" in m.get("label", "")]
            if verified:
                print(f"  ❌ {label}: FALSE POSITIVE! {verified[0].get('surah')}:{verified[0].get('ayah')} VERIFIED")
                return False
            print(f"  ✅ {label}: no false VERIFIED (transcript: '{res.get('transcript', '')[:40]}')")
            return True
    print(f"  ⚠️  {label}: poll timeout")
    return None

print("=== EDGE CASES (should all be rejected, no false VERIFIED) ===")
for path, label in [
    ("/tmp/silence_5s.wav", "Digital silence 5s"),
    ("/tmp/noise_5s.wav", "White noise 5s"),
    ("/tmp/tone_3s.wav", "440Hz tone 3s"),
]:
    verify(path, label)
