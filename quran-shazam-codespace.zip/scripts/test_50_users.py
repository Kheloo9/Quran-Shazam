"""50 different users testing Quran Shazam — verify + Q&A + translation.
Each user has a different profile/purpose. Issues logged as feedback.
"""
import http.client, json, time, urllib.parse, urllib.request, os

BASE = "localhost"
PORT = 8000
FEEDBACK = []

def log(user, feature, issue, severity="medium"):
    FEEDBACK.append({"user": user, "feature": feature, "issue": issue, "severity": severity})
    print(f"  ⚠️  User {user} [{feature}]: {issue} ({severity})")

def get(path, timeout=30):
    conn = http.client.HTTPConnection(BASE, PORT, timeout=timeout)
    conn.request("GET", path)
    r = conn.getresponse()
    return r.status, r.read()

def post_json(path, data, timeout=30):
    conn = http.client.HTTPConnection(BASE, PORT, timeout=timeout)
    body = json.dumps(data).encode()
    conn.request("POST", path, body, {"Content-Type": "application/json"})
    r = conn.getresponse()
    return r.status, r.read()

def download_audio(surah, ayah, qari="Alafasy_128kbps"):
    url = f"https://everyayah.com/data/{qari}/{surah:03d}{ayah:03d}.mp3"
    path = f"/tmp/u50_{surah}_{ayah}.mp3"
    if not os.path.exists(path):
        try:
            urllib.request.urlretrieve(url, path)
        except Exception as e:
            return None
    return path

def verify_audio(path, timeout=180):
    boundary = "----U50Test"
    with open(path, "rb") as f:
        data = f.read()
    body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"t.mp3\"\r\n"
            "Content-Type: audio/mpeg\r\n\r\n").encode() + data + f"\r\n--{boundary}--\r\n".encode()
    conn = http.client.HTTPConnection(BASE, PORT, timeout=timeout)
    conn.request("POST", "/api/verify", body,
                 {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = conn.getresponse()
    if r.status != 202:
        return None, f"HTTP {r.status}"
    job_id = json.loads(r.read()).get("job_id")
    for _ in range(25):
        time.sleep(8)
        s, body = get(f"/api/jobs/{job_id}", timeout=30)
        d = json.loads(body)
        if d.get("status") == "done":
            return d.get("result", {}), None
    return None, "timeout"

print("=" * 60)
print("50-USER TESTING — Quran Shazam")
print("=" * 60)

# ============ USERS 1-10: VERIFY (different surahs) ============
verify_tests = [
    (1, "New Muslim", 112, 1, "First surah to memorize"),
    (2, "Hafiz student", 1, 1, "Al-Fatihah daily"),
    (3, "Elderly uncle", 113, 1, "Short surah"),
    (4, "Child learner", 114, 1, "An-Nas"),
    (5, "Imam", 2, 255, "Ayat-ul-Kursi"),
    (6, "University student", 36, 1, "Ya-Sin"),
    (7, "Convert", 55, 1, "Ar-Rahman"),
    (8, "Teacher", 67, 1, "Al-Mulk"),
    (9, "Researcher", 18, 1, "Al-Kahf"),
    (10, "Night reciter", 78, 1, "An-Naba"),
]
print("\n--- USERS 1-10: VERIFY ---")
for uid, profile, s, a, note in verify_tests:
    print(f"User {uid} ({profile}): verifying {s}:{a} ({note})...")
    path = download_audio(s, a)
    if not path:
        log(uid, "verify", f"Could not download test audio for {s}:{a}", "low")
        continue
    result, err = verify_audio(path)
    if err:
        log(uid, "verify", f"Verification failed for {s}:{a}: {err}", "high")
        continue
    transcript = result.get("transcript", "")
    results = result.get("results", [])
    if not transcript.strip():
        log(uid, "verify", f"Empty transcript for {s}:{a}", "high")
    elif not results:
        log(uid, "verify", f"No matches for {s}:{a}, transcript: {transcript[:50]}", "medium")
    else:
        top = results[0]
        print(f"  ✅ {s}:{a} → {top.get('surah')}:{top.get('ayah')} [{top.get('label')}] {top.get('confidence', 0):.0f}%")

# ============ USERS 11-25: Q&A ============
qa_tests = [
    (11, "Curious teen", "What is Surah Al-Ikhlas?"),
    (12, "New Muslim", "How many ayat in Al-Fatihah?"),
    (13, "Student", "What does 2:255 say?"),
    (14, "Researcher", "What does the Quran say about patience?"),
    (15, "Child", "What is the shortest surah?"),
    (16, "Elderly", "Tell me about Surah Rahman"),
    (17, "Teacher", "How many Makki surahs are there?"),
    (18, "Convert", "Show me ayat ul kursi"),
    (19, "Hafiz", "What is the longest surah?"),
    (20, "Scholar", "What does the Quran say about parents?"),
    (21, "Teen", "how many surahs"),
    (22, "Student", "2:2"),
    (23, "Curious", "What is surah 18 about?"),
    (24, "New Muslim", "first surah"),
    (25, "Researcher", "What does Quran say about charity?"),
]
print("\n--- USERS 11-25: Q&A ---")
for uid, profile, q in qa_tests:
    s, body = get("/api/quran/ask?q=" + urllib.parse.quote(q), timeout=15)
    if s != 200:
        log(uid, "qa", f"Q&A failed for '{q}': HTTP {s}", "high")
        continue
    d = json.loads(body)
    dtype = d.get("type", "?")
    if dtype in ("error",) and "No results" in d.get("title", ""):
        log(uid, "qa", f"No results for '{q}'", "low")
    else:
        print(f"  ✅ User {uid} ({profile}): '{q[:35]}' → [{dtype}] {d.get('title', '')[:40]}")

# ============ USERS 26-40: TRANSLATION ============
print("\n--- USERS 26-40: TRANSLATION ---")
trans_tests = [
    (26, 1), (27, 2), (28, 18), (29, 36), (30, 55),
    (31, 67), (32, 78), (33, 112), (34, 113), (35, 114),
    (36, 5), (37, 12), (38, 19), (39, 56), (40, 108),
]
for uid, s in trans_tests:
    st, body = get(f"/api/quran/surah/{s}", timeout=15)
    if st != 200:
        log(uid, "translation", f"Surah {s} failed: HTTP {st}", "high")
        continue
    d = json.loads(body)
    ayahs = d.get("ayahs", [])
    if not ayahs:
        log(uid, "translation", f"Surah {s} has no ayat", "high")
        continue
    bad = 0
    for a in ayahs[:10]:  # check first 10
        if not a.get("arabic", "").strip(): bad += 1
        if not a.get("translation_en", "").strip(): bad += 1
        if not a.get("translation_ur", "").strip(): bad += 1
    if bad > 0:
        log(uid, "translation", f"Surah {s}: {bad} missing fields in first 10 ayat", "medium")
    else:
        print(f"  ✅ User {uid}: Surah {s} translations complete")

# ============ USERS 41-50: EDGE CASES & MIXED ============
print("\n--- USERS 41-50: EDGE CASES ---")
# 41: Very long question
long_q = "What does the Quran say about " + "patience " * 50
s, b = get("/api/quran/ask?q=" + urllib.parse.quote(long_q[:400]), timeout=15)
print(f"  User 41 (long Q): HTTP {s}")
# 42: Special chars
s, b = get("/api/quran/ask?q=" + urllib.parse.quote("What is <script>alert(1)</script>?"), timeout=15)
d = json.loads(b) if s == 200 else {}
if "<script>" in json.dumps(d):
    log(42, "qa", "XSS: script tag reflected in response!", "high")
else:
    print("  ✅ User 42 (XSS test): no reflection")
# 43: Arabic question
s, b = get("/api/quran/ask?q=" + urllib.parse.quote("ما هي أطول سورة؟"), timeout=15)
print(f"  User 43 (Arabic Q): HTTP {s}, type={json.loads(b).get('type') if s==200 else '?'}")
# 44: Search with special chars
s, b = get("/api/quran/search?q=" + urllib.parse.quote("'; DROP TABLE--"), timeout=15)
print(f"  ✅ User 44 (SQLi test): HTTP {s} (no crash)")
# 45: Invalid surah
s, b = get("/api/quran/surah/999", timeout=15)
if s not in (400, 404, 422):
    log(45, "api", f"Invalid surah 999 returned HTTP {s} (expected 4xx)", "medium")
else:
    print(f"  ✅ User 45 (invalid surah): HTTP {s}")
# 46-50: Mixed workflow — search → surah → tafseer → Q&A
for uid in range(46, 51):
    topics = ["mercy", "prayer", "patience", "charity", "faith"]
    topic = topics[uid - 46]
    s, b = get("/api/quran/search?q=" + topic, timeout=15)
    d = json.loads(b) if s == 200 else {}
    results = d.get("results", [])
    if not results:
        log(uid, "workflow", f"Search '{topic}' returned nothing", "medium")
        continue
    ref_s = results[0]["surah"]
    s2, b2 = get(f"/api/quran/surah/{ref_s}", timeout=15)
    d2 = json.loads(b2) if s2 == 200 else {}
    ayahs = d2.get("ayahs", [])
    has_tafseer = any(a.get("tafseer", "").strip() for a in ayahs[:3])
    if not has_tafseer:
        log(uid, "workflow", f"Surah {ref_s} (from '{topic}') has no tafseer", "medium")
    else:
        print(f"  ✅ User {uid} (workflow '{topic}'): search → surah {ref_s} → tafseer OK")

print("\n" + "=" * 60)
print(f"FEEDBACK: {len(FEEDBACK)} issues found")
print("=" * 60)
for f in FEEDBACK:
    print(f"  [{f['severity'].upper()}] User {f['user']} ({f['feature']}): {f['issue']}")

with open("/tmp/50user_feedback.json", "w") as fh:
    json.dump(FEEDBACK, fh, indent=2)
print("\nSaved to /tmp/50user_feedback.json")
