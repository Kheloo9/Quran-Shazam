#!/usr/bin/env python3
"""Golden test set runner — Quran Shazam (2026-10-19, professional audit).

FYP STUDY GUIDE: A "golden test set" is a FIXED list of checks that must pass
before any release. Unlike unit tests (which test code pieces), golden tests
check the RUNNING product end-to-end: real HTTP calls, real responses.
Run with:  python3 scripts/golden_test.py   (server must run on localhost:8000)

Each check prints PASS/FAIL; the scorecard at the end must be 100% green.
If any check fails, do NOT deploy — fix first.
"""
import json
import sys
import urllib.parse
import urllib.request
import urllib.error

BASE = "http://localhost:8000"
TIMEOUT = 25
passed, failed = 0, 0
results = []


def check(name, fn):
    """Run one golden check, record PASS/FAIL, never crash the runner."""
    global passed, failed
    try:
        detail = fn()
        passed += 1
        results.append(("PASS", name, detail or ""))
        print(f"  ✅ PASS  {name}" + (f" — {detail}" if detail else ""))
    except AssertionError as e:
        failed += 1
        results.append(("FAIL", name, str(e)))
        print(f"  ❌ FAIL  {name} — {e}")
    except Exception as e:  # noqa: BLE001 — runner must survive
        failed += 1
        results.append(("ERROR", name, f"{type(e).__name__}: {e}"))
        print(f"  🛑 ERROR {name} — {type(e).__name__}: {e}")


def get(path, headers=None):
    req = urllib.request.Request(BASE + path, headers=headers or {})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return r.status, r.headers.get("Content-Type", ""), r.read()


def get_json(path):
    status, ctype, body = get(path, {"Accept": "application/json"})
    assert status == 200, f"HTTP {status}"
    return json.loads(body)


# ---------------------------------------------------------------- checks
def main():
    print("Quran Shazam — GOLDEN TEST SET")
    print("=" * 50)

    print("\n[health]")
    def _health():
        h = get_json("/api/health")
        _t(h["ready"] is True, "not ready")
        return f"{h['corpus']['verse_count'] if 'corpus' in h and 'verse_count' in h['corpus'] else '?'} verses"
    check("health ready", _health)

    print("\n[quran data]")
    def _surahs():
        _t(len(get_json("/api/quran/surahs")) == 114, "count != 114")
        return "114"
    check("114 surahs listed", _surahs)

    def _s1():
        _t(len(get_json("/api/quran/surah/1")["ayat"]) == 7, "ayat != 7")
        return "7 ayat"
    check("surah 1 has 7 ayat", _s1)

    def _tafseer():
        _t(bool(get_json("/api/quran/tafseer/1/1").get("tafseer_en")), "empty")
        return "EN present"
    check("tafseer on-demand 1:1", _tafseer)

    print("\n[audio]")
    def _audio():
        s, c, b = get("/api/audio/1/1")
        _t(s == 200, f"HTTP {s}")
        _t("audio/mpeg" in c, f"content-type={c}")
        _t(len(b) > 5000, f"too small: {len(b)}")
        return f"{len(b)//1024}KB audio/mpeg"
    check("ayah audio 1:1 → 200 audio/mpeg", _audio)

    def _bad_ayah():
        _http_status("/api/audio/99/99", 400)
        return "400"
    check("invalid ayah rejected (99:99 → 400)", _bad_ayah)

    def _qaris():
        _t(any("Alafasy" in q.get("name", "") for q in get_json("/api/quran/qaris")), "missing")
        return "present"
    check("qaris list has Alafasy default", _qaris)

    print("\n[q&a / search / translate / duas]")
    def _ask():
        d = get_json("/api/quran/ask?question=" + urllib.parse.quote("What is Surah Ikhlas?"))
        _t(bool(d.get("answer")), "empty answer")
        return "answered"
    check("Q&A answers", _ask)

    def _xss():
        d = get_json("/api/quran/ask?question=" + urllib.parse.quote("<script>alert(1)</script>"))
        _t("<script>" not in d.get("answer", ""), "reflected")
        return "clean"
    check("XSS sanitized in ask", _xss)

    def _search():
        _t(len(get_json("/api/quran/search?q=" + urllib.parse.quote("mercy"))) > 0, "none")
        return "hits"
    check("search 'mercy' finds ayat", _search)

    def _translate():
        d = get_json("/api/quran/translate?text=" + urllib.parse.quote("mercy") + "&direction=en-ur")
        _t(d.get("candidates"), "none")
        return "candidates"
    check("translate endpoint live", _translate)

    def _duas():
        _t(all(d.get("reference") for d in get_json("/api/duas")), "missing ref")
        return "all referenced"
    check("duas have references", _duas)

    print("\n[security headers]")
    def _csp():
        req = urllib.request.Request(BASE + "/api/audio/1/1")
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            csp = r.headers.get("Content-Security-Policy", "")
        _t("everyayah.com" in csp, "everyayah missing from media-src")
        return "media-src ok"
    check("CSP allows everyayah fallback", _csp)

    total = passed + failed
    print("\n" + "=" * 50)
    print(f"SCORECARD: {passed}/{total} PASS" + ("  🎉 ALL GREEN — safe to deploy" if failed == 0 else "  ⚠️ FIX FAILURES BEFORE DEPLOY"))
    return 1 if failed else 0


def _t(cond, msg):
    assert cond, msg


def _http_status(path, want):
    try:
        get(path)
        got = 200
    except urllib.error.HTTPError as e:
        got = e.code
    _t(got == want, f"got {got}, want {want}")


if __name__ == "__main__":
    sys.exit(main())
