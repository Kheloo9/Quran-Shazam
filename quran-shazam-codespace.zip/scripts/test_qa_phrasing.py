"""Test that the same question asked different ways gets correct responses."""
import http.client, json, urllib.parse

def ask(q):
    conn = http.client.HTTPConnection("localhost", 8000, timeout=15)
    conn.request("GET", "/api/quran/ask?q=" + urllib.parse.quote(q))
    r = conn.getresponse()
    if r.status != 200:
        return None
    return json.loads(r.read())

def check(group_name, questions, expected_type, expected_check):
    print(f"\n=== {group_name} ===")
    issues = []
    for q in questions:
        d = ask(q)
        if d is None:
            print(f"  ❌ '{q[:40]}' → HTTP error")
            issues.append((q, "HTTP error"))
            continue
        dtype = d.get("type", "?")
        ok = dtype == expected_type and expected_check(d)
        status = "✅" if ok else "❌"
        print(f"  {status} '{q[:40]}' → [{dtype}] {d.get('title', '')[:45]}")
        if not ok:
            issues.append((q, f"got [{dtype}] {d.get('title', '')[:50]}"))
    return issues

all_issues = []

# 1. Surah info — different phrasings should all return surah 112
all_issues += check(
    "Surah Al-Ikhlas (different phrasings)",
    [
        "What is Surah Al-Ikhlas?",
        "Tell me about Surah Ikhlas",
        "surah 112",
        "What is surah number 112?",
        "ikhlas",
        "About Surah Al-Ikhlas",
    ],
    "surah",
    lambda d: d.get("surah_number") == 112,
)

# 2. Ayah lookup — different phrasings should all return 2:255
all_issues += check(
    "Ayat-ul-Kursi (different phrasings)",
    [
        "What does 2:255 say?",
        "Show me 2:255",
        "2:255",
        "ayat ul kursi",
        "Show me Ayat-ul-Kursi",
        "throne verse",
    ],
    "ayah",
    lambda d: "2:255" in d.get("title", ""),
)

# 3. Count questions
all_issues += check(
    "How many ayat (different phrasings)",
    [
        "How many ayat in Al-Baqarah?",
        "How many verses in surah 2?",
        "how many ayah in baqarah",
    ],
    "fact",
    lambda d: "286" in d.get("text", ""),
)

# 4. Topic search
all_issues += check(
    "Topic: patience (different phrasings)",
    [
        "What does the Quran say about patience?",
        "Quran on patience",
        "patience in the Quran",
        "Tell me about patience in Islam",
    ],
    "search",
    lambda d: len(d.get("results", [])) > 0,
)

# 5. Global facts
all_issues += check(
    "Longest surah (different phrasings)",
    [
        "What is the longest surah?",
        "Which surah is the longest?",
        "longest surah in quran",
    ],
    "surah",
    lambda d: d.get("surah_number") == 2,
)

print("\n" + "=" * 50)
print(f"TOTAL ISSUES: {len(all_issues)}")
for q, issue in all_issues:
    print(f"  - '{q[:50]}': {issue}")

with open("/tmp/qa_phrasing_issues.json", "w") as f:
    json.dump([{"q": q, "issue": i} for q, i in all_issues], f, indent=2)
