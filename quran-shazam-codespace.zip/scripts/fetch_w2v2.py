"""Resumable chunk downloader for the wav2vec2-base weights.

The sandbox kills long background downloads after a few minutes, so this
script downloads the big weights file in 8MB chunks with HTTP Range,
appending to a .part file. Re-run it as often as needed — it resumes
where it left off. When complete, it renames to the final filename.

Usage: python scripts/fetch_w2v2.py
"""
import os
import sys
import urllib.request

# facebook/wav2vec2-base weights (safetensors, ~360MB)
URL = ("https://huggingface.co/facebook/wav2vec2-base/"
       "resolve/main/pytorch_model.bin")
DEST_DIR = os.path.expanduser(
    "~/workspace/quran-shazam/backend/data/models/wav2vec2-base")
DEST = os.path.join(DEST_DIR, "pytorch_model.bin")
PART = DEST + ".part"
CHUNK = 8 * 1024 * 1024


def total_size():
    req = urllib.request.Request(URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=30) as r:
        return int(r.headers["Content-Length"])


def main():
    os.makedirs(DEST_DIR, exist_ok=True)
    if os.path.exists(DEST):
        print(f"ALREADY COMPLETE: {DEST} ({os.path.getsize(DEST)} bytes)")
        return 0
    total = total_size()
    have = os.path.getsize(PART) if os.path.exists(PART) else 0
    print(f"total={total} have={have} remaining={total - have}")
    if have >= total > 0:
        os.rename(PART, DEST)
        print("COMPLETE (renamed)")
        return 0
    # Download in chunks; stop after ~150s so the sandbox never kills us
    # mid-chunk (each chunk is independent anyway).
    import time
    t0 = time.time()
    while have < total and time.time() - t0 < 150:
        end = min(have + CHUNK - 1, total - 1)
        req = urllib.request.Request(URL, headers={"Range": f"bytes={have}-{end}"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                data = r.read()
        except Exception as exc:
            print(f"chunk failed at {have}: {exc}; resume next run")
            return 2
        if not data:
            print("empty chunk; resume next run")
            return 2
        with open(PART, "ab") as f:
            f.write(data)
        have += len(data)
        print(f"  +{len(data)//1024//1024}MB -> {have}/{total} "
              f"({100*have/total:.1f}%)", flush=True)
    if have >= total:
        os.rename(PART, DEST)
        print("COMPLETE")
        return 0
    print(f"paused at {100*have/total:.1f}% — re-run to continue")
    return 3


if __name__ == "__main__":
    sys.exit(main())
