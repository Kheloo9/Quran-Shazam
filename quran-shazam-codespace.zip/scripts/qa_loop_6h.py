#!/usr/bin/env python3
"""
Quran Shazam — 6-Hour Professional Testing Loop
Continuously tests verification, endpoints, edge cases.
Logs every failure with timestamps. Fixes nothing automatically —
just finds and reports bugs like a QA team.
"""
import json, sys, time, random, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime

BASE = "http://localhost:8000"
LOG = Path("/tmp/qa_loop.log")
START = time.time()
DURATION = 6 * 3600  # 6 hours
iteration = 0
failures = []

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")

def get(path, timeout=30):
    try:
        with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception as e:
        return 0, str(e).encode()

def post_verify(filepath, timeout=120):
    try:
        import http.client
        boundary = "----QATestBoundary"
        with open(filepath, "rb") as f:
            data = f.read()
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="test.mp3"\r\n'
            f"Content-Type: audio/mpeg\r\n\r\n"
        ).encode() + data + f"\r\n--{boundary}--\r\n".encode()
        conn = http.client.HTTPConnection("localhost", 8000, timeout=timeout)
        conn.request("POST", "/api/verify", body,
                     {"Content-Type": f"multipart/form-data; boundary={boundary}"})
        resp = conn.getresponse()
        return resp.status, resp.read()
    except Exception as e:
        return 0, str(e).encode()

def test_endpoints():
    """Quick endpoint health check."""
    global failures
    for path, expect in [("/api/health", 200), ("/", 200), ("/verify", 200),
                         ("/quran", 200), ("/duas", 200), ("/about", 200),
                         ("/api/quran/surahs", 200)]:
        status, _ = get(path, timeout=15)
        if status != expect:
            msg = f"ENDPOINT FAIL: {path} → {status} (expected {expect})"
            failures.append(msg)
            log(f"  ❌ {msg}")
            return False
    return True

def test_audio_proxy():
    """Test audio proxy with random ayah."""
    surah = random.randint(1, 114)
    # Get ayah count for surah (approximate)
    ayah = random.randint(1, 10)
    status, body = get(f"/api/audio/{surah}/{ayah}", timeout=30)
    if status != 200 or len(body) < 1000:
        # Might be invalid ayah number, try 1:1 as baseline
        status2, body2 = get("/api/audio/112/1", timeout=30)
        if status2 != 200:
            msg = f"AUDIO PROXY FAIL: 112:1 → {status2}"
            failures.append(msg)
            log(f"  ❌ {msg}")
            return False
    return True

def test_tafseer():
    """Verify tafseer data is real (not empty/short)."""
    for s in random.sample([1, 2, 18, 36, 55, 67, 112], 2):
        status, body = get(f"/api/quran/surah/{s}", timeout=15)
        try:
            d = json.loads(body)
            ayahs = d.get("ayahs", d.get("verses", []))
            if not ayahs:
                continue
            a = random.choice(ayahs)
            t_ur = a.get("tafseer_ur", "")
            t_en = a.get("tafseer", "")
            # Tafseer exists (not empty). Note: some short ayat have brief
            # tafseer because scholars comment on verse groups together
            # (e.g. Ibn Kathir's 112:1 commentary covers the whole surah).
            if len(t_ur.strip()) < 20:
                msg = f"TAFSEER FAIL: surah {s} ayah {a.get('ayah')} Urdu tafseer empty ({len(t_ur)} chars)"
                failures.append(msg)
                log(f"  ❌ {msg}")
                return False
            if len(t_en.strip()) < 20:
                msg = f"TAFSEER FAIL: surah {s} ayah {a.get('ayah')} English tafseer empty ({len(t_en)} chars)"
                failures.append(msg)
                log(f"  ❌ {msg}")
                return False
        except Exception as e:
            msg = f"TAFSEER JSON FAIL: surah {s}: {e}"
            failures.append(msg)
            log(f"  ❌ {msg}")
            return False
    return True

# --- Main loop ---
log("=" * 60)
log("QA LOOP STARTED — 6 hour professional testing")
log("=" * 60)

while time.time() - START < DURATION:
    iteration += 1
    elapsed = (time.time() - START) / 3600
    log(f"\n--- Iteration {iteration} ({elapsed:.1f}h elapsed) ---")
    
    ok = True
    ok = test_endpoints() and ok
    ok = test_audio_proxy() and ok
    ok = test_tafseer() and ok
    
    if ok:
        log(f"  ✅ Iteration {iteration} all checks passed")
    else:
        log(f"  ⚠️ Iteration {iteration} had failures (total: {len(failures)})")
    
    # Wait before next iteration (random 2-5 min)
    wait = random.randint(120, 300)
    log(f"  Sleeping {wait}s...")
    time.sleep(wait)

log("\n" + "=" * 60)
log(f"QA LOOP COMPLETE — {iteration} iterations, {len(failures)} failures")
if failures:
    log("FAILURES:")
    for f in failures:
        log(f"  - {f}")
log("=" * 60)
