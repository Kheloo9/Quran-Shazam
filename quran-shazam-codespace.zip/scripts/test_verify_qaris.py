"""Test verification: different qaris + lengths."""
import http.client, json, time

def verify(path, label, expected=None):
    boundary = "----QariTest"
    with open(path, "rb") as f:
        data = f.read()
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="t.mp3"\r\n'
            'Content-Type: audio/mpeg\r\n\r\n').encode() + data + f'\r\n--{boundary}--\r\n'.encode()
    conn = http.client.HTTPConnection("localhost", 8000, timeout=120)
    conn.request("POST", "/api/verify", body,
                 {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    r = conn.getresponse()
    if r.status != 202:
        print(f"  ❌ {label}: Upload HTTP {r.status}")
        return False
    job_id = json.loads(r.read()).get("job_id")
    for _ in range(20):
        time.sleep(10)
        c2 = http.client.HTTPConnection("localhost", 8000, timeout=30)
        c2.request("GET", f"/api/jobs/{job_id}")
        d = json.loads(c2.getresponse().read())
        if d.get("status") in ("done", "error"):
            if d.get("status") == "error":
                print(f"  ⚠️  {label}: rejected ({d.get('error', '?')[:60]})")
                return None
            res = d.get("result", {})
            results = res.get("results", [])
            top = results[0] if results else {}
            match = f"{top.get('surah')}:{top.get('ayah')}"
            ok = (expected is None) or (match == expected)
            print(f"  {'✅' if ok else '❌'} {label}: {match} [{top.get('label', '?')}] {top.get('confidence', 0):.0f}%")
            return ok
    print(f"  ❌ {label}: poll timeout")
    return False

print("=== QARI TESTS (all 112:1) ===")
for path, label in [
    ("/tmp/qari_Husary.mp3", "Husary 128k"),
    ("/tmp/qari_Husary64.mp3", "Husary 64k"),
    ("/tmp/qari_Basfar.mp3", "Basfar 192k"),
]:
    verify(path, label, "112:1")
