#!/usr/bin/env python3
"""QA harness: end-to-end verification of diverse samples.

For each sample it runs the FULL pipeline (decode -> faster-whisper ASR ->
Quran matching) and reports:
  * which ayat were identified vs expected (accuracy)
  * labels / confidence honesty
  * RTF and wall time (slowness detection)
  * any errors / tracebacks

Usage:
    python scripts/qa_test.py --models-dir /path/to/models [--sample t1]
"""
from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.engine.service import VerificationService

# (file, expected "surah:first-last", qari, note)
SAMPLES = [
    ("t1_alafasy_112.mp3",  "112:1-4",   "Alafasy",     "short, clean studio"),
    ("t2_basit_112.mp3",    "112:1-4",   "Abdul Basit", "short, different qari, egyptian style"),
    ("t3_minshawi_114.mp3", "114:1-6",   "Minshawi",    "short, different qari"),
    ("t4_husary_113.mp3",   "113:1-5",   "Husary",      "short, different qari"),
    ("t5_alafasy_yasin20.mp3", "36:1-20","Alafasy",     "medium 4.2 min"),
    ("t6_alafasy_rahman78.mp3", "55:1-78", "Alafasy",   "LONG 11.4 min stress"),
]

QA_DIR = Path("/tmp/bench/qa")


def expected_keys(spec: str) -> set[str]:
    surah, rng = spec.split(":")
    a, b = rng.split("-")
    return {f"{surah}:{i}" for i in range(int(a), int(b) + 1)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models-dir", default=None)
    ap.add_argument("--sample", default=None, help="run only this sample file")
    ap.add_argument("--data-dir", default="backend/data")
    args = ap.parse_args()

    print("== warming up service ==")
    svc = VerificationService(Path(args.data_dir))
    assert svc.corpus.ready, "corpus not ready"
    # Warm the ASR model once so sample timings are pure transcription.
    t0 = time.perf_counter()
    svc.asr._load()
    print(f"model loaded in {time.perf_counter()-t0:.1f}s "
          f"({svc.asr.device}/{svc.asr.compute_type})")

    samples = [s for s in SAMPLES if not args.sample or s[0] == args.sample]
    report: list[dict] = []
    for fname, spec, qari, note in samples:
        path = QA_DIR / fname
        exp = expected_keys(spec)
        print(f"\n{'='*70}\nSAMPLE {fname}  expected={spec}  qari={qari}  ({note})")
        t0 = time.perf_counter()
        try:
            r = svc.verify(path, request_id=f"qa-{fname}")
        except Exception:
            print("ERROR:\n" + traceback.format_exc())
            report.append({"sample": fname, "error": traceback.format_exc(limit=3)})
            continue
        wall = time.perf_counter() - t0
        got = {m["key"]: m for m in r["results"]}
        verified = {k for k, m in got.items() if m["label"] == "VERIFIED TEXT MATCH"}
        good = {k for k, m in got.items() if "GOOD" in m["label"] or "POSSIBLE" in m["label"]}
        wrong = {k for k in got if k not in exp and "RECOVERY" not in got[k]["label"]}
        missing = exp - set(got)
        rtf = r["processing_seconds"] / r["duration"] if r["duration"] else 0
        print(f"identified: {len(got)}  verified: {len(verified & exp)}  "
              f"good/possible: {len(good & exp)}")
        print(f"missing: {sorted(missing)[:12]}{'...' if len(missing)>12 else ''}")
        print(f"wrong-surah hits: {sorted(wrong)[:8]}")
        print(f"duration={r['duration']}s wall={wall:.1f}s realtime={r['realtime']}x RTF={rtf:.3f}")
        print(f"coverage={r['coverage']}% words={r['recognized_words']}")
        for m in r["results"][:14]:
            flag = "✓" if m["key"] in exp else "?"
            print(f"  {flag} {m['key']:>8} {m['label'][:28]:28} conf={m['confidence']}")
        report.append({
            "sample": fname, "expected": spec,
            "verified": len(verified & exp), "good": len(good & exp),
            "missing": len(missing), "wrong": len(wrong),
            "rtf": round(rtf, 3), "wall": round(wall, 1),
            "coverage": r["coverage"],
        })

    print(f"\n{'='*70}\nQA SUMMARY")
    for r in report:
        if "error" in r:
            print(f"  {r['sample']}: ERROR")
        else:
            print(f"  {r['sample']}: verified {r['verified']} + good {r['good']} "
                  f"| missing {r['missing']} wrong {r['wrong']} "
                  f"| RTF {r['rtf']} wall {r['wall']}s coverage {r['coverage']}%")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
