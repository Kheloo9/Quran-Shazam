"""Stage 3 experiment: do SHORT per-candidate prompts help hard clips?

ADR-0003 proved FULL-SURAH initial_prompts HURT (guided 2/7 vs unguided
7/7 ayat — the prompt makes Whisper hallucinate). This experiment asks
the narrower question: does a SHORT prompt (first ~8 words of the
candidate ayah) rescue a hard clip WITHOUT hallucinating?

Design (honest, with a control):
  - Hard clips: clips that previously got NO-MATCH / LOW.
  - For each clip: transcribe (a) no prompt, (b) short TRUE prompt
    (first 8 words of the true ayah), (c) short WRONG prompt (first 8
    words of a DIFFERENT ayah) — the anti-hallucination control.
  - Success = (b) recovers the ayah AND (c) does NOT produce the wrong
    ayah's words. If (c) hallucinates, short prompts are unsafe.

Usage: python scripts/test_short_prompt.py  (needs local Whisper model)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.engine.asr import QuranASR  # noqa: E402
from app.engine.media import decode_to_mono16k  # noqa: E402
from app.engine.normalization import normalize_arabic  # noqa: E402

DATA = Path(__file__).resolve().parents[1] / "backend" / "data"
CLIPS = Path.home() / "workspace/campaign20/clips"

# (clip, true ayah key, true ayah first-8-words prompt)
CASES = [
    ("hus_fatihah_003.mp3", "1:3", "الرحمن الرحيم مالك يوم الدين"),
    ("falaq_noisy.mp3", "113:1", "قل أعوذ برب الفلق"),
    ("asr_fast.mp3", "103:1", "والعصر إن الإنسان لفي خسر"),
]
WRONG_PROMPT = "قل هو الله أحد الله الصمد"  # 112:1-2 — control


def run(asr, clip, prompt):
    audio, sr = decode_to_mono16k(CLIPS / clip, 600)
    out = asr.transcribe_array(audio, sr, initial_prompt=prompt)
    return normalize_arabic(out["text"])


def main():
    asr = QuranASR(DATA / "models")
    print("== Stage 3 short-prompt experiment ==\n")
    for clip, key, true_prompt in CASES:
        t_none = run(asr, clip, None)
        t_true = run(asr, clip, true_prompt)
        t_wrong = run(asr, clip, WRONG_PROMPT)
        print(f"--- {clip} (true {key}) ---")
        print(f"  no prompt   ({len(t_none.split())}w): {t_none[:90]}")
        print(f"  true prompt ({len(t_true.split())}w): {t_true[:90]}")
        print(f"  WRONG prompt({len(t_wrong.split())}w): {t_wrong[:90]}")
        hallu = "احد" in t_wrong or "الصمد" in t_wrong
        print(f"  control hallucinated wrong ayah: {hallu}\n")


if __name__ == "__main__":
    main()
