#!/usr/bin/env python3
"""Pre-convert the Whisper model to CTranslate2 format.

Used at Docker build time so the first container start doesn't pay the
conversion cost. Safe to run multiple times (cached).

Usage:
    python scripts/convert_model.py --models-dir backend/data/models
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.engine.asr import QuranASR  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--models-dir", required=True)
    args = ap.parse_args()
    asr = QuranASR(Path(args.models_dir))
    # _load() converts (if needed) and loads; loading also validates the model.
    asr._load()
    print(f"OK: {asr.model_id} device={asr.device} compute={asr.compute_type}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
