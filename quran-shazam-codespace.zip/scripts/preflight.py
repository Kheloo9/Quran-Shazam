#!/usr/bin/env python3
"""Preflight checks before starting Quran Shazam.

Verifies: Python version, FFmpeg on PATH, required packages importable,
disk space for model+corpus, port free, corpus URL reachable.
Exit 0 = ready, exit 1 = problems found (listed).
"""
from __future__ import annotations

import shutil
import socket
import sys
import urllib.request

MIN_PYTHON = (3, 11)
REQUIRED_PACKAGES = ["fastapi", "uvicorn", "jinja2", "numpy", "soundfile", "requests", "slowapi"]
CORPUS_URL = "https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json"
PORT = 8000
MIN_DISK_GB = 4.0

problems: list[str] = []
ok: list[str] = []


def check(name: str, fn):
    try:
        detail = fn()
    except Exception as exc:  # noqa: BLE001 - we want the message
        problems.append(f"{name}: {exc}")
    else:
        ok.append(f"{name}: {detail}")


def check_python():
    if sys.version_info < MIN_PYTHON:
        raise RuntimeError(f"Python {'.'.join(map(str, MIN_PYTHON))}+ required, found {sys.version.split()[0]}")
    return sys.version.split()[0]


def check_ffmpeg():
    if not shutil.which("ffmpeg"):
        raise RuntimeError("ffmpeg not found on PATH (https://ffmpeg.org/download.html)")
    return shutil.which("ffmpeg")


def check_packages():
    missing = []
    for pkg in REQUIRED_PACKAGES:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        raise RuntimeError(f"missing packages: {', '.join(missing)} (run: pip install -r requirements.txt)")
    return f"{len(REQUIRED_PACKAGES)} packages present"


def check_disk():
    free_gb = shutil.disk_usage(".").free / (1024 ** 3)
    if free_gb < MIN_DISK_GB:
        raise RuntimeError(f"only {free_gb:.1f} GB free; {MIN_DISK_GB:.0f} GB recommended (model + corpus)")
    return f"{free_gb:.1f} GB free"


def check_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(("127.0.0.1", PORT)) == 0:
            raise RuntimeError(f"port {PORT} is already in use")
    return f"port {PORT} free"


def check_corpus_url():
    req = urllib.request.Request(CORPUS_URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=15) as r:
        if r.status != 200:
            raise RuntimeError(f"HTTP {r.status}")
    return "reachable"


check("python", check_python)
check("ffmpeg", check_ffmpeg)
check("packages", check_packages)
check("disk", check_disk)
check("port", check_port)
check("corpus-url", check_corpus_url)

print("== Quran Shazam preflight ==")
for line in ok:
    print(f"  [OK] {line}")
for line in problems:
    print(f"  [FAIL] {line}")
if problems:
    print(f"\n{len(problems)} problem(s) found. Fix them, then run preflight again.")
    sys.exit(1)
print("\nAll checks passed. Start with:  ./scripts/start.sh   (or start.bat on Windows)")
