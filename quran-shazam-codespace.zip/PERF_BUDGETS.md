# Performance Budgets — Quran Shazam

A **performance budget** is a promise: *"this endpoint answers within X seconds
for slow-but-normal conditions."* Professional teams set them so a slowdown is
treated as a **bug** (logged, investigated) instead of being discovered by an
unhappy user.

## The budgets

| Key | Endpoint | Budget | Why this number |
|-----|----------|--------|-----------------|
| `surah_load` | `GET /api/quran/surah/{n}` | 2.0 s | Largest surah (Al-Baqarah) measured 0.265 s; 2 s leaves 7x headroom |
| `tafseer` | `GET /api/quran/tafseer/{s}/{a}` | 1.0 s | Single JSON lookup; anything slower means disk/IO trouble |
| `audio_start` | `GET /api/audio/{s}/{a}` (first byte) | 5.0 s | Proxy fetch of a ~100 KB MP3; mobile networks need slack |
| `translate` | `GET /api/quran/translate` | 3.0 s | In-memory IDF ranking over 6,236 ayat; CPU-bound but small |
| `qa` | `POST /api/ask` | 10.0 s | Rule-based Q&A, no model inference; 10 s is generous |
| `verify_single_ayah` | verify job `processing_seconds` | 30.0 s | One ayah ≈ 15 s audio ≈ ~7 s ASR + matching; 30 s is 4x headroom |

Defined in `backend/app/engine/config.py` → `settings.perf_budgets`.
Visible in `GET /api/health` → `perf_budgets`.

## How they are enforced (log-only, never blocking)

`PerfBudgetMiddleware` (`backend/app/security.py`) times every request and, when
the path matches a budgeted prefix and the elapsed time passes the budget, logs:

```
perf_budget_exceeded path=/api/quran/surah/2 elapsed=8.31s budget=2.0s
```

It **never** blocks, retries, or alters the response — punishing the user for
our slowness would be wrong. The log line is the tripwire: during testing or
production monitoring, `perf_budget_exceeded` entries are investigated like bugs.

The verify pipeline is async (202 + polling), so its budget is checked against
`processing_seconds` in the job result instead of request time.

## For the FYP viva

If the examiner asks *"how do you know it stays fast?"*: point here. Budgets +
log-only enforcement + the `X-Response-Time` header on every response (added by
`RequestIdMiddleware`) = a professional performance story with almost no code.
